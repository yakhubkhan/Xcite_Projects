import React from 'react'
import { ContentBlockImageItemComponentType } from '../../../types/content/component'
import Heading from '../../atoms/Heading'
import { HeadingEnum } from '../../../types/content'
import MarkDown from '../../atoms/MarkDown'
import Image from '../../atoms/Image'

const ContentBlockImageItem: React.FunctionComponent<ContentBlockImageItemComponentType> =
  ({ heading, text, image, imageFirst }) => {
    return (
      <div className="sm:flex sm:gap-5 mb-10 sm:mb-20 last:mb-0 sm:items-center justify-center">
        {image && (
          <div
            className={`mb-6 sm:mb-0 sm:w-1/2 ${
              imageFirst ? 'sm:order-1' : 'sm:order-2'
            }`}
          >
            <Image
              src={image.src}
              alt={image.alt}
              layout="responsive"
              width={630}
              height={358}
              objectFit="cover"
            />
          </div>
        )}
        {text && (
          <div
            className={`px-5 sm:px-0 sm:w-1/2 h-fit ${
              imageFirst ? 'sm:order-2 sm:pl-9' : 'sm:pr-9 sm:order-1'
            } ${image ? '' : 'text-center'}`}
          >
            <Heading type={HeadingEnum.h2} className="mb-4 last:mb-0">
              {heading}
            </Heading>
            {text && <MarkDown>{text}</MarkDown>}
          </div>
        )}
      </div>
    )
  }
export default ContentBlockImageItem
