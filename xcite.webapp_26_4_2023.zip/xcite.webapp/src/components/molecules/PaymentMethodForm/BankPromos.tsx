import { useTranslation } from 'next-i18next'
import React, { useState } from 'react'
import {
    ButtonVariantEnum,
} from '../../../types/content'
import Button from '../../atoms/Button'
import Promolist from '../../organisms/Promolist'
import styles from './Payment.module.css'

interface Props {
    promoTitle?: string
    key?: string
    promoUrl?: string
    offerHeading?: string
    offerDetails?: string
    termsHeading?: string
    termsDetails?: string

}

const BankPromos = ({
    promoTitle,
    key,
    promoUrl,
    offerHeading,
    offerDetails,
    termsHeading,
    termsDetails,
}: Props): JSX.Element => {
    const { t } = useTranslation()
    const [storeModal, setStoreModal] = useState(false)
    const handleModal = () => {
        setStoreModal(true)
    }

    return (
        <li key={'pm' + key}>
            <div className="flex flex-1 gap-3 typography-small items-center">
                <img src={promoUrl} alt='' width={80} />
                <span className={`flex-1 ${styles.title}`}>{promoTitle}</span>
                <Button
                    variant={ButtonVariantEnum.textLink}
                    className="block"
                    onClick={handleModal}

                >
                    {t('see_more')}
                </Button>
            </div>
            {storeModal && (
                <Promolist
                    promoHeading={offerHeading}
                    promoDetail={offerDetails}
                    termHeading={termsHeading}
                    termDetail={termsDetails}
                    onCloseModal={() => setStoreModal(false)}
                    onConfirmModalClose={() => setStoreModal(false)}
                />
            )}
        </li>
  )
}

export default BankPromos
