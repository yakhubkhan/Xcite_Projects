import { useRouter } from 'next/router'
import React, { ReactNode, useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import {
  cartMessagesSelector,
  verifyCartThunk,
} from '../../../redux/slices/cart'
import { userProfileSelector } from '../../../redux/slices/profile'
import CartBulletin from '../CartBulletin'

type Props = {
  children: ReactNode
}

const VerifyCartWrapper = ({ children }: Props): JSX.Element => {
  const router = useRouter()

  const dispatch = useDispatch()

  const cartMessages = useSelector(cartMessagesSelector)
  const user = useSelector(userProfileSelector)

  const [isCartVerified, setIsCartVerified] = useState(false)

  const {
    iso_639_1: language,
    hreflang,
    country: { ctStore: store },
  } = localesFactory.createFromHrefLang(router.locale).current

  useEffect(() => {
    if (user.id && !isCartVerified) {
      const deliveryConfrim =
        children &&
        children[0].props?.children?.props?.segments.findIndex(
          (x: any) => x.value === ('Delivery' || 'التوصيل')
        )
      const isCallingFromDelivery = !deliveryConfrim
        ? false
        : deliveryConfrim != -1
        ? true
        : false
      dispatch(
        verifyCartThunk({
          user,
          store,
          language,
          locale: hreflang,
          callingFromDelivery: isCallingFromDelivery,
        })
      )
      setIsCartVerified(true)
    }
  }, [dispatch, hreflang, language, store, user, isCartVerified])

  return (
    <>
      {!!cartMessages.length && (
        <div className="col-span-full mb-8 md:mb-10 md:col-start-2 md:col-span-10">
          <CartBulletin cartMessages={cartMessages} />
        </div>
      )}
      {children}
    </>
  )
}

export default VerifyCartWrapper
