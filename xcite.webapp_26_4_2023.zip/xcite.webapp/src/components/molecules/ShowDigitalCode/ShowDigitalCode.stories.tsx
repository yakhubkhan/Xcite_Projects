import React from 'react'
import { Meta, Story } from '@storybook/react'
import { ShowDigitalCodeComponentType } from '../../../types/content/component'
import ShowDigitalCode from './ShowDigitalCode'

export default {
  title: 'Components/molecules/ShowDigitalCode',
  component: ShowDigitalCode,
} as Meta

const Template: Story<ShowDigitalCodeComponentType> = (args) => (
  <ShowDigitalCode {...args} />
)

export const Default = Template.bind({})

Default.args = {
  txnId: 'CT11135-847',
  sku: '625711',
}
