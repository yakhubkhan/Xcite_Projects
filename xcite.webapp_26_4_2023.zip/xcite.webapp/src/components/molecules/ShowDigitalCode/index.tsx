export { default } from './ShowDigitalCode'
