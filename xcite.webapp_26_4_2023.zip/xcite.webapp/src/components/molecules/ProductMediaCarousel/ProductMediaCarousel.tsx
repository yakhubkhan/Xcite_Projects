import React from 'react'
import { ProductMediaCarouselProps } from '../../../types/content'
import Carousel from '../../atoms/Carousel'
import Modal from '../../atoms/Modal'

export default function ProductMediaCarousel({
  pItems,
  carouselCurrItem,
  handleModal,
}: ProductMediaCarouselProps): JSX.Element {
  return (
    <Modal
      className="fixed inset-0 bg-gray-200 h-full w-full"
      extraCloseClasses="bg-gray-200"
      handleModal={handleModal}
      extraCloseBtnClasses="p-5"
    >
      <Carousel
        pItems={pItems}
        carouselCurrItem={carouselCurrItem}
        numDotsToShow={7}
        isCircular={false}
      ></Carousel>
    </Modal>
  )
}
