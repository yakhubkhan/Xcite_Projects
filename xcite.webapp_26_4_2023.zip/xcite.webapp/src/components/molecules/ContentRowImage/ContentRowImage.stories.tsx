import React from 'react'
import { Meta, Story } from '@storybook/react'
import { ContentRowImageBlocks } from '../../../types/content/component'
import ContentRowImage from './ContentRowImage'

export default {
  title: 'Components/molecules/ContentRowImage',
  component: ContentRowImage,
} as Meta

const Template: Story<ContentRowImageBlocks> = (args) => (
  <ContentRowImage {...args} />
)

export const FourItemsWithVariants = Template.bind({})
export const ThreeItems = Template.bind({})
export const TwoItems = Template.bind({})
export const OneItem = Template.bind({})

FourItemsWithVariants.args = {
  imageBlocks: [
    {
      image: {
        src: 'https://cdn.media.amplience.net/i/alghanim/product-description-1',
        alt: 'Alt text',
        type: 'img',
      },
    },
    {
      image: {
        src: 'https://cdn.media.amplience.net/i/alghanim/flower',
        alt: 'Alt text',
        type: 'img',
      },
      link: {
        url: '#',
      },
    },
    {
      image: {
        src: 'https://cdn.media.amplience.net/i/alghanim/flower',
        alt: 'Alt text',
        type: 'img',
      },
      link: {
        url: '#',
      },
    },
    {
      image: {
        src: 'https://cdn.media.amplience.net/i/alghanim/product-description-1',
        alt: 'Alt text',
        type: 'img',
      },
    },
  ],
}

ThreeItems.args = {
  imageBlocks: [
    {
      image: {
        src: 'https://cdn.media.amplience.net/i/alghanim/product-description-1',
        alt: 'Alt text',
        type: 'img',
      },
      link: {
        url: '#',
      },
    },
    {
      image: {
        src: 'https://cdn.media.amplience.net/i/alghanim/flower',
        alt: 'Alt text',
        type: 'img',
      },
      link: {
        url: '#',
      },
    },
    {
      image: {
        src: 'https://cdn.media.amplience.net/i/alghanim/flower',
        alt: 'Alt text',
        type: 'img',
      },
      link: {
        url: '#',
      },
    },
  ],
}

TwoItems.args = {
  imageBlocks: [
    {
      image: {
        src: 'https://cdn.media.amplience.net/i/alghanim/product-description-1',
        alt: 'Alt text',
        type: 'img',
      },
      link: {
        url: '#',
      },
    },
    {
      image: {
        src: 'https://cdn.media.amplience.net/i/alghanim/flower',
        alt: 'Alt text',
        type: 'img',
      },
      link: {
        url: '#',
      },
    },
  ],
}

OneItem.args = {
  imageBlocks: [
    {
      image: {
        src: 'https://cdn.media.amplience.net/i/alghanim/product-description-1',
        alt: 'Alt text',
        type: 'img',
      },
      link: {
        url: '#',
      },
    },
  ],
}
