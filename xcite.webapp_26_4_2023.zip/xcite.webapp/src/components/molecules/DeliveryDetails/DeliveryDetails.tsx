import { DeliveryMethodType } from '../../../types/content'
import {
  ClickAndCollect,
  DeliveryExpressIcon,
  DeliveryRegularIcon,
  DeliverySuperExpressIcon,
} from '../../atoms/Icon'

const DeliveryDetails: (method: DeliveryMethodType) => {
  icon: (props: React.SVGProps<SVGSVGElement>) => JSX.Element
  surcharge: string | null
  translationKey: string
} | null = (method: DeliveryMethodType) => {
  /** @todo create utility function formatPrice(hrefLang) **/
  const surcharge = method.surcharge
    ? `+${method.surcharge.formattedPrice} `
    : null
  switch (method.name) {
    case 'FreeDelivery':
      return {
        icon: DeliveryRegularIcon,
        translationKey: 'deliveryMethod_oneTwoDays',
        surcharge,
      }
    case '3-Hours-Express':
      return {
        icon: DeliveryExpressIcon,
        translationKey: 'deliveryMethod_threeHoursExpress',
        surcharge,
      }
    case '2-Hours-Express':
      return {
        icon: DeliverySuperExpressIcon,
        translationKey: 'deliveryMethod_twoHoursExpress',
        surcharge,
      }
    case '1-Hour-Express':
      return {
        icon: DeliverySuperExpressIcon,
        translationKey: 'deliveryMethod_oneHourExpress',
        surcharge,
      }
    case 'ClickAndCollect':
      return {
        icon: ClickAndCollect,
        translationKey: 'deliveryMethod_clickAndCollect',
        surcharge,
      }
    case 'ScheduledDelivery':
      return {
        icon: DeliveryRegularIcon,
        translationKey: 'deliveryMethod_scheduledDelivery',
        surcharge,
      }

    default:
      return null
  }
}

export default DeliveryDetails
