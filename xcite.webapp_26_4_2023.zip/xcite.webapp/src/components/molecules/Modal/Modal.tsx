import React, { FC, ReactPortal, useEffect } from 'react'
import ReactDOM from 'react-dom'

import { CloseIconSmall } from '../../atoms/Icon'
import Grid from '../../atoms/Grid'
import BackButton from '../BackButton'

import styles from './Modal.module.css'

export type Props = {
  children: React.ReactNode
  isShowing: boolean
  hide: () => void
  onBackClicked?: () => void
  backButton?: boolean
}

const ModalHeader: FC<{
  hide: () => void
  onBackClicked?: () => void
  backButton?: boolean
}> = (props) => {
  return (
    <div
      className={`flex mb-6 sm:mb-8 px-5 sm:px-10 items-center ${
        props.backButton && props.onBackClicked
          ? 'justify-between'
          : 'justify-end'
      }`}
    >
      {props.backButton && props.onBackClicked && (
        <BackButton onClick={props.onBackClicked} />
      )}
      <button type="button" onClick={props.hide} className="self-end">
        <CloseIconSmall className="w-5 h-5 text-primary-700 stroke-current" />
      </button>
    </div>
  )
}

const Modal = (props: Props): ReactPortal | null => {
  useEffect(() => {
    if (props.isShowing) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = 'unset'
    }
    return () => {
      document.body.style.overflow = 'unset'
    }
  }, [props.isShowing])

  return props.isShowing
    ? ReactDOM.createPortal(
        <div className="fixed top-0 left-0 right-0 bottom-0 z-40 flex items-end sm:items-start">
          <div
            className="absolute h-full w-full opacity-40 bg-gray-900"
            onClick={props.hide}
          ></div>
          <Grid className={styles.wrapper}>
            <div className={styles.modalBody}>
              <div className="bg-white rounded-t-lg pt-8 pb-15 max-h-full overflow-y-scroll sm:rounded-lg">
                <ModalHeader
                  backButton={props.backButton}
                  onBackClicked={props.onBackClicked}
                  hide={props.hide}
                />
                {props.children}
              </div>
            </div>
          </Grid>
        </div>,
        document.body
      )
    : null
}

export default Modal
