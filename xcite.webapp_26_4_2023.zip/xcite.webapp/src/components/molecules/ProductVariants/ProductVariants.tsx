import React from 'react'
import {
  ProductOptionType,
  ProductSelectVariantType,
} from '../../../types/content'
import { CircularBadge, RectangularBadge } from '../../atoms/Badge'

const selectedDimensionValue = (options: ProductOptionType[]) => {
  return options.find((option) => option.selected)?.value.label
}

const ProductVariants = ({
  options,
}: {
  options: ProductSelectVariantType[]
}): JSX.Element => {
  return (
    <>
      {!!options.length &&
        options.map((option, index) => {
          return (
            <div key={'pvopt' + index}>
              {option.key === 'color' && (
                <>
                  <div className="typography-default-strong mb-3">
                    {option.name}:{' '}
                    {selectedDimensionValue(option.variantOptions)}
                  </div>
                  <ul className="flex flex-wrap gap-5 mb-10">
                    {option.variantOptions.map((colorOption, index) => (
                      <li key={'pcb' + index}>
                        <CircularBadge option={colorOption} />
                      </li>
                    ))}
                  </ul>
                </>
              )}
              {option.key !== 'color' && (
                <>
                  <div className="typography-default-strong mb-3">
                    {option.name}:{' '}
                    {selectedDimensionValue(option.variantOptions)}
                  </div>
                  <ul className="flex flex-wrap gap-3 mb-10">
                    {option.variantOptions.map((sizeOption, index) => (
                      <li key={'psb' + index}>
                        <RectangularBadge option={sizeOption} />
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </div>
          )
        })}
    </>
  )
}

export default ProductVariants
