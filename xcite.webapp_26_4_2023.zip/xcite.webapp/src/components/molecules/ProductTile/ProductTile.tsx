import React from 'react'
import { useRouter } from 'next/router'
import { useTranslation } from 'next-i18next'
import {
  ButtonVariantEnum,
  CountryCodeEnum,
  HeadingEnum,
  ProductListType,
  ProductStatusEnum,
} from '../../../types/content'
import Heading from '../../atoms/Heading'
import Image from '../../atoms/Image'
import AddToCart from '../../organisms/AddToCart'
import ProductLabel from '../../atoms/ProductLabel'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import gtmDatalayer from '../../../util/gtmUtils'
import styles from './ProductTile.module.css'
import { getDiscountPercantage } from '../../../util/apiUtils'
import Link from 'next/link'

export type ProductTileType = ProductListType & { plpTile?: boolean }

export default function ProductTile({
  brand,
  magentoProductId,
  position,
  queryID,
  image,
  name,
  price,
  url,
  sku,
  status,
  labels,
  plpTile = false,
}: ProductTileType): JSX.Element {
  const router = useRouter()

  const { t } = useTranslation()
  const discountValue = price
    ? getDiscountPercantage(price.value, price.valueUnmodified)
    : 0

  const {
    country: { id: countryId },
  } = localesFactory.createFromHrefLang(router?.locale).current

  const handleClick = () => {
    const pdpInfo = {
      referenceProductId: magentoProductId,
      productId: sku,
      position: position,
      queryID: queryID,
    }
    gtmDatalayer('algoliaPdp', 'algoliaEvent', JSON.stringify(pdpInfo))
  }

  let sortedLabels
  if (labels) {
    sortedLabels = labels.sort((a, b) => a.localeCompare(b))
  }

  return (
    <Link href={url}>
      <a>
        <div
          data-insights-object-id={sku}
          data-insights-position={position}
          data-insights-query-id={queryID}
          data-insights-filter={`${brand}:${price?.value}`}
          className={`${styles.wrapper}`}
          onClick={handleClick}
        >
          {sortedLabels && (
            <div className="absolute z-10 flex flex-wrap gap-1">
              {sortedLabels.map(
                (label, index) =>
                  index < 2 &&
                  label != '' && (
                    <ProductLabel key={index}>{label}</ProductLabel>
                  )
              )}
            </div>
          )}
          <div className="sm:text-center">
            <Image
              src={image.src}
              alt={image.alt}
              layout="intrinsic"
              height={500}
              width={500}
              objectFit="contain"
              className="mb-4"
            ></Image>

            {brand && (
              <Heading type={HeadingEnum.h5} className="mb-2 text-lg">
                {brand}
              </Heading>
            )}

            <p className={`mb-2 typography-default ${styles.productName}`}>
              {name}
            </p>

            <Heading type={HeadingEnum.h4}>
              {discountValue > 0 ? (
                <>
                  <span
                    className={`text-2xl text-functional-red-800 block mb-2`}
                  >
                    {price?.formattedPrice}
                    {countryId === CountryCodeEnum.SaudiArabia && (
                      <span className="typography-small opacity-50 sm:pl-2 sm:rtl:pr-2 sm:rtl:pl-0 text-black">
                        {t('product_incl_vat_label')}
                      </span>
                    )}
                  </span>
                  <div className="flex mb-1 justify-center items-center gap-2 font-body">
                    <span className={`text-base line-through`}>
                      {price?.formattedPriceUnmodified}
                    </span>
                    {'  '}
                    <span
                      className={`text-base bg-functional-red-600 text-white px-2 py-[3px] leading-1 align-text-top inline-block font-normal`}
                    >
                      {discountValue}%
                    </span>
                  </div>
                </>
              ) : (
                <>
                  {price?.formattedPrice}
                  {countryId === CountryCodeEnum.SaudiArabia && (
                    <span className="typography-small opacity-50 sm:pl-2 sm:rtl:pr-2 sm:rtl:pl-0">
                      {t('product_incl_vat_label')}
                    </span>
                  )}
                </>
              )}
            </Heading>
          </div>
          <div
            className={`${styles.addToCart} ${
              plpTile ? styles.plpAddToCart : ''
            }`}
          >
            <AddToCart
              buttonVariant={ButtonVariantEnum.primaryOnLight}
              sku={sku}
              disabled={status !== ProductStatusEnum.InStock}
              className="flex-1 mt-6"
              pageType="CategoryView"
            >
              {t('addToCart_button_label')}
            </AddToCart>
          </div>
        </div>
      </a>
    </Link>
  )
}
