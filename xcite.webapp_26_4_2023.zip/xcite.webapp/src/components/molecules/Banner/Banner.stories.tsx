import React from 'react'
import { Meta, Story } from '@storybook/react'
import Banner from './Banner'
import {
  BannerComponentType,
  ComponentTypeEnum,
} from '../../../types/content/component'

export default {
  title: 'Components/molecules/Banner',
  component: Banner,
} as Meta

const Template: Story<BannerComponentType> = (args) => <Banner {...args} />

export const Default = Template.bind({})

Default.args = {
  type: ComponentTypeEnum.banner,
  twoColumnBanner: {
    imageAlignment: false,
    heading: 'The 5 Best Home Theater Systems of 2021',
    content: 'TV, Audio & Theater Systems',
    cta: {
      tooltip: '',
      label: 'Read & Shop',
      url: '/home',
    },
    media: {
      type: 'img',
      src: 'https://cdn.media.amplience.net/i/alghanim/mountains',
      alt: 'Banner Image',
    },
    textColor: '#000',
    bgColor: '#fff',
  },
}
