import React, { useEffect, useState } from 'react'
import ToggleSwitch from '../../atoms/ToggleSwitch'

const ToggleRefinement = ({
  currentRefinement,
  refine,
}: {
  currentRefinement: boolean
  refine: (value) => void
}): JSX.Element => {
  const [toggle, setToggle] = useState(currentRefinement)

  useEffect(() => {
    setToggle(currentRefinement)
  }, [currentRefinement])

  return (
    <ToggleSwitch
      onChange={() => {
        setToggle((prevState) => !prevState)
        refine(!toggle)
      }}
      checked={toggle}
    ></ToggleSwitch>
  )
}

export default ToggleRefinement
