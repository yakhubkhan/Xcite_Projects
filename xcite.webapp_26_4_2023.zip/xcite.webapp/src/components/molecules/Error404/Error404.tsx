import { useTranslation } from 'next-i18next'
import React from 'react'
import {
  ButtonVariantEnum,
  HeadingEnum,
  NavigationItemType,
} from '../../../types/content'
import { rewritePath } from '../../../util/seoUtils'
import { ButtonLink } from '../../atoms/Button/Button'
import Heading from '../../atoms/Heading'
import { LogoIcon } from '../../atoms/Icon'

export interface Props {
  homeLinkHref: string
  optionalPageLink?: NavigationItemType
}

const Error404 = ({ homeLinkHref, optionalPageLink }: Props): JSX.Element => {
  const { t } = useTranslation()

  return (
    <div className="max-w-[742px] h-full mx-auto bg-white sm:h-auto pt-2 sm:rounded-2xl sm:p-0 sm:w-[80%]">
      <div className="flex justify-center items-center relative px-5 py-3">
        <div className="absolute flex gap-1 left-5 rtl:right-5">
          <span className="w-2 h-2 rounded-full bg-primary-200"></span>
          <span className="w-2 h-2 rounded-full bg-primary-200"></span>
          <span className="w-2 h-2 rounded-full bg-primary-200"></span>
        </div>
        <Heading
          className="text-primary-200 typography-h5"
          type={HeadingEnum.h1}
        >
          {t('error_404_title')}
        </Heading>
      </div>
      <div className="px-5 pt-12 pb-20 flex flex-col items-center sm:px-20">
        <LogoIcon className="h-20 text-primary-900 fill-current mb-12" />
        <span className="typography-decorative-light text-primary-900 text-center mb-4">
          {t('error_404_content_heading')}
        </span>
        <span className="text-gray-600 mb-8">
          {t('error_404_content_subheading')}
        </span>
        <div className="flex gap-6">
          <ButtonLink
            href={homeLinkHref}
            variant={ButtonVariantEnum.secondaryOnLight}
            className="px-12"
          >
            {t('error_404_link_home_label')}
          </ButtonLink>
          {optionalPageLink && optionalPageLink.href && (
            <ButtonLink
              href={rewritePath(optionalPageLink.href)}
              variant={ButtonVariantEnum.secondaryOnLight}
              className="px-12"
            >
              {optionalPageLink.title}
            </ButtonLink>
          )}
        </div>
      </div>
    </div>
  )
}

export default Error404
