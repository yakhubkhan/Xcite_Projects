import { useTranslation } from 'next-i18next'
import {
  Frames,
  CardNumber,
  ExpiryDate,
  Cvv,
  PaymentMethod,
  FrameCardTokenizedEvent,
} from 'frames-react'
import React, { useState } from 'react'

import { ButtonVariantEnum, HeadingEnum } from '../../../types/content'
import Button from '../../atoms/Button'
import Heading from '../../atoms/Heading'
import Field from '../../atoms/Field'
import ErrorMessage from '../../atoms/ErrorMessage'
import LoadingIndicator from '../../atoms/LoadingIndicator'
import getConfig from 'next/config'

export type Props = {
  onCardDetailsSubmitted: (
    cardTokenizedResponse: FrameCardTokenizedEvent
  ) => void
  language: string
  store: string
  selectedPaymentLabel: string
  availablePaymentMethods: string[]
}

const CheckoutPaymentFrame = (props: {
  children: React.ReactNode
  frameState: {
    isActive: boolean
    isEmpty: boolean
    isValid: boolean
  }
  label: string
  errorLabel: string
}) => {
  const { isEmpty, isValid, isActive } = props.frameState
  return (
    <>
      <label>
        <div className="h-[46px] relative">
          {(!isEmpty || isActive) && (
            <span className="absolute -top-5 typography-label">
              {props.label}
            </span>
          )}
          {props.children}
        </div>
      </label>
      {!isValid && !isEmpty && <ErrorMessage>{props.errorLabel}</ErrorMessage>}
    </>
  )
}

const PaymentCardForm = (props: Props): JSX.Element => {
  const { t } = useTranslation()

  const [isLoading, setIsLoading] = useState(true)
  const [isCardNumberActive, setIsCardNumberActive] = useState(false)
  const [isExpiryDateActive, setIsExpiryDateActive] = useState(false)
  const [isCVVActive, setIsCVVActive] = useState(false)
  const [isCardNumberEmtpy, setIsCardNumberEmtpy] = useState(true)
  const [isExpiryDateEmtpy, setIsExpiryDateEmtpy] = useState(true)
  const [isCVVEmtpy, setIsCVVEmtpy] = useState(true)
  const [isCardNumberValid, setIsCardNumberValid] = useState(true)
  const [isExpiryDateValid, setIsExpiryDateValid] = useState(true)
  const [isCVVValid, setIsCVVValid] = useState(true)
  const [cardholderName, setCardholderName] = useState('')
  const [formError, setFormError] = useState('')

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>()

  const rightToLeftMode = props.language === 'ar' ? ['right_to_left'] : []
  const framesModes = [...rightToLeftMode, 'disable_copy_paste']

  const isFormComplete =
    !isCardNumberEmtpy && !isExpiryDateEmtpy && !isCVVEmtpy && cardholderName
  const isFormValid = isCardNumberValid && isExpiryDateValid && isCVVValid

  const checkPaymentMethod = () => {
    if (
      !paymentMethod ||
      !props.availablePaymentMethods.includes(paymentMethod)
    ) {
      setFormError(
        t('checkout_payment_checkoutdotcom_form_visa_mastercard_error', {
          paymentType: props.selectedPaymentLabel,
        })
      )
      throw new Error(
        t('checkout_payment_checkoutdotcom_form_visa_mastercard_error', {
          paymentType: props.selectedPaymentLabel,
        })
      )
    }
  }

  const onFrameBlurFocus = (e: { element: string }, isFocused: boolean) => {
    if (e.element === 'card-number') {
      setIsCardNumberActive(isFocused)
    }
    if (e.element === 'expiry-date') {
      setIsExpiryDateActive(isFocused)
    }
    if (e.element === 'cvv') {
      setIsCVVActive(isFocused)
    }
  }

  const onFrameValidationChanged = (e: {
    element: string
    isEmpty: boolean
    isValid: boolean
  }) => {
    if (e.element === 'card-number') {
      setIsCardNumberEmtpy(e.isEmpty)
      setIsCardNumberValid(e.isValid)
    }
    if (e.element === 'expiry-date') {
      setIsExpiryDateEmtpy(e.isEmpty)
      setIsExpiryDateValid(e.isValid)
    }
    if (e.element === 'cvv') {
      setIsCVVEmtpy(e.isEmpty)
      setIsCVVValid(e.isValid)
    }
  }

  const onCardTokenized = (e: FrameCardTokenizedEvent) => {
    localStorage.setItem('card_token', e.token)
    props.onCardDetailsSubmitted(e)
  }

  return (
    <div className="flex flex-col gap-9">
      <Heading type={HeadingEnum.h4}>
        {t('checkout_payment_checkoutdotcom_form_heading')}
      </Heading>
      <div className="relative grid gap-x-3 gap-y-8 grid-cols-2">
        {isLoading && (
          <LoadingIndicator className="my-0 absolute-center">
            {t('loadingIndicator_label')}
          </LoadingIndicator>
        )}
        <Frames
          config={{
            modes: framesModes,
            publicKey:
              props.store === 'kw'
                ? getConfig().publicRuntimeConfig.checkoutDotCom.publicKeyKW
                : getConfig().publicRuntimeConfig.checkoutDotCom.publicKeySA,

            localization: {
              cardNumberPlaceholder: t(
                'checkout_payment_checkoutdotcom_form_card_placeholder'
              ),
              expiryMonthPlaceholder: t(
                'checkout_payment_checkoutdotcom_form_expiry_month_placeholder'
              ),
              expiryYearPlaceholder: t(
                'checkout_payment_checkoutdotcom_form_expiry_year_placeholder'
              ),
              cvvPlaceholder: t(
                'checkout_payment_checkoutdotcom_form_cvv_placeholder'
              ),
            },
            cardholder: {
              name: cardholderName,
            },
            style: {
              base: {
                color: '#181818',
              },
              invalid: {
                color: '#181818',
              },
              placeholder: {
                focus: { color: '#181818', opacity: 0 },
                base: { color: '#6a6a6a' },
              },
              focus: {
                color: '#181818',
              },
            },
          }}
          cardTokenized={(e) => onCardTokenized(e)}
          cardTokenizationFailed={(e) => setFormError(e.message)}
          frameFocus={(e) => onFrameBlurFocus(e, true)}
          frameBlur={(e) => onFrameBlurFocus(e, false)}
          frameValidationChanged={(e) => onFrameValidationChanged(e)}
          ready={() => setIsLoading(false)}
          paymentMethodChanged={(e) => setPaymentMethod(e.paymentMethod)}
        >
          <div className="col-span-2">
            <CheckoutPaymentFrame
              frameState={{
                isActive: isCardNumberActive,
                isEmpty: isCardNumberEmtpy,
                isValid: isCardNumberValid,
              }}
              label={t('checkout_payment_checkoutdotcom_form_card_placeholder')}
              errorLabel={t('checkout_payment_checkoutdotcom_form_card_error')}
            >
              <CardNumber />
            </CheckoutPaymentFrame>
          </div>

          <div className="col-span-1">
            <CheckoutPaymentFrame
              frameState={{
                isActive: isExpiryDateActive,
                isEmpty: isExpiryDateEmtpy,
                isValid: isExpiryDateValid,
              }}
              label={`${t(
                'checkout_payment_checkoutdotcom_form_expiry_month_placeholder'
              )}/${t(
                'checkout_payment_checkoutdotcom_form_expiry_year_placeholder'
              )}`}
              errorLabel={t(
                'checkout_payment_checkoutdotcom_form_expiry_date_error'
              )}
            >
              <ExpiryDate />
            </CheckoutPaymentFrame>
          </div>

          <div className="col-span-1">
            <CheckoutPaymentFrame
              frameState={{
                isActive: isCVVActive,
                isEmpty: isCVVEmtpy,
                isValid: isCVVValid,
              }}
              label={t('checkout_payment_checkoutdotcom_form_cvv_placeholder')}
              errorLabel={t('checkout_payment_checkoutdotcom_form_cvv_error')}
            >
              <Cvv />
            </CheckoutPaymentFrame>
          </div>
        </Frames>
        {!isLoading && (
          <div className="col-span-2">
            <Field
              id="checkout-input-cardholder"
              labelText={t(
                'checkout_payment_checkoutdotcom_form_cardholder_placeholder'
              )}
              placeholder={t(
                'checkout_payment_checkoutdotcom_form_cardholder_placeholder'
              )}
              value={cardholderName}
              onChange={(e) => setCardholderName(e.target.value)}
            />
          </div>
        )}
      </div>
      <div>
        {formError && (
          <div className="mb-4">
            <ErrorMessage>{formError}</ErrorMessage>
          </div>
        )}
        <Button
          variant={ButtonVariantEnum.primaryOnLight}
          onClick={() => {
            try {
              checkPaymentMethod()
            } catch (e) {
              console.error(e)
              return
            }

            Frames.submitCard().catch((e) => setFormError(e))
          }}
          className="w-full"
          disabled={!isFormComplete || !isFormValid}
        >
          {t('checkout_payment_checkoutdotcom_form_button_label')}
        </Button>
      </div>
    </div>
  )
}

export default PaymentCardForm
