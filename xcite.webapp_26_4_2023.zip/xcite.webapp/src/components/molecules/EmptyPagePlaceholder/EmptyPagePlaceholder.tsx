import Button from '../../atoms/Button'
import { ButtonVariantEnum } from '../../../types/content'
import Heading from '../../atoms/Heading'
import { HeadingEnum } from '../../../types/content'
import SearchBox from '../../atoms/SearchBox'

const EmptyPagePlaceholder = ({
  icon,
  headlineText,
  copyText,
  buttonText,
  buttonOnClick,
  showSearchBox,
  searchBoxPlaceholder,
}: {
  icon?: React.ReactNode
  headlineText: string
  copyText?: string
  buttonText: string
  buttonOnClick: (e) => void
  showSearchBox?: boolean
  searchBoxPlaceholder?: string
}): JSX.Element => {
  return (
    <div className="text-center sm:my-10 w-full">
      <div className="mx-auto max-w-sm mb-14 text-darkblue-100">
        {icon && <div className="w-20 mx-auto">{icon}</div>}
        <Heading
          type={HeadingEnum.h3}
          className="text-xl sm:text-3xl mb-4 mt-6"
        >
          {headlineText}
        </Heading>
        {copyText && <p className="text-sm">{copyText}</p>}
      </div>
      <div className="flex justify-center flex-col sm:flex-row items-center">
        {showSearchBox && (
          <>
            <div className="w-2/3 sm:w-1/2">
              <SearchBox placeholder={searchBoxPlaceholder} />
            </div>
            <span className="my-3 sm:my-0 sm:mx-5 md:mx-9 text-lg font-bold sm:leading-6">
              or
            </span>
          </>
        )}

        <Button
          variant={ButtonVariantEnum.primaryOnLight}
          onClick={buttonOnClick}
          className="w-2/3 sm:w-1/2"
        >
          {buttonText}
        </Button>
      </div>
    </div>
  )
}

export default EmptyPagePlaceholder
