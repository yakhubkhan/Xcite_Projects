import React from 'react'
import { ContentRowTextBlocks } from '../../../types/content/component'
import styles from './ContentRowText.module.css'
import Heading from '../../atoms/Heading'
import { HeadingEnum } from '../../../types/content'
import Image from '../../atoms/Image'
import MarkDown from '../../atoms/MarkDown'

export default function ContentRowText(
  props: ContentRowTextBlocks
): JSX.Element {
  const { textBlocks } = props

  const getBlockGap = (items) => {
    switch (items.length) {
      case 4:
        return 'sm:gap-10'
      case 3:
        return 'sm:gap-12'
      case 2:
        return 'sm:gap-24'
      default:
        return ''
    }
  }

  return (
    <>
      {textBlocks && (
        <div
          className={`flex flex-col gap-12 sm:flex-row xl:container mx-auto px-5 ${getBlockGap(
            textBlocks
          )}`}
        >
          {textBlocks.map((item, index) => (
            <div
              key={index}
              className={`w-full flex flex-col gap-2 text-sm leading-2`}
            >
              {item.image && (
                <span className="mb-3">
                  <Image
                    src={item.image.src}
                    alt={item.image.alt}
                    width="80"
                    height="80"
                    layout="fixed"
                  />
                </span>
              )}
              {item.heading && (
                <Heading type={HeadingEnum.h4}>{item.heading}</Heading>
              )}
              {item.text && (
                <MarkDown className={styles.textStyles}>{item.text}</MarkDown>
              )}
            </div>
          ))}
        </div>
      )}
    </>
  )
}
