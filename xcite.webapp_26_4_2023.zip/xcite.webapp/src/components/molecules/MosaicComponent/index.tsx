export { default } from './MosaicComponent'
