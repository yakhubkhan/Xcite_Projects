export { default } from './CartIcon'
