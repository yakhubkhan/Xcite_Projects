import React from 'react'
import { Meta, Story } from '@storybook/react'
import { ContentBlockWithImageTextBlocks } from '../../../types/content/component'
import ContentBlockImage from './ContentBlockImage'

export default {
  title: 'Components/molecules/ContentBlockImage',
  component: ContentBlockImage,
} as Meta

const Template: Story<ContentBlockWithImageTextBlocks> = (args) => (
  <ContentBlockImage {...args} />
)

export const Default = Template.bind({})

Default.args = {
  imageTextBlocks: [
    {
      heading: 'Lorem ipsum dolor sit amet',
      text: 'Lorem ipsum dolor sit amet, **consetetur sadipscing** elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.',
      image: {
        type: 'img',
        alt: 'Alt text image',
        src: 'https://cdn.media.amplience.net/i/alghanim/iphone_white',
      },
      imageFirst: true,
    },
    {
      heading: 'Lorem ipsum dolor sit amet',
      text: 'Lorem ipsum dolor sit amet, **consetetur sadipscing** elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.',
      image: {
        type: 'img',
        alt: 'Alt text image',
        src: 'https://cdn.media.amplience.net/i/alghanim/iphone_white',
      },
      imageFirst: false,
    },
  ],
}
