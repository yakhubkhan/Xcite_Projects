export { default } from './ContentBlockImage'
