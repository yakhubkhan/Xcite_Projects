import React from 'react'
import { ContentBlockWithImageTextBlocks } from '../../../types/content/component'
import ContentBlockImageItem from '../ContentBlockImageItem'

export default function ContentBlockImage(
  props: ContentBlockWithImageTextBlocks
): JSX.Element {
  const { imageTextBlocks } = props

  return (
    <div className="mx-auto sm:px-5 w-full xl:container">
      {imageTextBlocks.map((item, index) => (
        <ContentBlockImageItem
          key={index}
          imageFirst={item.imageFirst}
          heading={item.heading}
          text={item.text}
          image={item.image}
        />
      ))}
    </div>
  )
}
