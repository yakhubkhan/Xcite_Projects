import React from 'react'
import { CtaType, HeadingEnum, ImageType } from '../../../types/content'
import Heading from '../../atoms/Heading'
import Image from '../../atoms/Image'
import { useRouter } from 'next/router'

export default function ContentsCarouselTile({
  title,
  image,
  cta,
}: {
  title?: string | undefined
  image: ImageType
  cta?: CtaType | undefined
}): JSX.Element {
  const router = useRouter()
  const handleClick = () => {
    if (cta?.url) {
      router.push(cta?.url)
      // if (cta?.isExternal) {
      //   window.open(cta?.url, '_ blank')
      // } else {
      //   router.push(cta?.url)
      // }
    }
  }

  return (
    <div
      className={`transition hover:shadow-sm ${cta?.url && 'cursor-pointer'}`}
      onClick={handleClick}
    >
      <div className="relative flex justify-center">
        <Image
          src={image.src}
          alt={image.alt}
          layout="intrinsic"
          height={750}
          width={500}
          objectFit="cover"
        ></Image>
        <div className="absolute bottom-0 w-full min-h-[35%] text-center bg-gradient-to-t from-[#000000cc] to-[#00000000]">
          {title && (
            <Heading type={HeadingEnum.h3} className="pt-4 text-white">
              {title}
            </Heading>
          )}
          {cta?.label && (
            <div className="mt-2">
              <Heading type={HeadingEnum.h5} className="pt-4 text-white">
                {cta?.label}
              </Heading>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
