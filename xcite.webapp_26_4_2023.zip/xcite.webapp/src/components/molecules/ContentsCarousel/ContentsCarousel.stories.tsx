import React from 'react'
import { Meta, Story } from '@storybook/react'
import { ContentsCarouselComponentType } from '../../../types/content/component'
import ContentsCarousel from './ContentsCarousel'

export default {
  title: 'Components/molecules/ContentsCarousel',
  component: ContentsCarousel,
} as Meta

const Template: Story<ContentsCarouselComponentType> = (args) => (
  <ContentsCarousel {...args} />
)

export const Default = Template.bind({})

Default.args = {
  contentsCarousel: {
    slides: [
      {
        title: 'School Books',
        cta: {
          url: '/chopard-oud-malaki-edp-for-men-80ml-perfume/p',
          tooltip: 'School Books Tooltip',
          label: 'Stationery',
        },
        image: {
          type: 'img',
          alt: 'books',
          src: 'https://cdn.media.amplience.net/i/alghanim/page_yieldeditedcd-99705/books',
        },
      },
      {
        title: 'Family Zone',
        cta: {
          url: '/asus-transformer-book-flip-tp300lj-core-i7-4gb-ram-1tb-hdd-13-3-inch-touch-screen-laptop-black/p',
          label: 'Family Category',
        },
        image: {
          type: 'img',
          alt: 'family',
          src: 'https://cdn.media.amplience.net/i/alghanim/product-description-2',
        },
      },
      {
        title: 'Audio',
        cta: {
          url: '/gorenje-90-x-60-cm-5-burner-floor-standing-gas-cooker-wansa-90cm-built-under-cooker-hood/p',
          label: 'Shop Category',
        },
        image: {
          type: 'img',
          alt: 'Audio',
          src: 'https://cdn.media.amplience.net/i/alghanim/Xcite-Homepage',
        },
      },
      {
        title: 'Watch and Clock',
        cta: {
          url: '/destiny-2-game-destiny-2-wireless-controller/p',
          label: 'Shop Category',
        },
        image: {
          type: 'img',
          alt: 'Watch',
          src: 'https://cdn.media.amplience.net/i/alghanim/redmi-header-banner-ar',
        },
      },
      {
        title: 'Household',
        cta: {
          url: '/nintendo-switch-colored-joy-con-portable-gaming-system-with-2-toys-controller-just-dance-2017-game-puyo-puyo-tetris/p',
          label: 'General Store',
        },
        image: {
          type: 'img',
          alt: 'house',
          src: 'https://cdn.media.amplience.net/i/alghanim/product-description-1',
        },
      },
    ],
  },
}
