import React from 'react'
import { ContentBlockWithVideoBlock } from '../../../types/content/component'
import Video from '../../atoms/Video'

export default function ContentBlockVideo(
  props: ContentBlockWithVideoBlock
): JSX.Element {
  const { youtubeLink, title } = props

  return (
    <div className="mx-auto sm:px-5 w-full xl:container">
      <Video youtubeLink={youtubeLink} title={title} width="900" />
    </div>
  )
}
