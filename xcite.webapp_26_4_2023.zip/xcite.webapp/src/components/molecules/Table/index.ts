export { default } from './Table'
