import React from 'react'
import { render, fireEvent } from '@testing-library/react'
import Accordion from '../Accordion'

describe('Accordion', () => {
  const item1Content = 'Item 1 content'
  const item1 = {
    id: 'item1',
    title: 'item 1',
    content: <p>{item1Content}</p>,
    isOpen: true,
  }

  const item2Content = 'Item 2 content'
  const item2 = {
    id: 'item2',
    title: 'item 2',
    content: <p>{item2Content}</p>,
  }
  const item3 = {
    id: 'item3',
    title: 'item 3',
    content: 'Item 3 content',
  }
  test('can open accordion items to see the contents', () => {
    const { getByText } = render(<Accordion items={[item1, item2, item3]} />)

    fireEvent.click(getByText(item2.title))
    expect(getByText(item2Content)).toBeInTheDocument()

    fireEvent.click(getByText(item3.title))
    expect(getByText(item3.content)).toBeInTheDocument()
  })
  test('the isOpen property should pre-open an item on render', () => {
    const { getByText } = render(<Accordion items={[item1, item2, item3]} />)

    expect(getByText(item1Content)).toBeInTheDocument()
  })
})
