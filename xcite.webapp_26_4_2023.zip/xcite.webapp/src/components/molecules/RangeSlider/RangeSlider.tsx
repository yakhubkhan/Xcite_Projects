import React, { useState, useEffect } from 'react'
import { Range, getTrackBackground } from 'react-range'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import { useRouter } from 'next/router'
import { getArabicCurrency } from '../../../util/apiUtils'
import styles from './RangeSlider.module.css'

const RangeSlider = ({
  min = 0,
  max,
  currentRefinement,
  canRefine,
  refine,
}: {
  min: number
  max: number
  currentRefinement: {
    min: number
    max: number
  }
  canRefine: boolean
  refine: (value: { min: number; max: number }) => void
}): JSX.Element => {
  const router = useRouter()
  const [values, setValues] = useState([min, max])
  const [showSlider, setShowSlider] = useState(false)
  const [inputMinvalue, setInputMinvalue] = useState(values[0])
  const [inputMaxvalue, setInputMaxvalue] = useState(values[1])
  const {
    country: { currency: currentCurrency },
    iso_639_1: languageKey,
  } = localesFactory.createFromHrefLang(router?.locale).current
  const currencyToDisplay =
    languageKey === 'ar' ? getArabicCurrency(currentCurrency) : currentCurrency

  useEffect(() => {
    if (
      (currentRefinement.min >= max && currentRefinement.max <= min) ||
      min === max
    ) {
      setShowSlider(false)
      return
    }

    if (canRefine) {
      const newMin = Math.max(currentRefinement.min, min)
      const newMax = Math.min(currentRefinement.max, max)
      setValues([newMin, newMax])
      setInputMinvalue(newMin)
      setInputMaxvalue(newMax)
      setShowSlider(canRefine)
    }
  }, [canRefine, currentRefinement.min, currentRefinement.max, min, max])

  const onChange = (values: number[]) => {
    setValues(values)
    setInputMinvalue(values[0])
    setInputMaxvalue(values[1])
  }
  const onFinalChange = (values: number[]) => {
    if (
      currentRefinement.min !== values[0] ||
      currentRefinement.max !== values[1]
    ) {
      refine({ min: values[0], max: values[1] })
    }
  }

  return showSlider ? (
    <div className="flex flex-col pb-4 gap-6">
      <div className="flex justify-between gap-5">
        <label className="flex gap-2 items-center rtl:order-1 rtl:flex-row-reverse">
          {currencyToDisplay}
          <input
            type="number"
            min={min}
            max={max}
            value={inputMinvalue}
            name="minValue"
            onChange={(e) => setInputMinvalue(Number(e.target.value))}
            onBlur={(e) => onFinalChange([Number(e.target.value), values[1]])}
            className={`w-full bg-gray-200 rounded py-2 px-4 text-center ${styles.rangeInput}`}
          />
        </label>
        <label className="flex gap-2 items-center rtl:flex-row-reverse">
          {currencyToDisplay}
          <input
            type="number"
            min={min}
            max={max}
            value={inputMaxvalue}
            name="maxValue"
            onChange={(e) => setInputMaxvalue(Number(e.target.value))}
            onBlur={(e) => onFinalChange([values[0], Number(e.target.value)])}
            className={`w-full bg-gray-200 rounded py-2 px-4 text-center ${styles.rangeInput}`}
          />
        </label>
      </div>
      <div className="px-4 relative">
        <Range
          values={values}
          min={min}
          max={max}
          onChange={(values) => onChange(values)}
          onFinalChange={(values) => onFinalChange(values)}
          renderTrack={({ props, children }) => (
            <div
              onMouseDown={props.onMouseDown}
              onTouchStart={props.onTouchStart}
            >
              <div
                ref={props.ref}
                className="h-1 w-full max-w-full rounded-sm"
                style={{
                  background: getTrackBackground({
                    values,
                    colors: ['#e7e7e7', '#00355f', '#e7e7e7'],
                    min: min,
                    max: max,
                  }),
                }}
              >
                {children}
              </div>
            </div>
          )}
          renderThumb={({ props }) => (
            <div
              {...props}
              className="absolute h-5 w-5 bg-white border-2 border-gray-900 rounded-full rtl:left-5 z-10 focus:outline-none"
            ></div>
          )}
        />
      </div>
    </div>
  ) : (
    <></>
  )
}

export default RangeSlider
