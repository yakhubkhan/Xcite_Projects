import React from 'react'

export interface GridProps {
  className?: string
}

const Grid: React.FunctionComponent<GridProps> = ({
  children,
  className = '',
}) => (
  <div
    className={`grid grid-cols-4 gap-x-5 w-full mx-auto px-5 sm:grid-cols-12 sm:px-10 lg:px-20 xl:container ${className}`}
  >
    {children}
  </div>
)

export default Grid
