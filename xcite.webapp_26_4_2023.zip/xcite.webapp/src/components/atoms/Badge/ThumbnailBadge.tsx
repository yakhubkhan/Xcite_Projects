import React from 'react'

// TODO - ThumbnailBadge atom is not in use.
// Can be used once, "where to use Thumbnail type?" will be decided by business.
const ThumbnailBadge = ({ children }): JSX.Element => {
  return (
    <span
      className={`cmn-inline-center px-2 py-2 w-16 h-16 border border-gray-500 rounded`}
    >
      {children}
    </span>
  )
}

export default ThumbnailBadge
