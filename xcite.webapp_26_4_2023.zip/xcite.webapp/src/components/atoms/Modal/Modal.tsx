import React from 'react'
import { ModalProps } from '../../../types/content'
import Button from '../Button'
import { ButtonVariantEnum } from '../../../types/content'

export default function Modal(props: ModalProps): JSX.Element {
  const {
    children,
    emptyDivClasses = '',
    className = '',
    extraCloseClasses = '',
    extraCloseBtnClasses = '',
    handleModal,
    showClose = true,
    backButton,
  } = props
  const [showModal, setShowModal] = React.useState(true)

  return (
    <>
      {showModal ? (
        <>
          <div
            className="fixed z-40 inset-0 w-full opacity-30 bg-gray-900"
            onClick={() => {
              setShowModal(false)
              handleModal(false)
            }}
          ></div>
          {emptyDivClasses && <div className={`${emptyDivClasses}`}></div>}
          <div className={`z-50 overflow-y-auto ${className}`}>
            {showClose && (
              <div
                className={`flex flex-row items-center justify-between ${extraCloseClasses}`}
              >
                <div className="flex justify-start">{backButton}</div>
                <div className={`flex justify-end min-w-fit`}>
                  <Button
                    variant={ButtonVariantEnum.textLink}
                    className={`${extraCloseBtnClasses}`}
                    type="button"
                    onClick={() => {
                      setShowModal(false)
                      handleModal(false)
                    }}
                  >
                    <img
                      src="/assets/icons/close.svg"
                      alt="close"
                      width="40"
                      height="40"
                    />
                  </Button>
                </div>
              </div>
            )}
            {children}
          </div>
        </>
      ) : null}
    </>
  )
}
