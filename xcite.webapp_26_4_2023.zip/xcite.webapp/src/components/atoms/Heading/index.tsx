export { default } from './Heading'
