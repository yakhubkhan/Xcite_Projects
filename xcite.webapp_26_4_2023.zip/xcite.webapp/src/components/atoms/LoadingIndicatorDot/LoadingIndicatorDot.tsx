import React from 'react'

export interface LoadingIndicatorProps {
  children: React.ReactNode
  className?: string
}

const LoadingIndicatorDot: React.FunctionComponent<LoadingIndicatorProps> = ({
  children,
  className = '',
}) => (
  <div className={`mt-6 ${className}`}>
    <div className="flex gap-4">
      <div className="animate-scaling animation-delay-100 w-3 h-3 bg-darkblue-100 rounded-full"></div>
      <div className="animate-scaling animation-delay-200 w-3 h-3 bg-darkblue-100 rounded-full"></div>
      <div className="animate-scaling animation-delay-300 w-3 h-3 bg-darkblue-100 rounded-full"></div>
      <div className="animate-scaling animation-delay-400 w-3 h-3 bg-darkblue-100 rounded-full"></div>
    </div>

    {children && <div className="mt-1 text-xs text-gray-600">{children}</div>}
  </div>
)

export default LoadingIndicatorDot
