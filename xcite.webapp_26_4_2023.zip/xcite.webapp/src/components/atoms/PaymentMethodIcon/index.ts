export { default } from './PaymentMethodIcon'
