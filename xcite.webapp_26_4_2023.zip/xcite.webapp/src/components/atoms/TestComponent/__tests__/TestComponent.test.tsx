import React from 'react'
import renderer from 'react-test-renderer'
import TestComponent from '../TestComponent'

it('renders the default state', () => {
  const tree = renderer.create(<TestComponent name="World" />).toJSON()
  expect(tree).toMatchSnapshot()
})

it('renders the highlighted state', () => {
  const tree = renderer
    .create(<TestComponent name="World" highlight />)
    .toJSON()
  expect(tree).toMatchSnapshot()
})
