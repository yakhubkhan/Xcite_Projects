import React from 'react'
import styles from './TestComponent.module.css'

export interface TestComponentProps {
  name: string
  highlight?: boolean
}

const TestComponent: React.FunctionComponent<TestComponentProps> = ({
  name,
  highlight = false,
}) => (
  <div
    className={`${styles.text} font-heading rtl:font-rtl leading-5 ${
      highlight ? 'text-3xl font-semibold' : 'text-base font-light'
    }`}
  >
    Hello {name}!
  </div>
)

export default TestComponent
