import React from 'react'

export interface ProductLabelProps {
  children: React.ReactNode
  type?: string
}

const defaultClasses = 'px-2 py-0.5 text-base text-white leading-2 self-start'

const Element = ({ className, children }) => {
  return <div className={`${defaultClasses} ${className}`}>{children}</div>
}

const ProductLabel: React.FunctionComponent<ProductLabelProps> = ({
  children,
  type,
}) => {
  switch (type) {
    case 'discount':
      return <Element className="bg-functional-red-600">{children}</Element>
    default:
      return <Element className="bg-functional-blue-400">{children}</Element>
  }
}

export default ProductLabel
