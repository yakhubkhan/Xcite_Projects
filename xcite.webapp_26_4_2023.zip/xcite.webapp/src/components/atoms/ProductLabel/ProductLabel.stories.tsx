import React from 'react'

import { Story, Meta } from '@storybook/react'

import ProductLabel, { ProductLabelProps } from './ProductLabel'

export default {
  title: 'Components/atoms/ProductLabel',
  component: ProductLabel,
} as Meta

const Template: Story<ProductLabelProps> = (args) => (
  <div className="absolute z-10 flex flex-wrap gap-1 m-10">
    {' '}
    <ProductLabel {...args}>{args.children}</ProductLabel>
  </div>
)
export const Default = Template.bind({})

Default.args = { type: 'discount', children: '20%' }
