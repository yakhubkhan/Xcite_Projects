import Link from 'next/link'
import React from 'react'
import { ButtonVariantEnum } from '../../../types/content'

export declare type ButtonProps = {
  onClick?: (e) => void
  children?: React.ReactNode
  variant?: ButtonVariantEnum
  className?: string
  icon?: React.ReactNode
  disabled?: boolean
  type?: 'button' | 'submit' | 'reset'
  ariaLabel?: string
  dataTestId?: string
}

export declare type ButtonLinkProps = ButtonProps & {
  href: string
  isExternalLink?: boolean
}

const BtnContent = ({ text, icon }) => (
  <span className="flex flex-row gap-3 justify-between items-center">
    {text}
    {icon}
  </span>
)

export const ButtonLink = React.forwardRef<HTMLAnchorElement, ButtonLinkProps>(
  (props, ref) => {
    const {
      children,
      variant = ButtonVariantEnum.primaryOnLight,
      className = '',
      icon,
      ariaLabel,
      dataTestId,
      href,
      isExternalLink = false,
    } = props

    const LinkElement = (linkElProps) => (
      <a
        className={`button ${variant} ${className}`}
        tabIndex={0}
        aria-label={ariaLabel}
        data-testid={dataTestId}
        {...linkElProps}
      >
        <BtnContent text={children} icon={icon} />
      </a>
    )

    return isExternalLink ? (
      <LinkElement href={href} target="_blank" rel="noreferrer" />
    ) : (
      <Link href={href} passHref>
        <LinkElement ref={ref} />
      </Link>
    )
  }
)

ButtonLink.displayName = 'ButtonLink'

export default function Button(props: ButtonProps): JSX.Element {
  const {
    onClick,
    children,
    variant = ButtonVariantEnum.primaryCta,
    className = '',
    icon,
    disabled,
    type = 'button',
    ariaLabel,
    dataTestId,
  } = props
  return (
    <button
      className={`button ${variant} ${className}`}
      onClick={onClick}
      disabled={disabled}
      type={type}
      aria-label={ariaLabel}
      data-testid={dataTestId}
    >
      <BtnContent text={children} icon={icon} />
    </button>
  )
}

Button.variant = ButtonVariantEnum

// --Uses--
// <Button variant={Button.variant.primaryCta}>
//   Add to cart
// </Button>
