import React from 'react'

function EyeCloseIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      fill="none"
      stroke="#181818"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path d="m3.908 15.417 13.021-12.5M8.229 14.063c.674.21 1.376.316 2.083.313 2.847.049 5.736-1.951 7.514-3.917a1.146 1.146 0 0 0 0-1.541A13.927 13.927 0 0 0 15.694 7" />
      <path d="M13.847 5.882A7.855 7.855 0 0 0 10.312 5c-2.778-.048-5.695 1.91-7.514 3.917a1.146 1.146 0 0 0 0 1.542 13.89 13.89 0 0 0 3.424 2.777" />
      <path d="M8.23 11.3a2.674 2.674 0 0 1 3.819-3.667M12.917 9.688a2.604 2.604 0 0 1-2.604 2.604" />
    </svg>
  )
}

export default EyeCloseIcon
