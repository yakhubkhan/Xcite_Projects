import React from 'react'

function ProfileIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      stroke="#181818"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M7 7.922a4.922 4.922 0 1 0 9.844 0 4.922 4.922 0 0 0-9.844 0v0ZM20 21.753v-1.21a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v1.21" />
    </svg>
  )
}

export default ProfileIcon
