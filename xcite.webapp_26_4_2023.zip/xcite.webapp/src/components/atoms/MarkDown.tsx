import React from 'react'
import ReactMarkdown from 'react-markdown'
import { isAbsoluteLinkRegex, isExternalLinkRegex } from '../../util/linkUtils'
import Link from './Link'

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
const MarkDown = (markdownProps) => {
  return (
    <ReactMarkdown
      components={{
        a: ({ children, ...props }) => {
          const isExternalLink = props.href?.match(isExternalLinkRegex)
          const isAbsoluteLink = props.href?.match(isAbsoluteLinkRegex)

          return isExternalLink ? (
            <a href={props.href} target="_blank" rel="noreferrer">
              {children}
            </a>
          ) : isAbsoluteLink ? (
            <a href={props.href}>{children}</a>
          ) : (
            <Link to={props.href || ''}>{children}</Link>
          )
        },
      }}
      {...markdownProps}
    />
  )
}

export default MarkDown
