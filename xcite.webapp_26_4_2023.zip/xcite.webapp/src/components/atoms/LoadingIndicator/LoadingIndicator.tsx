import React from 'react'
import Heading from '../../atoms/Heading'
import { HeadingEnum } from '../../../types/content'
import { SyncIcon } from '../Icon'

export interface LoadingIndicatorProps {
  children: React.ReactNode
  className?: string
}

const LoadingIndicator: React.FunctionComponent<LoadingIndicatorProps> = ({
  children,
  className = '',
}) => (
  <div className={`my-10 text-center ${className}`}>
    <div className="w-20 mx-auto">
      <SyncIcon className="animate-spin stroke-primary-900" />
    </div>

    {children && (
      <Heading type={HeadingEnum.h3} className="text-xl sm:text-3xl mb-4 mt-6">
        {children}
      </Heading>
    )}
  </div>
)

export default LoadingIndicator
