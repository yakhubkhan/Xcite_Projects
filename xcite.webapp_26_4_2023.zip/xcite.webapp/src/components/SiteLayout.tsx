import Head from 'next/head'
import React, { useEffect } from 'react'
import { useDispatch } from 'react-redux'

import {
  CountryCodeEnum,
  ShopPageMetaType,
  SiteLayoutProps,
} from '../types/content'
import { setPageMetaAction } from '../redux/slices/app'
import { addNavigationLinksAction } from '../redux/slices/navigation'
import Footer from './molecules/Footer'
import Header from './molecules/Header'
import ContentWrapper from './molecules/ContentWrapper'
import { useRouter } from 'next/router'
import { useTranslation } from 'next-i18next'
import localesFactory from '../lib/api/l18n/LocalesFactory'
import { getRouterDomainInfo } from '../util/routerUtils'
import { createUrl } from '../util/seoUtils'
import environment from '../lib/environment'

type Props = SiteLayoutProps & {
  children?: React.ReactNode
  meta: ShopPageMetaType
  isPreview?: boolean
  isEditorialPage?: boolean
}

const SiteLayout: React.FunctionComponent<Props> = ({
  namedLinks,
  meta,
  children,
  footer,
  navigation,
  isPreview = false,
  isEditorialPage = false,
}: Props) => {
  const dispatch = useDispatch()

  const { t } = useTranslation()

  const router = useRouter()
  const { defaultLocale } = router

  const { country } = localesFactory.createFromHrefLang(router.locale).current

  const { domain, currentLocale } = getRouterDomainInfo(router)

  const url = createUrl(currentLocale, '/', domain)
  const defaultUrl = createUrl(
    defaultLocale || environment.defaultLocale,
    '/',
    domain
  )

  useEffect(() => {
    dispatch(addNavigationLinksAction(namedLinks))
    dispatch(setPageMetaAction(meta))
  }, [dispatch, namedLinks, meta])

  return (
    <>
      <Head>
        <title>{meta.title}</title>
        {meta.description && (
          <meta name="description" content={meta.description} />
        )}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: `{
              "@context": "https://schema.org/",
              "@type": "ElectronicsStore",
              "brand": {
                "@type": "Thing",
                "name": "Xcite"
              },
              "name": "${t('meta_structured_data_name')}",
              "description'": "${t('meta_structured_data_description')}",
              "url": "${url}",
              "telephone": "${
                country.id === CountryCodeEnum.Kuwait ? '1803535' : '8004333334'
              }",
              "email": "${
                country.id === CountryCodeEnum.Kuwait
                  ? 'Xsupport@xcite.com'
                  : 'xsupportksa@xcite.com'
              }",
              "openingHours": "Mo,Tu,We,Th,Fr,Sa,Su 09:00-22:00",
              "logo": "${`${defaultUrl}/assets/icons/logo.jpg`}",
              "image": "${`${defaultUrl}/assets/icons/logo.jpg`}",
              "sameAs": ${
                country.id === CountryCodeEnum.Kuwait
                  ? '["https://twitter.com/xcitealghanim", "https://www.facebook.com/XcitebyAlghanim", "https://instagram.com/xcitealghanim", "https://www.youtube.com/user/Xcitealghanim"]'
                  : '["https://twitter.com/xciteksa", "https://www.facebook.com/XciteKSA/", "https://www.instagram.com/xciteksa/", "https://www.youtube.com/channel/UCcwtfMipIszMxExKGHkg1HA"]'
              },
              "address": ${
                country.id === CountryCodeEnum.Kuwait
                  ? '{"@type": "PostalAddress", "streetAddress": "Al-Shuhada Street", "addressLocality": "Sharq", "addressRegion": "Kuwait", "postalCode": "13001"}'
                  : '{"@type": "PostalAddress", "streetAddress": "King Abdullah Road", "addressLocality": "Salahuddin", "addressRegion": "Riyadh", "postalCode": "305149"}'
              }

            }`,
          }}
        />
      </Head>
      <Header
        navigation={navigation}
        namedLinks={namedLinks}
        isPreview={isPreview}
      />
      <ContentWrapper isEditorialPage={isEditorialPage}>
        {children}
      </ContentWrapper>
      <Footer footerContent={footer} />
    </>
  )
}

export default SiteLayout
