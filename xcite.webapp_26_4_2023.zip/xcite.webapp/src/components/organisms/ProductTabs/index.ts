export { default } from './ProductTabs'
