import { useRouter } from 'next/router'
import { useTranslation } from 'next-i18next'
import React, { useEffect, useCallback, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'

import { OrderHistoryComponentType } from '../../../types/content'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import { namedLinksSelector } from '../../../redux/slices/navigation'
import Grid from '../../atoms/Grid'
import Heading from '../../atoms/Heading'
import { HeadingEnum, StatusMessageEnum } from '../../../types/content'
import EmptyPagePlaceholder from '../../molecules/EmptyPagePlaceholder'
import Button from '../../atoms/Button'
import { ButtonVariantEnum } from '../../../types/content'
import LoadingIndicator from '../../atoms/LoadingIndicator'
import { ShoppingBagSadIcon } from '../../atoms/Icon'
import {
  getOrderHistory,
  orderHistorySelector,
  orderHistoryStatusSelector,
  resetOrderHistoryAction,
  userProfileSelector,
} from '../../../redux/slices/profile'
import OrderHistoryGroup from '../../molecules/OrderHistoryGroup'
import StatusMessage from '../../atoms/StatusMessage'

const OrderHistory: React.FunctionComponent<OrderHistoryComponentType> = () => {
  const router = useRouter()
  const { locale } = router

  const { t } = useTranslation()
  const namedLinks = useSelector(namedLinksSelector)
  const dispatch = useDispatch()
  const user = useSelector(userProfileSelector)

  const [offsetState, setOffsetState] = useState(0)
  const [ordersLoadedOnce, setOrdersLoadedOnce] = useState(false)
  const orderHistory = useSelector(orderHistorySelector)
  const orderHistoryStatus = useSelector(orderHistoryStatusSelector)
  const {
    iso_639_1: language,
    country: { ctStore: store },
    hreflang,
  } = localesFactory.createFromHrefLang(locale).current

  const limit = 5

  const onLoadOrders = useCallback(() => {
    dispatch(
      getOrderHistory({
        store: store,
        language: language,
        user: user,
        offset: offsetState,
        limit,
        locale: hreflang,
      })
    )
  }, [dispatch, language, offsetState, store, user, hreflang])

  const loadMoreOrders = () => {
    if (orderHistory.total > orderHistory.results.length) {
      setOffsetState(offsetState + limit)
    }
  }

  useEffect(() => {
    if (user.id && user.authenticated) {
      onLoadOrders()
    }
  }, [dispatch, onLoadOrders, user.authenticated, user.id])

  useEffect(() => {
    return () => {
      dispatch(resetOrderHistoryAction())
    }
  }, [dispatch])

  useEffect(() => {
    if (orderHistory?.results.length) {
      setOrdersLoadedOnce(true)
    }
  }, [orderHistory?.results.length, user.id])
  return (
    <Grid className="py-10 sm:py-20">
      {user.authenticated && (
        <>
          <div className="col-span-full md:col-start-2 md:col-span-10 mb-10 sm:mb-14">
            <Heading type={HeadingEnum.h2}>
              {t('profile_order_history_page_headline')}
            </Heading>
          </div>
          <div
            className={`grid grid-cols-4 gap-x-5 col-span-full sm:grid-cols-12`}
          >
            {orderHistoryStatus === 'loading' && !ordersLoadedOnce && (
              <div className="col-span-full md:col-start-3 md:col-span-8">
                <LoadingIndicator>
                  {t('loadingIndicator_label')}
                </LoadingIndicator>
              </div>
            )}
            {orderHistory.results.length > 0 && (
              <>
                <div className="col-span-full mb-16 md:col-start-2 md:col-span-6 md:pr-4 md:mb-0">
                  <StatusMessage
                    type={StatusMessageEnum.Warning}
                    className="mb-9"
                    showIcon={false}
                  >
                    {t('profile_order_history_page_delay_message')}
                  </StatusMessage>
                  {orderHistory.results.map((order) => (
                    <OrderHistoryGroup key={order.id} order={order} />
                  ))}
                  {orderHistory.total > orderHistory.results.length && (
                    <div className="text-center">
                      <Button
                        variant={ButtonVariantEnum.secondaryOnLight}
                        onClick={() => loadMoreOrders()}
                      >
                        {t('search_results_showMore_button_label')}
                      </Button>
                    </div>
                  )}
                  {orderHistoryStatus === 'loading' && ordersLoadedOnce && (
                    <LoadingIndicator>
                      {t('loadingIndicator_label')}
                    </LoadingIndicator>
                  )}
                </div>
              </>
            )}

            {(orderHistoryStatus === 'failed' ||
              (orderHistoryStatus === 'succeeded' &&
                orderHistory.results.length === 0)) && (
              <div className="col-span-full md:col-start-3 md:col-span-8">
                <EmptyPagePlaceholder
                  icon={<ShoppingBagSadIcon />}
                  headlineText={t('profile_order_history_noOrders_headline')}
                  buttonText={t('profile_order_history_noOrders_button_label')}
                  buttonOnClick={() => router.push(namedLinks.home)}
                  showSearchBox
                  searchBoxPlaceholder={t(
                    'profile_order_history_noOrders_searchBox_placeholder'
                  )}
                />
              </div>
            )}
          </div>
        </>
      )}
    </Grid>
  )
}

export default OrderHistory
