import React from 'react'
import { Navigation } from 'swiper'
import { Swiper, SwiperSlide } from 'swiper/react'

import ProductTile from '../../molecules/ProductTile'
import { HeadingEnum } from '../../../types/content'
import Heading from '../../atoms/Heading'
import Link from '../../atoms/Link'
import Grid from '../../atoms/Grid'
import { ProductCarouselComponentType } from '../../../types/content/component'

const ProductCarousel: React.FunctionComponent<ProductCarouselComponentType> =
  ({ productCarousel: { products, heading, cta } }) => {
    return products?.length > 0 ? (
      <Grid className="px-0 sm:px-0 lg:px-0">
        <div className="col-span-full flex items-center">
          <Swiper
            slidesPerView={'auto'}
            spaceBetween={20}
            className="product-carousel-swiper"
            modules={[Navigation]}
            navigation
            breakpoints={{
              '1': {
                slidesPerView: 1.65,
              },
              '550': {
                slidesPerView: 2.5,
              },
              '768': {
                slidesPerView: 3.25,
              },
              '1024': {
                slidesPerView: 4.25,
              },
              '1200': {
                slidesPerView: 5.25,
              },
            }}
          >
            <SwiperSlide>
              <div className="p-5">
                <Heading type={HeadingEnum.h2} className="mb-4">
                  {heading}
                </Heading>
                {cta.label && cta.url && (
                  <Link to={cta.url} className="underline">
                    {cta.label}
                  </Link>
                )}
              </div>
            </SwiperSlide>
            {products.map((product, index) => (
              <SwiperSlide key={index + 'pc'}>
                <ProductTile {...product} />
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </Grid>
    ) : (
      <> </>
    )
  }

export default ProductCarousel
