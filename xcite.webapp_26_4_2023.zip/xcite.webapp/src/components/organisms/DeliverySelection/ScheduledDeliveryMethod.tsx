import { useTranslation } from 'next-i18next'
import React, { useEffect, useState } from 'react'
import {
  AsyncResponseStatusEnum,
  ButtonVariantEnum,
  CartShippingDetails,
} from '../../../types/content'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import { useModal } from '../../../hooks'
import Modal from '../../molecules/Modal'
import Button from '../../atoms/Button'
import SelectionBox from '../../atoms/SelectionBox'
import { DeliveryRegularIcon } from '../../atoms/Icon'
import { useRouter } from 'next/router'
import { useDispatch, useSelector } from 'react-redux'
import { userProfileSelector } from '../../../redux/slices/profile'
import {
  resetSlotsStateAction,
  resetSlotsErrorAndStatusAction,
  scheduledDeliverySelector,
  getTimeSlotsThunk,
  softReserveTimeSlotThunk,
  setActiveGroupAction,
} from '../../../redux/slices/scheduledDelivery'
import TimeSlotSelectionTable from '../../molecules/TimeSlotSelectionTable'
import LoadingIndicator from '../../atoms/LoadingIndicator'
import { CommercetoolsSoftReserveSlotReqBody } from '../../../types/api'

interface Props {
  shippingDetails: CartShippingDetails
  minPrice: string
  maxPrice: string
  deliveryTeam: string
  deliveryGroupSlug: string
  onSelectDeliveryMethod: () => void
}

const ScheduledDeliveryMethod = ({
  shippingDetails,
  minPrice,
  maxPrice,
  deliveryTeam,
  deliveryGroupSlug,
  onSelectDeliveryMethod,
}: Props): JSX.Element => {
  const router = useRouter()

  const { t } = useTranslation()

  const dispatch = useDispatch()
  const user = useSelector(userProfileSelector)
  const {
    timeSlotTable,
    getSlotsStatus,
    getSlotsError,
    reserveSlotStatus,
    selectedSlots,
    activeGroup,
  } = useSelector(scheduledDeliverySelector)

  const groupSlot = selectedSlots.find(
    (slot) => slot.deliveryGroupSlug === deliveryGroupSlug
  )

  const { isShowing: isShowingModal, toggle: toggleModal } = useModal()

  const [enableSelectionBox, setEnableSelectionBox] = useState(false)

  const {
    iso_639_1: language,
    country: { ctStore: store },
    hreflang: locale,
  } = localesFactory.createFromHrefLang(router?.locale).current

  const onReserveSlot = (activeSlot: CommercetoolsSoftReserveSlotReqBody) => {
    dispatch(
      softReserveTimeSlotThunk({
        language,
        store,
        locale,
        user,
        reqBody: activeSlot,
      })
    )
  }

  // Open the modal and fetch the slots to fill the table
  const onGetSlots = () => {
    toggleModal()
    dispatch(setActiveGroupAction({ groupSlug: deliveryGroupSlug }))
    dispatch(
      getTimeSlotsThunk({
        deliveryTeam: deliveryTeam,
        language,
        store,
        locale,
        user,
      })
    )
  }

  // close the modal once the slot has been reserved
  useEffect(() => {
    if (
      reserveSlotStatus === AsyncResponseStatusEnum.succeeded &&
      groupSlot?.deliveryGroupSlug === activeGroup
    ) {
      toggleModal()
      dispatch(resetSlotsErrorAndStatusAction())
    }
  }, [
    deliveryGroupSlug,
    dispatch,
    reserveSlotStatus,
    groupSlot,
    toggleModal,
    activeGroup,
  ])

  // Mark the delivery method box as selected, only if the user reserved a slot
  useEffect(() => {
    if (groupSlot && shippingDetails.selected) {
      setEnableSelectionBox(true)
    } else {
      setEnableSelectionBox(false)
    }
  }, [groupSlot, shippingDetails.selected])

  // When the component is about to be unmounted, the slot redux state is resetted
  useEffect(() => {
    return () => {
      dispatch(resetSlotsStateAction())
    }
  }, [dispatch])

  const isTimeSlotSelected = () =>
    shippingDetails.deliveryDetails && shippingDetails.deliveryCharge

  return (
    <SelectionBox
      value={shippingDetails.key}
      disabled={!shippingDetails.enabled}
      checked={enableSelectionBox}
      onValChange={() => onSelectDeliveryMethod()}
      extraClassName="items-start"
    >
      <div className="flex flex-col gap-3 w-full">
        <div className="flex gap-3">
          <DeliveryRegularIcon className="h-6 w-6 stroke-current" />
          <div>
            <p className="typography-small">
              {t('deliveryMethod_scheduledDelivery')}
            </p>
            {isTimeSlotSelected() ? (
              <>
                <p className="typography-small-strong">
                  {shippingDetails.deliveryDetails?.localizedDate}
                </p>
                <p className="typography-small-strong">
                  {shippingDetails.deliveryCharge?.formattedPrice
                    ? `+${shippingDetails.deliveryCharge.formattedPrice}`
                    : timeSlotTable?.translationLabels.free}
                </p>
                <Button
                  variant={ButtonVariantEnum.textLink}
                  onClick={onGetSlots}
                >
                  {t('checkout_delivery_timeslot_edit_button')}
                </Button>
              </>
            ) : (
              <p className="typography-small-strong">
                {minPrice} - {maxPrice}
              </p>
            )}
          </div>
        </div>
        {!isTimeSlotSelected() && (
          <Button
            variant={ButtonVariantEnum.primaryCta}
            onClick={onGetSlots}
            className="md:w-full"
          >
            {t('checkout_delivery_timeslot_select_button')}
          </Button>
        )}
      </div>
      <Modal isShowing={isShowingModal} hide={toggleModal}>
        <>
          {getSlotsStatus === AsyncResponseStatusEnum.loading && (
            <LoadingIndicator>{t('loadingIndicator_label')}</LoadingIndicator>
          )}
          {getSlotsStatus === AsyncResponseStatusEnum.failed &&
            getSlotsError && (
              <p className="px-5 sm:px-10 text-functional-red-800">
                {t(getSlotsError)}
              </p>
            )}
          {getSlotsStatus === AsyncResponseStatusEnum.succeeded &&
            timeSlotTable && (
              <TimeSlotSelectionTable
                {...timeSlotTable}
                selectedSlot={groupSlot}
                onReserveSlot={onReserveSlot}
                reserveSlotStatus={reserveSlotStatus}
                deliveryGroupSlug={deliveryGroupSlug}
                selectedSlotDeliveryCharges={
                  shippingDetails.deliveryCharge?.formattedPrice || ''
                }
              />
            )}
        </>
      </Modal>
    </SelectionBox>
  )
}

export default ScheduledDeliveryMethod
