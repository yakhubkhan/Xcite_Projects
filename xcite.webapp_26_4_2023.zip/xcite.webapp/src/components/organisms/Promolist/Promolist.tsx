import { useRouter } from 'next/router'
import { useTranslation } from 'next-i18next'
import React, { useCallback, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'

import {
  ButtonVariantEnum,
  HeadingEnum,
  PickupStoresType,
} from '../../../types/content'
import Modal from '../../atoms/Modal'
import Heading from '../../atoms/Heading'
import MarkDown from '../../atoms/MarkDown'


export default function Promolist({
  promoHeading,
  promoDetail,
  termHeading,
  termDetail,
  onCloseModal,
}: {
  promoHeading?:string
  promoDetail?: string
  termHeading?: string
  termDetail?: string
  onCloseModal: () => void
  onConfirmModalClose: () => void
}): JSX.Element {
  
  



  return (
    <Modal
      className={`bg-white rounded-t-lg justify-center items-center fixed left-0 w-full bottom-0 px-5 py-7 sm:top-2/4 sm:left-2/4 sm:max-w-[633px] sm:h-[fit-content] sm:rounded-xl sm:-translate-x-1/2 sm:-translate-y-1/2 sm:px-8 sm:pb-7 sm:pt-8`}
      extraCloseClasses={`pb-4`}
      handleModal={onCloseModal}
      showClose={true}
     
    >
        <>
        <Heading type={HeadingEnum.h4} className="mb-4">
                    {promoHeading}
        </Heading>
        <MarkDown>{promoDetail}</MarkDown>
        <br/>
        <Heading type={HeadingEnum.h4} className="mb-4">
                    {termHeading}
        </Heading>
        <MarkDown>{termDetail}</MarkDown>
              {/* <Button
                variant={ButtonVariantEnum.primaryOnLight}
                className={`w-full my-8`}
                onClick={onCloseModal}
              >
               
                {t('cart_store_modal_close')}
              </Button> */}
            </>
      
    </Modal>
  )
}
