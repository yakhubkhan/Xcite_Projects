export { default } from './ProductWarranty'
