import { HeadingEnum, SecondSectionType } from '../../../types/content'
import Heading from '../../atoms/Heading'
import MarkDown from '../../atoms/MarkDown'
import styles from './ProductWarranty.module.css'

const ProductWarrantyExclusions = ({
  secondSection,
}: {
  secondSection: SecondSectionType
}): JSX.Element => {
  const { heading, blocks } = secondSection

  return (
    <div className="col-span-full px-5 sm:px-0 py-8">
      <Heading type={HeadingEnum.h4}>{heading}</Heading>
      <div className="flex flex-wrap flex-col sm:flex-row px-4">
        {blocks.map((data, index) => {
          const { heading, text } = data
          return (
            <div className="w-full sm:w-2/4 sm:pr-7 py-5" key={index}>
              <Heading type={HeadingEnum.h5} className={'py-4'}>
                {heading}
              </Heading>
              <div className={`${styles.list} typography-small`}>
                <MarkDown>{text}</MarkDown>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

export default ProductWarrantyExclusions
