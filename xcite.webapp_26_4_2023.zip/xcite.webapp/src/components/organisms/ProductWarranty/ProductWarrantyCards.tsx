import getConfig from 'next/config'
import { useEffect, useState } from 'react'
import { useDispatch } from 'react-redux'
import environment from '../../../lib/environment'
import { selectedProductWarrantyAction } from '../../../redux/slices/warranty'
import {
  ButtonVariantEnum,
  WarrantyTranslationLabelsType,
  WarrantyTypeGroup,
  WarrantyYearGroup,
} from '../../../types/content'
import Button from '../../atoms/Button'
import { GreenTickIcon, RedCrossIcon } from '../../atoms/Icon'

const ProductWarrantyCards = ({
  warrantyPackages,
  closeModal,
  translationLabels,
  selectedWarranty,
  pliFrom,
  cartWarrantyDetails,
}: {
  warrantyPackages: WarrantyTypeGroup
  closeModal: () => void
  translationLabels: WarrantyTranslationLabelsType
  selectedWarranty?: WarrantyYearGroup
  pliFrom?: string
  cartWarrantyDetails?: (data) => void
}): JSX.Element => {
  const dispatch = useDispatch()

  const [showAllWarrantyButtons, setShowAllWarrantyButtons] = useState(false)
  const showAllWarranty = () => {
    setShowAllWarrantyButtons(true)
  }

  const handleSelectedWarranty = (data, icon) => {
    const content = { ...data, icon }
    if (pliFrom !== 'cart') {
      dispatch(selectedProductWarrantyAction(content))
    }
    if (pliFrom === 'cart') {
      cartWarrantyDetails?.(data.warranty)
    }
    closeModal()
  }

  useEffect(() => {
    if (selectedWarranty?.warranty.warrantyType) {
      if (warrantyPackages.typeName === selectedWarranty.warranty.typeName) {
        setShowAllWarrantyButtons(true)
      }
    }
  }, [selectedWarranty, warrantyPackages])

  return (
    <div
      key={warrantyPackages.typeName}
      id={warrantyPackages.typeName}
      className=""
    >
      <div className="w-32 h-10">
        <img
          src={`${getConfig().publicRuntimeConfig.amplience.dam.baseUrl}/i/${
            getConfig().publicRuntimeConfig.amplience.dam.hubname
          }/${warrantyPackages.icon.name}`}
          alt={`${warrantyPackages.icon.name}`}
        />
      </div>
      <div className="pt-4">
        <ul>
          {warrantyPackages?.features.map((data, index) => {
            return (
              <li
                key={index}
                className="flex justify-start typography-small mb-1"
              >
                <span className="pr-4">
                  {data.isApplicable ? (
                    <GreenTickIcon className="w-6 h-6" />
                  ) : (
                    <RedCrossIcon className="w-6 h-6" />
                  )}
                </span>
                <span>{data.description}</span>
              </li>
            )
          })}
        </ul>
      </div>
      <div className="flex flex-row gap-2 justify-center my-4">
        {warrantyPackages.warrantyVendorGroups?.map((vendorGroups) => {
          return (
            <div key={vendorGroups.vendor} className="flex flex-col w-full">
              <div className="text-center typography-small">
                <span>
                  {translationLabels.vendor}:{' '}
                  <span className="font-bold">{vendorGroups.vendor}</span>
                </span>
              </div>
              {vendorGroups.warrantyYearGroups.map((yearGroups) => {
                return (
                  <div key={yearGroups.warranty.warrantyType}>
                    {yearGroups.selected && !showAllWarrantyButtons ? (
                      <Button
                        variant={ButtonVariantEnum.primaryOnLight}
                        disabled={false}
                        className={`w-full`}
                        key={yearGroups.warranty.year}
                        onClick={() =>
                          handleSelectedWarranty(
                            yearGroups,
                            warrantyPackages.icon
                          )
                        }
                      >
                        <div className="flex flex-col">
                          <span>
                            {yearGroups.warranty?.year}{' '}
                            {yearGroups.warranty?.year &&
                            ~~yearGroups.warranty?.year <= 1
                              ? translationLabels.year
                              : translationLabels.years}
                          </span>
                          <span className="font-normal typography-label">
                            {yearGroups.formattedPrice.formattedPrice}
                          </span>
                        </div>
                      </Button>
                    ) : null}
                    {showAllWarrantyButtons && (
                      <Button
                        type="button"
                        className={`w-full my-2 bg-white active:bg-gray-100 hover:bg-gray-50 ${
                          yearGroups.warranty.warrantyType ===
                          selectedWarranty?.warranty.warrantyType
                            ? ` border-2 border-primary-700`
                            : `border border-gray-900 focus:border-functional-blue-400`
                        }`}
                        key={yearGroups.warranty.year}
                        onClick={() =>
                          handleSelectedWarranty(
                            yearGroups,
                            warrantyPackages.icon
                          )
                        }
                      >
                        <div className="cmn-flex-center flex-wrap leading-2 gap-x-2">
                          <span>
                            {yearGroups?.warranty?.year}{' '}
                            {yearGroups?.warranty?.year &&
                            ~~yearGroups?.warranty?.year <= 1
                              ? translationLabels.year
                              : translationLabels.years}{' '}
                          </span>
                          <span className="font-normal">
                            {yearGroups.formattedPrice.formattedPrice}
                          </span>
                        </div>
                      </Button>
                    )}
                  </div>
                )
              })}
            </div>
          )
        })}
      </div>
      {!showAllWarrantyButtons && (
        <div>
          <Button
            type="button"
            variant={ButtonVariantEnum.secondaryOnLight}
            className={`w-full`}
            disabled={false}
            onClick={showAllWarranty}
          >
            {translationLabels.showAllPeriodsCTA}
          </Button>
        </div>
      )}
      {warrantyPackages?.disclaimer && (
        <div className="typography-caption text-gray-600 pt-6">
          {warrantyPackages?.disclaimer}
        </div>
      )}
    </div>
  )
}

export default ProductWarrantyCards
