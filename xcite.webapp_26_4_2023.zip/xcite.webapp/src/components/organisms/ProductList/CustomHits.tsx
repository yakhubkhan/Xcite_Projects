import getConfig from 'next/config'
import { useTranslation } from 'next-i18next'
import React, { useCallback, useEffect, useRef, useState } from 'react'
import { connectInfiniteHits } from 'react-instantsearch-dom'

import mapAlgoliaHits from '../../../lib/api/processors/ProductListProcessor'
import { ButtonVariantEnum } from '../../../types/content'
import ProductTile from '../../molecules/ProductTile'
import Button from '../../atoms/Button'
import gtmDatalayer from '../../../util/gtmUtils'
import styles from './ProductList.module.css'

const Hits = ({ hits, refineNext, hasMore, hrefLang, facets, query }) => {
  const amplienceDAMUrl = `${
    getConfig().publicRuntimeConfig.amplience.dam.baseUrl
  }/s/${getConfig().publicRuntimeConfig.amplience.dam.hubname}`
  const mappedHits = mapAlgoliaHits(hits, hrefLang, amplienceDAMUrl)
  const [hitsCollection, setHitsCollection] = useState<HTMLCollection>()
  const { t } = useTranslation()
  const listRef = useRef<HTMLUListElement>(null)

  useEffect(() => {
    if (mappedHits) {
      const items = mappedHits.map((s) => s?.sku)?.slice(0, 3)
      const eventActionObj = {
        item: items,
        categoryId: query,
      }
      if (items?.length > 0) {
        gtmDatalayer('view_list', 'List View', JSON.stringify(eventActionObj))
      }
    }
  }, [facets])

  const defineTileMinHeight = useCallback(() => {
    if (mappedHits) {
      Array.from(hitsCollection as HTMLCollectionOf<HTMLLIElement>).map(
        (item) => {
          item.style.cssText = `min-height: ${item.offsetHeight}px;`
        }
      )
    }
  }, [hitsCollection, mappedHits])

  const onRefineNext = () => {
    refineNext()
    defineTileMinHeight()
  }

  useEffect(() => {
    setHitsCollection(listRef.current?.children)
  }, [])

  useEffect(() => {
    hitsCollection && defineTileMinHeight()
  }, [defineTileMinHeight, hitsCollection])

  useEffect(() => {
    window.addEventListener('resize', defineTileMinHeight)
    return () => {
      window.removeEventListener('resize', defineTileMinHeight)
    }
  }, [defineTileMinHeight])

  return (
    <>
      <ul
        className="grid grid-cols-4 gap-5 sm:grid-cols-12 xl:grid-cols-10 mb-28"
        ref={listRef}
      >
        {mappedHits.map((hit) => (
          <li
            key={hit.sku}
            className="col-span-2 sm:col-span-4 sp:col-span-3 md:col-span-4 lg:col-span-3 xl:col-span-2 relative flex"
          >
            <div data-insights-index={query} className={styles.tileWrapper}>
              <ProductTile {...hit} plpTile />
            </div>
          </li>
        ))}
      </ul>
      <div className="flex justify-center">
        {hasMore && (
          <Button
            variant={ButtonVariantEnum.secondaryOnLight}
            onClick={onRefineNext}
          >
            {t('search_results_showMore_button_label')}
          </Button>
        )}
      </div>
    </>
  )
}

export default connectInfiniteHits(Hits)
