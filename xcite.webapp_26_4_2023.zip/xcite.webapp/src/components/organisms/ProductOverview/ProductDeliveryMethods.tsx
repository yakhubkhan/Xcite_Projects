import React, { useState } from 'react'

import {
  ButtonVariantEnum,
  DeliveryMethodType,
  ProductStatusEnum,
} from '../../../types/content'
import { useTranslation } from 'next-i18next'
import Button from '../../atoms/Button'
import Storelist from '../Storelist/index'
import { cartItemsSelector } from '../../../redux/slices/cart'
import { useSelector } from 'react-redux'
import DeliveryDetails from '../../molecules/DeliveryDetails'
import { useRouter } from 'next/router'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'

const ClickAndCollectMethod = (
  methodName: string,
  heading: string,
  icon: React.FunctionComponentElement<React.SVGProps<SVGSVGElement>>,
  sku: string,
  t: any,
  prodStatus?: ProductStatusEnum
): JSX.Element => {
  const cartItems = useSelector(cartItemsSelector)
  const cartItem = cartItems.find((item) => {
    if (item.sku === sku) {
      return item
    }
  })

  const [storeModal, setStoreModal] = useState(false)

  const handleModal = () => {
    setStoreModal(true)
  }
  return (
    <li key={methodName} className="flex gap-2 typography-small py-3">
      {icon}
      <div>
        <span className="font-bold">{t(heading)} </span>
        <>
          {!cartItem?.pickupStore?.id && (
            <Button
              variant={ButtonVariantEnum.textLink}
              className="block"
              onClick={handleModal}
              disabled={
                prodStatus === ProductStatusEnum.Discontinued ||
                prodStatus === undefined
              }
            >
              {t(
                'pdp_product_sections_quickOverview_content_shipping_chooseStore'
              )}
            </Button>
          )}
          {cartItem?.pickupStore?.id && (
            <>
              <div className="pt-1">
                <span className="font-bold">{cartItem?.pickupStore?.name}</span>
                <Button
                  variant={ButtonVariantEnum.textLink}
                  className="block"
                  onClick={handleModal}
                  disabled={
                    prodStatus === ProductStatusEnum.Discontinued ||
                    prodStatus === undefined
                  }
                >
                  {t(
                    'pdp_product_sections_quickOverview_content_shipping_change'
                  )}
                </Button>
              </div>
            </>
          )}
          {storeModal && (
            <Storelist
              sku={sku}
              onCloseModal={() => setStoreModal(false)}
              skuLineItemId={cartItem ? cartItem?.id : 'noSku'}
              onConfirmModalClose={() => setStoreModal(false)}
            />
          )}
        </>
      </div>
    </li>
  )
}

const FreeDeliveryMethod = (
  methodName: string,
  icon: React.FunctionComponentElement<React.SVGProps<SVGSVGElement>>,
  t: any,
  wideDelivery?: string
): JSX.Element => {
  return (
    <li key={methodName}>
      {wideDelivery === 'CashAndCarry' ? (
        <ul>
          <li className="flex gap-2 typography-small py-3">
            {icon}
            <span className="flex-1">
              <span className="typography-small-strong">
                {t('pdp_product_shipping_free_delivery_cash_carry_heading')}
              </span>{' '}
              <span>
                {t('pdp_product_shipping_free_delivery_cash_carry_content_1')}
              </span>{' '}
              <span className="typography-small-strong">
                {t('pdp_product_shipping_free_delivery_cash_carry_suffix_1')}
              </span>
            </span>
          </li>
          <li className="flex gap-2 typography-small py-3">
            {icon}
            <span className="flex-1">
              <span className="typography-small-strong">
                {t('pdp_product_shipping_free_delivery_cash_carry_heading')}
              </span>{' '}
              <span>
                {t('pdp_product_shipping_free_delivery_cash_carry_content_2')}
              </span>{' '}
              <span className="typography-small-strong">
                {t('pdp_product_shipping_free_delivery_cash_carry_suffix_2')}
              </span>
            </span>
          </li>
        </ul>
      ) : wideDelivery === 'DeliveryAndInstallation' ? (
        <div className="flex gap-2 typography-small py-3">
          {icon}
          <span className="flex-1">
            {t(
              'pdp_product_shipping_free_delivery_delivery_installation_content'
            )}
          </span>
        </div>
      ) : (
        <></>
      )}
    </li>
  )
}

const ScheduledDeliveryMethod = (
  methodName: string,
  icon: React.FunctionComponentElement<React.SVGProps<SVGSVGElement>>,
  t: any,
  wideDelivery?: string
): JSX.Element => {
  return (
    <li key={methodName} className="flex gap-2 typography-small py-3">
      {icon}
      <span className="flex-1">
        <span className="typography-small-strong">
          {t('pdp_product_scheduled_delivery_cash_carry_heading')}
        </span>{' '}
        <span>
          {t('pdp_product_shipping_scheduled_delivery_cash_carry_content_1')}
        </span>{' '}
      </span>
    </li>
  )
}

const OneHourExpressDeliveryMethod = (
  methodName: string,
  icon: React.FunctionComponentElement<React.SVGProps<SVGSVGElement>>,
  surcharge: string | null,
  t: any
): JSX.Element => {
  return (
    <li key={methodName} className="flex gap-2 typography-small py-3">
      {icon}
      <div className="flex-1">
        <div className="pb-1">
          <span className="font-bold">
            {t('pdp_product_shipping_express_delivery_1hrs_heading')}{' '}
          </span>
          <span>({surcharge || t('deliveryMethod_free')})</span>
        </div>
        <div className="typography-label">
          {t('pdp_product_shipping_express_delivery_1hrs_content')}
        </div>
      </div>
    </li>
  )
}

const ExpressDeliveryMethod = (
  methodName: string,
  icon: React.FunctionComponentElement<React.SVGProps<SVGSVGElement>>,
  surcharge: string | null,
  t: any
): JSX.Element => {
  return (
    <li key={methodName} className="flex gap-2 typography-small py-3">
      {icon}
      <div className="flex-1">
        <div className="pb-1">
          <span className="font-bold">
            {t('pdp_product_shipping_express_delivery_2hrs_heading')}{' '}
          </span>
          <span>({surcharge || t('deliveryMethod_free')})</span>
        </div>
        <div className="typography-label">
          {t('pdp_product_shipping_express_delivery_2hrs_content')}
        </div>
      </div>
    </li>
  )
}

const renderDeliveryMethod = (
  method: DeliveryMethodType,
  sku: string,
  t: any,
  prodStatus?: ProductStatusEnum,
  wideDelivery?: string,
  countryId?: string
) => {
  const details = DeliveryDetails(method)
  if (!details) {
    return
  }
  if (countryId === 'kw' && method.name === 'FreeDelivery') {
    return
  }
  if (countryId === 'sa' && method.name === 'ScheduledDelivery') {
    return
  }
  if (countryId === 'sa' && method.name === '1-Hour-Express') {
    return
  }
  const icon = React.createElement(details.icon, {
    className: 'h-6 w-6 stroke-current text-gray-900',
  })
  switch (method.name) {
    case 'ClickAndCollect':
      return ClickAndCollectMethod(
        method.name,
        details.translationKey,
        icon,
        sku,
        t,
        prodStatus
      )
    case 'FreeDelivery':
      return FreeDeliveryMethod(method.name, icon, t, wideDelivery)
    case 'ScheduledDelivery':
      return ScheduledDeliveryMethod(method.name, icon, t, wideDelivery)
    case '1-Hour-Express':
      return OneHourExpressDeliveryMethod(
        method.name,
        icon,
        details.surcharge,
        t
      )
    case '2-Hours-Express':
    case '3-Hours-Express':
      return ExpressDeliveryMethod(method.name, icon, details.surcharge, t)
  }
}

const ProductDeliveryMethods = ({
  methods,
  sku,
  prodStatus,
  wideDelivery,
}: {
  methods: DeliveryMethodType[]
  sku: string
  prodStatus: ProductStatusEnum | undefined
  wideDelivery?: string
}): JSX.Element => {
  const { t } = useTranslation()
  const router = useRouter()
  const {
    country: { id: countryId },
  } = localesFactory.createFromHrefLang(router?.locale).current
  return (
    <ul>
      {methods.map((method) =>
        renderDeliveryMethod(
          method,
          sku,
          t,
          prodStatus,
          wideDelivery,
          countryId
        )
      )}
    </ul>
  )
}

export default ProductDeliveryMethods
