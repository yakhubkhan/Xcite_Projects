import React, { ComponentType } from 'react'

export class ComponentRegistry {
  private readonly componentMap: Record<
    string,
    React.ComponentType | React.FunctionComponent<any>
  >

  constructor(
    map: Record<string, ComponentType | React.FunctionComponent<any>>
  ) {
    this.componentMap = map
  }

  getComponent(
    name: string
  ): React.ComponentClass | React.FunctionComponent | null {
    if (name in this.componentMap) {
      return this.componentMap[name]
    }
    return null
  }
}
