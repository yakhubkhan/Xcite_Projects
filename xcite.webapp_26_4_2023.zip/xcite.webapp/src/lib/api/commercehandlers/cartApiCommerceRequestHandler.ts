import { DefaultApiCommerceRequestHandler } from './defaultApiCommerceRequestHandler'
import { CommercetoolsUserStorePayload } from '../../../types/api'
import { CartType } from '../../../types/content'
import commerceFacadeClient from '../clients/commercefacade/commerceFacadeClient'

class CartApiCommerceRequestHandler extends DefaultApiCommerceRequestHandler {
  async handleRequest(
    payload: CommercetoolsUserStorePayload
  ): Promise<CartType> {
    return commerceFacadeClient.cart.getCartByUserId(payload)
  }
  async handleUpdateCartGroupingRequest(
    payload: CommercetoolsUserStorePayload
  ): Promise<CartType> {
    return commerceFacadeClient.cart.updateCartGroupingByUserId(payload)
  }
}

export const cartApiCommerceRequestHandler = new CartApiCommerceRequestHandler()
