import { commercetoolsDiscountPayload } from '../../../types/api'
import { CartType, DiscountErrorResponseType } from '../../../types/content'
import commerceFacadeClient from '../clients/commercefacade/commerceFacadeClient'
import { DefaultApiCommerceRequestHandler } from './defaultApiCommerceRequestHandler'

class AddAndRemoveDiscountRequestHandler extends DefaultApiCommerceRequestHandler {
  async handleAddRequest(
    payload: commercetoolsDiscountPayload
  ): Promise<CartType | DiscountErrorResponseType> {
    return commerceFacadeClient.cart.addDiscount(payload)
  }
  async handleRemoveRequest(
    payload: commercetoolsDiscountPayload
  ): Promise<CartType> {
    return commerceFacadeClient.cart.removeDiscount(payload)
  }
}

export const addAndRemoveDiscountRequestHandler =
  new AddAndRemoveDiscountRequestHandler()
