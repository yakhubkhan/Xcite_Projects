import { DefaultApiCommerceRequestHandler } from './defaultApiCommerceRequestHandler'
import {
  CommerceToolsOrderPayload,
  CommerceToolsOrderReprintPayload,
} from '../../../types/api'
import { OrderReprint, Order } from '../../../types/content'
import commerceFacadeClient from '../clients/commercefacade/commerceFacadeClient'

class OrderDetailsApiCommerceRequestHandler extends DefaultApiCommerceRequestHandler {
  async handleRequest(payload: CommerceToolsOrderPayload): Promise<Order> {
    return commerceFacadeClient.order.getOrderDetails(payload)
  }
  async handleReprintRequest(
    payload: CommerceToolsOrderReprintPayload
  ): Promise<OrderReprint> {
    return commerceFacadeClient.order.getOrdersReprint(payload)
  }
}

export const orderDetailsApiCommerceRequestHandler =
  new OrderDetailsApiCommerceRequestHandler()
