import { DefaultApiCommerceRequestHandler } from './defaultApiCommerceRequestHandler'
import { AvailableWarranties } from '../../../types/content'
import commerceFacadeClient from '../clients/commercefacade/commerceFacadeClient'
import { CommercetoolsGetAvailableWarrantiesPayload } from '../../../types/raw/ctWarranty'

class GetWarrantiesCommerceRequestHandler extends DefaultApiCommerceRequestHandler {
  async handleRequest(
    payload: CommercetoolsGetAvailableWarrantiesPayload
  ): Promise<AvailableWarranties[]> {
    return commerceFacadeClient.warranty.getWarranties(payload)
  }
}

export const getWarrantiesCommerceRequestHandler =
  new GetWarrantiesCommerceRequestHandler()
