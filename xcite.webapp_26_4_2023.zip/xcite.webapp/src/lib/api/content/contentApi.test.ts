/* eslint-disable @typescript-eslint/no-var-requires */
import { getContent } from './contentApi'
import { ContentApiRequest } from './ContentApiRequest'
import { ApiRequestHandler } from '../handlers/ApiRequestHandler'
import { enKW } from '../l18n/LocalesFactory'
import ProductDetailPageHandler from '../handlers/ProductDetailPageHandler'
import ProductCategoryPageHandler from '../handlers/ProductCategoryPageHandler'

jest.mock('next')

const defaultApiRequestHandler =
  require('../handlers/DefaultApiRequestHandler').default

describe('it should call the right page handler depending on request', () => {
  jest.mock('../handlers/ProductDetailPageHandler')
  jest.mock('../handlers/ProductCategoryPageHandler')

  const testCase = (
    url: string,
    expectedPath: string,
    expectedHandler: ApiRequestHandler,
    expectedLocale
  ) => {
    it(`calls correct handler for ${url}`, async () => {
      const spyResolve = jest
        .spyOn(expectedHandler, 'resolveRequest')
        .mockImplementationOnce((contentApiRequest): Promise<any> => {
          expect(contentApiRequest).toBeInstanceOf(ContentApiRequest)
          expect(contentApiRequest.pathname).toBe(expectedPath)
          expect(contentApiRequest.locale).toEqual(expectedLocale)
          return Promise.resolve({})
        })

      await getContent(url, enKW.hreflang)
      expect(spyResolve).toHaveBeenCalledTimes(1)
    })
  }

  testCase('/', '/', defaultApiRequestHandler, enKW)
  testCase(
    '/my_product/p',
    '/my_product/p',
    ProductDetailPageHandler.prototype,
    enKW
  )
  testCase(
    '/my_category/c',
    '/my_category/c',
    ProductCategoryPageHandler.prototype,
    enKW
  )
})
