import axios, { AxiosRequestConfig, AxiosResponse } from 'axios'
import environment from '../../../environment'
import { ProductClient } from './productClient'
import { CommercetoolsUserStorePayload } from '../../../../types/api'
import { CartClient } from './cartClient'
import { UserProfileType } from '../../../../types/content'
import { InventoryClient } from './inventoryClient'
import { OrderClient } from './orderClient'
import { PaymentClient } from './paymentClient'
import { DeliveryClient } from './deliveryClient'
import { WarrantyClient } from './warrantyClient'
import { CustomersClient } from './customersClient'

class CommerceFacadeClient {
  product = new ProductClient()
  cart = new CartClient()
  inventoryClient = new InventoryClient()
  order = new OrderClient()
  payment = new PaymentClient()
  delivery = new DeliveryClient()
  warranty = new WarrantyClient()
  customers = new CustomersClient()

  public proxyToCommerceBackend = async (
    request: AxiosRequestConfig
  ): Promise<AxiosResponse> => {
    request.paramsSerializer = (params) => {
      let searchParams = ''
      Object.keys(params).forEach((paramKey) => {
        const paramVal = params[paramKey]
        if (Array.isArray(paramVal)) {
          paramVal.forEach((param) => {
            searchParams = `${searchParams}${paramKey}=${encodeURIComponent(
              param
            )}&`
          })
        } else {
          searchParams = `${searchParams}${paramKey}=${encodeURIComponent(
            paramVal
          )}&`
        }
      })
      searchParams = searchParams.substring(0, searchParams.length - 1)
      return searchParams
    }

    return axiosClient.request(request)
  }
}

const axiosClient = axios.create({
  baseURL: environment.apiBackendBaseUrlPublic,
})

export const fetchBackendDataWithoutCache = async (
  url: string,
  request?: CommercetoolsUserStorePayload
) => {
  const config = await setupConfigCacheOff(request)
  try {
    const { data } = await axiosClient.get(url, config)
    return data
  } catch (error) {
    throw error
  }
}
const setupConfigCacheOff = async (request?: CommercetoolsUserStorePayload) => {
  const config: AxiosRequestConfig = {}
  if (request?.token) {
    config.headers = { Authorization: request?.token }
    config.headers = { 'cache-control': 'no-cache' }
    config.headers = { pragma: 'no-cache' }
    return config
  }

  return config
}

export const fetchBackendData = async (
  url: string,
  request?: CommercetoolsUserStorePayload
) => {
  const config = await setupConfig(request)
  try {
    const { data } = await axiosClient.get(url, config)
    return data
  } catch (error) {
    throw error
  }
}

const setupConfig = async (request?: CommercetoolsUserStorePayload) => {
  const config: AxiosRequestConfig = {}
  if (request?.token) {
    config.headers = { Authorization: request?.token }

    return config
  }

  return config
}

export const postBackendData = async (
  url: string,
  reqBody,
  request: CommercetoolsUserStorePayload
) => {
  const config = await setupConfig(request)
  try {
    const { data } = await axiosClient.post(url, reqBody, config)
    return data
  } catch (error) {
    throw error
  }
}

export const deleteBackendData = async (
  url: string,
  request: CommercetoolsUserStorePayload
) => {
  const config = await setupConfig(request)
  try {
    const { data } = await axiosClient.delete(url, config)
    return data
  } catch (error) {
    throw error
  }
}

const commerceFacadeClient = new CommerceFacadeClient()

export default commerceFacadeClient
