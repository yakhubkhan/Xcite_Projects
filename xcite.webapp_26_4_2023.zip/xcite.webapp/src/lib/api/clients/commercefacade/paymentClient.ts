import {
  CommerceToolsPaymentAddMethodPayload,
  CommercetoolsUserStorePayload,
} from '../../../../types/api'
import { CartType, PaymentMethodType } from '../../../../types/content'
import {transformPaymentMethods} from '../../processors/PaymentMethodsProcessor'
import { fetchBackendData, postBackendData } from './commerceFacadeClient'
import transformCart from '../../processors/CartProcessor'
import { userUrlParams } from '../BFF/baseClient'

export class PaymentClient {
  public getPaymentMethods = async (
    payload: CommercetoolsUserStorePayload
  ): Promise<PaymentMethodType[]> => {
    const { store, locale = '', user, deviceType } = payload
    let device = ''
    if (deviceType === 'ios' || deviceType === 'android') {
      device = deviceType
    } else {
      device = 'web'
    }
    try {
      const data = await fetchBackendData(
        `/payments/methods?${userUrlParams(
          user
        )}store=${store}&deviceType=${device}`,
        payload
      )
      return transformPaymentMethods(data, locale)
    } catch (error) {
      throw error
    }
  }

  public addPaymentMethodToCart = async (
    payload: CommerceToolsPaymentAddMethodPayload
  ): Promise<CartType> => {
    const {
      paymentMethod,
      store,
      user,
      language,
      locale = '',
      reqBody,
    } = payload
    try {
      const data = await postBackendData(
        `payments/cart/add/${paymentMethod}?${userUrlParams(
          user
        )}store=${store}`,
        reqBody,
        payload
      )
      return transformCart(data, store, language, locale)
    } catch (error) {
      throw error
    }
  }
}
