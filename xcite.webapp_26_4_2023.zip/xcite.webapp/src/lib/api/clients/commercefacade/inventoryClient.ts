import { CartType, PickupStoresType } from '../../../../types/content'
import transformPickupStores from '../../processors/PickupStoresProcessor'
import transformCart from '../../processors/CartProcessor'
import {
  deleteBackendData,
  fetchBackendData,
  postBackendData,
} from './commerceFacadeClient'
import {
  CommercetoolsCartUpdateItemPickupPayload,
  CommercetoolsLoadStoresPayload,
} from '../../../../types/raw/ctInventory'
import { CommerceToolsUpdateLineItemPayload } from '../../../../types/raw/ctCart'
import { userUrlParams } from '../BFF/baseClient'

export class InventoryClient {
  loadStoresToPickup = async (
    payload: CommercetoolsLoadStoresPayload
  ): Promise<PickupStoresType> => {
    try {
      const { sku, store, location, locale = '' } = payload
      const stores = await fetchBackendData(
        `/inventory/store-pickup/${sku}?store=${store}&latitude=${
          location?.lat || ''
        }&longitude=${location?.lng || ''}&locale=${locale}`
      )

      return transformPickupStores(stores, locale)
    } catch (error) {
      throw error
    }
  }

  removeStorePickup = async (
    payload: CommerceToolsUpdateLineItemPayload
  ): Promise<CartType> => {
    const { lineItemId, store = 'kw', user, language, locale = '' } = payload
    try {
      const data = await deleteBackendData(
        `/inventory/store-pickup/remove/${lineItemId}?${userUrlParams(
          user
        )}store=${store}`,
        payload
      )
      return transformCart(data, store, language, locale)
    } catch (err) {
      throw err
    }
  }

  updateStorePickup = async (
    payload: CommercetoolsCartUpdateItemPickupPayload
  ): Promise<CartType> => {
    const {
      lineItemId,
      store = 'kw',
      user,
      language,
      locale = '',
      cartSetClickAndCollectOptionsDTO,
    } = payload

    try {
      const data = await postBackendData(
        `/inventory/store-pickup/${lineItemId}?${userUrlParams(
          user
        )}store=${store}`,
        cartSetClickAndCollectOptionsDTO,
        payload
      )
      return transformCart(data, store, language, locale)
    } catch (err) {
      throw err
    }
  }
}
