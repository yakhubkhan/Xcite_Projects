import environment from '../../environment'
import axios from 'axios'
import { ContentKeyMapType, ContentNavigationPayload } from '../../../types/api'
import { MediaType } from '../../../types/content'
import { AmplienceContentKeyMapType } from '../../../types/amplience'
import localesFactory from '../l18n/LocalesFactory'
import { transformNavigationNodes } from '../processors/utils'

class AmplienceClient {
  public static getContentApiParams(targetLocale: string) {
    return {
      depth: 'all',
      format: 'inlined',
      locale: targetLocale,
    }
  }

  private static getBaseUrl(vse = '') {
    return vse
      ? `https://${vse}`
      : environment.apiAmplienceEnableUncachedApi
      ? environment.apiAmplienceUncachedBaseUrl
      : environment.apiAmplienceBaseUrl
  }

  private static getRequestPayload(
    contentKeyMap: ContentKeyMapType,
    targetLocale: string
  ) {
    let requests = []
    for (const prop of Object.keys(contentKeyMap)) {
      requests = requests.concat(
        contentKeyMap[prop].map((key) => {
          return { key }
        })
      )
    }
    return {
      parameters: this.getContentApiParams(targetLocale),
      requests: requests,
    }
  }

  public getContentById(id: string, targetLocale: string, vse) {
    const url = `${AmplienceClient.getBaseUrl(vse)}/content/id/${id}`
    return axios
      .get(url, {
        params: AmplienceClient.getContentApiParams(
          getAmplienceFallbackChain(targetLocale)
        ),
      })
      .then((result) => {
        return result.data
      })
      .catch((error) => {
        throw error
      })
  }

  /**
   * fetch requested content types via post request
   * @param contentKeyMap
   * @param targetLocale en-KW or en-SA,en-KW
   * @param vse Amplience Virtual Staging Environment (hostname without protocol)
   */
  public getContents(
    contentKeyMap: ContentKeyMapType,
    targetLocale: string,
    vse: string
  ): Promise<AmplienceContentKeyMapType> {
    return axios
      .post(
        `${AmplienceClient.getBaseUrl(vse)}/content/fetch`,
        AmplienceClient.getRequestPayload(
          contentKeyMap,
          getAmplienceFallbackChain(targetLocale)
        )
      )
      .then((result) => {
        const response: Record<string, any> = {}
        for (const prop of Object.keys(contentKeyMap)) {
          response[prop] = this.findFirstMatchingContent(
            contentKeyMap[prop],
            result.data?.responses
          )
        }
        return response as AmplienceContentKeyMapType
      })
      .catch((error) => {
        throw error
      })
  }

  private findFirstMatchingContent(contentKeys, responses) {
    for (const contentKey of contentKeys) {
      const matchingContent = responses?.find((el) => {
        return (
          !el.hasOwnProperty('error') &&
          el.content?._meta?.deliveryKey === contentKey
        )
      })
      if (matchingContent) {
        return matchingContent
      }
    }
    return null
  }

  public async getMediaSetMetaData(
    sku: string,
    localeKey: string
  ): Promise<MediaType[]> {
    const imageSetUrl = `${environment.apiAmplienceDamBaseUrl}/s/${environment.apiAmplienceDamHubname}/${sku}-SET.json?deep=true`
    const media: MediaType[] = await axios.get(imageSetUrl).then((res) => {
      const localizedSet = res.data.items?.find(
        (item) =>
          item.type == 'set' &&
          item.name.toLowerCase() == `${sku}-${localeKey}-SET`.toLowerCase()
      )
      if (localizedSet) {
        return localizedSet.set?.items ? localizedSet.set?.items : []
      } else {
        const assets = res.data?.items?.filter((item) => item.type != 'set')
        return assets ? assets : []
      }
    })
    return media
  }

  public getContentByKey(key: string, targetLocale: string, vse = '') {
    const url = `${AmplienceClient.getBaseUrl(vse)}/content/key/${key}`
    return axios
      .get(url, {
        params: AmplienceClient.getContentApiParams(
          getAmplienceFallbackChain(targetLocale)
        ),
      })
      .then((result) => {
        return result.data
      })
      .catch((error) => {
        throw error
      })
  }

  public async getChannelNavigation(payload: ContentNavigationPayload) {
    const locale = localesFactory.createFromHrefLang(payload.locale).current
    const {
      country: { id: countryCode },
      hreflang: localeKey,
    } = locale

    try {
      const amplienceNavigation = await amplienceClient.getContentByKey(
        `xc/${payload.channel}/navigation/${countryCode}`,
        localeKey,
        ''
      )

      return transformNavigationNodes(amplienceNavigation.content, locale)
    } catch (error) {
      throw error
    }
  }
}

const getAmplienceFallbackChain = (localeKey) => {
  switch (localeKey) {
    case 'ar-KW':
      return 'ar-KW,en-KW'
    case 'en-SA':
      return 'en-SA,en-KW'
    case 'ar':
    case 'ar-SA':
      return 'ar-SA,en-SA,ar-KW,en-KW'
    default:
      return 'en-KW'
  }
}

const amplienceClient = new AmplienceClient()
export default amplienceClient
