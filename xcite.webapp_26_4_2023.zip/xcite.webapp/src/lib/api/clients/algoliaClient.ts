import getConfig from 'next/config'
import algoliasearch from 'algoliasearch'
import { findResultsState } from 'react-instantsearch-dom/server'

import {
  AlgoliaContextsEnum,
  AlgoliaProduct,
  AlgoliaSearchProps,
} from '../../../types/algolia'
import AlgoliaSearch from '../../../components/organisms/AlgoliaSearch'
import environment from '../../environment'
import { Locale } from '../l18n/Locale'
import localesFactory from '../l18n/LocalesFactory'

class AlgoliaClient {
  private readonly DEFAULT_RESULT_COUNT = 20

  client = algoliasearch(
    getConfig().publicRuntimeConfig.algolia.indexName,
    getConfig().publicRuntimeConfig.algolia.apiKey
  )

  public findProductsByCategory(
    categoryKey: string,
    locale: Locale,
    maxResults?: number,
    ruleContexts?: AlgoliaContextsEnum[]
  ) {
    const index = this.client.initIndex(locale.algoliaIndex)
    return index
      .search<AlgoliaProduct>('', {
        filters: `categoryKeys:${categoryKey}`,
        ruleContexts,
        offset: 0,
        length: maxResults || this.DEFAULT_RESULT_COUNT,
      })
      .catch((error) => {
        console.error('algolia error', error)
        throw error
      })
  }

  public triggerAlgoliaSearch = async (
    searchQuery: string,
    categoryName = '',
    hrefLang = environment.defaultLocale
  ): Promise<AlgoliaSearchProps> => {
    const locale = localesFactory.createFromHrefLang(hrefLang).current
    const {
      algoliaSortIndex: algoliaSortIndexNames,
      algoliaSortIndex: { relevancy: indexName },
    } = locale

    const resultsState = await findResultsState(AlgoliaSearch, {
      algoliaSortIndexNames,
      categoryName,
      indexName,
      hrefLang,
      searchClient: this.client,
      searchQuery,
    })

    return {
      indexName,
      algoliaSortIndexNames,
      resultsState: JSON.parse(JSON.stringify(resultsState)),
      categoryName,
      hrefLang,
      searchQuery,
    }
  }
}

const algoliaClient = new AlgoliaClient()
export default algoliaClient
