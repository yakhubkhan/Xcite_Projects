import {
  RAPOrderHistory,
  RAPOrderHistoryAPIPayload,
} from '../../../../types/rap'
import { BaseController } from './baseController'

export class OrdersController extends BaseController {
  public getOrderHistory = async (
    payload: RAPOrderHistoryAPIPayload
  ): Promise<RAPOrderHistory> => {
    const { customerId, offset, recordCount, salesOrg } = payload

    try {
      const response = await this.client.get(
        `/getorderstatus?customerId=${customerId}&offset=0${offset}&recordCount=${recordCount}&salesOrg=${salesOrg}`
      )
      return response.data
    } catch (error) {
      console.error(error)
      throw error
    }
  }
}
