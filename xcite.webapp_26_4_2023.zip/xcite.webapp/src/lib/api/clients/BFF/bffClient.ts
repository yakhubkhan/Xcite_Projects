import AddressClient from './addressClient'
import CartClient from './cartClient'
import PaymentClient from './paymentClient'
import ProfileClient from './profileClient'
import InventoryClient from './inventoryClient'
import WarrantyClient from './warrantyClient'
import OrderClient from './orderClient'
import DeliveryClient from './delivery'
import MobileConfigMagentoClient from './mobileConfigMagento'
import MobileConfigProdClient from './mobileConfigProd'
import MobileConfigStageClient from './mobileConfigStage'
import MobileConfigDevClient from './mobileConfigDev'

class BFFClient {
  public static cart = new CartClient()
  public static address = new AddressClient()
  public static payment = new PaymentClient()
  public static profile = new ProfileClient()
  public static inventory = new InventoryClient()
  public static warranty = new WarrantyClient()
  public static order = new OrderClient()
  public static delivery = new DeliveryClient()
  public static mobileConfigDev = new MobileConfigDevClient()
  public static mobileConfigStage = new MobileConfigStageClient()
  public static mobileConfigProd = new MobileConfigProdClient()
  public static mobileConfigMagento = new MobileConfigMagentoClient()
}

export default BFFClient
