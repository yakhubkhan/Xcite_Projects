import { BaseClient, userUrlParams } from './baseClient'
import { OrderPagedResult } from '../../../../types/content'
import { reportErrorUtils } from '../../../../util/reportErrorUtils'
import { CommercetoolsPaginationPayload } from '../../../../types/api'

class ProfileClient extends BaseClient {
  public getOrderHistory = async (
    params: CommercetoolsPaginationPayload
  ): Promise<OrderPagedResult> => {
    const { store, user, language, offset, limit, locale } = params

    const config = await this.setHeaders(user.authenticated)

    try {
      const response = await this.client.get(
        `/com/orders?${userUrlParams(
          user
        )}store=${store}&offset=${offset}&language=${language}&locale=${locale}&limit=${limit}`,
        config
      )
      return response.data
    } catch (error) {
      if (error instanceof Error) {
        return reportErrorUtils(error)
      }
      throw error
    }
  }
}

export default ProfileClient
