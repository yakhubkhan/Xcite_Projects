import axios, { AxiosRequestConfig } from 'axios'
import { Auth } from 'aws-amplify'
import { transformEnumerations } from '../processors/ProfileProcessor'
import {
  PaymentMethodType,
  ResourceEnumType,
  UserProfileType,
} from '../../../types/content'
import { reportErrorUtils } from '../../../util/reportErrorUtils'

const axiosClient = axios.create({
  baseURL: '/api',
})

async function setupConfig(needsToken: boolean) {
  const config: AxiosRequestConfig = {}
  if (needsToken) {
    const session = await Auth.currentSession()
    const token = session.getIdToken().getJwtToken()
    config.headers = { Authorization: `Bearer ${token}` }
  }
  return config
}

const fetchBackendData = async (url: string, needsToken = false) => {
  const config = await setupConfig(needsToken)
  try {
    const { data } = await axiosClient.get(url, config)
    return data
  } catch (error) {
    throw error
  }
}

const postBackendData = async (url: string, reqBody, needsToken = false) => {
  const config = await setupConfig(needsToken)
  try {
    const { data } = await axiosClient.post(url, reqBody, config)
    return data
  } catch (error) {
    throw error
  }
}

export const getAuthenticatedCustomer = async (
  ctUserName: string
): Promise<UserProfileType> => {
  try {
    const meCustomer = await fetchBackendData(
      `customers/me?id=${ctUserName}`,
      true
    )
    return meCustomer
  } catch (error) {
    if (error instanceof Error) {
      return reportErrorUtils(error)
    }
    throw error
  }
}

export const postAuthenticatedCustomer = async (payload: {
  ctUserName: string
  profileData
}): Promise<UserProfileType> => {
  try {
    const { ctUserName, profileData } = payload
    const meCustomer = await postBackendData(
      `customers/me?id=${ctUserName}`,
      profileData,
      true
    )
    return { ...meCustomer, id: ctUserName }
  } catch (error) {
    if (error instanceof Error) {
      return reportErrorUtils(error)
    }
    throw error
  }
}

export const getEnumByResource = async (payload: {
  localeKey: string
  resourceId: string
  query: string
}): Promise<ResourceEnumType> => {
  const { resourceId, query, localeKey } = payload
  try {
    const enumVal = await fetchBackendData(
      `enumerations/${resourceId}?${query}`,
      true
    )
    return transformEnumerations(enumVal, localeKey)
  } catch (error) {
    if (error instanceof Error) {
      return reportErrorUtils(error)
    }
    throw error
  }
}

export const getCustomerExists = async (
  userName: string
): Promise<{ customerStatus: string; mfaMethod: string }> => {
  try {
    const customerExists = await fetchBackendData(
      `/customers/exists?emailOrPhoneNumber=${encodeURIComponent(userName)}`
    )
    return customerExists
  } catch (err) {
    throw err
  }
}
