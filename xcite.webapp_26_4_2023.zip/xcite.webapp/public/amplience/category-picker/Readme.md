# Amplience Category Picker

## What does it do?

This UI widget extends Amplience to provide a multi locale category picker. Since the SDK does not provide an event
listener we will not get notified on changes of the selected locales. Instead we show always all available languages.
The same approach is taken by the localization extension (https://github.com/amplience/dc-extension-localization).

Use http://localhost:3000/amplience/category-picker/index.html?local=1 for standalone testing as the query param will
use a dummy SDK instead of the original SDK.

How to use Extensions in Dynamic Content: https://amplience.com/docs/development/extensions.html  
Dynamic Content SDK: https://github.com/amplience/dc-extensions-sdk

The picker uses the BFF `(/api/amplience/categories?locale=...)` to fetch the category lists depending on locale from
the backend.
