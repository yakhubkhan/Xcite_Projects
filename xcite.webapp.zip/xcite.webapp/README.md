This is a [Next.js](https://nextjs.org/) project bootstrapped
with [`create-next-app`](https://github.com/vercel/next.js/tree/canary/packages/create-next-app).

## Dependencies
Required Node version: 16.x

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `pages/index.tsx`. The page auto-updates as you edit the file.

[API routes](https://nextjs.org/docs/api-routes/introduction) can be accessed
on [http://localhost:3000/api/hello](http://localhost:3000/api/hello). This endpoint can be edited
in `pages/api/hello.tsx`.

The `pages/api` directory is mapped to `/api/*`. Files in this directory are treated
as [API routes](https://nextjs.org/docs/api-routes/introduction) instead of React pages.

### Building components

All Building blocks of the website, are defined in the `src/components` folder, and distributed based on the [Atomic Design](https://bradfrost.com/blog/post/atomic-web-design/) methodology:

- Atoms: basic building blocks
- Molecules: groups of atoms bonded together and the smallest fundamental units of a compound
- Organisms: groups of molecules joined together to form a relatively complex, distinct section of an interface.
- Templates: Templates consist mostly of groups of organisms stitched together to form pages

Each component should contain the following template:

- **index.js**: Entry point of the component
- **componentName.tsx**: Declaration of the JSX Markup and logic for the Component
- **componentName.module.css**: Custom style for that component (_Optional_)
- **./\_\_tests\_\_/componentName.test.tsx**: Unit tests and snapshot tests for that component
- **./\_\_tests\_\_/\_\_snapshots\_\_/\*\***: Auto generated snapshosts in case of using snapshot tests
- **componentName.stories.js**: Story for that component to be shown in Storybook

## Building

**Build app for production**

    npm run build

See [Next.js build documentation for details](https://nextjs.org/docs/deployment)

**Build docker image**

    npm run build-image

## Running

**Run Next.js**

    npm run start

**Run in Docker**

    npm run start-docker

## Running tests and creating reports

For this project we use [Jest](https://jestjs.io/) and [React Testing Library](https://testing-library.com/docs/react-testing-library/intro) for Unit Tests and [React Test Renderer](https://reactjs.org/docs/test-renderer.html) for Snapshot Testing.

In order to run all unit tests you can run

`npm run test`

OR

`npm run test:dev` for running teests in watch mode.

Additionnally you can run `npm run test:udpateSnapshots` to update the snapshots if they are failing

### Bundle Analysis

Run Bundle Analyzer

```
npm run analyze
```

The outcome will be generated in the `.next/analyze` directory

### Caching

In production all responses for CMS content will have cache headers added.
The timings can be set using ENV variables with the following names

    HTTP_CACHE_SMAXAGE
    NEXT_PUBLIC_HTTP_STALE_WHILE_REVALIDATE
    NEXT_PUBLIC_HTTP_STALE_IF_ERROR

## Relevant documentation

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js/) - your feedback and contributions
are welcome!
