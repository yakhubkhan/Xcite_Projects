// eslint-disable-next-line @typescript-eslint/no-var-requires
const { i18n } = require('./next-i18next.config.js')

// eslint-disable-next-line @typescript-eslint/no-var-requires
const withBundleAnalyzer = require('@next/bundle-analyzer')({
  enabled: process.env.ANALYZE === 'true',
})

const ContentSecurityPolicy = `
  default-src * data: 'unsafe-inline';
  script-src * data: 'unsafe-inline' 'unsafe-eval';
  style-src * data: 'unsafe-inline';
  worker-src * blob:;
  child-src blob: gap:;
  img-src * blob: data: 'unsafe-inline';
  font-src * data: 'unsafe-inline';
  media-src * data: 'unsafe-inline';
  object-src * data: 'unsafe-inline';
  prefetch-src * data: 'unsafe-inline';
  frame-src * data: 'unsafe-inline';
  connect-src * 'self' blob: data: 'unsafe-inline';
`

module.exports = withBundleAnalyzer({
  i18n,
  generateEtags: false,
  reactStrictMode: true,
  images: {
    domains: ['cdn.media.amplience.net'],
  },
  // Use the CDN in production and localhost for development.
  // @todo create a solution that works in local environment, too
  // assetPrefix: isProd ? 'https://cdn.xcite.com' : '',
  poweredByHeader: false,
  async rewrites() {
    return [
      {
        source: '/api/content/:slug*',
        destination: '/api/content/:slug*',
      },
      {
        source: '/:slug*/c',
        destination: '/category/:slug*',
      },
      {
        source: '/:slug*/p',
        destination: '/product/:slug*',
      },
      {
        source: '/:slug*/search',
        destination: '/search',
      },
      { source: '/robots.txt', destination: '/api/robots' },
      {
        source: '/sitemaps/sitemap-index.xml',
        destination: '/api/sitemaps/sitemap-index',
      },
      {
        source: '/sitemaps/sitemap-langs.xml',
        destination: '/api/sitemaps/sitemap-langs',
      },
      {
        source: '/sitemaps/sitemap-pages.xml',
        destination: '/api/sitemaps/sitemap-pages',
      },
      {
        source: '/sitemaps/:slug.xml',
        destination: '/api/sitemaps/:slug',
      },
      {
        source: '/apple-app-site-association',
        destination: '/api/mobile/apple-app-site-association',
      },
      {
        source: '/.well-known/apple-app-site-association',
        destination: '/api/mobile/well-known-apple-app-site-association',
      },
      {
        source: '/.well-known/assetlinks.json',
        destination: '/api/mobile/assetlinks',
      },
      {
        source: '/assetlinks.json',
        destination: '/api/mobile/assetlinks',
      },
      {
        source: '/xapi/config',
        destination: '/api/mobile/xapi/config',
      },
      {
        source: '/xapi/apikey',
        destination: '/api/mobile/xapi/apikey',
      },
      {
        source: '/xapi/store',
        destination: '/api/mobile/xapi/store',
      },
    ]
  },
  publicRuntimeConfig: {
    env: process.env.APP_ENVIRONMENT,
    awsConfig: {
      Auth: {
        region: process.env.NEXT_PUBLIC_COGNITO_REGION,
        userPoolId: process.env.NEXT_PUBLIC_COGNITO_USER_POOL_ID,
        userPoolWebClientId:
          process.env.NEXT_PUBLIC_COGNITO_USER_POOL_WEB_CLIENT_ID,
        mandatorySignIn: false,
      },
    },
    host: {
      kw: process.env.NEXT_PUBLIC_API_HOST_KW,
      sa: process.env.NEXT_PUBLIC_API_HOST_SA,
    },
    checkoutDotCom: {
      publicKeyKW: process.env.NEXT_PUBLIC_CHECKOUTCOM_API_KEY_KW,
      publicKeySA: process.env.NEXT_PUBLIC_CHECKOUTCOM_API_KEY_SA,
    },
    algolia: {
      indexName: process.env.NEXT_PUBLIC_API_ALGOLIA_APP_ID,
      apiKey: process.env.NEXT_PUBLIC_API_ALGOLIA_API_KEY,
      pageResults: process.env.NEXT_PUBLIC_API_ALGOLIA_PAGE_RESULTS || 60,
      indexDefault: process.env.NEXT_PUBLIC_API_ALGOLIA_INDEX_DEFAULT,
    },
    moengage: {
      saAppId: process.env.NEXT_PUBLIC_MOENGAGE_APP_ID_SA,
      kwAappId: process.env.NEXT_PUBLIC_MOENGAGE_APP_ID_KW,
    },
    google: {
      reCaptchaSiteKey: process.env.NEXT_PUBLIC_GOOGLE_RECAPTCHA_SITE_KEY,
      mapsAPIKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY,
    },
    gtm: {
      saContainerId: process.env.NEXT_PUBLIC_GTM_CONTAINER_ID_SA,
      kwContainerId: process.env.NEXT_PUBLIC_GTM_CONTAINER_ID_KW,
    },
    flixmedia: {
      saDistributerId: process.env.FLIXMEDIA_ID_SA,
      kwDistributerId: process.env.FLIXMEDIA_ID_KW,
    },
	tamara: {
      tamaraUrl: process.env.TAMARA_BACKEND_BASE_URL,
    },
    criteo: {
      saEnglishAccountId: process.env.NEXT_PUBLIC_CRITEO_ACCOUNT_EN_SA,
      saArabicAccountId: process.env.NEXT_PUBLIC_CRITEO_ACCOUNT_AR_SA,
      kwEnglishAccountId: process.env.NEXT_PUBLIC_CRITEO_ACCOUNT_EN_KW,
      kwArabicAccountId: process.env.NEXT_PUBLIC_CRITEO_ACCOUNT_AR_KW,
    },
    xciteStore: {
      enSaStoreID: process.env.NEXT_PUBLIC_STOREID_ACCOUNT_EN_SA,
      saArStoreID: process.env.NEXT_PUBLIC_STOREID_ACCOUNT_AR_SA,
      enKwStoreID: process.env.NEXT_PUBLIC_STOREID_ACCOUNT_EN_KW,
      saKwStoreID: process.env.NEXT_PUBLIC_STOREID_ACCOUNT_AR_KW,
    },
    amplience: {
      dam: {
        baseUrl: process.env.NEXT_PUBLIC_API_AMPLIENCE_DAM_BASEURL,
        staticBaseUrl: process.env.NEXT_PUBLIC_API_AMPLIENCE_DAM_STATIC_BASEURL,
        hubname: process.env.NEXT_PUBLIC_API_AMPLIENCE_DAM_HUBNAME,
      },
    },
    tabby: {
      publickey: process.env.NEXT_PUBLIC_TABBY_KEY,
    },
  },
  webpack: (config, { buildId, dev, isServer, defaultLoaders, webpack }) => {
    console.log(
      'isServer',
      isServer,
      'dev',
      dev,
      'Webpack processing for ',
      isServer ? 'server' : 'webapp',
      'Next.js buildId',
      buildId
    )
    config.plugins.push(
      new webpack.IgnorePlugin({
        // Ignore all test files
        resourceRegExp: /test.ts/,
      })
    )
    config.plugins.push(
      new webpack.IgnorePlugin({
        // Ignore all files in mocks directory ("context")
        resourceRegExp: /(.*?)/,
        contextRegExp: /mocks/,
      })
    )
    // Important: return the modified config
    return config
  },
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          {
            key: 'Content-Security-Policy',
            value: ContentSecurityPolicy.replace(/\s{2,}/g, ' ').trim(),
          },
        ],
      },
    ]
  },
})
