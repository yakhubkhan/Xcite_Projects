module.exports = {
  collectCoverageFrom: [
    'src/**/*.{js,jsx,ts,tsx}',
    '!src/**/*.test.{js,jsx,ts,tsx}',
    '!**/node_modules/**',
  ],
  coverageDirectory: '<rootDir>/coverage',
  coverageThreshold: {
    global: {
      branches: 50,
      functions: 50,
      lines: 50,
      statements: 50,
    },
    './src/components/': {
      branches: 40,
      statements: 40,
    },
  },
  moduleNameMapper: {
    '\\.(css)$': 'identity-obj-proxy',
    '^@components/(.*)$': '<rootDir>/src/components/$1',
    '#node-web-compat': './node-web-compat-node.js',
  },
  preset: 'ts-jest',
  setupFilesAfterEnv: ['<rootDir>/jest.setup.ts'],
  testMatch: ['**/*.test.(ts|tsx)'],
  testPathIgnorePatterns: ['<rootDir>/.next/', '<rootDir>/node_modules/'],
  transform: {
    '^.+\\.(js|jsx|ts|tsx)$': '<rootDir>/node_modules/babel-jest',
  },
  testEnvironment: 'jest-environment-jsdom',
}
process.env = Object.assign(process.env, {
  NEXT_PUBLIC_API_AMPLIENCE_BASE_URL:
    'https://alghanimpoc.cdn.content.amplience.net',
  NEXT_PUBLIC_API_AMPLIENCE_UNCACHED_BASE_URL:
    'https://55d5yq6oplzh179rl1s50y6a2.staging.bigcontent.io',
  NEXT_PUBLIC_API_AMPLIENCE_ENABLE_UNCACHED_API: 'false',
  NEXT_PUBLIC_API_HOST_KW: 'xcite.kw.localhost:3000',
  NEXT_PUBLIC_API_HOST_SA: 'xcite.sa.localhost:3000',
  NEXT_PUBLIC_API_AMPLIENCE_DAM_BASEURL: 'https://cdn.media.amplience.net',
  NEXT_PUBLIC_API_AMPLIENCE_DAM_STATIC_BASEURL:
    'https://alghanim.a.bigcontent.io/v1/static',
  NEXT_PUBLIC_API_AMPLIENCE_DAM_HUBNAME: 'alghanim',
  API_BACKEND_BASE_URL:
    'http://jwttest-env-1.eba-tzweigbt.eu-central-1.elasticbeanstalk.com/commerce',
  NEXT_PUBLIC_HTTP_ENABLE_CACHE_HEADERS: true,
  NEXT_PUBLIC_USE_MOCK: true,
  NEXT_PUBLIC_API_ALGOLIA_APP_ID: '0J1187QK1C',
  NEXT_PUBLIC_API_ALGOLIA_API_KEY:
    'YjRjMjMyMjExMzhhNGRkYzVjYzJhODc1NGE2M2UwYjFlNjgwOTcyOGU5ZjgzYThiMGFmNWQ3NjFhOWNmYTJjMmZpbHRlcnM9Jm51bWVyaWNGaWx0ZXJzPXZpc2liaWxpdHlfc2VhcmNoJTNEMQ',
  NEXT_PUBLIC_API_ALGOLIA_INDEX_DEFAULT: 'xcite_dev_',

  CF_PRODUCT_STATUS_FIELD_KW: 'status_kw',
  CF_PRODUCT_STATUS_FIELD_SA: 'status_ksa',
})
