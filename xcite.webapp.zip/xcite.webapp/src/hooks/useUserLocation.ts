import { useEffect, useState } from 'react'

interface userLocation {
  lat: number
  lng: number
}

const useUserLocation = (): userLocation | undefined => {
  const [userLocation, setUserLocation] = useState<userLocation>()

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) =>
        setUserLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        })
      )
    }
  }, [])

  return userLocation
}

export default useUserLocation
