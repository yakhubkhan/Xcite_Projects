import {
  MutableRefObject,
  useCallback,
  useEffect,
  useRef,
  useState,
} from 'react'

const useIntersectionObserver = (
  options: IntersectionObserverInit
): [MutableRefObject<null>, boolean] => {
  const [inView, setInView] = useState(false)
  const containerRef = useRef(null)

  const callbackFunction = useCallback(
    (entries: IntersectionObserverEntry[]) => {
      const [entry] = entries
      setInView(entry.isIntersecting)
    },
    []
  )

  useEffect(() => {
    const observer = new IntersectionObserver(callbackFunction, options)

    if (containerRef.current) {
      observer.observe(containerRef.current)
    }

    return () => {
      observer.disconnect()
    }
  }, [callbackFunction, options])

  return [containerRef, inView]
}

export default useIntersectionObserver
