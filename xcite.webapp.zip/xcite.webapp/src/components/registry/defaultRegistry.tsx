import React, { ComponentType } from 'react'
import {
  Banner,
  Cart,
  CheckoutConfirmation,
  ContentBlockImage,
  OrderHistory,
  Payment,
  ProductCarousel,
  Profile,
  Login,
  ReviewOrder,
  ShippingAddress,
  HeroBanner,
  ContentBlockVideo,
  ContentRowText,
  ContentRowImage,
  ContentsCarousel,
  MosaicComponent,
  HtmlComponent,
  DeliverySelection,
} from '../content'
import { ComponentRegistry } from './ComponentRegistry'

const defaultComponentMap: Record<
  string,
  ComponentType | React.FunctionComponent<any>
> = {
  twoColumnBanner: Banner,
  Cart,
  CheckoutConfirmation,
  contentBlockWithImage: ContentBlockImage,
  contentRowText: ContentRowText,
  imageRowComponent: ContentRowImage,
  ShippingAddress,
  Payment,
  ProductCarousel,
  Profile,
  Login,
  OrderHistory,
  ReviewOrder,
  herobanner: HeroBanner,
  contentsCarousel: ContentsCarousel,
  youtubeVideoBlock: ContentBlockVideo,
  mosaicComponent: MosaicComponent,
  htmlComponent: HtmlComponent,
  DeliverySelection,
}
// @todo load seo agnostic components dynamically:
// Authenticator: dynamic(() => import('../components/content/Authenticator')),

const defaultRegistry = new ComponentRegistry(defaultComponentMap)
export default defaultRegistry
