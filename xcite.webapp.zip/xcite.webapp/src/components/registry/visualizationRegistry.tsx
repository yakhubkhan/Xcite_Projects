import React, { ComponentType } from 'react'
import {
  Banner,
  ContentBlockImage,
  ContentBlockVideo,
  ContentRowImage,
  ContentRowText,
  ContentsCarousel,
  HeroBanner,
  HtmlComponent,
  MosaicComponent,
  ProductCarousel,
} from '../content'
import { ComponentRegistry } from './ComponentRegistry'

const visualizationComponentMap: Record<
  string,
  ComponentType | React.FunctionComponent<any>
> = {
  contentBlockWithImage: ContentBlockImage,
  contentRowText: ContentRowText,
  contentsCarousel: ContentsCarousel,
  herobanner: HeroBanner,
  htmlComponent: HtmlComponent,
  imageRowComponent: ContentRowImage,
  mosaicComponent: MosaicComponent,
  ProductCarousel,
  twoColumnBanner: Banner,
  youtubeVideoBlock: ContentBlockVideo,
}

const visualizationRegistry = new ComponentRegistry(visualizationComponentMap)
export default visualizationRegistry
