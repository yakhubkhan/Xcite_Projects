import React, { ComponentType } from 'react'
import { Banner } from '../content'
import { ComponentRegistry } from './ComponentRegistry'

const productCategoryPageComponentMap: Record<
  string,
  ComponentType | React.FunctionComponent<any>
> = {
  Banner,
}

const productCategoryRegistry = new ComponentRegistry(
  productCategoryPageComponentMap
)
export default productCategoryRegistry
