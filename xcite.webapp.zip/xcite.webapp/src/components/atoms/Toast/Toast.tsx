import React from 'react'
import ReactDOM from 'react-dom'

export declare type ToastProps = {
  children?: React.ReactNode
  duration?: number
  className: string
}

export default function Toast(props: ToastProps): JSX.Element {
  const { children, duration = 10000, className } = props
  const toastDiv = document.createElement('div')
  toastDiv.setAttribute('id', 'toast')
  const [node] = React.useState(toastDiv)

  React.useEffect(() => {
    const removeNode = () => {
      const toastElem = document.getElementById('toast')
      toastElem?.remove()
    }
    document.body.appendChild(node).classList.add(className)

    setTimeout(() => {
      removeNode()
    }, duration)

    return () => removeNode()
  }, [duration, node])

  return ReactDOM.createPortal(children, node)
}
