import React from 'react'
import { ProductOptionType } from '../../../types/content'
import { CheckInCircleTransparentIcon, CircleCrossIcon } from '../Icon'
import Link from '../Link'

const checkInCircleTransparentIcon = (
  <CheckInCircleTransparentIcon className="w-6 h-6" stroke="#fff" />
)

const circleCrossIcon = <CircleCrossIcon className="w-8 h-8" stroke="#929292" />

const CircularBadge = ({
  option,
}: {
  option: ProductOptionType
}): JSX.Element => {
  return (
    <Link
      to={`/${option.slug}/p`}
      className={
        option.slug && option.available
          ? 'cursor-pointer'
          : 'pointer-events-none cursor-none'
      }
    >
      <div className="flex flex-col cmn-inline-center">
        <span
          className={`relative cmn-inline-center w-8 h-8 rounded-full ${
            option.selected ? 'border-2 border-primary-700' : ''
          }`}
        >
          {option.selected && (
            <div className="absolute">{checkInCircleTransparentIcon}</div>
          )}
          {!option.available && (
            <div className="absolute">{circleCrossIcon}</div>
          )}
          <span
            style={{
              backgroundColor: `${option.value.hex}`,
              boxShadow: '0px 0px 5px rgb(0 0 0 / 10%)',
            }}
            className={`w-6 h-6 rounded-full ${
              !option.available ? 'opacity-50' : ''
            }`}
          ></span>
        </span>
        <span>{option.value.label}</span>
      </div>
    </Link>
  )
}

export default CircularBadge
