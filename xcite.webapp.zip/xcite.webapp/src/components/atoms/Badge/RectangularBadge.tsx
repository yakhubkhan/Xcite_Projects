import React from 'react'
import { ProductOptionType } from '../../../types/content'
import Link from '../Link'

const RectangularBadge = ({
  option,
}: {
  option: ProductOptionType
}): JSX.Element => {
  return (
    <Link
      to={`/${option.slug}/p`}
      className={
        option.slug && option.available
          ? 'cursor-pointer'
          : 'pointer-events-none cursor-none'
      }
    >
      <span
        className={`cmn-inline-center min-w-[40px] min-h-[40px] px-2 py-1.5 text-sm rounded ${
          option.selected
            ? 'font-bold text-primary-700 border shadow-[inset_0_0_0_1px] border-primary-700'
            : 'text-gray-900 border border-gray-500'
        } ${!option.available ? 'opacity-50' : ''}`}
      >
        <span className="">{option.value.label}</span>
      </span>
    </Link>
  )
}

export default RectangularBadge
