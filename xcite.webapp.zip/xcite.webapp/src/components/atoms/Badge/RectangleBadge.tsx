import React from 'react'

const RectangleBadge = ({
  selected,
  disable,
  onClick,
  children,
}: {
  selected: boolean
  disable?: boolean
  onClick?: () => void
  children: React.ReactNode
}): JSX.Element => {
  return (
    <span
      onClick={onClick}
      className={`cursor-pointer min-w-[52px] min-h-[40px] px-2 py-1.5 text-sm rounded ${
        selected
          ? 'font-bold text-primary-700 border shadow-[inset_0_0_0_1px] border-primary-700'
          : 'text-gray-900 border border-gray-500'
      } ${disable ? 'opacity-50' : ''}`}
    >
      {children}
    </span>
  )
}

export default RectangleBadge
