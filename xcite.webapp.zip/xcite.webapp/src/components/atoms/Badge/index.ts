export { default as CircularBadge } from './CircularBadge'
export { default as RectangularBadge } from './RectangularBadge'
export { default as ThumbnailBadge } from './ThumbnailBadge'
export { default as RectangleBadge } from './RectangleBadge'
