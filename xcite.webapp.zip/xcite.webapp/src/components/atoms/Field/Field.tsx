import { useTranslation } from 'next-i18next'
import React from 'react'
import { InputTypeEnum } from '../../../types/content'
import {
  WarningIcon,
  WarningFilledIcon,
  CheckInCircleFilledIcon,
} from '../../atoms/Icon'
import ErrorMessage from '../ErrorMessage'
import { ArrowDropDownIcon } from '../Icon'

import styles from './Field.module.css'

export declare type FieldProps = {
  disabled?: boolean
  className?: string
  leftIconTag?: JSX.Element | null
  id: string
  labelText?: string
  onChange?: (e) => void
  placeholder?: string
  rightIconAction?: () => void
  rightIconTag?: JSX.Element | null
  selectOptions?: {
    key: string
    label: string
  }[]
  errorMessage?: string
  type?: InputTypeEnum
  value?: string
  required?: boolean
  readOnly?: boolean
  transparent?: boolean
  name?: string
  min?: string
  max?: string
  confirmed?: boolean
  showPlaceholderOption?: boolean
}

export const InputField = (props: FieldProps) => {
  const {
    disabled,
    className = '',
    leftIconTag,
    id,
    onChange,
    placeholder,
    rightIconAction,
    rightIconTag,
    transparent,
    type = InputTypeEnum.text,
    required = false,
    readOnly,
    name,
    errorMessage,
    min,
    max,
    confirmed = false,
    value,
  } = props

  return (
    <>
      {leftIconTag && (
        <div className="pl-2 rtl:pl-0 rtl:pr-2">{leftIconTag}</div>
      )}
      <input
        autoComplete="off"
        className={`typography-small ${styles.fieldElement} ${styles.input} ${className}`}
        data-transparent={transparent}
        disabled={disabled || confirmed}
        id={id}
        name={name ? name : id}
        onChange={onChange}
        placeholder={placeholder}
        type={type}
        value={value}
        required={required}
        readOnly={readOnly}
        aria-invalid={errorMessage ? true : false}
        min={min}
        max={max}
        onFocus={(e) => (e.target.placeholder = '')}
        onBlur={(e) => (e.target.placeholder = placeholder || '')}
      />
      {(rightIconTag || errorMessage || confirmed) && (
        <div
          className={`pr-2 rtl:pr-0 rtl:pl-2 ${
            rightIconAction ? 'cursor-pointer' : ''
          }`}
          onClick={rightIconAction}
        >
          {errorMessage ? (
            transparent ? (
              <WarningFilledIcon className="w-6 h-6 text-functional-red-800 fill-current" />
            ) : (
              <WarningIcon className="w-6 h-6 text-functional-red-800 stroke-current" />
            )
          ) : confirmed ? (
            <CheckInCircleFilledIcon className="w-6 h-6 text-functional-green-600 fill-current" />
          ) : (
            rightIconTag
          )}
        </div>
      )}
    </>
  )
}

const Dropdown = (props: FieldProps) => {
  const { t } = useTranslation()

  const {
    disabled,
    className = '',
    leftIconTag,
    id,
    onChange,
    placeholder,
    selectOptions = [],
    required = false,
    name,
    errorMessage,
    value,
    showPlaceholderOption = true,
  } = props

  return (
    <>
      {(leftIconTag || errorMessage) && (
        <div className="pl-2">
          {errorMessage ? (
            <WarningIcon className="w-6 h-6 text-functional-red-800 stroke-current" />
          ) : (
            leftIconTag
          )}
        </div>
      )}
      <select
        className={`typography-small ${styles.fieldElement} ${styles.select} ${className}`}
        disabled={disabled}
        id={id}
        name={name ? name : id}
        onChange={onChange}
        value={value}
        required={required}
      >
        {showPlaceholderOption && (
          <option value="" disabled>
            {placeholder ? placeholder : t('user_form_select_option_none')}
          </option>
        )}
        {selectOptions.map((option) => (
          <option key={option.key} value={option.key}>
            {option.label}
          </option>
        ))}
      </select>
      <div className="absolute right-2 rtl:left-2 rtl:right-auto pointer-events-none">
        <ArrowDropDownIcon
          className={`w-6 h-6 stroke-gray-900 ${
            disabled ? 'stroke-gray-400 ' : ''
          }`}
        />
      </div>
    </>
  )
}

export default function Field(props: FieldProps): JSX.Element {
  const {
    disabled,
    id,
    labelText,
    onChange,
    type = InputTypeEnum.text,
    value,
    readOnly,
    errorMessage,
    transparent = false,
    confirmed = false,
    className,
  } = props

  return (
    <div>
      <div className="flex justify-center">
        <label htmlFor={id} className={styles.label}>
          {labelText !== undefined && (
            <div
              className={`typography-label ${styles.labelText} ${
                value ? 'block' : 'hidden'
              }`}
            >
              {labelText}
            </div>
          )}
          <div
            className={`${className ? className : ''} ${styles.fieldWrapper} ${
              transparent ? styles.transparent : ''
            } ${
              disabled
                ? `${styles.disabled}`
                : readOnly
                ? `${styles.readOnly}`
                : errorMessage
                ? `${styles.error} fieldHasError`
                : confirmed
                ? styles.confirmed
                : styles.defaultStates
            }`}
          >
            {type === InputTypeEnum.select ? (
              <Dropdown {...props} value={value} onChange={onChange} />
            ) : (
              <InputField {...props} value={value} onChange={onChange} />
            )}
          </div>
        </label>
      </div>
      {errorMessage && (
        <ErrorMessage transparent={transparent}>{errorMessage}</ErrorMessage>
      )}
    </div>
  )
}
