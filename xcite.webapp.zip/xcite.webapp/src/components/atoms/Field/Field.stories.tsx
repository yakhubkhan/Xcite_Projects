import React from 'react'

import { Story, Meta } from '@storybook/react'

import Field, { FieldProps } from './Field'
import { PencilIcon, SearchIcon } from '../Icon'
import { InputTypeEnum } from '../../../types/content'

export default {
  title: 'Components/atoms/Field',
  component: Field,
} as Meta

const Template: Story<FieldProps> = (args) => (
  <div className="p-8">
    <div className="w-96">
      <Field {...args} />
    </div>
  </div>
)

export const Default = Template.bind({})

Default.args = {
  id: 'test-id',
  labelText: 'Label',
  placeholder: 'Label',
}

export const Disabled = Template.bind({})

Disabled.args = {
  id: 'test-id',
  labelText: 'Label',
  placeholder: 'Label',
  disabled: true,
}

export const ReadOnly = Template.bind({})

ReadOnly.args = {
  id: 'test-id',
  labelText: 'Label',
  placeholder: 'Label',
  value: 'Read only value',
  readOnly: true,
}

export const WithError = Template.bind({})

WithError.args = {
  id: 'test-id',
  labelText: 'Label',
  placeholder: 'Label',
  value: 'Wrong Value',
  errorMessage: 'Error Message',
}

export const Confirmed = Template.bind({})

Confirmed.args = {
  id: 'test-id',
  labelText: 'Label',
  placeholder: 'Label',
  value: 'Confirmed value',
  confirmed: true,
}

export const LeftRightIcon = Template.bind({})

LeftRightIcon.args = {
  id: 'test-id',
  labelText: 'Label',
  placeholder: 'Label',
  leftIconTag: <SearchIcon className="w-6 h-6 text-gray-600 stroke-current" />,
  rightIconTag: <PencilIcon className="w-6 h-6 text-gray-600 stroke-current" />,
}

export const Dropdown = Template.bind({})

Dropdown.args = {
  id: 'test-id',
  labelText: 'Label',
  placeholder: 'Label',
  type: InputTypeEnum.select,
  selectOptions: [
    {
      key: '1',
      label: 'option 1',
    },
    {
      key: '2',
      label: 'option 2',
    },
    {
      key: '3',
      label: 'option 3',
    },
    {
      key: '4',
      label: 'option 4',
    },
  ],
}

export const DropdownError = Template.bind({})

DropdownError.args = {
  id: 'test-id',
  labelText: 'Label',
  placeholder: 'Label',
  type: InputTypeEnum.select,
  value: 'Wrong Value',
  errorMessage: 'Error Message',
  selectOptions: [
    {
      key: '1',
      label: 'option 1',
    },
    {
      key: '2',
      label: 'option 2',
    },
    {
      key: '3',
      label: 'option 3',
    },
    {
      key: '4',
      label: 'option 4',
    },
  ],
}

export const DropdownLeftIcon = Template.bind({})

DropdownLeftIcon.args = {
  id: 'test-id',
  labelText: 'Label',
  placeholder: 'Label',
  type: InputTypeEnum.select,
  leftIconTag: <SearchIcon className="w-6 h-6 text-gray-600 stroke-current" />,
  selectOptions: [
    {
      key: '1',
      label: 'option 1',
    },
    {
      key: '2',
      label: 'option 2',
    },
    {
      key: '3',
      label: 'option 3',
    },
    {
      key: '4',
      label: 'option 4',
    },
  ],
}
export const DropdownDisabled = Template.bind({})

DropdownDisabled.args = {
  id: 'test-id',
  labelText: 'Label',
  placeholder: 'Label',
  type: InputTypeEnum.select,
  leftIconTag: <SearchIcon className="w-6 h-6 text-gray-600 stroke-current" />,
  disabled: true,
  selectOptions: [
    {
      key: '1',
      label: 'option 1',
    },
    {
      key: '2',
      label: 'option 2',
    },
    {
      key: '3',
      label: 'option 3',
    },
    {
      key: '4',
      label: 'option 4',
    },
  ],
}
