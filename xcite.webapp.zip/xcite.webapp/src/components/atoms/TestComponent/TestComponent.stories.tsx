import React from 'react'

import { Story, Meta } from '@storybook/react'

import TestComponent, { TestComponentProps } from './TestComponent'

export default {
  title: 'Components/atoms/TestComponent',
  component: TestComponent,
} as Meta

//👇 We create a “template” of how args map to rendering
const Template: Story<TestComponentProps> = (args) => (
  <TestComponent {...args} />
)

//👇 Each story then reuses that template
export const Default = Template.bind({})

Default.args = {
  highlight: false,
  name: 'World',
}
