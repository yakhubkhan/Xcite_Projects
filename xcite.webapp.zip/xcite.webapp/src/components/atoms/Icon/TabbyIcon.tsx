import React from 'react'

function TabbyIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <img
      src={'/assets/icons/Tabby-payment.svg'}
      alt="Tamara Logo"
      width="24"
      height="24"
    />
  )
}

export default TabbyIcon
