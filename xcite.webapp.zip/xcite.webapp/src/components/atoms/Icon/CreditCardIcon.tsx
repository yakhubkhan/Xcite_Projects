import React from 'react'

function CreditCardIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M20.5 5H4.25C3.55964 5 3 5.55964 3 6.25V17.5C3 18.1904 3.55964 18.75 4.25 18.75H20.5C21.1904 18.75 21.75 18.1904 21.75 17.5V6.25C21.75 5.55964 21.1904 5 20.5 5Z"
        stroke="current"
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M3 8.75H21.75"
        stroke="current"
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M6.75 12.5H13.625"
        stroke="current"
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M6.75 15H11.125"
        stroke="current"
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export default CreditCardIcon
