import React from 'react'

function ArrowTopRightSquareIcon(
  props: React.SVGProps<SVGSVGElement>
): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 18 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M13.2002 10.3887V15.0762C13.2002 15.3248 13.1014 15.5633 12.9256 15.7391C12.7498 15.9149 12.5113 16.0137 12.2627 16.0137H2.88769C2.63905 16.0137 2.4006 15.9149 2.22478 15.7391C2.04897 15.5633 1.9502 15.3248 1.9502 15.0762V5.70117C1.9502 5.45253 2.04897 5.21407 2.22478 5.03826C2.4006 4.86244 2.63905 4.76367 2.88769 4.76367H7.57519"
        stroke="#185E8F"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M16.0498 6.16797V1.94922H11.8311"
        stroke="#185E8F"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M16.0499 1.94922L7.875 10.1241"
        stroke="#185E8F"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export default ArrowTopRightSquareIcon
