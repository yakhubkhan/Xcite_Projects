import React from 'react'

function CheckInCircleIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 40 40"
      fill="none"
      stroke="#639448"
      strokeWidth="3"
      strokeLinecap="round"
      strokeLinejoin="round"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path d="M5 20.625a15.625 15.625 0 1 0 31.25 0 15.625 15.625 0 0 0-31.25 0v0Z" />
      <path d="m12.291 22.327 3.403 4.83a1.457 1.457 0 0 0 2.37.07l10.894-13.782" />
    </svg>
  )
}

export default CheckInCircleIcon
