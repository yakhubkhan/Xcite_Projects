import React from 'react'

function ClickAndCollect(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M17.6242 7.99902H5.86468C5.58229 7.9875 5.30533 8.07889 5.08525 8.25621C4.86518 8.43352 4.71696 8.68471 4.66814 8.96308L3.00166 20.5576C2.99303 20.7168 3.01815 20.876 3.07537 21.0248C3.13259 21.1735 3.22063 21.3085 3.33369 21.4209C3.44676 21.5333 3.58231 21.6204 3.73144 21.6767C3.88057 21.733 4.03992 21.7571 4.19903 21.7475H19.2899C19.4489 21.7571 19.6082 21.733 19.7573 21.6767C19.9064 21.6204 20.0419 21.5332 20.1549 21.4209C20.2679 21.3085 20.3559 21.1735 20.413 21.0247C20.4701 20.8759 20.4951 20.7168 20.4864 20.5576L18.8199 8.96308C18.7711 8.68485 18.623 8.43379 18.4031 8.25649C18.1832 8.07919 17.9065 7.98771 17.6242 7.99902V7.99902Z"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M14.802 5.54722C14.6652 4.83223 14.2839 4.18711 13.7235 3.72239C13.1632 3.25767 12.4587 3.00229 11.7307 3V3C11.0063 3.00318 10.3054 3.25707 9.74703 3.71854C9.18865 4.18 8.80728 4.82057 8.66772 5.53139"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M13.9611 13.623L11.0281 17.5334L9.24414 15.7503"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export default ClickAndCollect
