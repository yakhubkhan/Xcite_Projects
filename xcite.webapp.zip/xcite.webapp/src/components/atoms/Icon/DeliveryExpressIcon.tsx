import React from 'react'

function DeliveryExpressIcon(
  props: React.SVGProps<SVGSVGElement>
): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M3 13.2871L5.45098 14.528"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M3.07837 9.95703L5.42504 11.2138"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M4.06738 7.18945L5.47689 8.05819"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M11.4229 6.55078L18.3076 10.0683"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M14.0958 5.18523L8.93184 7.82398C8.64393 7.97333 8.40279 8.19919 8.23494 8.47673C8.0671 8.75426 7.97905 9.07271 7.98049 9.39705V15.1377C7.97913 15.4621 8.0673 15.7806 8.2353 16.0582C8.4033 16.3357 8.64461 16.5615 8.93267 16.7108L14.0958 19.3487C14.3341 19.4708 14.598 19.5345 14.8657 19.5345C15.1334 19.5345 15.3973 19.4708 15.6355 19.3487L20.7987 16.7108C21.0867 16.5615 21.3279 16.3357 21.4957 16.0581C21.6636 15.7806 21.7516 15.4621 21.7501 15.1377V9.39705C21.7517 9.07267 21.6637 8.75415 21.4958 8.47658C21.328 8.19901 21.0867 7.97318 20.7987 7.82398L15.6355 5.18523C15.3972 5.06348 15.1333 5 14.8657 5C14.598 5 14.3342 5.06348 14.0958 5.18523V5.18523Z"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M21.4778 8.44727L14.8651 11.8254L8.25317 8.44727"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M14.8652 11.8281V19.5357"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M18.3076 10.0684V12.4985"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export default DeliveryExpressIcon
