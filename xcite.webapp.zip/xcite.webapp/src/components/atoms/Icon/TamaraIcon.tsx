import React from 'react'

function TamaraIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <img
    src={
     '/assets/icons/Tamara.svg'
    }
    alt="Tamara Logo"
    width="24"
    height="24"
  />
  )
}

export default TamaraIcon