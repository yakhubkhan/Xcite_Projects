import React from 'react'

function ArrowUpDown(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="24"
      height="24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="m13.023 15.076 3.978 3.978 3.977-3.978M17 5v14.054M6.75 5v14.25M10.728 8.977 6.751 4.999 2.773 8.977"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export default ArrowUpDown
