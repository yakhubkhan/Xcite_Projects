import React from 'react'

function PayPalIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M14.1037 7.92167C14.1899 7.68502 14.2163 7.43071 14.1805 7.18138C14.1447 6.93205 14.0478 6.69545 13.8984 6.49264C13.749 6.28984 13.5518 6.12713 13.3243 6.019C13.0968 5.91087 12.8461 5.86067 12.5945 5.87289H10.4085L9.4939 9.97045H11.5884C12.171 9.94067 12.7289 9.72599 13.1812 9.35758C13.6335 8.98917 13.9566 8.48619 14.1037 7.92167V7.92167Z"
        stroke="current"
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M3 18.5488L6.65854 3H14.2409C16.5183 3 19.0518 4.6372 18.2927 8.10366C17.9965 9.53576 17.2052 10.8177 16.0578 11.7243C14.9103 12.6309 13.4801 13.1042 12.0183 13.061H8.82622L7.46342 18.5488H3Z"
        stroke="current"
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M21.1739 8.20508C22.5458 10.638 20.8263 16.1807 15.3659 16.263H12.0641L10.6739 21.7508H6.21045L6.42996 20.6167"
        stroke="current"
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export default PayPalIcon
