import React from 'react'

function CheckInCircleWhiteBgIcon(
  props: React.SVGProps<SVGSVGElement>
): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path d="M12.375 3a9.375 9.375 0 1 0 0 18.75 9.375 9.375 0 0 0 0-18.75Zm5.414 6.406-5.352 7.258a.782.782 0 0 1-1.117.148L7.5 13.758a.782.782 0 0 1-.117-1.102.781.781 0 0 1 1.086-.117l3.187 2.547 4.875-6.617a.781.781 0 0 1 1.086-.164.78.78 0 0 1 .172 1.101Z" />
    </svg>
  )
}

export default CheckInCircleWhiteBgIcon
