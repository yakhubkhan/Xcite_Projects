import React from 'react'

function CheckInCircleTransparentIcon(
  props: React.SVGProps<SVGSVGElement>
): JSX.Element {
  return (
    <svg
      width="24"
      height="24"
      fill="none"
      stroke="current"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path d="m19 7.3-9.288 9.286a.3.3 0 0 1-.424 0L5 12.3" />
    </svg>
  )
}

export default CheckInCircleTransparentIcon
