import React from 'react'

function EyeOpenIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      fill="none"
      stroke="#00355F"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path d="M10.311 5c-2.799-.046-5.694 1.91-7.514 3.913a1.155 1.155 0 0 0 0 1.546c1.78 1.961 4.667 3.963 7.514 3.915 2.848.048 5.735-1.954 7.517-3.915a1.155 1.155 0 0 0 0-1.546c-1.822-2.003-4.717-3.96-7.517-3.912Z" />
      <path d="M12.915 9.687a2.604 2.604 0 1 1-5.208-.002 2.604 2.604 0 0 1 5.208.002Z" />
    </svg>
  )
}

export default EyeOpenIcon
