import React from 'react'

function DeliveryRegularIcon(
  props: React.SVGProps<SVGSVGElement>
): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M21.75 13.5V7.25C21.75 6.91848 21.6183 6.60054 21.3839 6.36612C21.1495 6.1317 20.8315 6 20.5 6H10.5C10.1685 6 9.85054 6.1317 9.61612 6.36612C9.3817 6.60054 9.25 6.91848 9.25 7.25V12.25"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M9.25 12.25V7.25H6.75C5.75544 7.25 4.80161 7.64509 4.09835 8.34835C3.39509 9.05161 3 10.0054 3 11V16C3 16.3315 3.1317 16.6495 3.36612 16.8839C3.60054 17.1183 3.91848 17.25 4.25 17.25H4.875"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M3 12.25H5.5C5.83152 12.25 6.14946 12.1183 6.38388 11.8839C6.6183 11.6495 6.75 11.3315 6.75 11V7.25"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M6.75 16.625C6.75 17.1223 6.94754 17.5992 7.29917 17.9508C7.65081 18.3025 8.12772 18.5 8.625 18.5C9.12228 18.5 9.59919 18.3025 9.95082 17.9508C10.3025 17.5992 10.5 17.1223 10.5 16.625C10.5 16.1277 10.3025 15.6508 9.95082 15.2992C9.59919 14.9475 9.12228 14.75 8.625 14.75C8.12772 14.75 7.65081 14.9475 7.29917 15.2992C6.94754 15.6508 6.75 16.1277 6.75 16.625V16.625Z"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M16.75 16.625C16.75 17.1223 16.9475 17.5992 17.2992 17.9508C17.6508 18.3025 18.1277 18.5 18.625 18.5C19.1223 18.5 19.5992 18.3025 19.9508 17.9508C20.3025 17.5992 20.5 17.1223 20.5 16.625C20.5 16.1277 20.3025 15.6508 19.9508 15.2992C19.5992 14.9475 19.1223 14.75 18.625 14.75C18.1277 14.75 17.6508 14.9475 17.2992 15.2992C16.9475 15.6508 16.75 16.1277 16.75 16.625Z"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M12.375 17.25H14.875"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export default DeliveryRegularIcon
