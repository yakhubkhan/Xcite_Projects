import React from 'react'

function WarningFilledIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="1 0 16 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path d="M14.38 12.45 9.175 2.556a1.041 1.041 0 0 0-1.843 0L2.124 12.45a1.041 1.041 0 0 0 .032 1.04 1.041 1.041 0 0 0 .89.485h10.413a1.042 1.042 0 0 0 .922-1.525ZM7.733 6.165a.52.52 0 1 1 1.041 0V9.29a.52.52 0 1 1-1.041 0V6.165Zm.547 5.988a.797.797 0 0 1-.792-.766.77.77 0 0 1 .765-.796.796.796 0 0 1 .792.765.77.77 0 0 1-.765.797Z" />
    </svg>
  )
}

export default WarningFilledIcon
