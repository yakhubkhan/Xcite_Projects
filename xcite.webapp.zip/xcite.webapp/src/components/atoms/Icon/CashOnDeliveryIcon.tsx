import React from 'react'

function CashOnDeliveryIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M20.0833 21.7507L17.5833 18.0007V13.6257C17.5833 11.8507 13.9917 9.94232 13 9.08398"
        stroke="current"
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M14.6333 14.7001L11.5916 12.2668C11.4909 12.1661 11.3714 12.0862 11.2399 12.0318C11.1083 11.9773 10.9673 11.9492 10.825 11.9492C10.6826 11.9492 10.5416 11.9773 10.41 12.0318C10.2785 12.0862 10.159 12.1661 10.0583 12.2668C9.95761 12.3675 9.87774 12.487 9.82325 12.6185C9.76877 12.7501 9.74072 12.8911 9.74072 13.0334C9.74072 13.1758 9.76877 13.3168 9.82326 13.4484C9.87774 13.5799 9.95761 13.6994 10.0583 13.8001L13 17.1334V19.2168C13 20.2001 14.4083 21.7168 14.4083 21.7168"
        stroke="current"
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M13 19.2167C13.0033 19.3833 12.9735 19.5489 12.9123 19.704C12.851 19.859 12.7596 20.0003 12.6433 20.1197C12.527 20.2391 12.3882 20.3342 12.2348 20.3995C12.0815 20.4648 11.9167 20.4989 11.75 20.5H4.25C3.91848 20.5 3.60054 20.3683 3.36612 20.1339C3.1317 19.8995 3 19.5815 3 19.25V4.25C3 3.91848 3.1317 3.60054 3.36612 3.36612C3.60054 3.1317 3.91848 3 4.25 3H11.75C12.0815 3 12.3995 3.1317 12.6339 3.36612C12.8683 3.60054 13 3.91848 13 4.25V13.4167"
        stroke="current"
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M7.37485 14.1918C6.77392 14.0597 6.24281 13.7106 5.88317 13.2113C5.52352 12.7121 5.36062 12.0978 5.42562 11.486C5.49062 10.8741 5.77897 10.3077 6.23547 9.89521C6.69198 9.48268 7.28457 9.25299 7.89985 9.25009C8.40662 9.24567 8.90205 9.40012 9.31652 9.69176"
        stroke="current"
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M5.5 5.29102V6.54102"
        stroke="current"
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M10.5 17.375V18.2083"
        stroke="current"
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export default CashOnDeliveryIcon
