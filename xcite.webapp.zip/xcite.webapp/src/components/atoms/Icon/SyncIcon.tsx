import React from 'react'

function SyncIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M8.85938 14.7227H3V20.582"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M20.8391 15.868C20.2185 17.6816 19.0167 19.2398 17.4201 20.3007C15.8235 21.3615 13.9214 21.8658 12.009 21.7353C10.0965 21.6048 8.28058 20.8467 6.84293 19.5788C5.40529 18.3108 4.4263 16.6038 4.05786 14.7227"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M15.8906 10.0352H21.75V4.17578"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M3.91089 8.88755C4.5315 7.07388 5.73333 5.51574 7.32992 4.45486C8.9265 3.39399 10.8286 2.88969 12.741 3.02021C14.6535 3.15074 16.4694 3.90879 17.9071 5.17675C19.3447 6.44471 20.3237 8.15169 20.6921 10.0329"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export default SyncIcon
