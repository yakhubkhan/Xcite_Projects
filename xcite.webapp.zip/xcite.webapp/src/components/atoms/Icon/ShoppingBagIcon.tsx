import React from 'react'

function ShoppingBagIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M17.6242 7.99706H5.86468C5.58229 7.98555 5.30533 8.07694 5.08525 8.25426C4.86518 8.43157 4.71696 8.68275 4.66814 8.96112L3.00166 20.5557C2.99303 20.7148 3.01815 20.874 3.07537 21.0228C3.13259 21.1716 3.22063 21.3066 3.33369 21.4189C3.44676 21.5313 3.58231 21.6185 3.73144 21.6748C3.88057 21.7311 4.03992 21.7552 4.19903 21.7455H19.2899C19.4489 21.7552 19.6082 21.7311 19.7573 21.6748C19.9064 21.6185 20.0419 21.5313 20.1549 21.4189C20.2679 21.3065 20.3559 21.1715 20.413 21.0228C20.4701 20.874 20.4951 20.7148 20.4864 20.5557L18.8199 8.96112C18.7711 8.6829 18.623 8.43184 18.4031 8.25454C18.1832 8.07724 17.9065 7.98575 17.6242 7.99706V7.99706Z"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M14.8023 5.54722C14.6654 4.83223 14.2841 4.18711 13.7238 3.72239C13.1634 3.25767 12.4589 3.00229 11.731 3V3C11.0066 3.00318 10.3057 3.25707 9.74727 3.71854C9.1889 4.18 8.80753 4.82057 8.66797 5.53139"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M13.9611 13.625L11.0281 17.5354L9.24414 15.7523"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export default ShoppingBagIcon
