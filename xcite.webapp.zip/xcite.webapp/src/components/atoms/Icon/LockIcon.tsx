import React from 'react'

function LockIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      stroke="#181818"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M17.5 10.5H6.25c-.69 0-1.25.56-1.25 1.25v8.75c0 .69.56 1.25 1.25 1.25H17.5c.69 0 1.25-.56 1.25-1.25v-8.75c0-.69-.56-1.25-1.25-1.25ZM7.5 10.5V7.375a4.375 4.375 0 0 1 8.75 0V10.5" />
      <path d="M11.875 15.5a.312.312 0 1 0 0 .624.312.312 0 0 0 0-.624v0Z" />
    </svg>
  )
}

export default LockIcon
