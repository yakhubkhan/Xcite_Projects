import React from 'react'

function DiscountIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="m15.25 32.75 17.5-17.5M17.333 20.25a2.917 2.917 0 1 0 0-5.834 2.917 2.917 0 0 0 0 5.833ZM30.667 33.583a2.917 2.917 0 1 0 0-5.833 2.917 2.917 0 0 0 0 5.833ZM5.25 10.25v-2.5a2.5 2.5 0 0 1 2.5-2.5h2.5M10.25 42.75h-2.5a2.5 2.5 0 0 1-2.5-2.5v-2.5M5.25 16.5v5M5.25 26.5v5M42.75 16.5v5M16.5 5.25h5M42.75 37.75v2.5a2.5 2.5 0 0 1-2.5 2.5h-2.5M42.75 31.5v-5M31.5 42.75h-5M26.5 5.25h5M37.75 5.25h2.5a2.5 2.5 0 0 1 2.5 2.5v2.5M21.5 42.75h-5"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export default DiscountIcon
