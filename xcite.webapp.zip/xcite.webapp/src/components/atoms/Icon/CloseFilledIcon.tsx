import React from 'react'

function CloseFilledIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 -2 16 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path d="M6.25 0a6.25 6.25 0 1 0 0 12.5 6.25 6.25 0 0 0 0-12.5Zm2.86 8.37a.521.521 0 0 1-.735.74L6.344 7.077a.13.13 0 0 0-.188 0L4.125 9.11a.521.521 0 1 1-.734-.74l2.03-2.025a.13.13 0 0 0 0-.188l-2.03-2.031a.52.52 0 0 1 .734-.734l2.031 2.03a.13.13 0 0 0 .188 0l2.031-2.03a.52.52 0 0 1 .734.734L7.08 6.156a.13.13 0 0 0 0 .188l2.03 2.026Z" />
    </svg>
  )
}

export default CloseFilledIcon
