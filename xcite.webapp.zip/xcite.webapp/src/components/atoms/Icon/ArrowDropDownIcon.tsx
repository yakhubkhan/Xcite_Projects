import React from 'react'

function ArrowDropDownIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M16.5 10L12.212 14.2876C12.1842 14.3155 12.1511 14.3376 12.1148 14.3527C12.0784 14.3677 12.0394 14.3755 12 14.3755C11.9606 14.3755 11.9216 14.3677 11.8852 14.3527C11.8489 14.3376 11.8158 14.3155 11.788 14.2876L7.5 10"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export default ArrowDropDownIcon
