import React from 'react'

function ArrowLeftIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      fill="none"
      stroke="current"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path d="M11.67 5 6.906 9.764a.333.333 0 0 0 0 .472L11.67 15" />
    </svg>
  )
}

export default ArrowLeftIcon
