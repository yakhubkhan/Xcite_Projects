import React from 'react'

function TrackingIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 24 24"
      fill="current"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M21.3501 5.72461C21.3501 7.14128 19.2359 10.4563 18.4859 11.5879C18.4574 11.6309 18.4187 11.6662 18.3733 11.6906C18.3279 11.7149 18.2771 11.7277 18.2255 11.7277C18.1739 11.7277 18.1232 11.7149 18.0777 11.6906C18.0323 11.6662 17.9936 11.6309 17.9651 11.5879C17.2143 10.4571 15.1001 7.14128 15.1001 5.72461C15.1001 4.89581 15.4293 4.10095 16.0154 3.5149C16.6014 2.92885 17.3963 2.59961 18.2251 2.59961C19.0539 2.59961 19.8488 2.92885 20.4348 3.5149C21.0209 4.10095 21.3501 4.89581 21.3501 5.72461V5.72461Z"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M18.2251 5.41211C18.308 5.41211 18.3875 5.44503 18.4461 5.50364C18.5047 5.56224 18.5376 5.64173 18.5376 5.72461"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M17.9126 5.72461C17.9126 5.64173 17.9455 5.56224 18.0041 5.50364C18.0627 5.44503 18.1422 5.41211 18.2251 5.41211"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M18.2251 6.03711C18.1422 6.03711 18.0627 6.00419 18.0041 5.94558C17.9455 5.88697 17.9126 5.80749 17.9126 5.72461"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M18.5376 5.72461C18.5376 5.80749 18.5047 5.88697 18.4461 5.94558C18.3875 6.00419 18.308 6.03711 18.2251 6.03711"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M6.3501 12.2871C6.43298 12.2871 6.51246 12.32 6.57107 12.3786C6.62967 12.4372 6.6626 12.5167 6.6626 12.5996"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M6.0376 12.5996C6.0376 12.5167 6.07052 12.4372 6.12913 12.3786C6.18773 12.32 6.26722 12.2871 6.3501 12.2871"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M6.3501 12.9121C6.26722 12.9121 6.18773 12.8792 6.12913 12.8206C6.07052 12.762 6.0376 12.6825 6.0376 12.5996"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M6.6626 12.5996C6.6626 12.6825 6.62967 12.762 6.57107 12.8206C6.51246 12.8792 6.43298 12.9121 6.3501 12.9121"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M6.3501 8.84961C7.34466 8.84961 8.29849 9.2447 9.00175 9.94796C9.70501 10.6512 10.1001 11.605 10.1001 12.5996C10.1001 14.2004 7.8601 17.2463 6.8426 18.5479C6.78414 18.6228 6.70941 18.6833 6.62407 18.7249C6.53874 18.7665 6.44504 18.7881 6.3501 18.7881C6.25515 18.7881 6.16146 18.7665 6.07612 18.7249C5.99078 18.6833 5.91605 18.6228 5.8576 18.5479C4.8401 17.2471 2.6001 14.2004 2.6001 12.5996C2.6001 11.605 2.99519 10.6512 3.69845 9.94796C4.40171 9.2447 5.35554 8.84961 6.3501 8.84961V8.84961Z"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M6.3501 21.3496H13.8501C14.1816 21.3496 14.4996 21.2179 14.734 20.9835C14.9684 20.7491 15.1001 20.4311 15.1001 20.0996V16.3496C15.1001 16.0181 15.2318 15.7001 15.4662 15.4657C15.7006 15.2313 16.0186 15.0996 16.3501 15.0996H18.8501"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export default TrackingIcon
