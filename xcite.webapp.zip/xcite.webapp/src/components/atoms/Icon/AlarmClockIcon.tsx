import React from 'react'

function AlarmClockIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 24 24"
      fill="none"
      stroke="#181818"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path d="M4 14.25a7.5 7.5 0 1 0 15 0 7.5 7.5 0 0 0-15 0v0ZM16.5 8.625l1.563-1.563M17.75 6.75l.625.625M11.5 6.75V3M13.375 3h-3.75M11.5 14.873l-3.125-3.459" />
    </svg>
  )
}

export default AlarmClockIcon
