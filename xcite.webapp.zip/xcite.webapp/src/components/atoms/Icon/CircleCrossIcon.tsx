import React from 'react'

function CircleCrossIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 32 32"
      fill="none"
      stroke="current"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <circle cx="16" cy="16" r="15.5" />
      <path
        fill="#929292"
        d="M4.43 26.154 26.247 4.34l1.414 1.415L5.845 27.568z"
      />
    </svg>
  )
}

export default CircleCrossIcon
