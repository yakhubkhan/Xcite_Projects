import React from 'react'

function WarningIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 20 20"
      fill="none"
      stroke="current"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path d="M10.312 15a.26.26 0 1 0 0 .521.26.26 0 0 0 0-.521Z" />
      <path d="M10.313 12.915V7.707v5.208Z" fill="current" />
      <path d="M10.313 12.915V7.707" />
      <path d="M11.438 3.201a1.254 1.254 0 0 0-2.251 0L2.608 16.603a1.056 1.056 0 0 0 .949 1.522h13.511a1.056 1.056 0 0 0 .949-1.522L11.438 3.2Z" />
    </svg>
  )
}

export default WarningIcon
