import React from 'react'

function CheckIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 16 12"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M15 1.30078L5.712 10.5874C5.68417 10.6153 5.65113 10.6374 5.61475 10.6525C5.57837 10.6675 5.53938 10.6753 5.5 10.6753C5.46062 10.6753 5.42163 10.6675 5.38525 10.6525C5.34887 10.6374 5.31583 10.6153 5.288 10.5874L1 6.29981"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export default CheckIcon
