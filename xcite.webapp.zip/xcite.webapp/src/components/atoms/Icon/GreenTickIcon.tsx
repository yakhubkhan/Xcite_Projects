import React from 'react'

function GreenTickIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 25 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M19.5 7.30078L10.212 16.5874C10.1842 16.6153 10.1511 16.6374 10.1148 16.6525C10.0784 16.6675 10.0394 16.6753 10 16.6753C9.96062 16.6753 9.92163 16.6675 9.88525 16.6525C9.84887 16.6374 9.81583 16.6153 9.788 16.5874L5.5 12.2998"
        stroke="#639448"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export default GreenTickIcon
