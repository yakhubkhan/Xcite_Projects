import React from 'react'

function PencilIcon(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M20.8664 3.88361C20.5825 3.60096 20.2455 3.37734 19.8747 3.22569C19.5039 3.07404 19.1068 2.99736 18.7062 3.00007C18.3056 3.00278 17.9095 3.08484 17.5408 3.24149C17.1721 3.39815 16.8381 3.6263 16.5581 3.91278L4.47498 15.9959L3 21.75L8.75408 20.2742L20.8372 8.19104C21.1238 7.91116 21.352 7.57725 21.5087 7.20862C21.6654 6.83999 21.7475 6.44396 21.7502 6.04341C21.7529 5.64286 21.6762 5.24575 21.5245 4.87504C21.3728 4.50432 21.1491 4.16735 20.8664 3.88361V3.88361Z"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M16.2129 4.25781L20.4912 8.53608"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M4.47559 15.9941L8.75802 20.2691"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export default PencilIcon
