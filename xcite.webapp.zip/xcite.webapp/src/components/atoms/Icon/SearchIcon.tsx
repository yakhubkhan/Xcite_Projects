import React from 'react'

function Search(props: React.SVGProps<SVGSVGElement>): JSX.Element {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M4.37464 13.1758C5.07074 14.8137 6.38899 16.108 8.03939 16.774C9.68979 17.4399 11.5371 17.423 13.1751 16.7269C14.813 16.0308 16.1073 14.7126 16.7733 13.0622C17.4392 11.4118 17.4223 9.56441 16.7262 7.92649C16.0301 6.28857 14.7119 4.99426 13.0615 4.3283C11.4111 3.66233 9.5637 3.67926 7.92578 4.37536C6.28786 5.07145 4.99355 6.3897 4.32758 8.0401C3.66162 9.6905 3.67855 11.5379 4.37464 13.1758V13.1758Z"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M15.2949 15.2949L20.4993 20.5"
        stroke="current"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export default Search
