import NextImage, {
  ImageLoaderProps,
  ImageProps as NextImageProps,
} from 'next/image'

export declare type ImageProps = NextImageProps

const myLoader = (props: ImageLoaderProps) => {
  return `${props.src}?img404=default&w=${props.width}&qlt=${
    props.quality || 75
  }&fmt=auto`
}

export default function Image(props: ImageProps): JSX.Element {
  return <NextImage {...props} loader={myLoader} />
}

// --Uses--
//  <Image
//     src={productPic}
//     layout="responsive"
//     alt="Picture of the product"
// />
