export { default } from './Image'
