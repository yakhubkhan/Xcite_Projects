import { PaymentMethodName } from '../../../types/content'
import {
  CashOnDeliveryIcon,
  CreditCardIcon,
  KnetIcon,
  PayPalIcon,
  TamaraIcon,
  TabbyIcon,
} from '../Icon'

const PaymentMethodIcon = ({
  methodName,
  checked,
  disabled,
}: {
  methodName: PaymentMethodName
  checked?: boolean
  disabled?: boolean
}): JSX.Element => {
  const className = `h-6 w-6 stroke-current ${
    checked ? 'text-primary-700' : disabled ? 'text-gray-300' : 'text-gray-900'
  }`
  switch (methodName) {
    case 'CashOnDelivery':
      return <CashOnDeliveryIcon className={className} />
    case 'Paypal':
      return <PayPalIcon className={className} />
    case 'Knet':
      return <KnetIcon className={className} />
    case 'Tamara':
      return <TamaraIcon className={className} />
    case 'Tabby':
      return <TabbyIcon className={className} />
    case 'CreditCard':
      return <CreditCardIcon className={className} />
    default:
      return <CashOnDeliveryIcon className={className} />
  }
}

export default PaymentMethodIcon
