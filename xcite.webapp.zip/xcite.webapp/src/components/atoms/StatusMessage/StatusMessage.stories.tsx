import React from 'react'
import { Story, Meta } from '@storybook/react'
import StatusMessage, { StatusMessageProps } from './StatusMessage'
import { StatusMessageEnum } from '../../../types/content'

export default {
  title: 'Components/atoms/StatusMessage',
  component: StatusMessage,
} as Meta

const dummyText =
  'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.'

const Template: Story<StatusMessageProps> = (args) => (
  <StatusMessage {...args} />
)

export const Error = Template.bind({})

Error.args = {
  children: dummyText,
  type: StatusMessageEnum.Error,
}

export const Warning = Template.bind({})

Warning.args = {
  children: dummyText,
  type: StatusMessageEnum.Warning,
}

export const Success = Template.bind({})

Success.args = {
  children: dummyText,
  type: StatusMessageEnum.Success,
}
