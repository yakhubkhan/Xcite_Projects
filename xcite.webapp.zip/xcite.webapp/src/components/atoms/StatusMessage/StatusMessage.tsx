import React from 'react'
import styles from './StatusMessage.module.css'
import { WarningFilledIcon, CheckIcon, DealIcon } from '../Icon'
import { StatusMessageEnum } from '../../../types/content'

export interface StatusMessageProps {
  children: React.ReactNode
  type: StatusMessageEnum
  className?: string
  showIcon?: boolean
}

const StatusMessage: React.FunctionComponent<StatusMessageProps> = ({
  children,
  type,
  className,
  showIcon = true,
}) => (
  <div
    className={`border-[1px] rounded-md p-2 flex gap-3 ${
      type === StatusMessageEnum.Error && styles.error
    } ${type === StatusMessageEnum.Warning && styles.warning} ${
      type === StatusMessageEnum.Success && styles.success
    } ${type === StatusMessageEnum.Offer && styles.offer} ${className}`}
  >
    {showIcon && (
      <span
        className={`w-6 h-6 ${
          type === StatusMessageEnum.Offer && styles.offerIcon
        }`}
      >
        {type === StatusMessageEnum.Error && (
          <WarningFilledIcon className="text-functional-red-800 fill-current" />
        )}
        {type === StatusMessageEnum.Warning && (
          <WarningFilledIcon className="text-functional-yellow-700 fill-current" />
        )}
        {type === StatusMessageEnum.Success && (
          <CheckIcon className="text-functional-green-600 stroke-current" />
        )}
        {type === StatusMessageEnum.Offer && (
          <DealIcon className="text-functional-red-800 fill-current" />
        )}
      </span>
    )}

    <p className="w-fit">{children}</p>
  </div>
)

export default StatusMessage
