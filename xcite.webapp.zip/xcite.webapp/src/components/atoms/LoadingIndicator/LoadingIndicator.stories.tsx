import React from 'react'

import { Story, Meta } from '@storybook/react'

import LoadingIndicator, { LoadingIndicatorProps } from './LoadingIndicator'

export default {
  title: 'Components/atoms/LoadingIndicator',
  component: LoadingIndicator,
} as Meta

const Template: Story<LoadingIndicatorProps> = (args) => (
  <LoadingIndicator {...args} />
)

//👇 Each story then reuses that template
export const Default = Template.bind({})

Default.args = {
  children: 'Loading',
}
