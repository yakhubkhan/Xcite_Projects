import React from 'react'

import { Story, Meta } from '@storybook/react'

import Grid, { GridProps } from './Grid'

export default {
  title: 'Components/atoms/Grid',
  component: Grid,
} as Meta

//👇 We create a “template” of how args map to rendering
const Template: Story<GridProps> = (args) => (
  <Grid {...args}>
    <div className="bg-functional-red-600 bg-opacity-50"></div>
    <div className="bg-functional-red-600 bg-opacity-50"></div>
    <div className="bg-functional-red-600 bg-opacity-50"></div>
    <div className="bg-functional-red-600 bg-opacity-50"></div>
    <div className="hidden sm:block bg-functional-red-600 bg-opacity-50"></div>
    <div className="hidden sm:block bg-functional-red-600 bg-opacity-50"></div>
    <div className="hidden sm:block bg-functional-red-600 bg-opacity-50"></div>
    <div className="hidden sm:block bg-functional-red-600 bg-opacity-50"></div>
    <div className="hidden sm:block bg-functional-red-600 bg-opacity-50"></div>
    <div className="hidden sm:block bg-functional-red-600 bg-opacity-50"></div>
    <div className="hidden sm:block bg-functional-red-600 bg-opacity-50"></div>
    <div className="hidden sm:block bg-functional-red-600 bg-opacity-50"></div>
  </Grid>
)

//👇 Each story then reuses that template
export const Default = Template.bind({})

Default.args = {
  className: 'h-screen',
}
