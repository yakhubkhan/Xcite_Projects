import { useRouter } from 'next/router'
import React, { useState } from 'react'
import gtmDatalayer from '../../../util/gtmUtils'

import { SearchIcon, CloseIconSmall } from '../../atoms/Icon'
import Field from '../Field'

const searchIcon = (
  <div className="w-6 h-6">
    <SearchIcon className="stroke-current text-gray-600" />
  </div>
)

const closeIcon = (
  <div className="w-6 h-6">
    <CloseIconSmall className="stroke-current text-primary-900" />
  </div>
)

export declare type SearchBoxProps = {
  placeholder?: string
  searchVal?: string
}

export default function SearchBox(props: SearchBoxProps): JSX.Element {
  const router = useRouter()
  const [valueState, setValueState] = useState(props.searchVal || '')

  const triggerSearch = () => {
    if (valueState) {
      const eventActionObj = {
        searchQuery: valueState,
        eventAction: 'searchBarClick',
      }
      gtmDatalayer(
        'searchClick',
        'navigation_menu',
        JSON.stringify(eventActionObj)
      )
      router.push(`/search?q=${valueState}`)
    }
    return false
  }

  const changeValue = (e: React.ChangeEvent<HTMLInputElement>) => {
    setValueState(e.target.value)
  }

  const clearSearch = () => {
    setValueState('')
  }

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault()
        triggerSearch()
      }}
    >
      <Field
        id="search"
        leftIconTag={searchIcon}
        rightIconTag={valueState !== '' ? closeIcon : undefined}
        placeholder={props.placeholder}
        value={valueState}
        onChange={(e) => changeValue(e)}
        rightIconAction={clearSearch}
      />
    </form>
  )
}
