import React from 'react'
import { Story, Meta } from '@storybook/react'
import SearchBox, { SearchBoxProps } from './SearchBox'

export default {
  title: 'Components/atoms/SearchBox',
  component: SearchBox,
} as Meta

const Template: Story<SearchBoxProps> = (props) => (
  <div className="p-4">
    <SearchBox {...props} />
  </div>
)

export const Default = Template.bind({})
Default.args = {
  placeholder: 'A placeholder for search',
}

export const SearchWithValue = Template.bind({})
SearchWithValue.args = {
  placeholder: '',
  searchVal: 'This is search valuse',
}
