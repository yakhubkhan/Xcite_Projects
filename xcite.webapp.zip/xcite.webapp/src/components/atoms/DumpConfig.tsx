import React from 'react'
import getConfig from 'next/config'

const { publicRuntimeConfig } = getConfig()

export interface DumpConfigProps {
  className: string
}

const DumpConfig: React.FunctionComponent<DumpConfigProps> = ({
  className,
}) => (
  <div className={`${className}`}>{JSON.stringify(publicRuntimeConfig)}</div>
)

export default DumpConfig
