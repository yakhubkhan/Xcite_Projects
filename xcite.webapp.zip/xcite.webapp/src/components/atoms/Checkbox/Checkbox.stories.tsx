import React from 'react'
import { Story, Meta } from '@storybook/react'
import Checkbox, { CheckboxProps } from './Checkbox'

export default {
  title: 'Components/atoms/Checkbox',
  component: Checkbox,
} as Meta

const Template: Story<CheckboxProps> = (props) => (
  <div className="p-4">
    <Checkbox {...props} />
  </div>
)

export const Default = Template.bind({})
Default.args = {
  text: 'Compare',
  withBackground: false,
}
