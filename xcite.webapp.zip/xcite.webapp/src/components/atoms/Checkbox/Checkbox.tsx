import styles from './Checkbox.module.css'

export declare type CheckboxProps = {
  id: string
  name: string
  value?: string
  onChange?: () => void
  text?: string
  className?: string
  withBackground?: boolean
}

export default function Checkbox(props: CheckboxProps): JSX.Element {
  const {
    onChange,
    text,
    id,
    name,
    value,
    className = '',
    withBackground = false,
  } = props
  return (
    <label
      htmlFor={id}
      className="inline-flex items-center gap-3 cursor-pointer"
    >
      <input
        id={id}
        name={name}
        value={value}
        onChange={onChange}
        type="checkbox"
        className={`${styles.input} absolute opacity-0 border-2 h-5 w-5 cursor-pointer focus:outline-none ${className}`}
      />
      <div
        className={`${styles.customInput}${
          withBackground ? ` ${styles.withBackground} bg-gray-100` : ''
        } relative h-5 w-5 border-2 border-gray-900 rounded-sm`}
      >
        <svg
          className="hidden fill-current text-white"
          width="16"
          height="16"
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path d="M10 15.172L19.192 5.979L20.607 7.393L10 18L3.636 11.636L5.05 10.222L10 15.172Z" />
        </svg>
      </div>
      {text && <span className="typography-small">{text}</span>}
    </label>
  )
}
