import React from 'react'
import renderer from 'react-test-renderer'
import ProductLabel from '../ProductLabel'

it('renders the default state', () => {
  const tree = renderer.create(<ProductLabel>Trending</ProductLabel>).toJSON()
  expect(tree).toMatchSnapshot()
})
