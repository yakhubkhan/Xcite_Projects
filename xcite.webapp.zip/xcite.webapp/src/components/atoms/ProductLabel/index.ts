export { default } from './ProductLabel'
