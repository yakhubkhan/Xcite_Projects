import React from 'react'
import { HeadingEnum } from '../../../types/content'

export interface HeadingComponentProps {
  children: React.ReactNode
  className?: string
  type: HeadingEnum
}

const Heading = (
  { children, className, type }: HeadingComponentProps,
  ref: React.Ref<HTMLDivElement>
): JSX.Element => {
  switch (type) {
    case 'h1':
      return (
        <h1 className={className} ref={ref}>
          {children}
        </h1>
      )
    case 'h2':
      return (
        <h2 className={className} ref={ref}>
          {children}
        </h2>
      )
    case 'h3':
      return (
        <h3 className={className} ref={ref}>
          {children}
        </h3>
      )
    case 'h4':
      return (
        <h4 className={className} ref={ref}>
          {children}
        </h4>
      )
    case 'h5':
      return (
        <h5 className={className} ref={ref}>
          {children}
        </h5>
      )
    default:
      return (
        <h1 className={className} ref={ref}>
          {children}
        </h1>
      )
  }
}

export default React.forwardRef(Heading)
