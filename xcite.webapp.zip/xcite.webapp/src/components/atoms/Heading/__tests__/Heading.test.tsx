import React from 'react'
import renderer from 'react-test-renderer'
import { HeadingEnum } from '../../../../types/content'
import Heading from '../Heading'

it('renders h1', () => {
  const tree = renderer
    .create(<Heading type={HeadingEnum.h1}>Hello World</Heading>)
    .toJSON()
  expect(tree).toMatchSnapshot()
})

it('renders h2', () => {
  const tree = renderer
    .create(<Heading type={HeadingEnum.h2}>Hello World</Heading>)
    .toJSON()
  expect(tree).toMatchSnapshot()
})

it('renders h3', () => {
  const tree = renderer
    .create(<Heading type={HeadingEnum.h3}>Hello World</Heading>)
    .toJSON()
  expect(tree).toMatchSnapshot()
})

it('renders h4', () => {
  const tree = renderer
    .create(<Heading type={HeadingEnum.h4}>Hello World</Heading>)
    .toJSON()
  expect(tree).toMatchSnapshot()
})

it('renders h5', () => {
  const tree = renderer
    .create(<Heading type={HeadingEnum.h5}>Hello World</Heading>)
    .toJSON()
  expect(tree).toMatchSnapshot()
})
