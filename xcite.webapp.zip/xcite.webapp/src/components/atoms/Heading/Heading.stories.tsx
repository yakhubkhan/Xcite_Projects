import React from 'react'
import { Story, Meta } from '@storybook/react'
import { HeadingEnum } from '../../../types/content'
import Heading, { HeadingComponentProps } from './Heading'

export default {
  title: 'Components/atoms/Heading',
  component: Heading,
} as Meta

const Template: Story<HeadingComponentProps> = (args) => (
  <Heading {...args}>{args.children}</Heading>
)

export const Default = Template.bind({})

Default.args = {
  children: 'Hello World',
  type: HeadingEnum.h1,
  className: '',
}

export const DecorativeHeadingBold = Template.bind({})

DecorativeHeadingBold.args = {
  children: 'Hello World',
  type: HeadingEnum.h1,
  className: 'typography-decorative-bold',
}

export const DecorativeHeadingLight = Template.bind({})

DecorativeHeadingLight.args = {
  children: 'Hello World',
  type: HeadingEnum.h1,
  className: 'typography-decorative-light',
}
