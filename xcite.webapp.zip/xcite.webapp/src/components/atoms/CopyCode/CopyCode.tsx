import React, { useState } from 'react'
import { CopyIcon, CheckIcon } from '../Icon'

export interface CopyCodeProps {
  children: string
  className?: string
}

const CopyCode: React.FunctionComponent<CopyCodeProps> = ({
  children,
  className = '',
}) => {
  const [showTooltip, setToolTipVisibility] = useState(false)

  const copyCode = (e) => {
    e.preventDefault()
    navigator.clipboard.writeText(children)
    setToolTipVisibility(true)

    const interval = setTimeout(() => {
      setToolTipVisibility(false)
    }, 2000)

    return () => {
      clearTimeout(interval)
    }
  }

  return (
    <div
      className={`border-gray-300 border-[1px] rounded pl-3 pr-10 py-2 relative font-semibold w-full overflow-hidden text-ellipsis ${className}`}
    >
      {children}
      <span
        className="absolute right-2 top-1/2 -translate-y-1/2 stroke-gray-900 hover:cursor-pointer w-5 h-5"
        onClick={(e) => copyCode(e)}
      >
        <CopyIcon />
      </span>
      <div
        className={`absolute right-0 top-1/2 -translate-y-1/2 transition-all z-10 bg-functional-green-400 h-full p-3 stroke-white w-10 ${
          showTooltip ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <CheckIcon />
      </div>
    </div>
  )
}

export default CopyCode
