import React from 'react'
import { Story, Meta } from '@storybook/react'
import CopyCode, { CopyCodeProps } from './CopyCode'

export default {
  title: 'Components/atoms/CopyCode',
  component: CopyCode,
} as Meta

const Template: Story<CopyCodeProps> = (args) => <CopyCode {...args} />

export const Default = Template.bind({})

Default.args = {
  children: 'Message',
}
