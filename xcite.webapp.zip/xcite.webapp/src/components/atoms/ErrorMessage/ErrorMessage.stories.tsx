import React from 'react'
import { Story, Meta } from '@storybook/react'
import ErrorMessage, { ErrorMessageProps } from './ErrorMessage'

export default {
  title: 'Components/atoms/ErrorMessage',
  component: ErrorMessage,
} as Meta

const Template: Story<ErrorMessageProps> = (args) => <ErrorMessage {...args} />

//👇 Each story then reuses that template
export const Default = Template.bind({})

Default.args = {
  children: 'Message',
}
