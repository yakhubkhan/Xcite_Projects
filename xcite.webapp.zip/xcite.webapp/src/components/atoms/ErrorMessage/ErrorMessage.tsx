import React from 'react'

export interface ErrorMessageProps {
  transparent?: boolean
  children: React.ReactNode
}

const ErrorMessage: React.FunctionComponent<ErrorMessageProps> = ({
  transparent = false,
  children,
}) => (
  <p
    className={`typography-label ${
      transparent
        ? 'bg-functional-red-700 p-1 mt-1 text-white'
        : 'text-functional-red-800 pt-1'
    }`}
  >
    {children}
  </p>
)

export default ErrorMessage
