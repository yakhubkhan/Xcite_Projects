import React from 'react'
import styles from './Carousel.module.css'
import SwiperCore, { Navigation, Pagination } from 'swiper'
import { Swiper, SwiperSlide } from 'swiper/react'
import { CarouselProps } from '../../../types/content'

export default function Carousel(props: CarouselProps): JSX.Element {
  const { pItems, carouselCurrItem = 0 } = props
  SwiperCore.use([Navigation, Pagination])

  const slides = () => {
    return pItems.map((item, idx) => {
      if (item.type !== 'img') return
      return (
        <div key={idx + 'sl'}>
          <SwiperSlide>
            <div className={`object-fill display flex justify-center`}>
              <div className="display block">
                <img src={item?.src} alt={item?.alt} />
              </div>
            </div>
          </SwiperSlide>
        </div>
      )
    })
  }

  return (
    <div className={`flex w-full ${styles.carousel}`}>
      <div className="flex items-center w-full">
        <Swiper
          className="carousel"
          initialSlide={carouselCurrItem}
          navigation
          pagination={{
            clickable: true,
            dynamicBullets: pItems.length > 5 ? true : false,
            el: '.swiper-pagination',
          }}
        >
          {slides()}
        </Swiper>
      </div>
      <div className="swiper-pagination"></div>
    </div>
  )
}
