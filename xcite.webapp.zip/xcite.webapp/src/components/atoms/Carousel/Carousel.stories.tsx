import React from 'react'
import { Story, Meta } from '@storybook/react'
import Carousel from './Carousel'
import { CarouselProps, ImageType } from '../../../types/content'

export default {
  title: 'Components/atoms/Carousel',
  component: Carousel,
} as Meta

const Template: Story<CarouselProps> = (props) => (
  <div className="p-4 bg-gray-20">
    <Carousel {...props} />
  </div>
)

const imgItem: ImageType[] = [
  {
    type: 'img',
    src: 'https://loremflickr.com/850/750/random=1',
    alt: 'random1',
  },
  {
    type: 'img',
    src: 'https://loremflickr.com/850/750/cat',
    alt: 'Cat',
  },
  {
    type: 'img',
    src: 'https://loremflickr.com/850/750/random=2',
    alt: 'random2',
  },
  {
    type: 'img',
    src: 'https://loremflickr.com/850/750/dog',
    alt: 'Dog',
  },
  {
    type: 'img',
    src: 'https://loremflickr.com/850/750/random=3',
    alt: 'random3',
  },
  {
    type: 'img',
    src: 'https://loremflickr.com/850/750/paris',
    alt: 'Paris',
  },
  {
    type: 'img',
    src: 'https://loremflickr.com/850/750/random=4',
    alt: 'random4',
  },
  {
    type: 'img',
    src: 'https://loremflickr.com/850/750/forest',
    alt: 'Forest',
  },
  {
    type: 'img',
    src: 'https://loremflickr.com/850/750/random=5',
    alt: 'random5',
  },
  {
    type: 'img',
    src: 'https://loremflickr.com/850/750/dog',
    alt: 'Dog',
  },
  {
    type: 'img',
    src: 'https://loremflickr.com/850/750/cat',
    alt: 'Cat',
  },
]

export const Default = Template.bind({})
Default.args = {
  pItems: imgItem,
  carouselCurrItem: 0,
  numDotsToShow: 7,
  isCircular: false,
}
