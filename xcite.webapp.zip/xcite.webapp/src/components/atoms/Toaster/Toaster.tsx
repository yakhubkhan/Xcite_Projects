import { ToastPropsType, ToastType } from '../../../types/content'
import { CheckInCircleWhiteBgIcon, WarningToastIcon } from '../Icon'
import Toast from '../Toast/Toast'

const Toaster = ({
  toastMsg,
  duration,
  className,
  type = ToastType.success,
}: ToastPropsType): JSX.Element => {
  return (
    <Toast duration={duration} className={className}>
      <div className="flex flex-col justify-center">
        <div
          className={`cmn-inline-center typography-h4 p-2 mb-2 text-white rounded-lg ${
            type === ToastType.success
              ? 'bg-functional-green-600'
              : 'bg-functional-red-800'
          }`}
        >
          <div className="px-4">
            {type === ToastType.success && (
              <CheckInCircleWhiteBgIcon className="w-6 h-6" fill="#fff" />
            )}
            {type === ToastType.error && (
              <WarningToastIcon className="w-6 h-6" />
            )}
          </div>
          <div>
            <div>{toastMsg}</div>
          </div>
        </div>
      </div>
    </Toast>
  )
}

export default Toaster
