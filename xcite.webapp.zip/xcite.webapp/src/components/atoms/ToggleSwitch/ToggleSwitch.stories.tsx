import React from 'react'

import { Story, Meta } from '@storybook/react'

import ToggleSwitch, { ToggleSwitchProps } from './ToggleSwitch'

export default {
  title: 'Components/atoms/ToggleSwitch',
  component: ToggleSwitch,
} as Meta

const Template: Story<ToggleSwitchProps> = (args) => (
  <div className="p-4">
    <ToggleSwitch {...args} />
  </div>
)

export const Default = Template.bind({})

Default.args = {
  disabled: false,
}

export const WithLabel = Template.bind({})

WithLabel.args = {
  label: 'Some label',
  disabled: false,
}
