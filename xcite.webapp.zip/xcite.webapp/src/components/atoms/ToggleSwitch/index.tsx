export { default } from './ToggleSwitch'
