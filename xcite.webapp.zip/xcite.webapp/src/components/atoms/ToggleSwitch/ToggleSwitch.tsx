import React from 'react'

export declare type ToggleSwitchProps = {
  className?: string
  onChange?: (e) => void
  checked?: boolean
  disabled?: boolean
  label?: string
}

export default function ToggleSwitch(props: ToggleSwitchProps): JSX.Element {
  const { className = '', onChange, checked, disabled, label } = props

  return (
    <label className={`relative inline-flex gap-2 py-3 items-center`}>
      <input
        type="checkbox"
        className={`absolute top-0 left-0 w-full h-full opacity-0 peer ${
          disabled ? 'cursor-default' : 'cursor-pointer'
        }`}
        onChange={onChange}
        disabled={disabled}
        checked={checked}
      />
      <div
        className={`w-10 h-6 inline-flex items-center p-[6px] cursor-pointer rounded-full bg-gray-400 after:h-3 after:w-3 after:bg-white after:shadow-md after:rounded-full after:transform after:duration-200 after:ease-in-out after:peer-disabled:opacity-60 peer-disabled:cursor-default peer-disabled:bg-gray-300 peer-hover:bg-gray-300
        peer-checked:bg-functional-green-600 peer-checked:peer-disabled:bg-functional-green-300 peer-checked:after:translate-x-4 peer-checked:peer-hover:bg-functional-green-400 rtl:peer-checked:after:-translate-x-4 ${className}`}
      />
      {label && (
        <span className="typography-small peer-checked:typography-small-strong peer-disabled:text-gray-400">
          {label}
        </span>
      )}
    </label>
  )
}
