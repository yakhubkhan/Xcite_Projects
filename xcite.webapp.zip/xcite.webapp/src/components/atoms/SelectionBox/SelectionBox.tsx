import React from 'react'
import { PaymentMethodName } from '../../../types/content'

interface Props {
  onValChange: (e: React.ChangeEvent<HTMLInputElement>) => void
  value?: PaymentMethodName | string
  checked: boolean
  disabled?: boolean
  inputName?: string
  inputId?: string
  children?: React.ReactNode
  extraClassName?: string
}

const SelectionBox = ({
  onValChange,
  value,
  checked,
  disabled,
  inputName,
  inputId,
  children,
  extraClassName,
}: Props): JSX.Element => {
  return (
    <label
      className={`flex rounded p-3 w-full ${
        checked
          ? 'border shadow-[inset_0_0_0_1px] border-primary-700 bg-primary-50 text-primary-700'
          : 'border border-gray-500'
      } ${disabled ? 'text-gray-300 border-gray-300' : 'cursor-pointer'}`}
      htmlFor={inputId}
    >
      <input
        type="radio"
        name={inputName}
        id={inputId}
        value={value}
        onChange={onValChange}
        className="h-0 w-0 appearance-none"
        checked={checked}
        disabled={disabled}
      />
      <div className={`flex flex-1 gap-3 typography-small ${extraClassName}`}>
        {children}
      </div>
    </label>
  )
}

export default SelectionBox
