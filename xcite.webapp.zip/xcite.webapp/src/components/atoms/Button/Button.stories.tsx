import React from 'react'
import { Story, Meta } from '@storybook/react'
import { ButtonVariantEnum } from '../../../types/content'
import Button, { ButtonProps } from './Button'
import CartIcon from '../Icon/CartIcon'

export default {
  title: 'Components/atoms/Button',
  component: Button,
} as Meta

const Template: Story<ButtonProps> = (args) => (
  <div className="p-4">
    <Button {...args}>{args.children}</Button>
  </div>
)

export const Default = Template.bind({})

Default.args = {
  children: 'Add to cart',
  variant: ButtonVariantEnum.primaryCta,
  className: '',
  disabled: false,
}

Default.argTypes = {
  variant: {
    options: Object.keys(ButtonVariantEnum),
    control: { type: 'radio' },
  },
}

export const WithIcon = Template.bind({})

WithIcon.args = {
  children: 'Add to cart',
  variant: ButtonVariantEnum.primaryCta,
  className: '',
  icon: <CartIcon className="w-6 h-6 text-black stroke-current" />,
  disabled: false,
}

WithIcon.argTypes = {
  variant: {
    options: Object.keys(ButtonVariantEnum),
    control: { type: 'radio' },
  },
}
