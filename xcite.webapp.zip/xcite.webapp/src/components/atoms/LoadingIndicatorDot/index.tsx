export { default } from './LoadingIndicatorDot'
