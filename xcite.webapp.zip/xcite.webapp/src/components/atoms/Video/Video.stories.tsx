import React from 'react'
import { Story, Meta } from '@storybook/react'
import { VideoComponentType } from '../../../types/content/component'
import Video from './Video'

export default {
  title: 'Components/atoms/Video',
  component: Video,
} as Meta

const Template: Story<VideoComponentType> = (args) => <Video {...args} />

//👇 Each story then reuses that template
export const Default = Template.bind({})

Default.args = {
  youtubeLink: 'https://youtu.be/vozT7cGkWUQ',
  width: '700',
}
