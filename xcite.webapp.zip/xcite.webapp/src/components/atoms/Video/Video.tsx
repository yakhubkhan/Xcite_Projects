import React from 'react'
import YouTube, { YouTubeProps } from 'react-youtube'
import { VideoComponentType } from '../../../types/content/component'
import styles from './Video.module.css'

const Video: React.FC<VideoComponentType> = ({
  youtubeLink,
  className = '',
  width = '800',
  title = '',
}) => {
  const opts: YouTubeProps['opts'] = {
    height: 'auto',
    width: width,
    playerVars: {
      autoplay: 0,
      color: 'white',
      modestbranding: 1,
    },
  }

  const getYouTubeVideoId = (url) => {
    const IdRegex =
      /(?:youtube(?:-nocookie)?\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/
    const videoId = url.match(IdRegex)[1]
    return videoId
  }

  return (
    <div
      className={`${styles.videoWrapper} ${className}`}
      style={{ maxWidth: width + 'px' }}
    >
      <YouTube
        videoId={getYouTubeVideoId(youtubeLink)}
        title={title}
        opts={opts}
      />
    </div>
  )
}

export default Video
