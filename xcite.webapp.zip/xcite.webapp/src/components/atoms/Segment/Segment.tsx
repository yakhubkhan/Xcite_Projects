import React from 'react'
import { CheckInCircleFilledIcon, CheckInCircleIcon } from '../Icon'
import Link from '../Link'

export declare type SegmentProps = {
  segments: {
    value: string
    actionUri: string
    disabled?: boolean
    completed?: boolean
  }[]
  openSeg: number
}

export default function Segment(props: SegmentProps): JSX.Element {
  const { segments, openSeg } = props
  return (
    <>
      <div className="flex flex-wrap">
        {segments.map((segment, index) => (
          <div
            key={`seg${index}`}
            className={`flex-auto text-center ${
              openSeg === index ? 'bg-white' : 'bg-gray-200'
            }
            ${index === 0 && 'ltr:rounded-tl-lg rtl:rounded-tr-lg'} ${
              index === segments.length - 1 &&
              'ltr:rounded-tr-lg rtl:rounded-tl-lg'
            }`}
          >
            <Link
              to={segment.actionUri}
              className={`flex justify-center items-center gap-3
                ${
                  segment.disabled
                    ? 'pointer-events-none cursor-none'
                    : 'cursor-pointer'
                }`}
            >
              <div
                className={`font-bold ${
                  openSeg === index ? 'text-primary-800' : 'text-gray-400'
                }`}
              >
                {segment.value}
              </div>
              {segment.completed && (
                <CheckInCircleFilledIcon className="w-6 h-6 text-functional-green-600 fill-current" />
              )}
            </Link>
          </div>
        ))}
      </div>
    </>
  )
}
