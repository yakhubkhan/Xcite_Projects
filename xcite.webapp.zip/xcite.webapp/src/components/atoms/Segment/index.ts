export { default } from './Segment'
