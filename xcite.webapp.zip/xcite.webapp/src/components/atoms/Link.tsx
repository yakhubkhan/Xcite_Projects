import * as React from 'react'
import { default as NextLink } from 'next/link'

interface IProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  to: string
}

const Link: ({ to, ...props }: IProps) => JSX.Element = ({
  to,
  ...props
}: IProps) => {
  return (
    <NextLink href={to}>
      <a {...props} />
    </NextLink>
  )
}

export default Link
