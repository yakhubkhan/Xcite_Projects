import React from 'react'

import { Story, Meta } from '@storybook/react'

import BundleDescription, { Props } from './BundleDescription'
import Grid from '../../atoms/Grid'

export default {
  title: 'Components/molecules/BundleDescription',
  component: BundleDescription,
} as Meta

const Template: Story<Props> = (args) => (
  <Grid>
    <div className="col-span-full">
      <BundleDescription {...args} />
    </div>
  </Grid>
)

export const Default = Template.bind({})

Default.args = {
  bundleItems: [
    {
      id: 'item-1',
      name: 'Philips Drip Coffee Maker - Black (HD7462/20)',
      brand: 'Phillips',
      details: '* Power: 1000W\n * Water capacity: 1.2L',
      image: {
        type: 'img',
        alt: 'Philips Drip Coffee Maker - Black (HD7462/20)',
        src: 'https://cdn.media.amplience.net/s/alghanim/634818-SET?img404=default&w=640&qlt=75&fmt=auto',
      },
      magentoProductId: '213234',
      productId: '90358885-3ebd-4555-ab26-6413d2b17e4b',
      sku: '634818',
      slug: 'philips-drip-coffee-maker-black-hd7462-20',
      colour: 'blue',
      mc1: 'HOME APPLIANCE',
      mc2: 'SMALL HOME APPLIANCE',
      mc3: 'PACKAGE',
    },
    {
      id: 'item-2',
      name: 'Philips ProMix Hand blender with Chopper and Whisk - 800W (HR2652/91)',
      brand: 'Phillips',
      details: '* 800W blending power\n * SpeedTouch with speed guidance',
      image: {
        type: 'img',
        alt: 'Philips ProMix Hand blender with Chopper and Whisk - 800W (HR2652/91)',
        src: 'https://cdn.media.amplience.net/s/alghanim/527221-SET?img404=default&w=640&qlt=75&fmt=auto',
      },
      magentoProductId: '223234',
      productId: '90358882-3ebd-4555-ab26-6413d2b17e4b',
      sku: '527221',
      slug: 'philips-promix-hand-blender-with-chopper-and-whisk-800w-hr2652-91',
      colour: 'blue',
      mc1: 'HOME APPLIANCE',
      mc2: 'SMALL HOME APPLIANCE',
      mc3: 'PACKAGE',
    },
    {
      id: 'item-3',
      name: 'Philips Compact Food Processor - 850W 2.1L (HR7530/01)',
      brand: 'Phillips',
      details: '* Power: 2200 W\n * Capacity: 1.7 L\n * Stainless steel design',
      image: {
        type: 'img',
        alt: 'Philips Compact Food Processor - 850W 2.1L (HR7530/01)',
        src: 'https://cdn.media.amplience.net/s/alghanim/526706-SET?img404=default&w=640&qlt=75&fmt=auto',
      },
      magentoProductId: '224234',
      productId: '90358812-3ebd-4555-ab26-6413d2b17e4b',
      sku: '526706',
      slug: 'philips-compact-food-processor-850w-2-1l-hr7530-01',
      colour: 'blue',
      mc1: 'HOME APPLIANCE',
      mc2: 'SMALL HOME APPLIANCE',
      mc3: 'PACKAGE',
    },
  ],
}
