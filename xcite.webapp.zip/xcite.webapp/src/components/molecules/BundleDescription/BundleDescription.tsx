import { useTranslation } from 'next-i18next'
import React from 'react'
import { HeadingEnum, BundleLineItemType } from '../../../types/content'
import Heading from '../../atoms/Heading'
import LineItem from '../LineItem'

export interface Props {
  bundleItems: BundleLineItemType[]
}

const BundleDescription = ({ bundleItems }: Props): JSX.Element => {
  const { t } = useTranslation()

  return (
    <div className="bundle-description">
      <Heading
        type={HeadingEnum.h2}
        className="typography-decorative-bold mb-10"
      >
        {t('pdp_product_bundle_description_heading')}
      </Heading>
      <Heading type={HeadingEnum.h3} className="typography-h2 mb-10">
        {t('pdp_product_bundle_description_subheading')}
      </Heading>
      <ul className="flex flex-col gap-10">
        {bundleItems.map((item) => (
          <li key={item.id}>
            <LineItem item={item} />
          </li>
        ))}
      </ul>
    </div>
  )
}

export default BundleDescription
