import { useTranslation } from 'next-i18next'
import { DomainLocale } from 'next/dist/server/config-shared'
import { useRouter } from 'next/router'
import React from 'react'
import environment from '../../../lib/environment'
import ArrowUpDown from '../../atoms/Icon/ArrowUpDown'

const findOtherDomainLocale = (
  locale: string | undefined,
  domainLocales: DomainLocale[] | undefined
) => {
  if (domainLocales && locale) {
    const domain = domainLocales.find(
      (domainLocale) => !domainLocale.locales?.includes(locale)
    )?.domain

    return domain
  }

  return ''
}

const CountrySelector = (): JSX.Element => {
  const { locale, domainLocales } = useRouter()
  const { t } = useTranslation()

  const otherDomain = findOtherDomainLocale(locale, domainLocales)

  const port = environment.isLocalEnvironment ? `:${environment.localPort}` : ''

  const href = otherDomain ? `//${otherDomain}${port}` : ''

  return (
    <a
      href={href}
      className="flex typography-small text-white cursor-pointer p-1"
    >
      <ArrowUpDown className="text-white stroke-current" />
      <span className="pl-2 rtl:pr-2">{t('country_switch_label')}</span>
    </a>
  )
}

export default CountrySelector
