import { useRouter } from 'next/router'
import React, { useEffect, useState } from 'react'
import { Autoplay, Pagination } from 'swiper'
import { Swiper, SwiperSlide } from 'swiper/react'

import { ButtonVariantEnum, CtaType, HeadingEnum } from '../../../types/content'
import { HeroBannerComponentType } from '../../../types/content/component'
import Button from '../../atoms/Button'
import Grid from '../../atoms/Grid'
import Heading from '../../atoms/Heading'
import Image from '../../atoms/Image/Image'

const HeroBanner: React.FunctionComponent<HeroBannerComponentType> = ({
  heroBanner: { slides },
  hideNavigationDots,
}) => {
  const [isLoop, setIsLoop] = useState(false)
  const router = useRouter()
  const openLink = (cta: CtaType | undefined) => {
    if (cta?.url) {
      router.push(cta.url)
    }
    // if (cta?.url && !cta?.isExternal) {
    //   router.push(cta.url)
    // } else if (cta?.url && cta?.isExternal) {
    //   window.open(cta?.url, '_blank')
    // }
  }

  useEffect(() => {
    slides.length > 1 ? setIsLoop(true) : setIsLoop(false)
  }, [slides.length])

  return (
    <Grid className="px-0 xs:px-0 sm:px-0 lg:px-0 xl:px-0">
      <div
        className={`col-span-full flex items-center ${
          hideNavigationDots ? '' : 'pb-6'
        }`}
      >
        <Swiper
          modules={hideNavigationDots ? [Autoplay] : [Autoplay, Pagination]}
          className="h-full w-full herobanner-swiper"
          direction="horizontal"
          initialSlide={1}
          slidesPerView={1}
          grabCursor={true}
          keyboard={{
            enabled: true,
            onlyInViewport: false,
          }}
          effect={'slide'}
          centeredSlides={true}
          autoplay={{
            delay: 3000,
            disableOnInteraction: false,
            pauseOnMouseEnter: true,
          }}
          loop={isLoop}
          breakpoints={{
            '1': {
              pagination: hideNavigationDots
                ? false
                : {
                    clickable: false,
                    el: '.herobanner-swiper-pagination',
                  },
            },
            '768': {
              pagination: hideNavigationDots
                ? false
                : {
                    clickable: true,
                    el: '.herobanner-swiper-pagination',
                  },
            },
          }}
        >
          {slides.map((slide, index) => (
            <SwiperSlide
              key={index}
              className={`h-full swiper-bg ${
                slide.cta?.url ? `cursor-pointer` : ``
              }`}
              onClick={() => openLink(slide.cta)}
            >
              <Image
                src={slide.image.src}
                alt={slide.image.alt}
                layout="fill"
                objectFit="cover"
                objectPosition="center"
              />
              <div
                className={`flex h-[inherit] relative z-10 ${
                  slide.isBlackGradient
                    ? `${slide.isLineEnd ? `gradient-end` : `gradient-start`}`
                    : ``
                }`}
              >
                <Grid className={`justify-center`}>
                  <div
                    style={{ ['--dynamic-color-3' as string]: slide.textColor }}
                    className={`col-span-6 flex gap-4 xs:gap-6 flex-col justify-center ${
                      slide.isLineEnd
                        ? `sm:col-start-7 items-end`
                        : `items-start`
                    }`}
                  >
                    {slide.heading && (
                      <Heading
                        type={HeadingEnum.h1}
                        className="text-dynamic-color-3 leading-2 text-xl xs:leading-4 xs:text-3xl"
                      >
                        {slide.heading}
                      </Heading>
                    )}
                    {slide.cta?.label && (
                      <div>
                        <Button
                          variant={ButtonVariantEnum.secondaryOnDark}
                          className={`text-dynamic-color-3 ring-dynamic-color-3 active:ring-dynamic-color-3 hover:ring-dynamic-color-3 focus:ring-dynamic-color-3 text-xs xs:text-base py-1 xs:py-3`}
                        >
                          {slide.cta?.label}
                        </Button>
                      </div>
                    )}
                  </div>
                </Grid>
              </div>
            </SwiperSlide>
          ))}
          {!hideNavigationDots && (
            <div className="herobanner-swiper-pagination"></div>
          )}
        </Swiper>
      </div>
    </Grid>
  )
}
export default HeroBanner
