import React from 'react'
import { Story, Meta } from '@storybook/react'
import HeroBanner from './HeroBanner'
import {
  ComponentTypeEnum,
  HeroBannerComponentType,
} from '../../../types/content/component'

export default {
  title: 'Components/molecules/HeroBanner',
  component: HeroBanner,
} as Meta

const Template: Story<HeroBannerComponentType> = (args) => (
  <HeroBanner {...args} />
)

export const Default = Template.bind({})

Default.args = {
  type: ComponentTypeEnum.heroBanner,
  heroBanner: {
    slides: [
      {
        heading: 'Macbook Pro M1',
        cta: {
          url: '/computers-tablet/c',
          label: 'Buy Now!',
        },
        image: {
          type: 'img',
          alt: '',
          src: 'https://cdn.media.amplience.net/i/alghanim/banner-header-mac-En%201',
        },
        isLineEnd: false,
        isBlackGradient: false,
        textColor: 'rgb(225,225,225)',
      },
      {
        heading: 'Sony Bravia XR',
        cta: {
          url: '/kw-outdoor-travel/c',
          label: 'Buy Now!',
        },
        image: {
          type: 'img',
          alt: '',
          src: 'https://cdn.media.amplience.net/i/alghanim/banner-header-sony-En',
        },
        isLineEnd: false,
        isBlackGradient: true,
        textColor: 'rgb(225,225,225)',
      },
      {
        heading: 'Redmi watch 2 lite',
        cta: {
          url: '/kw-home-automation/c',
          label: 'Buy Now!',
        },
        image: {
          type: 'img',
          alt: '',
          src: 'https://cdn.media.amplience.net/i/alghanim/redmi-header-banner',
        },
        isLineEnd: false,
        isBlackGradient: true,
        textColor: 'rgb(0,0,0)',
      },
    ],
  },
}
