import React, { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useTranslation } from 'next-i18next'
import { userProfileSelector } from '../../../redux/slices/profile'
import { ShowDigitalCodeComponentType } from '../../../types/content/component'
import { PlusIcon } from '../../atoms/Icon'
import LoadingIndicatorDot from '../../atoms/LoadingIndicatorDot'
import CopyCode from '../../atoms/CopyCode'
import StatusMessage from '../../atoms/StatusMessage'
import {
  getOrderHistoryReprintThunk,
  orderHistoryReprintSelector,
} from '../../../redux/slices/profile'
import {
  ReprintStatusEnum,
  AsyncResponseStatusEnum,
  StatusMessageEnum,
} from '../../../types/content'
import { useRouter } from 'next/router'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'

export default function ShowDigitalCode({
  txnId,
  sku,
}: ShowDigitalCodeComponentType): JSX.Element {
  const router = useRouter()
  const dispatch = useDispatch()
  const user = useSelector(userProfileSelector)
  const { t } = useTranslation()
  const [showCode, setShowCode] = useState(false)
  const [generatedCode, setGeneratedCode] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [hasError, setHasError] = useState(false)
  const [nAState, setNAState] = useState(false)
  const reprintResult = useSelector(orderHistoryReprintSelector)

  const {
    iso_639_1: language,
    country: { ctStore: store },
  } = localesFactory.createFromHrefLang(router?.locale).current

  const getActivationCode = () => {
    if (reprintResult?.status !== AsyncResponseStatusEnum.loading) {
      if (showCode) {
        setHasError(false)
      }

      setShowCode(!showCode)
    }
  }

  const setErrorState = () => {
    setIsLoading(false)
    setHasError(true)
    setGeneratedCode('')
    setNAState(false)
  }

  useEffect(() => {
    if (showCode && !generatedCode && !isLoading && !hasError && !nAState) {
      dispatch(
        getOrderHistoryReprintThunk({
          user,
          store,
          language,
          txnId,
          sku,
        })
      )
      setIsLoading(true)
    }
  }, [
    dispatch,
    generatedCode,
    hasError,
    isLoading,
    language,
    txnId,
    showCode,
    user,
    nAState,
    store,
    sku,
  ])

  useEffect(() => {
    if (isLoading && !generatedCode) {
      // Activation Code fetching is successful
      if (
        reprintResult?.status === AsyncResponseStatusEnum.succeeded &&
        sku === reprintResult.sku
      ) {
        switch (reprintResult.reprintStatus) {
          case ReprintStatusEnum.OK:
            setGeneratedCode(reprintResult.activationCode)
            setIsLoading(false)
            break
          case ReprintStatusEnum.ERROR_WHILE_PRINTING:
            setErrorState()
            setIsLoading(false)
            break
          case ReprintStatusEnum.NOT_APPLICABLE:
            setIsLoading(false)
            setNAState(true)
            break
          case ReprintStatusEnum.WAITING_FOR_RESULT:
            setTimeout(function () {
              setIsLoading(false)
            }, 20000)
            break
          default:
            break
        }
      }

      // Activation Code fetching has an error
      if (reprintResult?.status === AsyncResponseStatusEnum.failed) {
        setErrorState()
      }
    }
  }, [generatedCode, isLoading, reprintResult, nAState])

  return (
    <div className="flex gap-4 pl-4 pr-6">
      <span
        className={`rounded-[50%] bg-gray-100 w-6 h-6 stroke-gray-900 relative transition-all ${
          reprintResult?.status !== AsyncResponseStatusEnum.loading
            ? 'opacity-100 hover:cursor-pointer'
            : showCode
            ? 'opacity-100 hover:cursor-pointer'
            : 'opacity-30'
        }`}
        onClick={() => getActivationCode()}
      >
        <PlusIcon
          className={`w-4 h-4 absolute-center ${
            showCode && 'rotate-45'
          } transition-all`}
        />
      </span>
      <div className="w-full sm:max-w-xs">
        <div className="font-heading font-semibold mb-2">
          {!showCode
            ? t('profile_order_history_show_code_heading_closed')
            : t('profile_order_history_show_code_heading_open')}
        </div>
        {showCode &&
          (generatedCode ? (
            <CopyCode className="animate-appearFromAbove">
              {generatedCode}
            </CopyCode>
          ) : isLoading ? (
            <LoadingIndicatorDot className="animate-appearFromAbove">
              {t('codeLoadingIndicator_label')}
            </LoadingIndicatorDot>
          ) : nAState ? (
            <p>{t('checkout_order_confirmation_show_code_na_label')}</p>
          ) : (
            <div className="animate-appearFromAbove">
              <StatusMessage
                type={StatusMessageEnum.Error}
                className="leading-2 typography-label"
              >
                {t('profile_order_history_show_code_status_error')}
              </StatusMessage>
            </div>
          ))}
      </div>
    </div>
  )
}
