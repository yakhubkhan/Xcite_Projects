import React from 'react'
import { ContentHTMLBlocks } from '../../../types/content/component'

const HtmlComponent: React.FunctionComponent<ContentHTMLBlocks> = ({
  html,
  className,
}) => {
  return (
    <div className={className} dangerouslySetInnerHTML={{ __html: html }} />
  )
}
export default HtmlComponent
