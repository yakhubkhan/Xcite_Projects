import { useRouter } from 'next/router'
import { CtaType } from '../../../types/content'
import { HeadingEnum } from '../../../types/content'
import { MosaicComponentType } from '../../../types/content/component'
import Heading from '../../atoms/Heading'
import Image from '../../atoms/Image'

const MosaicComponent: React.FunctionComponent<MosaicComponentType> = ({
  mosaicComponent: { tiles },
}): JSX.Element => {
  const router = useRouter()
  const openLink = (cta: CtaType | undefined) => {
    if (cta?.url) {
      router.push(cta.url)
    }
    // if (cta?.url && !cta?.isExternal) {
    //   router.push(cta.url)
    // } else if (cta?.url && cta?.isExternal) {
    //   window.open(cta?.url, '_blank')
    // }
  }
  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 w-full mx-auto max-w-[1920px] gap-0 gap-x-0 gap-y-0">
      {tiles?.map((tile, index) => {
        const { title, image, cta } = tile
        return (
          <div
            className={`relative flex justify-center min-w-[180px] ${
              cta?.url ? `cursor-pointer` : ``
            }`}
            key={`${title}+${index}`}
            onClick={() => openLink(cta)}
          >
            <Image
              src={image.src}
              alt={image.alt}
              layout="intrinsic"
              height={480}
              width={480}
              objectFit="cover"
            />
            <div className="absolute bottom-0 sm:bottom-10 w-full text-center">
              {title && (
                <Heading type={HeadingEnum.h3} className="pt-4 px-5 text-white">
                  {title}
                </Heading>
              )}
              {cta?.url && (
                <div className="mx-2 my-4">
                  <Heading type={HeadingEnum.h5} className="text-white">
                    {cta?.label}
                  </Heading>
                </div>
              )}
            </div>
          </div>
        )
      })}
    </div>
  )
}

export default MosaicComponent
