import { Meta, Story } from '@storybook/react'
import { MosaicComponentType } from '../../../types/content/component'
import MosaicComponent from './MosaicComponent'

export default {
  title: 'Components/molecules/MosaicComponent',
  component: MosaicComponent,
} as Meta

const Template: Story<MosaicComponentType> = (args) => (
  <MosaicComponent {...args} />
)

export const Default = Template.bind({})

Default.args = {
  mosaicComponent: {
    tiles: [
      {
        title: 'Home appliances',
        cta: {
          url: '/product/fallback',
          tooltip: 'Appliances tooltip',
          label: 'Shop',
          isExternal: false,
        },
        image: {
          type: 'img',
          alt: 'appliances',
          src: 'https://cdn.media.amplience.net/i/alghanim/small-home-appliances/appliances',
        },
      },
      {
        title: 'Home appliances',
        cta: {
          url: '/product/fallback',
          tooltip: 'appliances tooltip2',
          label: 'Shop',
          isExternal: false,
        },
        image: {
          type: 'img',
          alt: 'appliances2',
          src: 'https://cdn.media.amplience.net/i/alghanim/page_yieldeditedcd-99705/appliances2',
        },
      },
      {
        title: 'Home appliances',
        cta: {
          url: 'https://www.xcite.com/apple-macbook-pro-m1-ram-8gb-256gb-ssd-13-3-inch-2020-space-grey.html',
          tooltip: 'appliances tooltip3',
          label: 'Shop',
          isExternal: true,
        },
        image: {
          type: 'img',
          alt: 'appliances3',
          src: 'https://cdn.media.amplience.net/i/alghanim/test-banner-header-en/appliances3',
        },
      },
      {
        title: 'Home appliances',
        cta: {
          url: '/product/fallback',
          tooltip: 'appliances tooltip4',
          label: 'Shop',
          isExternal: false,
        },
        image: {
          type: 'img',
          alt: 'appliances4',
          src: 'https://cdn.media.amplience.net/i/alghanim/banner-header-mac-En%201/appliances4',
        },
      },
    ],
  },
}
