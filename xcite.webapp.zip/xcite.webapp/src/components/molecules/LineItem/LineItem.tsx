import { useTranslation } from 'next-i18next'
import React from 'react'
import {
  BundleLineItemType,
  ButtonVariantEnum,
  HeadingEnum,
} from '../../../types/content'
import { reduceMarkdownBulletPoints } from '../../../util/templateUtils'
import { ButtonLink } from '../../atoms/Button/Button'
import Heading from '../../atoms/Heading'
import { ArrowTopRightSquareIcon } from '../../atoms/Icon'
import Image from '../../atoms/Image'
import MarkDown from '../../atoms/MarkDown'

export interface Props {
  item: BundleLineItemType
}
const NUMBER_DETAIL_LINES = 2

const LineItem = ({ item }: Props): JSX.Element => {
  const { t } = useTranslation()
  return (
    <article className="line-item grid grid-cols-6 gap-x-5 sm:grid-cols-12">
      <div className="col-span-2">
        <Image
          alt={item.image.alt}
          src={item.image.src}
          layout="intrinsic"
          width={280}
          height={280}
          objectFit="contain"
        />
      </div>
      <div className="col-span-4 sm:col-span-10">
        <div className="flex flex-col gap-4 items-start">
          <div>
            <span className="typography-small">{item.brand}</span>
            <Heading type={HeadingEnum.h5}>{item.name}</Heading>
          </div>
          <div className="typography-small">
            <MarkDown>
              {reduceMarkdownBulletPoints(item.details, NUMBER_DETAIL_LINES)}
            </MarkDown>
          </div>
          {item.slug && (
            <div>
              <ButtonLink
                variant={ButtonVariantEnum.textLink}
                href={`/${item.slug}/p`}
                isExternalLink
              >
                <div
                  className={`flex flex-row justify-start items-center gap-2`}
                >
                  <span className="typography-default text-primary-700">
                    {t('pdp_product_bundle_lineitem_product_page_link')}
                  </span>
                  <ArrowTopRightSquareIcon
                    className={`w-4 h-4 stroke-primary-700`}
                  />
                </div>
              </ButtonLink>
            </div>
          )}
        </div>
      </div>
    </article>
  )
}

export default LineItem
