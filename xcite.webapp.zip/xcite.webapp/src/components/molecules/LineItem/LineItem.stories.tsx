import React from 'react'

import { Story, Meta } from '@storybook/react'

import LineItem, { Props } from './LineItem'
import Grid from '../../atoms/Grid'

export default {
  title: 'Components/molecules/LineItem',
  component: LineItem,
} as Meta

const Template: Story<Props> = (args) => (
  <Grid>
    <div className="col-span-full">
      <LineItem {...args} />
    </div>
  </Grid>
)

export const Default = Template.bind({})

Default.args = {
  item: {
    id: 'item-1',
    name: 'Philips Drip Coffee Maker - Black (HD7462/20)',
    brand: 'Phillips',
    details: '* Power: 1000W\n * Water capacity: 1.2L',
    image: {
      type: 'img',
      alt: 'Philips Drip Coffee Maker - Black (HD7462/20)',
      src: 'https://cdn.media.amplience.net/s/alghanim/634818-SET?img404=default&w=640&qlt=75&fmt=auto',
    },
    magentoProductId: '213234',
    productId: '90358885-3ebd-4555-ab26-6413d2b17e4b',
    sku: '634818',
    slug: 'philips-drip-coffee-maker-black-hd7462-20',
    colour: 'blue',
    mc1: 'HOME APPLIANCE',
    mc2: 'SMALL HOME APPLIANCE',
    mc3: 'PACKAGE',
  },
}
