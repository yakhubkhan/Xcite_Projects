import React from 'react'
import { Meta, Story } from '@storybook/react'
import Grid from '../../atoms/Grid'
import ProductTile, { ProductTileType } from './ProductTile'

export default {
  title: 'Components/molecules/ProductTile',
  component: ProductTile,
} as Meta

const defaultProductTile: ProductTileType = {
  image: {
    alt: '',
    src: 'https://cdn.media.amplience.net/i/alghanim/iphone_white',
    type: 'img',
  },
  name: 'iPhone White 8GB 128GB',
  price: {
    currency: 'KD',
    formattedPrice: '699.000 KD',
    formattedPriceUnmodified: '729.000 KD',
    formattedCredit: '290.000 KD',
    value: 699.0,
    valueUnmodified: 729.0,
  },
  url: '/',
  position: '',
  queryID: '',
  magentoProductId: '213234',
  productId: '',
  sku: '1234',
}

const Template: Story<ProductTileType> = (props) => (
  <Grid>
    <div className="col-span-2 sm:col-span-4 lg:col-span-3">
      <ProductTile {...props} />
    </div>
  </Grid>
)

export const Default = Template.bind({})
Default.args = {
  ...defaultProductTile,
}

export const ProductWithBrand = Template.bind({})
ProductWithBrand.args = {
  ...defaultProductTile,
  brand: 'Apple',
}
