export { default } from './ProductTile'
