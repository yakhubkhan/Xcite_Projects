import { useTranslation } from 'next-i18next'
import { ButtonVariantEnum } from '../../../types/content'
import Button from '../../atoms/Button'
import { ButtonLink } from '../../atoms/Button/Button'
import Grid from '../../atoms/Grid'
import { useEffect, useState } from 'react'

const CookieBanner: React.FunctionComponent = () => {
  const { t } = useTranslation()
  const cookieName = 'cookieConsentStatus'
  const cookieValue = 'dismiss'
  const [displayBanner, setDisplayBanner] = useState(false)

  const saveConsentCookie = () => {
    const expires = new Date()
    expires.setFullYear(expires.getFullYear() + 1)
    document.cookie =
      cookieName +
      '=' +
      cookieValue +
      ';expires=' +
      expires.toUTCString() +
      ';path=/'
    setDisplayBanner(false)
  }

  useEffect(() => {
    const showCookieTimer = setTimeout(() => {
      const cookieData = document.cookie
        .split(';')
        .map((cookie) => cookie.slice(0, cookie.indexOf('=')).trim())
      cookieData.includes(cookieName)
        ? setDisplayBanner(false)
        : setDisplayBanner(true)
    }, 2000)
    return () => {
      clearTimeout(showCookieTimer)
    }
  }, [displayBanner])

  return (
    <>
      {displayBanner && (
        <div className="absolute w-full bg-white shadow-sm">
          <Grid className="items-center p-4">
            <div className="col-span-3 sm:col-span-9">
              <span className="typography-default">
                {t('cookie_banner_message')}&nbsp;
                <ButtonLink
                  variant={ButtonVariantEnum.textLink}
                  href="/privacy"
                  isExternalLink={true}
                >
                  <span className="typography-default text-primary-700">
                    {t('cookie_banner_privacy_policy_label')}
                  </span>
                </ButtonLink>
              </span>
            </div>
            <div className="col-span-1 sm:col-span-3">
              <Button
                variant={ButtonVariantEnum.primaryOnLight}
                className="w-full"
                onClick={saveConsentCookie}
              >
                {t('cookie_banner_dismiss_label')}
              </Button>
            </div>
          </Grid>
        </div>
      )}
    </>
  )
}

export default CookieBanner
