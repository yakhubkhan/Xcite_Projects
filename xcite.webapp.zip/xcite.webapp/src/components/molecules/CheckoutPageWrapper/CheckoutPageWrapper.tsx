import { useTranslation } from 'next-i18next'
import { useRouter } from 'next/router'
import React, { useEffect } from 'react'
import { useSelector } from 'react-redux'
import { cartTotalItemsSelector } from '../../../redux/slices/cart'
import { namedLinksSelector } from '../../../redux/slices/navigation'
import Grid from '../../atoms/Grid'
import EmptyPagePlaceholder from '../EmptyPagePlaceholder'

const CheckoutPageWrapper = ({
  children,
}: {
  children: React.ReactNode
}): JSX.Element => {
  const { t } = useTranslation()

  const router = useRouter()

  const totalItems = useSelector(cartTotalItemsSelector)
  const namedLinks = useSelector(namedLinksSelector)

  useEffect(() => {
    document.body.classList.add('checkout')
    return () => document.body.classList.remove('checkout')
  }, [])

  return (
    <div className="flex-1 sm:bg-gray-50 checkout-page">
      <Grid className="items-start py-10 sm:py-16">
        {totalItems > 0 ? (
          children
        ) : (
          <div className="cmn-flex-center col-span-full w-full sm:w-3/4 md:w-2/4 mx-auto">
            <EmptyPagePlaceholder
              headlineText={t('cart_empty_heading')}
              buttonText={t('cart_empty_button_label')}
              buttonOnClick={() => router.push(namedLinks.home)}
              showSearchBox
              searchBoxPlaceholder={t(
                'profile_order_history_noOrders_searchBox_placeholder'
              )}
            />
          </div>
        )}
      </Grid>
    </div>
  )
}

export default CheckoutPageWrapper
