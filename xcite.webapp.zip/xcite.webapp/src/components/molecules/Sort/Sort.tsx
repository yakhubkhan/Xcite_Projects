import React, { useEffect, useState } from 'react'
import { InputTypeEnum } from '../../../types/content'
import Field from '../../atoms/Field'
import { ArrowLeftIcon } from '../../atoms/Icon'

const arrowDownIcon = (
  <ArrowLeftIcon className="w-5 h-5 -rotate-90" stroke="#181818" />
)

const Sort = ({
  items,
  currentRefinement,
  refine,
}: {
  defaultRefinement: string
  items: { value: string; label: string }[]
  currentRefinement: string
  refine: (value) => void
}): JSX.Element => {
  const [sortVal, setSortVal] = useState(currentRefinement)
  const selectOptions = items.map((item) => {
    return { key: item.value, label: item.label }
  })

  useEffect(() => {
    setSortVal(currentRefinement)
  }, [currentRefinement, sortVal])

  return (
    <div className="w-full">
      <Field
        id="sort"
        onChange={(e) => {
          refine(e.target.value)
          setSortVal(e.target.value)
        }}
        rightIconTag={arrowDownIcon}
        selectOptions={selectOptions}
        type={InputTypeEnum.select}
        value={sortVal}
        showPlaceholderOption={false}
      ></Field>
    </div>
  )
}

export default Sort
