import { useTranslation } from 'next-i18next'
import { ButtonVariantEnum } from '../../../types/content'
import { ButtonLink } from '../../atoms/Button/Button'
import ToggleSwitch from '../../atoms/ToggleSwitch'

interface Props {
  handleToggle: () => void
  checked: boolean
}

const TermsAndConditionToggle = ({
  handleToggle,
  checked,
}: Props): JSX.Element => {
  const { t } = useTranslation()
  return (
    <div className={`flex flex-row gap-3 items-start`}>
      <div>
        <ToggleSwitch onChange={handleToggle} checked={checked} />
      </div>
      <div className="typography-small pt-3">
        {t('checkout_summary_terms_and_condition_message')}&nbsp;
        <ButtonLink
          variant={ButtonVariantEnum.textLink}
          href="/terms-and-conditions"
          isExternalLink
        >
          <span className="typography-small text-primary-700">
            {t('checkout_summary_terms_and_condition_label')}
          </span>
        </ButtonLink>
      </div>
    </div>
  )
}

export default TermsAndConditionToggle
