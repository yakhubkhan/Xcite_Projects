import { useTranslation } from 'next-i18next'
import { useRouter } from 'next/router'
import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux'
import gtmDatalayer from '../../../util/gtmUtils'
import { namedLinksSelector } from '../../../redux/slices/navigation'
import { getRouterDomainInfo } from '../../../util/routerUtils'
import { rewritePath } from '../../../util/seoUtils'

const LanguageSelector = ({
  className,
}: {
  className?: string
}): JSX.Element => {
  const router = useRouter()
  const { asPath } = router

  const path = rewritePath(asPath)

  const { t } = useTranslation()

  const namedLinks = useSelector(namedLinksSelector)

  const [langChangePram, setLangChangePram] = useState('')

  const getOtherLocaleHref = () => {
    const { domain, otherLocale } = getRouterDomainInfo(router)

    return otherLocale !== domain?.defaultLocale ? `/${otherLocale}` : ''
  }

  useEffect(() => {
    if (
      namedLinks.search &&
      (path.indexOf(namedLinks.search) === 0 || path.indexOf('/c?') > 0) &&
      path.indexOf('&reset') === -1
    ) {
      const queryParam = '?q=' + router.query.q + '&reset=list'
      setLangChangePram(queryParam)
    } else {
      setLangChangePram('')
    }
  })
  //}, [path, namedLinks.search]) // this is previous code for line 45

  return (
    <a
      href={`${getOtherLocaleHref()}${path}${langChangePram}`}
      className={`block typography-small cursor-pointer p-1 z-50 ${className}`}
      onClick={() =>
        gtmDatalayer('navigation_menu', 'navigation_menu', 'Language-click')
      }
    >
      {t('language_switch_label')}
    </a>
  )
}

export default LanguageSelector
