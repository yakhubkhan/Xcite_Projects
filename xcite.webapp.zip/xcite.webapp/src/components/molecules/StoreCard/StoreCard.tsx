import { HeadingEnum } from '../../../types/content'
import { FooterComponent } from '../../../types/content/footer'
import Heading from '../../atoms/Heading'
import Image from '../../atoms/Image'

const StoreCard = ({ top }: FooterComponent): JSX.Element => {
  return (
    <div className="col-span-full sm:w-[318px]">
      <div className="bg-functional-blue-100 rounded-lg px-5 py-3">
        <Heading type={HeadingEnum.h5} className="text-primary-900 mb-4">
          {top?.mobileAppBlock?.title}
        </Heading>
        <div className="flex flex-row gap-2 rtl:flex-row-reverse">
          {top?.mobileAppBlock?.appLinks.map((image, index) => {
            return (
              <a
                key={index}
                href={image.url}
                className="flex"
                target="_blank"
                rel="noreferrer"
              >
                <Image
                  src={image.icon.src}
                  alt={image.icon.alt}
                  layout="intrinsic"
                  width={134}
                  height={40}
                ></Image>
              </a>
            )
          })}
        </div>
      </div>
    </div>
  )
}

export default StoreCard
