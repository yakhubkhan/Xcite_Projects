import React from 'react'

import { Story, Meta } from '@storybook/react'

import Error404, { Props } from './Error404'

export default {
  title: 'Components/molecules/Error404',
  component: Error404,
} as Meta

const Template: Story<Props> = (args) => (
  <div className="p-4 bg-product-ice-50 h-screen flex items-center">
    <Error404 {...args} />
  </div>
)

export const Default = Template.bind({})

Default.args = {
  homeLinkHref: '/',
  optionalPageLink: {
    title: 'Deals',
    href: '/',
  },
}
