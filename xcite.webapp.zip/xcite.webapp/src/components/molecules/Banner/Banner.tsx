import React from 'react'
import { ButtonVariantEnum, HeadingEnum } from '../../../types/content'
import { ButtonLink } from '../../atoms/Button/Button'
import Heading from '../../atoms/Heading'
import Image from '../../atoms/Image'
import { BannerComponentType } from '../../../types/content/component'

const Banner: React.FunctionComponent<BannerComponentType> = ({
  twoColumnBanner: {
    heading,
    content,
    cta,
    media,
    imageAlignment,
    textColor = 'white',
    bgColor = '#2e266c',
  },
}) => {
  return (
    <div
      style={{
        ['--dynamic-color-1' as string]: textColor,
        ['--dynamic-color-2' as string]: bgColor,
      }}
      className={`flex flex-col w-full h-[200vw] mx-auto sm:h-[50vw] sm:max-h-[720px] ${
        imageAlignment ? 'sm:flex-row-reverse' : 'sm:flex-row'
      }`}
    >
      <div className={`relative flex-1`}>
        {media.type === 'img' && (
          <Image
            src={media.src}
            alt={media.alt}
            layout="fill"
            objectFit="cover"
          />
        )}
      </div>
      <div
        className={`flex-1 flex flex-col items-center xl:items-start justify-center bg-dynamic-color-2`}
      >
        <div className="px-6 sm:px-16 lg:px-32 xl:max-w-4xl ">
          <Heading type={HeadingEnum.h2} className={`text-dynamic-color-1`}>
            {heading}
          </Heading>
          <p className={`typography-default text-dynamic-color-1 my-6`}>
            {content}
          </p>
          {cta.label && cta.url && (
            <ButtonLink
              variant={ButtonVariantEnum.secondaryOnDark}
              className="text-dynamic-color-1 ring-dynamic-color-1 active:bg-dynamic-color-2 active:ring-dynamic-color-1 hover:bg-dynamic-color-2 hover:ring-dynamic-color-1 focus:ring-dynamic-color-1"
              href={cta.url}
              isExternalLink={cta.isExternal}
            >
              {cta.label}
            </ButtonLink>
          )}
        </div>
      </div>
    </div>
  )
}

export default Banner
