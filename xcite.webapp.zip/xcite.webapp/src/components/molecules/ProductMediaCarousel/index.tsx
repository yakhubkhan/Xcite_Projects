export { default } from './ProductMediaCarousel'
