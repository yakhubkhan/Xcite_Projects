import { useTranslation } from 'next-i18next'
import React, { useState } from 'react'
import { useSelector } from 'react-redux'

import {
  AsyncResponseStatusEnum,
  ButtonVariantEnum,
  HeadingEnum,
  PaymentMethodName,
  PaymentMethodType,
  BankPromoType,
} from '../../../types/content'
import { cartStatusSelector } from '../../../redux/slices/cart'
import { paymentStatusSelector } from '../../../redux/slices/payment'
import Button from '../../atoms/Button'
import Heading from '../../atoms/Heading'
import PaymentMethodIcon from '../../atoms/PaymentMethodIcon'
import SelectionBox from '../../atoms/SelectionBox'
import gtmDatalayer from '../../../util/gtmUtils'
import styles from './Payment.module.css'
import BankPromos from './BankPromos'

const PaymentMethodForm = ({
  selectedPaymentMethod,
  paymentMethods,
  bankPromos,
  onSubmitPaymentMethod,
}: {
  selectedPaymentMethod?: PaymentMethodName
  paymentMethods: PaymentMethodType[]
  bankPromos: BankPromoType[]
  onSubmitPaymentMethod: (paymentMethod?: PaymentMethodName) => void
}): JSX.Element => {
  const { t } = useTranslation()

  const paymentStatus = useSelector(paymentStatusSelector)
  const cartStatus = useSelector(cartStatusSelector)

  const [paymentMethod, setPaymentMethod] = useState(selectedPaymentMethod)

  const onPaymentMethodChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPaymentMethod(PaymentMethodName[e.target.value])
  }

  const onPaymentSubmitGtm = () => {
    const eventActionObj =
      '{"paymentMethod":' +
      JSON.stringify(paymentMethod) +
      ',"eventAction": "Confirm Payment Type"}'
    gtmDatalayer(
      'order_review_options',
      'Order Review Options View',
      eventActionObj
    )
  }

  return (
    <form
      className="flex flex-col gap-8"
      onSubmit={(e) => {
        e.preventDefault()
        onSubmitPaymentMethod(paymentMethod)
        onPaymentSubmitGtm()
      }}
      data-testid="submit-payment-method"
    >
      
      <Heading type={HeadingEnum.h4}>
        {t('checkout_payment_form_heading')}
      </Heading>
	  {bankPromos.length >= 1 && (
        <div className={`flex-1 ${styles.fieldset}`}>
          <ul className="flex flex-col gap-4">
            {bankPromos.map((promoData, index) => {
              return (
                <BankPromos
                  promoTitle={promoData?.title}
                  key={promoData?.key}
                  promoUrl={promoData?.iconUrl}
                  offerHeading={promoData?.offerHeading}
                  offerDetails={promoData?.offerDescription}
                  termsHeading={promoData?.termsHeading}
                  termsDetails={promoData?.termsDescription}

                />
              )


            })}
          </ul>
        </div>
      )}
      <div className="flex-1">
        <ul className="flex flex-col gap-4">
          {paymentMethods.map((method, index) => {
            return (
              <li key={'pm' + index}>
                {method && (
                  <SelectionBox
                    value={method.name}
                    onValChange={onPaymentMethodChange}
                    checked={
                      method.name.toLowerCase() === paymentMethod?.toLowerCase()
                    }
                    inputName="payment-method"
                    inputId={`payment-${method.name}`}
                    extraClassName="items-center"
                  >
                    <PaymentMethodIcon
                      methodName={method.name}
                      checked={
                        method.name.toLowerCase() ===
                        paymentMethod?.toLowerCase()
                      }
                    />
                    <span className="flex-1">{method.label}</span>
                  </SelectionBox>
                )}
              </li>
            )
          })}
        </ul>
      </div>
      <Button
        type="submit"
        variant={ButtonVariantEnum.primaryOnLight}
        disabled={
          !paymentMethod ||
          cartStatus === AsyncResponseStatusEnum.loading ||
          paymentStatus === AsyncResponseStatusEnum.loading
        }
      >
        {t('checkout_payment_form_button_label')}
      </Button>
    </form>
  )
}

export default PaymentMethodForm
