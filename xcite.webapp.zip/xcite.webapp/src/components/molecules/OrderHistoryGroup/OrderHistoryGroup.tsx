import Button from '../../atoms/Button'
import { ButtonVariantEnum, HeadingEnum, Order } from '../../../types/content'
import Heading from '../../atoms/Heading'
import { useTranslation } from 'next-i18next'
import { useState } from 'react'
import { ReceiptSlipIcon } from '../../atoms/Icon'
import OrderHistoryTile from '../OrderHistoryTile'
import PaymentSummary from '../PaymentSummary'

const orderInfoGenerator = (infoTitle: string, infoDetails: string) => {
  return (
    <div>
      <div className="flex mb-2">
        <ReceiptSlipIcon className="h-6 w-6 text-gray-500 stroke-current" />
        <div className="flex-1 typography-small-strong pl-2">{infoTitle}</div>
      </div>
      <div className="cmn-flex-items-center">
        <span className="flex-1 typography-small text-gray-600 leading-2">
          {infoDetails}
        </span>
      </div>
    </div>
  )
}

const OrderHistoryGroup = ({ order }: { order: Order }): JSX.Element => {
  const { t } = useTranslation()
  const [ordersDetailsToggle, setOrdersDetailsToggle] = useState(true)

  const openChatWidget = () => {
    document.getElementById('mobile-chat-container')?.click()
  }

  const formatRAPPaymentOption = (rapPaymentCode: string): string => {
    switch (rapPaymentCode) {
      case 'KGUL':
        return t('profile_order_history_rap_payment_option_kgul')
      case 'PGBC':
        return t('profile_order_history_rap_payment_option_pgbc')
      case 'PTMC':
        return t('profile_order_history_rap_payment_option_ptmc')
      case 'PGBT':
        return t('profile_order_history_rap_payment_option_pgbt')
      case 'XCTK':
        return t('profile_order_history_rap_payment_option_xctk')
      case 'PTVI':
        return t('profile_order_history_rap_payment_option_ptvi')
      case 'XCTJ':
        return t('profile_order_history_rap_payment_option_xctj')
      case 'PTAM':
        return t('profile_order_history_rap_payment_option_ptam')
      case 'GCCF':
        return t('profile_order_history_rap_payment_option_gccf')
      case 'PTVJ':
        return t('profile_order_history_rap_payment_option_ptvj')
      case 'A1':
        return t('profile_order_history_rap_payment_option_a1')
      case 'A2':
        return t('profile_order_history_rap_payment_option_a2')
      default:
        return ''
    }
  }

  return (
    <div
      className={`mb-8 sm:mb-10 last:mb-0 ${
        !ordersDetailsToggle
          ? ''
          : 'rounded-lg sm:rounded-2xl border-gray-400 border-[1px] p-5 sm:p-10 sm:pt-9'
      }`}
    >
      <div
        className={`${
          !ordersDetailsToggle
            ? 'rounded-lg sm:rounded-2xl border-gray-400 border-[1px] p-5 sm:p-10 sm:pt-9'
            : ''
        }`}
      >
        <div className="flex flex-col gap-10">
          <div>
            <Heading type={HeadingEnum.h3}>
              {t('profile_order_history_tile_headline', {
                id: order.orderNumber,
              })}
            </Heading>
            <p>
              {`${t('profile_order_history_order_created_label')} ${
                order.placedOnDate
              }`}
            </p>
          </div>
          <ul>
            {order.lineItems.map((lineItem) => (
              <OrderHistoryTile
                key={lineItem.id}
                item={lineItem}
                orderPlacedOnDate={order.placedOnDate}
              />
            ))}
          </ul>
          {!ordersDetailsToggle && (
            <>
              <div className="flex flex-col gap-6 p-4 bg-gray-50 rounded-lg">
                {order.shippingAddress &&
                  orderInfoGenerator(
                    t('checkout_shipping_form_heading'),
                    order.shippingAddress
                  )}
                {order.billingAddress &&
                  orderInfoGenerator(
                    t('checkout_billing_address_form_heading'),
                    order.billingAddress
                  )}
                {order.paymentMethod &&
                  orderInfoGenerator(
                    t('cart_checkout_payment_label'),
                    formatRAPPaymentOption(order.paymentMethod)
                  )}
              </div>
              <div className="border border-functional-blue-50 rounded-lg p-2">
                <span className="typography-default">
                  {t('profile_order_history_page_cancel_or_return_message')}
                  &nbsp;
                  <span
                    className={`${
                      globalThis?.Freshbots ? 'underline cursor-pointer' : ''
                    }`}
                    onClick={globalThis?.Freshbots && openChatWidget}
                  >
                    {t(
                      'profile_order_history_page_contact_customer_service_message'
                    )}
                  </span>
                  .
                </span>
              </div>
            </>
          )}
        </div>
      </div>
      {!ordersDetailsToggle && (
        <div className="px-6 sm:px-10 pt-10">
          <PaymentSummary paymentSummaryDetails={order.price} />
        </div>
      )}
      <div className={'mt-10'}>
        <Button
          className={`w-full ${!ordersDetailsToggle ? '' : 'sm:w-fit'}`}
          variant={ButtonVariantEnum.secondaryOnLight}
          onClick={() => setOrdersDetailsToggle(!ordersDetailsToggle)}
        >
          {ordersDetailsToggle
            ? t('profile_order_history_tile_details_button_label')
            : t('profile_order_history_tile_hide_details_button_label')}
        </Button>
      </div>
    </div>
  )
}

export default OrderHistoryGroup
