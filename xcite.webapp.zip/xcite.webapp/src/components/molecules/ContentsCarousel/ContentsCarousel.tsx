import React from 'react'
import { Navigation } from 'swiper'
import { Swiper, SwiperSlide } from 'swiper/react'

import { ContentsCarouselComponentType } from '../../../types/content/component'
import Grid from '../../atoms/Grid'
import ContentsCarouselTile from '../ContentsCarouselTile'

const ContentsCarousel: React.FunctionComponent<ContentsCarouselComponentType> =
  ({ contentsCarousel: { slides } }) => {
    return slides?.length > 0 ? (
      <Grid className="px-0 sm:px-0 lg:px-0">
        <div className="col-span-full">
          <Swiper
            slidesPerView={'auto'}
            spaceBetween={4}
            className="contents-carousel-swiper"
            modules={[Navigation]}
            loop={true}
            navigation
            breakpoints={{
              '1': {
                slidesPerView: 1.65,
              },
              '550': {
                slidesPerView: 2.5,
              },
              '768': {
                slidesPerView: 3.25,
              },
              '1024': {
                slidesPerView: 4.25,
              },
              '1200': {
                slidesPerView: 5.25,
              },
            }}
          >
            {slides.map((slide, index) => (
              <SwiperSlide key={index + 'cc'} className="px-2">
                <ContentsCarouselTile {...slide} />
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </Grid>
    ) : (
      <> </>
    )
  }
export default ContentsCarousel
