export { default } from './ContentsCarousel'
