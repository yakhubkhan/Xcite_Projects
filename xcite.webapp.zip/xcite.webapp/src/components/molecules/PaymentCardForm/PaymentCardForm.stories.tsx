import React from 'react'

import { Story, Meta } from '@storybook/react'

import PaymentCardForm, { Props } from './PaymentCardForm'

export default {
  title: 'Components/atoms/PaymentCardForm',
  component: PaymentCardForm,
} as Meta

const Template: Story<Props> = (args) => (
  <div className="p-4">
    <PaymentCardForm {...args} />
  </div>
)

export const Default = Template.bind({})

Default.args = {
  onCardDetailsSubmitted: () => console.log('payment submitted'),
}
