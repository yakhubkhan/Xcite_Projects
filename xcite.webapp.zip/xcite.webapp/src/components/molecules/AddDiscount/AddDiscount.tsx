import { useTranslation } from 'next-i18next'
import { useRouter } from 'next/router'
import { useCallback, useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import {
  addDiscountThunk,
  cdpCouponDetailsSelector,
  discountCodesSelector,
  discountErrorParamsSelector,
  discountStatusSelector,
  removeDiscountThunk,
} from '../../../redux/slices/cart'
import { userProfileSelector } from '../../../redux/slices/profile'
import {
  AsyncResponseStatusEnum,
  ButtonVariantEnum,
  CouponCodeReasonEnum,
  HeadingEnum,
  ToastDuration,
  ToastType,
} from '../../../types/content'
import gtmDatalayer from '../../../util/gtmUtils'
import Button from '../../atoms/Button'
import ErrorMessage from '../../atoms/ErrorMessage'
import Field from '../../atoms/Field'
import Heading from '../../atoms/Heading'
import { DiscountIcon, MinusIcon, PlusIcon } from '../../atoms/Icon'
import Toaster from '../../atoms/Toaster'

const AddDiscount = (): JSX.Element => {
  const { t } = useTranslation()
  const dispatch = useDispatch()
  const router = useRouter()
  const user = useSelector(userProfileSelector)
  const discount = useSelector(discountCodesSelector)
  const discountErrorMsg = useSelector(discountErrorParamsSelector)
  const discountStatus = useSelector(discountStatusSelector)
  const cdpcouponDetails = useSelector(cdpCouponDetailsSelector)
  const [showDiscountField, setShowDiscountField] = useState(false)
  const [discountCode, setDiscountCode] = useState('')
  const [isDiscountApplied, setIsDiscountApplied] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')
  const [successMsg, setSuccessMsg] = useState('')
  const [discountError, setDiscountError] = useState('')
  const [appliedCode, setAppliedCode] = useState('')
  const {
    iso_639_1: language,
    country: { ctStore: store },
    hreflang,
  } = localesFactory.createFromHrefLang(router?.locale).current

  const discountHandler = () => {
    if (isDiscountApplied) {
      gtmDatalayer('remove_cdp', 'remove_cdp', 'remove_cdp')
    }
    setShowDiscountField(!showDiscountField)
    if (errorMessage) {
      setErrorMessage('')
      setDiscountCode('')
    }
    if (isDiscountApplied) {
      dispatch(
        removeDiscountThunk({
          store,
          user,
          language,
          locale: hreflang,
          promocode: appliedCode,
        })
      )
      closeDiscountField()
    }
  }

  const validateDiscountCode = (code: string) => {
    setErrorMessage('')
    const discountCouponRegex = new RegExp('^[a-zA-Z0-9\\s]+$')
    let error = ''
    if (!discountCouponRegex.test(code)) {
      error = t('discount_invalid_promocode_message')
    }
    return error
  }

  const closeDiscountField = () => {
    if (!isDiscountApplied) setIsDiscountApplied(false)
    setShowDiscountField(false)
    setDiscountCode('')
  }

  const handleDiscountCode = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDiscountCode(e.target.value)
  }

  const submitDiscountCode = useCallback(
    (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault()
      const errors = validateDiscountCode(discountCode)
      setDiscountError(errors)
      if (!errors) {
        dispatch(
          addDiscountThunk({
            store,
            user,
            language,
            locale: hreflang,
            promocode: discountCode,
          })
        )
      }
    },
    [discountCode, dispatch, language, store, user]
  )

  useEffect(() => {
    if (discount.length > 0 || cdpcouponDetails) {
      setAppliedCode(cdpcouponDetails?.couponCode || discount[0].code)
      setIsDiscountApplied(true)
      setShowDiscountField(false)
    } else {
      setIsDiscountApplied(false)
    }
  }, [discount, cdpcouponDetails, appliedCode])

  useEffect(() => {
    const settingErrorMessage = (couponCodeReason) => {
      switch (couponCodeReason) {
        case CouponCodeReasonEnum.InvalidCoupon:
          return t('discount_invalid_promocode_message')
        case CouponCodeReasonEnum.InactivePromotion:
          return t('discount_invalid_promocode_message')
        case CouponCodeReasonEnum.ExpiredCoupon:
          return t('discount_expired_promocode_message')
        case CouponCodeReasonEnum.RedeemedCoupon:
          return t('discount_redeemed_promocode_message')
        case CouponCodeReasonEnum.InvalidProductCoupon:
          return t('discount_invalid_product_promocode_message')
        case CouponCodeReasonEnum.MinOrderCoupon:
          return t('discount_minorder_promocode_message')
        case CouponCodeReasonEnum.OfflineCoupon:
          return t('discount_offline_promocode_message')
        case CouponCodeReasonEnum.OrderTypeCoupon:
          return t('discount_ordertype_promocode_message')
        case CouponCodeReasonEnum.MinProductValueCoupon:
          return t('discount_invalid_promocode_message')
        default:
          return t('discount_invalid_promocode_message')
      }
    }
    setErrorMessage(settingErrorMessage(discountErrorMsg?.couponCodeReason))
  }, [discountErrorMsg, t])

  useEffect(() => {
    if (discount.length > 0 || cdpcouponDetails) {
      setSuccessMsg(t('checkout_order_discount_success_message'))
      gtmDatalayer('add_cdp', 'add_cdp', 'add_cdp')
    }
  }, [discount, cdpcouponDetails, submitDiscountCode, t])

  return (
    <div
      className={`flex flex-row gap-4 ${
        isDiscountApplied ? `items-center` : ''
      }`}
    >
      <Button
        variant={ButtonVariantEnum.buttonCircle}
        onClick={discountHandler}
        className={`flex-none`}
      >
        {isDiscountApplied ? (
          <MinusIcon className={`h-full w-full stroke-current text-black`} />
        ) : (
          <PlusIcon
            className={`h-full w-full stroke-current text-black ${
              showDiscountField ? `rotate-45` : ``
            }`}
          />
        )}
      </Button>
      {isDiscountApplied && (
        <DiscountIcon
          className={`h-12 w-12 stroke-current text-gray-500 flex-none`}
        />
      )}
      <div className="flex-1 text-clip overflow-hidden">
        <Heading type={HeadingEnum.h5}>
          {isDiscountApplied
            ? discount[0]?.description
              ? discount[0]?.description
              : t('checkout_order_cdp_coupon_success_message')
            : showDiscountField
            ? t('checkout_order_discount_type_your_code_label')
            : t('checkout_order_discount_add_discount_label')}
        </Heading>
        {showDiscountField && (
          <form onSubmit={submitDiscountCode}>
            <div className="flex flex-row my-2 sm:max-w-xs">
              <div className="flex-auto">
                <Field
                  id="discountCode"
                  value={discountCode}
                  onChange={handleDiscountCode}
                  placeholder={t('checkout_order_discount_placeholder_label')}
                  className="ltr:rounded-l ltr:rounded-r-none rtl:rounded-r rtl:rounded-l-none"
                />
              </div>
              <Button
                disabled={discountStatus === AsyncResponseStatusEnum.loading}
                variant={ButtonVariantEnum.primaryOnLight}
                type="submit"
                className="ltr:rounded-r ltr:rounded-l-none rtl:rounded-l rtl:rounded-r-none w-1/4"
              >
                {t('checkout_order_discount_apply_label')}
              </Button>
            </div>
            {errorMessage && <ErrorMessage>{errorMessage}</ErrorMessage>}
            {discountError && <ErrorMessage>{discountError}</ErrorMessage>}
          </form>
        )}
        {discountStatus === AsyncResponseStatusEnum.succeeded && successMsg && (
          <Toaster
            toastMsg={`${successMsg}`}
            className={`cmn-toast`}
            duration={ToastDuration}
            type={ToastType.success}
          />
        )}
      </div>
    </div>
  )
}

export default AddDiscount
