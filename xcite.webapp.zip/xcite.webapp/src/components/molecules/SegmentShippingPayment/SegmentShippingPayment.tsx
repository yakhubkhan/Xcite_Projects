import React from 'react'
import Segment from '../../atoms/Segment'

const SegmentShippingPayment = ({ t, openSeg }): JSX.Element => {
  return (
    <Segment
      segments={[
        {
          value: t('checkout_shipping_segment_label'),
          actionUri: '/checkout/shipping',
          disabled: true,
        },
        {
          value: t('checkout_payment_segment_label'),
          actionUri: '/checkout/payment',
        },
      ]}
      openSeg={openSeg}
    />
  )
}

export default SegmentShippingPayment
