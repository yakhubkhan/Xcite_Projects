export { default } from './SegmentShippingPayment'
