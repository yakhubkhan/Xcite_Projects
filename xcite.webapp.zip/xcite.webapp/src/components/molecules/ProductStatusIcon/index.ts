export { default } from './ProductStatusIcon'
