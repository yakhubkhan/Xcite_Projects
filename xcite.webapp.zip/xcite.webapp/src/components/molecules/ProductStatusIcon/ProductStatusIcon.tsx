import { useTranslation } from 'react-i18next'
import { CommercetoolsMessageCodeEnum } from '../../../types/commerceTools'
import { ProductStatusEnum } from '../../../types/content'
import {
  AlarmClockIcon,
  CheckInCircleFilledIcon,
  CloseFilledIcon,
  WarningFilledIcon,
} from '../../atoms/Icon'

const checkInCircleFilledIcon = (
  <CheckInCircleFilledIcon
    className="w-4 h-4"
    fill="#639448"
    stroke="#639448"
  />
)

const closeFilledIcon = <CloseFilledIcon className="w-4 h-4" fill="#B83830" />

const warningFilledIcon = (
  <WarningFilledIcon className="w-4 h-4" fill="#B83830" />
)

const iconMsgGenerator = (icon, message) => {
  return (
    <div className="flex items-center gap-x-1">
      {icon}
      <span className="typography-small text-functional-red-800">
        {message}
      </span>
    </div>
  )
}

// TODO - for Only few left
// const alarmClockIcon = <AlarmClockIcon className="w-4 h-4" stroke="#FEA41A" />

const ProductStatusIcon = ({
  methodName,
}: {
  methodName: ProductStatusEnum | CommercetoolsMessageCodeEnum | undefined
}): JSX.Element => {
  const { t } = useTranslation()
  switch (methodName) {
    case ProductStatusEnum.OutOfStock:
      return iconMsgGenerator(
        warningFilledIcon,
        t('pdp_product_outofstock_label')
      )
    case ProductStatusEnum.Discontinued:
      return iconMsgGenerator(
        closeFilledIcon,
        t('pdp_product_discontinued_label')
      )
    case ProductStatusEnum.InStock:
      return (
        <div className="flex items-center gap-x-1">
          {checkInCircleFilledIcon}
          <span className="typography-small">
            {t('pdp_product_inStock_label')}
          </span>
        </div>
      )
    case CommercetoolsMessageCodeEnum.PRODUCT_STATUS_OUT_OF_ONLINE_STOCK:
      return iconMsgGenerator(
        warningFilledIcon,
        t('pdp_product_outofstock_label')
      )
    case CommercetoolsMessageCodeEnum.PRODUCT_STATUS_DISCONTINUED:
      return iconMsgGenerator(
        closeFilledIcon,
        t('pdp_product_discontinued_label')
      )
    case CommercetoolsMessageCodeEnum.PRODUCT_STATUS_OUT_OF_CNC_STOCK:
      return iconMsgGenerator(
        warningFilledIcon,
        t('cart_checkout_item_outofstock_store_label')
      )
    case CommercetoolsMessageCodeEnum.PRODUCT_STATUS_OUT_OF_CNC_ONLINE_IN_STOCK:
      return iconMsgGenerator(
        warningFilledIcon,
        t('cart_checkout_item_outofstock_store_label')
      )
    case CommercetoolsMessageCodeEnum.PRODUCT_STATUS_OUT_OF_SELECTED_STORE_STOCK:
      return iconMsgGenerator(
        warningFilledIcon,
        t('cart_checkout_item_outofstock_selected_store_label')
      )
    case CommercetoolsMessageCodeEnum.INSUFFICIENT_STOCK_ONLINE:
      return iconMsgGenerator(
        warningFilledIcon,
        t('cart_error_insufficient_product_status')
      )
    case CommercetoolsMessageCodeEnum.INSUFFICIENT_STOCK_CNC:
      return iconMsgGenerator(
        warningFilledIcon,
        t('cart_error_insufficient_product_status')
      )
    case CommercetoolsMessageCodeEnum.CLICK_AND_COLLECT_NOT_ALLOWED:
      return iconMsgGenerator(
        warningFilledIcon,
        t('cart_error_click_and_collect_not_allowed')
      )
    default:
      return <></>
  }
}

export default ProductStatusIcon
