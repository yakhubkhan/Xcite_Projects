export { default } from './ContentRowText'
