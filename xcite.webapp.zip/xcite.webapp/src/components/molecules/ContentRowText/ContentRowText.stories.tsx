import React from 'react'
import { Meta, Story } from '@storybook/react'
import { ContentRowTextBlocks } from '../../../types/content/component'
import ContentRowText from './ContentRowText'

export default {
  title: 'Components/molecules/ContentRowText',
  component: ContentRowText,
} as Meta

const Template: Story<ContentRowTextBlocks> = (args) => (
  <ContentRowText {...args} />
)

export const FourItemsWithVariants = Template.bind({})
export const ThreeItems = Template.bind({})
export const TwoItems = Template.bind({})
export const OneItem = Template.bind({})

FourItemsWithVariants.args = {
  textBlocks: [
    {
      image: {
        src: 'https://cdn.media.amplience.net/i/alghanim/iphone_white',
        alt: 'Alt text',
        type: 'img',
      },
      heading: 'This is a headline',
      text: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. ',
    },
    {
      image: {
        src: 'https://cdn.media.amplience.net/i/alghanim/iphone_white',
        alt: 'Alt text',
        type: 'img',
      },
      heading: 'This is a headline',
    },
    {
      text: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. ',
    },
    {
      heading: 'This is a headline',
      text: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. ',
    },
  ],
}

ThreeItems.args = {
  textBlocks: [
    {
      image: {
        src: 'https://cdn.media.amplience.net/i/alghanim/iphone_white',
        alt: 'Alt text',
        type: 'img',
      },
      heading: 'This is a headline',
      text: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. ',
    },
    {
      image: {
        src: 'https://cdn.media.amplience.net/i/alghanim/iphone_white',
        alt: 'Alt text',
        type: 'img',
      },
      heading: 'This is a headline',
      text: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. ',
    },
    {
      image: {
        src: 'https://cdn.media.amplience.net/i/alghanim/iphone_white',
        alt: 'Alt text',
        type: 'img',
      },
      heading: 'This is a headline',
      text: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. ',
    },
  ],
}

TwoItems.args = {
  textBlocks: [
    {
      image: {
        src: 'https://cdn.media.amplience.net/i/alghanim/iphone_white',
        alt: 'Alt text',
        type: 'img',
      },
      heading: 'This is a headline',
      text: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. ',
    },
    {
      image: {
        src: 'https://cdn.media.amplience.net/i/alghanim/iphone_white',
        alt: 'Alt text',
        type: 'img',
      },
      heading: 'This is a headline',
      text: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. ',
    },
  ],
}
OneItem.args = {
  textBlocks: [
    {
      image: {
        src: 'https://cdn.media.amplience.net/i/alghanim/iphone_white',
        alt: 'Alt text',
        type: 'img',
      },
      heading: 'This is a headline',
      text: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. ',
    },
  ],
}
