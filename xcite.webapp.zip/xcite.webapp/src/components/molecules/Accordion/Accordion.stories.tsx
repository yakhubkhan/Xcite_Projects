import React from 'react'
import { Story, Meta } from '@storybook/react'
import Accordion, { AccordionItemType } from './Accordion'

export default {
  title: 'Components/molecules/Accordion',
  component: Accordion,
} as Meta

const Template: Story<{ items: AccordionItemType[] }> = (args) => (
  <div className="p-4">
    <Accordion {...args} />
  </div>
)

export const Default = Template.bind({})

Default.args = {
  items: [
    {
      id: 'item1',
      title: 'item 1',
      content: <p>Item 1 content</p>,
      isOpen: true,
    },

    {
      id: 'item2',
      title: 'item 2',
      content: <p>Item 2 content</p>,
    },
    {
      id: 'item3',
      title: 'item 3',
      content: 'Item 3 content',
    },
  ],
}
