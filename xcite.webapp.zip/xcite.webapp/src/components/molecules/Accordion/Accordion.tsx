import React, { useState } from 'react'
import { PlusIcon, MinusIcon } from '../../atoms/Icon'

export interface AccordionItemType {
  id: string
  title: string
  content: JSX.Element | string
  isOpen?: boolean
}

export const AccordionItem = ({
  item,
}: {
  item: AccordionItemType
}): JSX.Element => {
  const [open, setOpen] = useState(item.isOpen)
  return (
    <div key={item.id} className="py-8 border-b border-b-gray-300">
      <p
        className="typography-default-strong flex justify-between items-center cursor-pointer"
        onClick={() => setOpen((prevState) => !prevState)}
      >
        <span>{item.title}</span>
        <span className="w-6 h-6">
          {open ? (
            <MinusIcon className="stroke-current text-black" />
          ) : (
            <PlusIcon className="stroke-current text-black" />
          )}
        </span>
      </p>
      <div className={`pt-6 ${open ? '' : 'h-0 hidden'}`}>{item.content}</div>
    </div>
  )
}

const Accordion = ({ items }: { items: AccordionItemType[] }): JSX.Element => (
  <>
    {items.map((item) => (
      <AccordionItem key={item.id} item={item} />
    ))}
  </>
)

export default Accordion
