export { default } from './ContentsCarouselTile'
