import React from 'react'
import { Meta, Story } from '@storybook/react'
import ProductVariants from '.'
import { ProductSelectVariantType } from '../../../types/content'

export default {
  title: 'Components/molecules/ProductVariants',
  component: ProductVariants,
} as Meta

const Template: Story<ProductSelectVariantType> = (args) => (
  <div className="p-4">
    <ProductVariants options={[args]} />
  </div>
)

export const ProductColorVariant = Template.bind({})

ProductColorVariant.args = {
  key: 'color',
  name: 'Colour',
  variantOptions: [
    {
      sku: '501202-A',
      slug: 'slug-501202-A',
      value: {
        key: 'Silver',
        label: 'Silver',
        hex: '#c0c0c0',
      },
      available: true,
      selected: true,
    },
    {
      sku: '501202-C',
      slug: 'slug-501202-C',
      value: {
        key: 'Natural',
        label: 'Natural',
        hex: '#E5D3BF',
      },
      available: false,
      selected: false,
    },
    {
      sku: '501202-C',
      slug: 'slug-501202-C',
      value: {
        key: 'Green',
        label: 'Green',
        hex: '#078326',
      },
      available: true,
      selected: false,
    },
    {
      sku: '501202-C',
      slug: 'slug-501202-C',
      value: {
        key: 'floralwhite',
        label: 'Floralwhite',
        hex: '#fffaf0',
      },
      available: true,
      selected: false,
    },
  ],
}

export const ProductSizeVariant = Template.bind({})

ProductSizeVariant.args = {
  key: 'phonesInternalStorageFinal',
  name: 'Storage Capacity',
  variantOptions: [
    {
      sku: '501202',
      slug: 'apple-iphone-6s-plus-128gb-12mp-4g-lte-smartphone-silver-2',
      value: {
        key: '128gb',
        label: '128GB',
      },
      available: true,
      selected: false,
    },
    {
      sku: '501202-A',
      slug: 'slug-501202-A',
      value: {
        key: 'ExternalUpTo32gb',
        label: 'External Up To 32GB',
      },
      available: true,
      selected: true,
    },
    {
      sku: '501202-B',
      slug: 'slug-501202-B',
      value: {
        key: '200kb',
        label: '200KB',
      },
      available: false,
      selected: false,
    },
  ],
}
