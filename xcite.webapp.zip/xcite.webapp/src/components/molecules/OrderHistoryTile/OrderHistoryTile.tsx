import {
  CartWarrantyItem,
  OrderLineItem,
  ButtonVariantEnum,
  RapDeliveryInfoStatusCodeEnum,
} from '../../../types/content'
import { RAPDeliveryInfo } from '../../../types/rap'
import { useTranslation } from 'next-i18next'
import Image from '../../atoms/Image'
import ShowDigitalCode from '../ShowDigitalCode'
import { ButtonLink } from '../../atoms/Button/Button'
import { TrackingIcon } from '../../atoms/Icon'
import { useEffect, useState } from 'react'

const DIGITAL_TRANSACTION_ID_ERROR_CODE = '9999999999'

const OrderHistoryItem = ({
  item,
  orderPlacedOnDate,
}: {
  item: OrderLineItem
  orderPlacedOnDate: string
}) => {
  const { t } = useTranslation()

  const [showPreorderStatus, setShowPreorderStatus] = useState(false)

  useEffect(() => {
    if (
      item.deliveryInfo?.statusCode ===
        RapDeliveryInfoStatusCodeEnum.CANCELLED &&
      item.isPreOrder
    ) {
      setShowPreorderStatus(true)
    }
  }, [item])

  const formatRAPDeliveryInfo = (rapDeliveryInfo: RAPDeliveryInfo): string => {
    // rapDeliveryInfo: statusCode, date, time, plannedDate, plannedTime
    switch (rapDeliveryInfo.statusCode) {
      case RapDeliveryInfoStatusCodeEnum.REACHED_DEST_HUB:
        return t('profile_order_history_rap_delivery_status_reached_dest_hub')
      case RapDeliveryInfoStatusCodeEnum.RVP_DELIVERED:
        return t('profile_order_history_rap_delivery_status_rvp_delivered')
      case RapDeliveryInfoStatusCodeEnum.UNDELIVERED:
        return t('profile_order_history_rap_delivery_status_undelivered')
      case RapDeliveryInfoStatusCodeEnum.ORD_CONFIRMED:
        return t('profile_order_history_rap_delivery_status_ord_confirmed')
      case RapDeliveryInfoStatusCodeEnum.DELIVERED:
        return t('profile_order_history_rap_delivery_status_delivered', {
          date: rapDeliveryInfo.date,
          time: rapDeliveryInfo.time,
        })
      case RapDeliveryInfoStatusCodeEnum.RETURNED:
        return t('profile_order_history_rap_delivery_status_returned')
      case RapDeliveryInfoStatusCodeEnum.ORD_PICKED:
        return t('profile_order_history_rap_delivery_status_ord_picked')
      case RapDeliveryInfoStatusCodeEnum.AT_LOCATION:
        return t('profile_order_history_rap_delivery_status_at_location')
      case RapDeliveryInfoStatusCodeEnum.LOADING_COMPLETE:
        return t('profile_order_history_rap_delivery_status_loading_complete')
      case RapDeliveryInfoStatusCodeEnum.LOC_NOT_FOUND:
        return t('profile_order_history_rap_delivery_status_loc_not_found')
      case RapDeliveryInfoStatusCodeEnum.OUT_FOR_DELIVERY:
        return t('profile_order_history_rap_delivery_status_out_for_delivery')
      case RapDeliveryInfoStatusCodeEnum.OUT_FOR_PICKUP:
        return t('profile_order_history_rap_delivery_status_out_for_pickup')
      case RapDeliveryInfoStatusCodeEnum.RVP_PICKUP_FAIL:
        return t('profile_order_history_rap_delivery_status_rvp_pickup_fail')
      case RapDeliveryInfoStatusCodeEnum.PARTIAL_DELIVERED:
        return t('profile_order_history_rap_delivery_status_partial_delivered')
      case RapDeliveryInfoStatusCodeEnum.IN_TRANSIT:
        return t('profile_order_history_rap_delivery_status_in_transit')
      case RapDeliveryInfoStatusCodeEnum.CANCELLED:
        return t('profile_order_history_rap_delivery_status_cancelled')
      case RapDeliveryInfoStatusCodeEnum.REACHED_ORG_HUB:
        return t('profile_order_history_rap_delivery_status_reached_org_hub')
      case RapDeliveryInfoStatusCodeEnum.RTO:
        return t('profile_order_history_rap_delivery_status_rto')
      case RapDeliveryInfoStatusCodeEnum.COLLECTION_PENDING:
        return t('profile_order_history_rap_delivery_status_collection_pending')
      case RapDeliveryInfoStatusCodeEnum.COLLECTION_COMPLETED:
        return t(
          'profile_order_history_rap_delivery_status_collection_completed'
        )
      default:
        return ''
    }
  }

  const productDeliveryInfo =
    item.deliveryInfo && !item.digitalTransactionId
      ? formatRAPDeliveryInfo(item.deliveryInfo)
      : undefined

  return (
    <div className="flex gap-5">
      <Image
        alt={item.image.alt}
        src={item.image.src}
        layout="intrinsic"
        width={100}
        height={100}
        objectFit="contain"
      />
      <div className="flex-1 flex flex-col gap-1">
        {showPreorderStatus && (
          <div>
            <span className="inline-block px-2 py-1 bg-functional-yellow-50">
              {t('profile_order_history_preorder_label')}
            </span>
          </div>
        )}
        <p
          className={`typography-small ${
            showPreorderStatus ? 'text-gray-600' : ''
          }`}
        >
          {item.name}
        </p>
        {item.digitalTransactionId &&
          item.digitalTransactionId !== DIGITAL_TRANSACTION_ID_ERROR_CODE && (
            <p className="typography-small-strong">
              {t(
                'profile_order_history_order_delivery_status_digital_product',
                {
                  date: orderPlacedOnDate,
                }
              )}
            </p>
          )}
        {item.digitalTransactionId &&
          item.digitalTransactionId === DIGITAL_TRANSACTION_ID_ERROR_CODE && (
            <p className="typography-small-strong text-functional-red-800">
              {t('profile_order_history_rap_error_digital_transaction')}
            </p>
          )}
        {!showPreorderStatus && productDeliveryInfo && (
          <p className="typography-small-strong">{productDeliveryInfo}</p>
        )}

        <p className="typography-label text-gray-600">
          {t('profile_order_history_tile_quantity', {
            quantity: item.quantity,
          })}
        </p>

        {item.warranties &&
          item.warranties.map((warranty) => {
            return (
              <p key={warranty.sku} className="typography-label text-gray-600">
                Warranty: {warranty.name}
              </p>
            )
          })}
      </div>
    </div>
  )
}

const TrackingLinkBtn = ({ trackingLink }) => {
  const { t } = useTranslation()

  return (
    <ButtonLink
      className="sm:max-w-[300px]"
      variant={ButtonVariantEnum.primaryOnLight}
      href={trackingLink}
      isExternalLink
    >
      {t('profile_order_history_tracking_link_label')}
      <TrackingIcon className="w-6 h-6 text-white stroke-current fill-transparent" />
    </ButtonLink>
  )
}

const OrderHistoryTile = ({
  item,
  orderPlacedOnDate,
}: {
  item: OrderLineItem
  orderPlacedOnDate: string
}): JSX.Element => {
  const { t } = useTranslation()

  const showExpectedDelivery =
    item.deliveryInfo?.statusCode !== RapDeliveryInfoStatusCodeEnum.DELIVERED &&
    item.deliveryInfo?.plannedDate &&
    item.deliveryInfo?.plannedTime

  return (
    <li className="flex flex-col gap-4 border-b border-gray-300 last:border-b-0 py-4 first:pt-0 last:pb-0">
      {item.deliveryInfo && showExpectedDelivery && (
        <p className="typography-default-strong text-functional-green-600">
          {t('profile_order_history_order_delivery_status_expected_delivery', {
            date: item.deliveryInfo.plannedDate,
            time: item.deliveryInfo.plannedTime,
          })}
        </p>
      )}
      <OrderHistoryItem item={item} orderPlacedOnDate={orderPlacedOnDate} />
      {item.trackingLink && !item.isPreOrder && (
        <TrackingLinkBtn trackingLink={item.trackingLink} />
      )}
      {item.digitalTransactionId &&
        item.digitalTransactionId !== DIGITAL_TRANSACTION_ID_ERROR_CODE && (
          <ShowDigitalCode txnId={item.digitalTransactionId} sku={item.sku} />
        )}
    </li>
  )
}

export default OrderHistoryTile
