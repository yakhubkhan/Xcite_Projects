import React, { useCallback, useEffect, useRef } from 'react'

const TabSection = ({
  activeTab,
  children,
  id,
  pageHeight,
  setActiveTab,
  tabContentOffset,
  intersectionObserverOpts,
}: {
  activeTab: string
  children: React.ReactNode
  id: string
  pageHeight: number
  setActiveTab: (id: string) => void
  tabContentOffset: number
  intersectionObserverOpts?: IntersectionObserverInit
}): JSX.Element => {
  const tabSectionRef = useRef(null)

  const callbackFunction = useCallback(
    (entries: IntersectionObserverEntry[]) => {
      const [entry] = entries

      if (entry.isIntersecting && entry.target.id !== activeTab) {
        setActiveTab(entry.target.id)
      }
    },
    [activeTab, setActiveTab]
  )

  const createObserver = useCallback(() => {
    const options = {
      root: intersectionObserverOpts?.root || null,
      rootMargin:
        intersectionObserverOpts?.rootMargin ||
        `${tabContentOffset * -1}px 0px ${
          (pageHeight - tabContentOffset - 1) * -1
        }px 0px`,
      threshold: intersectionObserverOpts?.threshold || 0.0,
    }

    return new IntersectionObserver(callbackFunction, options)
  }, [intersectionObserverOpts, tabContentOffset, pageHeight, callbackFunction])

  useEffect(() => {
    const observer = createObserver()

    if (tabSectionRef.current) {
      observer.observe(tabSectionRef.current)
    }

    return () => {
      observer.disconnect()
    }
  }, [createObserver])

  return (
    <section
      id={id}
      ref={tabSectionRef}
      className="mb-14"
      style={{
        paddingTop: `${tabContentOffset}px`,
        marginTop: `-${tabContentOffset}px`,
      }}
    >
      {children}
    </section>
  )
}

export default TabSection
