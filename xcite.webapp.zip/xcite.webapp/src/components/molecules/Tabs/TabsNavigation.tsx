import React, { useCallback, useEffect, useState } from 'react'

import { TabType } from './Tabs'

const Tab = ({ tab, activeTab, onTabClicked }): JSX.Element => {
  return (
    <li id={`tab-${tab.id}`}>
      <a
        className={`block px-4 py-3 whitespace-nowrap sm:px-14 ${
          activeTab === tab.id
            ? 'typography-default-strong text-primary-900'
            : 'typography-default text-gray-600'
        }`}
        href={`#${tab.id}`}
        onClick={(e) => {
          e.preventDefault()
          onTabClicked(tab)
        }}
      >
        {tab.title}
      </a>
    </li>
  )
}

const TabIndicator = ({ activeTab }): JSX.Element => {
  const [width, setWidth] = useState(0)
  const [translateX, setTranslateX] = useState(0)

  const positionIndicator = useCallback(() => {
    const activeTabDomElement = document.getElementById(`tab-${activeTab}`)

    setWidth(activeTabDomElement?.offsetWidth || 0)
    setTranslateX(activeTabDomElement?.offsetLeft || 0)
  }, [activeTab])

  useEffect(() => {
    window.addEventListener('resize', positionIndicator)
    return () => {
      window.removeEventListener('resize', positionIndicator)
    }
  }, [positionIndicator])

  useEffect(() => {
    positionIndicator()
  }, [positionIndicator])

  return (
    <span
      className={`absolute bottom-0 h-0.5 bg-primary-900`}
      style={{
        width: `${width}px`,
        transform: `translateX(${translateX}px)`,
        transition: 'transform .3s ease-in-out,width .3s ease-in-out',
      }}
    />
  )
}

const TabsNavigation = (
  {
    activeTab,
    tabs,
    wrapperClasses,
  }: {
    activeTab: string
    tabs: TabType[]
    wrapperClasses: string
  },
  ref: React.Ref<HTMLDivElement>
): JSX.Element => {
  const onTabClicked = (tab: TabType) => {
    const tabSection = document.getElementById(tab.id)
    tabSection?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <div
      ref={ref}
      className={`sticky top-0 bg-white overflow-hidden z-10 border-b border-b-gray-300`}
    >
      <div className={`overflow-auto m-auto ${wrapperClasses}`}>
        <ul className="relative flex min-w-min">
          {tabs.map((tab) => (
            <Tab
              key={tab.id}
              tab={tab}
              activeTab={activeTab}
              onTabClicked={onTabClicked}
            />
          ))}
        </ul>
        <TabIndicator activeTab={activeTab} />
      </div>
    </div>
  )
}

export default React.forwardRef(TabsNavigation)
