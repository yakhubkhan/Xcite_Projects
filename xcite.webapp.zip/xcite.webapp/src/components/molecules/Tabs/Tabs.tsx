import React, { useEffect, useRef, useState } from 'react'
import { useWindowSize } from '../../../hooks'
import TabSection from './TabSection'
import TabsNavigation from './TabsNavigation'

export interface TabsComponentType {
  tabs: TabType[]
  wrapperClasses: string
  intersectionObserverOpts?: IntersectionObserverInit
}

export type TabType = {
  component: JSX.Element
  id: string
  title: string
}

const Tabs = ({
  tabs,
  wrapperClasses,
  intersectionObserverOpts,
}: TabsComponentType): JSX.Element => {
  const tabNavigationRef = useRef<HTMLDivElement>(null)
  const [activeTab, setActiveTab] = useState('')

  const size = useWindowSize()
  const tabContentOffset = tabNavigationRef?.current?.offsetHeight || 0

  useEffect(() => {
    setActiveTab(tabs[0]?.id)
  }, [tabs])

  return (
    <div>
      <TabsNavigation
        ref={tabNavigationRef}
        activeTab={activeTab}
        tabs={tabs}
        wrapperClasses={wrapperClasses}
      />
      <div className="pt-8 sm:pt-12 md:pt-32">
        {tabs.map((tab) => (
          <TabSection
            key={tab.id}
            activeTab={activeTab}
            id={tab.id}
            pageHeight={size.height || 0}
            setActiveTab={(id) => setActiveTab(id)}
            tabContentOffset={tabContentOffset}
            intersectionObserverOpts={intersectionObserverOpts}
          >
            {tab.component}
          </TabSection>
        ))}
      </div>
    </div>
  )
}

export default Tabs
