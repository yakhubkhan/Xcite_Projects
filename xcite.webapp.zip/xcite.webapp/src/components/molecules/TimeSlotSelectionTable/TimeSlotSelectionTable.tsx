import React, { useState } from 'react'
import { CommercetoolsSoftReserveSlotReqBody } from '../../../types/api'
import {
  AsyncResponseStatusEnum,
  ButtonVariantEnum,
  HeadingEnum,
  TimeSlotSelectionDialog,
} from '../../../types/content'
import Button from '../../atoms/Button'
import Heading from '../../atoms/Heading'
import Slot from './Slot'
import styles from './TimeSlotSelectionTable.module.css'

export type Props = TimeSlotSelectionDialog & {
  selectedSlot?: CommercetoolsSoftReserveSlotReqBody
  reserveSlotStatus?: AsyncResponseStatusEnum
  onReserveSlot: (activeSlot: CommercetoolsSoftReserveSlotReqBody) => void
  deliveryGroupSlug: string
  selectedSlotDeliveryCharges: string
}

const TimeSlotSelectionTable = (props: Props): JSX.Element => {
  const {
    selectedSlot,
    reserveSlotStatus = AsyncResponseStatusEnum.idle,
    onReserveSlot,
    deliveryGroupSlug,
    selectedSlotDeliveryCharges,
  } = props

  const [activeSlot, setActiveSlot] = useState<
    CommercetoolsSoftReserveSlotReqBody | undefined
  >(selectedSlot)
  const [deliveryCharges, setDeliveryCharges] = useState(
    selectedSlotDeliveryCharges
  )

  return (
    <>
      <div className={styles.header}>
        <Heading type={HeadingEnum.h4}>{props.subline}</Heading>
      </div>
      <div className={styles.tableWrapper}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th className={styles.colSticky}></th>
              {props.tableDateHeader?.map((date) => (
                <th key={date.formattedDate}>
                  <div>
                    <p className="typography-small-strong uppercase">
                      {date.weekday}
                    </p>
                    <p className="typography-small">{date.formattedDate}</p>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {props.availableSlots?.map((timeslot) => {
              const { slotNumber } = timeslot
              const slotNumberKey = `slotNumber_${slotNumber}`
              return (
                <tr key={slotNumberKey} className={styles.row}>
                  <td className={styles.colSticky}>
                    <div>
                      <p className="typography-small-strong">{timeslot.name}</p>
                      <p className="typography-small">
                        <span className={styles.time}>{timeslot.start} - </span>
                        <span className={styles.time}>{timeslot.end}</span>
                      </p>
                    </div>
                  </td>
                  {timeslot.slots.map((slot, i) => {
                    const { notAvailable: notAvailableLabel, free: freeLabel } =
                      props.translationLabels

                    return (
                      <Slot
                        key={`${slotNumberKey}-slot_${i}`}
                        slot={slot}
                        slotNumber={slotNumber}
                        activeSlot={activeSlot}
                        freeLabel={freeLabel}
                        notAvailableLabel={notAvailableLabel}
                        onSelectSlot={() => {
                          setActiveSlot({
                            date: slot.raw?.date || '',
                            deliveryGroupSlug,
                            slotNumber,
                          })
                          setDeliveryCharges(
                            slot.formattedDeliveryCharge?.formattedPrice ||
                              props.translationLabels.free
                          )
                        }}
                      />
                    )
                  })}
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
      <div className={styles.footer}>
        <span className="typography-default">
          {deliveryCharges &&
            `${props.translationLabels.deliveryCharge} ${deliveryCharges}`}
        </span>
        <Button
          variant={ButtonVariantEnum.primaryOnLight}
          onClick={() => {
            if (activeSlot) {
              onReserveSlot(activeSlot)
            }
          }}
          disabled={
            reserveSlotStatus === AsyncResponseStatusEnum.loading || !activeSlot
          }
        >
          {props.translationLabels.cta}
        </Button>
      </div>
    </>
  )
}

export default TimeSlotSelectionTable
