import { CommercetoolsSoftReserveSlotReqBody } from '../../../types/api'
import { DeliveryTimeslot } from '../../../types/content'
import styles from './TimeSlotSelectionTable.module.css'

const Slot = ({
  slot,
  activeSlot,
  slotNumber,
  freeLabel,
  notAvailableLabel,
  onSelectSlot,
}: {
  slot: DeliveryTimeslot
  activeSlot?: CommercetoolsSoftReserveSlotReqBody
  slotNumber: number
  freeLabel: string
  notAvailableLabel: string
  onSelectSlot: () => void
}): JSX.Element => {
  const isSelected =
    activeSlot?.date === slot.raw?.date && activeSlot?.slotNumber === slotNumber

  return (
    <td
      onClick={() => {
        if (slot.isEnabled) {
          onSelectSlot()
        }
      }}
    >
      <div
        className={`typography-label ${styles.slot} ${
          isSelected
            ? styles.slotSelected
            : slot.isEnabled
            ? styles.slotEnabled
            : styles.slotDisabled
        }`}
      >
        {!slot.isEnabled
          ? notAvailableLabel
          : slot.formattedDeliveryCharge?.formattedPrice || freeLabel}
      </div>
    </td>
  )
}

export default Slot
