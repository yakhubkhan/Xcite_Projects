import React, { useEffect, useState } from 'react'
import { ButtonVariantEnum } from '../../../types/content'
import Button from '../../atoms/Button'
import { MinusIcon, PlusIcon } from '../../atoms/Icon'

export interface QuantityCounterProps {
  quantity: number
  itemTotalQuantity: number
  maxQuantity: number
  isLoading?: boolean
  onUpdateQuantity?: (value: number) => void
  increaseLabel: string
  decreaseLabel: string
}

const QuantityCounter = ({
  quantity,
  itemTotalQuantity,
  maxQuantity,
  onUpdateQuantity,
  isLoading = false,
  increaseLabel,
  decreaseLabel,
}: QuantityCounterProps): JSX.Element => {
  const [currentValue, setCurrentValue] = useState(quantity)
  const [minusDisabled, setMinusDisabled] = useState(false)
  const [plusDisabled, setPlusDisabled] = useState(false)

  const subtractQuantity = () => {
    if (onUpdateQuantity) onUpdateQuantity(currentValue - 1)
  }

  const increaseQuantity = () => {
    if (onUpdateQuantity) onUpdateQuantity(currentValue + 1)
  }

  useEffect(() => {
    setCurrentValue(quantity)
  }, [quantity])

  useEffect(() => {
    setMinusDisabled(currentValue <= 1 || isLoading)
    setPlusDisabled(
      currentValue >= maxQuantity ||
        isLoading ||
        itemTotalQuantity >= maxQuantity
    )
  }, [currentValue, maxQuantity, isLoading])

  return (
    <div className="relative w-full flex justify-between max-w-[120px]">
      <Button
        disabled={minusDisabled}
        variant={ButtonVariantEnum.buttonCircle}
        onClick={subtractQuantity}
        className={minusDisabled ? 'cursor-default' : ''}
        ariaLabel={decreaseLabel}
      >
        <MinusIcon
          className={`h-full w-full stroke-current ${
            minusDisabled ? 'text-gray-400' : 'text-black'
          }`}
        />
      </Button>
      <span className="typography-small-strong text-center">
        {currentValue}
      </span>
      <Button
        disabled={plusDisabled}
        variant={ButtonVariantEnum.buttonCircle}
        onClick={increaseQuantity}
        className={plusDisabled ? 'cursor-default' : ''}
        ariaLabel={increaseLabel}
      >
        <PlusIcon
          className={`h-full w-full stroke-current ${
            plusDisabled ? 'text-gray-400' : 'text-black'
          }`}
        />
      </Button>
    </div>
  )
}

export default QuantityCounter
