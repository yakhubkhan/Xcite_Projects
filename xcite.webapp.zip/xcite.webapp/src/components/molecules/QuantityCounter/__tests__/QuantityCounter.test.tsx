import { render, screen, fireEvent } from '@testing-library/react'

import QuantityCounter from '../QuantityCounter'

describe('QuantityCounter', () => {
  test('should render counter', () => {
    render(
      <QuantityCounter
        quantity={2}
        itemTotalQuantity={2}
        maxQuantity={5}
        increaseLabel="increase quantity"
        decreaseLabel="decrease quantity"
      />
    )
    expect(screen.getByText('2'))
  })

  test('should disable the increase button when the quantity is equal to the maximum', () => {
    render(
      <QuantityCounter
        quantity={5}
        itemTotalQuantity={5}
        maxQuantity={5}
        increaseLabel="increase quantity"
        decreaseLabel="decrease quantity"
      />
    )

    expect(
      screen.getByRole('button', {
        name: 'increase quantity',
      })
    ).toBeDisabled()
  })

  test('should disable the decrease button when the quantity is equal to 0', () => {
    render(
      <QuantityCounter
        quantity={0}
        itemTotalQuantity={0}
        maxQuantity={5}
        increaseLabel="increase quantity"
        decreaseLabel="decrease quantity"
      />
    )

    expect(
      screen.getByRole('button', {
        name: 'decrease quantity',
      })
    ).toBeDisabled()
  })
})
