import React from 'react'
import { Story, Meta } from '@storybook/react'
import QuantityCounter, { QuantityCounterProps } from './QuantityCounter'

export default {
  title: 'Components/molecules/QuantityCounter',
  component: QuantityCounter,
} as Meta

const Template: Story<QuantityCounterProps> = (args) => (
  <div className="p-4">
    <QuantityCounter {...args} />
  </div>
)

export const Default = Template.bind({})

Default.args = {
  quantity: 1,
  itemTotalQuantity: 2,
  maxQuantity: 5,
  onUpdateQuantity: (quantity) => console.log(quantity),
}
