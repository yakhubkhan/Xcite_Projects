import React from 'react'
import { Meta, Story } from '@storybook/react'
import { ContentBlockWithVideoBlock } from '../../../types/content/component'
import ContentBlockVideo from './ContentBlockVideo'

export default {
  title: 'Components/molecules/ContentBlockVideo',
  component: ContentBlockVideo,
} as Meta

const Template: Story<ContentBlockWithVideoBlock> = (args) => (
  <ContentBlockVideo {...args} />
)

export const Default = Template.bind({})

Default.args = {
  youtubeLink: 'https://www.youtube.com/watch?v=Fazi4FLDwzc',
  title: 'Title',
}
