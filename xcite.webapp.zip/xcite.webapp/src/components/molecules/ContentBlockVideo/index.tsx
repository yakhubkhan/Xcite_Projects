export { default } from './ContentBlockVideo'
