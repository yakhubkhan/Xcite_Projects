import React from 'react'
import Map, { Props } from './Map'
import { Story, Meta } from '@storybook/react'

export default {
  title: 'Components/molecules/Map',
  component: Map,
} as Meta

const Template: Story<Props> = (args) => (
  <div className="p-4">
    <Map {...args} />
  </div>
)

export const Default = Template.bind({})

Default.args = {
  locale: 'en-KW',
}
