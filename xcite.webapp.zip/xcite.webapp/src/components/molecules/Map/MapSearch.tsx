import { useTranslation } from 'next-i18next'
import React, { useCallback, useEffect, useRef, useState } from 'react'
import {
  Combobox,
  ComboboxInput,
  ComboboxList,
  ComboboxOption,
  ComboboxPopover,
} from '@reach/combobox'
import usePlacesAutocomplete, {
  getGeocode,
  getLatLng,
} from 'use-places-autocomplete'

import {
  AsyncResponseStatusEnum,
  ButtonVariantEnum,
} from '../../../types/content'
import Button from '../../atoms/Button'

import styles from './Map.module.css'

interface Props {
  shopCountry: string
  error: string
  geocodedValue: string
  onClearValue: () => void
  onSearch: (address: {
    addressResults: google.maps.GeocoderResult[]
    location: google.maps.LatLngLiteral
  }) => void
  onSubmitLocation: (e: React.FormEvent<HTMLFormElement>, value: string) => void
  mapStatus: AsyncResponseStatusEnum
}

const MapSearch: React.FC<Props> = ({
  shopCountry,
  geocodedValue = '',
  error,
  onClearValue,
  onSearch,
  onSubmitLocation,
  mapStatus,
}) => {
  const { t } = useTranslation()
  const inputRef = useRef<HTMLInputElement>(null)

  const [requestNewSessionToken, setRequestNewSessionToken] = useState(true)
  const [sessionToken, setSessionToken] =
    useState<google.maps.places.AutocompleteSessionToken>()

  const getSessionToken = () => sessionToken

  useEffect(() => {
    if (requestNewSessionToken) {
      const token = new google.maps.places.AutocompleteSessionToken()
      setSessionToken(token)
      setRequestNewSessionToken(false)
    }
  }, [requestNewSessionToken])

  const { ready, value, suggestions, setValue, clearSuggestions } =
    usePlacesAutocomplete({
      requestOptions: {
        componentRestrictions: { country: shopCountry },
        sessionToken: getSessionToken(),
      },
      debounce: 300,
    })

  const onGeocoded = useCallback(() => {
    setValue(geocodedValue, false)
    clearSuggestions()
    if (inputRef.current) {
      inputRef.current.blur()
    }
  }, [geocodedValue, setValue, clearSuggestions])

  const onOptionSelected = async (address: string) => {
    setValue(address, false)
    clearSuggestions()
    setRequestNewSessionToken(true)

    try {
      const addressResults = await getGeocode({ address })
      const { lat, lng } = await getLatLng(addressResults[0])
      onSearch({
        addressResults,
        location: { lat, lng },
      })
    } catch (error) {
      console.error(error)
    }
  }

  useEffect(() => {
    onGeocoded()
  }, [onGeocoded])

  return (
    <form onSubmit={(e) => Promise.resolve(onSubmitLocation(e, value))}>
      <fieldset className={`grid-rows-2 ${styles.fieldset}`}>
        <Combobox onSelect={onOptionSelected} className="sm:col-span-1">
          <ComboboxInput
            ref={inputRef}
            value={value}
            onChange={(e) => {
              if (geocodedValue) {
                setValue('')
                onClearValue()
              } else {
                setValue(e.target.value)
              }
            }}
            disabled={!ready || mapStatus === AsyncResponseStatusEnum.loading}
            placeholder={t('checkout_shipping_map_search_placeholder')}
            className={`w-full p-3 typography-small rounded ${
              error
                ? 'border-2 border-functional-red-800'
                : 'border border-gray-400'
            }`}
          />
          {suggestions.status === 'OK' && (
            <ComboboxPopover className="bg-white border border-gray-400">
              <ComboboxList className="px-4 py-2">
                {suggestions.data.map(({ place_id, description }) => (
                  <ComboboxOption
                    key={place_id}
                    value={description}
                    className="cursor-pointer py-2"
                  />
                ))}
              </ComboboxList>
            </ComboboxPopover>
          )}
        </Combobox>
        {error && (
          <p className="pt-1 typography-label text-functional-red-800 sm:row-start-2 sm:col-span-2">
            {error}
          </p>
        )}
        <Button
          variant={ButtonVariantEnum.primaryOnLight}
          className="rounded-none px-12 mt-8 sm:mt-0 sm:col-span-1"
          type="submit"
          disabled={
            value === '' || mapStatus === AsyncResponseStatusEnum.loading
          }
        >
          {t('checkout_shipping_map_submit')}
        </Button>
      </fieldset>
    </form>
  )
}

export default MapSearch
