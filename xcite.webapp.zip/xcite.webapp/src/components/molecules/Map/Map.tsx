import getConfig from 'next/config'
import { useTranslation } from 'next-i18next'
import React, { useState } from 'react'
import { useLoadScript } from '@react-google-maps/api'
import { getGeocode, getLatLng } from 'use-places-autocomplete'

import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import {
  AsyncResponseStatusEnum,
  HeadingEnum,
  MapLocation,
} from '../../../types/content'
import MapSearch from './MapSearch'
import MapView from './MapView'
import Heading from '../../atoms/Heading'

export interface Props {
  coordinates: google.maps.LatLngLiteral | undefined
  formattedAddress: string
  locale: string
  onSubmit: (response: MapLocation) => void
  mapStatus: AsyncResponseStatusEnum
  mapType: string
}

declare type Libraries = (
  | 'drawing'
  | 'geometry'
  | 'localContext'
  | 'places'
  | 'visualization'
)[]
const libraries: Libraries = ['places']

const Map: React.FC<Props> = (props) => {
  const { isLoaded: isMapLoaded, loadError: mapLoadError } = useLoadScript({
    googleMapsApiKey: getConfig().publicRuntimeConfig.google.mapsAPIKey,
    language:
      props?.locale === 'en-KW' || props?.locale === 'en-SA' ? 'en' : 'ar',
    libraries,
  })

  const { t } = useTranslation()

  const [error, setError] = useState('')
  const [searchValue, setSearchValue] = useState(props.formattedAddress)
  const [geolocationResults, setGeolocationResults] = useState<
    google.maps.GeocoderResult[]
  >([])
  const [coordinates, setCoordinates] = useState<
    google.maps.LatLngLiteral | undefined
  >(props.coordinates)

  const shopCountry = localesFactory.createFromHrefLang(props.locale).current
    .country.id

  const changeLocation = (
    addressResults?: google.maps.GeocoderResult[],
    location?: google.maps.LatLngLiteral
  ) => {
    setError('')
    if (addressResults) {
      setSearchValue(addressResults[0]?.formatted_address || '')
      setGeolocationResults(addressResults)
    } else {
      setSearchValue('')
      setGeolocationResults([])
    }
    setCoordinates(location)
  }

  const validateSearchResults = (results: google.maps.GeocoderResult[]) => {
    let errorMsg = ''
    const selectedCountries = results.map((result) =>
      result.address_components.find((component) =>
        component.types.find((type) => type === 'country')
      )
    )
    if (selectedCountries.length === 0) {
      errorMsg = t('checkout_shipping_map_location_error')
    }
    selectedCountries.map((country) => {
      if (country?.short_name !== shopCountry.toUpperCase()) {
        errorMsg = t('checkout_shipping_map_location_error')
      }
    })

    return errorMsg
  }

  const submitLocation = async (
    e: React.FormEvent<HTMLFormElement>,
    value: string
  ) => {
    e.preventDefault()
    let results = geolocationResults
    let currentLocation = coordinates
    if (results.length === 0) {
      results = await getGeocode({ address: value })
      currentLocation = await getLatLng(results[0])
      changeLocation(results, currentLocation)
    }

    const errorMsg = validateSearchResults(results)

    if (errorMsg) {
      setError(errorMsg)
      return
    }

    if (results?.length && currentLocation?.lat && currentLocation?.lng) {
      props.onSubmit({
        coordinates: currentLocation,
        results,
        formattedAddress: searchValue,
      })
    } else {
      setError(errorMsg)
    }
  }

  if (mapLoadError) return <div>{t('checkout_shipping_map_loading_error')}</div>
  if (!isMapLoaded) return <div>{t('checkout_shipping_map_loading')}</div>

  return (
    <div className="col-span-full flex flex-col sm:flex-col-reverse">
      <Heading type={HeadingEnum.h4} className="mb-6 sm:hidden">
        {props.mapType === 'shipping'
          ? t('checkout_shipping_form_heading')
          : t('checkout_billing_address_form_heading')}
      </Heading>
      <div className="flex-1 mb-8">
        <MapView
          coordinates={coordinates}
          locale={props.locale}
          onChangeLocation={changeLocation}
          mapStatus={props.mapStatus}
        />
      </div>
      <MapSearch
        shopCountry={shopCountry}
        error={error}
        geocodedValue={searchValue}
        onClearValue={() => changeLocation()}
        onSearch={({ addressResults, location }) =>
          changeLocation(addressResults, location)
        }
        onSubmitLocation={(e, value) => submitLocation(e, value)}
        mapStatus={props.mapStatus}
      />
    </div>
  )
}

export default Map
