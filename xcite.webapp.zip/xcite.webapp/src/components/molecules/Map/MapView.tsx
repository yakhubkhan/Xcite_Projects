import React, { useEffect, useRef, useState } from 'react'
import { GoogleMap, Marker } from '@react-google-maps/api'

import {
  calculateCountryCoordinates,
  getCountryBounds,
  revereseGeocoding,
} from '../../../util/mapUtils'
import mapStyles from './mapStyles'
import { AsyncResponseStatusEnum } from '../../../types/content'

interface Props {
  coordinates: google.maps.LatLngLiteral | undefined
  locale: string
  onChangeLocation: (
    addressResults: google.maps.GeocoderResult[],
    coordinates: google.maps.LatLngLiteral
  ) => void
  mapStatus: AsyncResponseStatusEnum
}

const mapOptions = {
  disableDefaultUI: true,
  styles: mapStyles,
  zoomControl: true,
  mapTypeControl: true,
  scaleControl: true,
  streetViewControl: true,
  rotateControl: true,
  fullscreenControl: true,
}

const MapView: React.FC<Props> = ({
  coordinates,
  locale,
  onChangeLocation,
  mapStatus,
}) => {
  const mapRef = useRef<google.maps.Map | null>(null)
  const [mapCenter, setMapCenter] = useState<
    google.maps.LatLngLiteral | undefined
  >(coordinates)
  const [marker, setMarker] = useState<google.maps.LatLngLiteral | undefined>(
    coordinates
  )

  const panMapTo = ({ lat, lng }) => {
    if (mapRef.current) {
      const currentZoom = mapRef.current.getZoom() || 0
      if (currentZoom < 12) {
        mapRef.current.setZoom(12)
      }
      mapRef.current.panTo({ lat, lng })
      setMarker({ lat, lng })
    }
  }

  const onRevereseGeocoding = async (
    coordinates: google.maps.LatLngLiteral
  ) => {
    const addressResults = await revereseGeocoding(coordinates)
    onChangeLocation(addressResults, coordinates)
  }

  const onMarkerDragEnd = async (event: google.maps.MapMouseEvent) => {
    const newCoords = {
      lat: Number(event.latLng?.lat()),
      lng: Number(event.latLng?.lng()),
    }
    onRevereseGeocoding(newCoords)
    setMarker(newCoords)
  }

  const onMapDragEnd = async () => {
    marker && onRevereseGeocoding(marker)
  }

  const onMapCenterChanged = async () => {
    const map = mapRef.current
    if (map) {
      const newPos = map.getCenter()?.toJSON()
      setMarker(newPos)
    }
  }

  const positionMapAtUserLocation = async (position: GeolocationPosition) => {
    const pos = {
      lat: position.coords.latitude,
      lng: position.coords.longitude,
    }
    onRevereseGeocoding(pos)
    panMapTo(pos)
  }

  const positionMapAtShopCountry = async () => {
    const center = await calculateCountryCoordinates(locale)
    const bounds = await getCountryBounds(locale)
    if (mapRef.current) {
      mapRef.current.fitBounds(bounds)
      setMapCenter(center)
      setMarker(center)
    }
  }

  const onMapLoad = async (map: google.maps.Map) => {
    mapRef.current = map
    if (coordinates) {
      onRevereseGeocoding(coordinates)
      panMapTo(coordinates)
      return
    }
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        positionMapAtUserLocation,
        positionMapAtShopCountry
      )
    } else {
      positionMapAtShopCountry()
    }
  }

  useEffect(() => {
    if (coordinates) {
      panMapTo(coordinates)
    }
  }, [coordinates])

  return (
    <GoogleMap
      center={mapCenter}
      options={mapOptions}
      onLoad={onMapLoad}
      mapContainerClassName="h-[480px] w-full sm:h-[600px]"
      onDrag={onMapCenterChanged}
      onDragEnd={onMapDragEnd}
    >
      {marker && mapStatus !== AsyncResponseStatusEnum.loading && (
        <Marker
          draggable={true}
          position={marker}
          icon={{
            url: '/assets/icons/marker.svg',
            scaledSize: new window.google.maps.Size(48, 48),
          }}
          onDragEnd={onMarkerDragEnd}
        />
      )}
    </GoogleMap>
  )
}

export default MapView
