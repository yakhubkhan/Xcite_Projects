import { useTranslation } from 'next-i18next'
import React from 'react'
import { CommercetoolsMessageCodeEnum } from '../../../types/commerceTools'
import { CartMessageType, HeadingEnum } from '../../../types/content'
import Heading from '../../atoms/Heading'
import { WarningFilledIcon } from '../../atoms/Icon'

const warningFilledIcon = (
  <WarningFilledIcon className="w-6 h-6" fill="#B83830" />
)

const cartMessageLanguageMapper = (
  code: CommercetoolsMessageCodeEnum
): string => {
  switch (code) {
    case CommercetoolsMessageCodeEnum.INVALID_PRODUCT_STATUS:
      return 'cart_error_invalid_product_status'
    case CommercetoolsMessageCodeEnum.OUT_OF_STOCK:
      return 'cart_error_oos_product_status'
    case CommercetoolsMessageCodeEnum.PRODUCT_STATUS_DISCONTINUED:
      return 'cart_error_invalid_product_status'
    case CommercetoolsMessageCodeEnum.PRODUCT_STATUS_OUT_OF_ONLINE_STOCK:
      return 'cart_error_oos_online_product_status'
    case CommercetoolsMessageCodeEnum.PRODUCT_STATUS_OUT_OF_CNC_ONLINE_IN_STOCK:
      return 'cart_error_oos_offline_instock_online_product_status'
    case CommercetoolsMessageCodeEnum.PRODUCT_STATUS_OUT_OF_CNC_STOCK:
      return 'cart_error_oos_product_status'
    case CommercetoolsMessageCodeEnum.PRODUCT_STATUS_OUT_OF_SELECTED_STORE_STOCK:
      return 'cart_error_oos_selected_store_product_status'
    case CommercetoolsMessageCodeEnum.INSUFFICIENT_STOCK_ONLINE:
      return 'cart_error_insufficient_product_status'
    case CommercetoolsMessageCodeEnum.INSUFFICIENT_STOCK_CNC:
      return 'cart_error_insufficient_product_status'
    case CommercetoolsMessageCodeEnum.CLICK_AND_COLLECT_NOT_ALLOWED:
      return 'cart_error_click_and_collect_not_allowed'
    case CommercetoolsMessageCodeEnum.INVALID_SCHEDULED_TIMESLOT:
      return 'cart_error_invalid_scheduled_timeslot'
    case CommercetoolsMessageCodeEnum.SAP_UNCONFIRMED_QTY:
      return 'cart_error_insufficient_product_status'
  }
}

const CartBulletin = ({
  cartMessages,
}: {
  cartMessages: CartMessageType[]
}): JSX.Element => {
  const { t } = useTranslation()

  return (
    <div className="flex-1 p-2 sm:p-4 border border-functional-red-800 rounded-md">
      <div className="flex">
        {warningFilledIcon}
        <Heading
          type={HeadingEnum.h4}
          className="pl-2 rtl:pr-2 rtl:pl-0 text-functional-red-800"
        >
          {t('cart_checkout_bulletin_heading')}
        </Heading>
      </div>
      <ul className="list-disc pt-2 pl-6 sm:pl-8 rtl:pr-6 rtl:sm:pr-8 rtl:pl-0">
        {cartMessages.map((message, index) => {
          if (
            message.code !== CommercetoolsMessageCodeEnum.OUT_OF_STOCK &&
            message.code !== CommercetoolsMessageCodeEnum.INVALID_PRODUCT_STATUS
          ) {
            return (
              <li key={'msg' + index}>
                {`${message.quantity} ${t(
                  cartMessageLanguageMapper(message.code)
                )}`}
              </li>
            )
          }
        })}
      </ul>
    </div>
  )
}

export default CartBulletin
