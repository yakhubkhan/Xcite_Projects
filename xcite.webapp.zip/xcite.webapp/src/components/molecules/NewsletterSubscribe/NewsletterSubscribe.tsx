import { useTranslation } from 'next-i18next'
import { useState } from 'react'
import {
  ButtonVariantEnum,
  HeadingEnum,
  ToastDuration,
  ToastType,
} from '../../../types/content'
import { moengageUtils } from '../../../util/moengageUtils'
import { emailValidationRegex } from '../../../util/formValidation'
import Button from '../../atoms/Button'
import Field from '../../atoms/Field'
import Heading from '../../atoms/Heading'
import Toaster from '../../atoms/Toaster'
import gtmDatalayer from '../../../util/gtmUtils'

const NewsletterSubscribe = (): JSX.Element => {
  const { t } = useTranslation()
  const [email, setEmail] = useState('')
  const [errorMsg, setErrorMsg] = useState('')
  const [successMsg, setSuccessMsg] = useState(false)

  const moengageSubscription = () => {
    if (email.match(emailValidationRegex)) {
      try {
        const eventActionObj =
          '{"newsletterFooterEmail": ' +
          JSON.stringify(email) +
          ',"eventAction":"Get Our Offers"}'
        gtmDatalayer('newsletter_sign_up', 'newsletter_sign_up', eventActionObj)
        moengageUtils({ email: email })
        setEmail('')
        setSuccessMsg(true)
        setTimeout(() => setSuccessMsg(false), 5000)
      } catch (error) {}
    } else {
      setErrorMsg(
        email
          ? t('checkout_shipping_address_validation_email')
          : t('user_form_generic_validation_email_required')
      )
    }
  }

  return (
    <>
      <div className="sm:min-h-[95px]"></div>
      <div className="col-span-full rounded-lg sm:absolute sm:w-3/6 sm:max-w-[450px] sm:ltr:left-2/4 sm:rtl:left-10 lg:rtl:left-20">
        <div className="pt-10 pb-3 sm:pt-0">
          {successMsg && (
            <Toaster
              toastMsg={`${t('user_subscription_success_message')}`}
              duration={ToastDuration}
              className={'cmn-toast'}
              type={ToastType.success}
            />
          )}
          <Heading type={HeadingEnum.h5} className="mb-4">
            {t('footer_email_updates_heading')}
          </Heading>
          <div className="flex felx-row gap-2 sm:pr-10">
            <div className="flex-1" onClick={() => setErrorMsg('')}>
              <Field
                id="email"
                onChange={(e) => {
                  setErrorMsg('')
                  setEmail(e.target.value)
                }}
                placeholder={t('footer_email_address_placeholder')}
                transparent={true}
                value={email}
                errorMessage={errorMsg}
                className="text-white"
              />
            </div>
            <div>
              <Button
                variant={ButtonVariantEnum.primaryOnDark}
                onClick={moengageSubscription}
              >
                {t('footer_subscription_label')}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default NewsletterSubscribe
