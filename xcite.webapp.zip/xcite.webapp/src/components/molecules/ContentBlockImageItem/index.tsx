export { default } from './ContentBlockImageItem'
