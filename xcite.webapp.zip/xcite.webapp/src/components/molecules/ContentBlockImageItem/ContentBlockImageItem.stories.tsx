import React from 'react'
import { Meta, Story } from '@storybook/react'
import ContentBlockImageItem from './ContentBlockImageItem'
import { ContentBlockImageItemComponentType } from '../../../types/content/component'

export default {
  title: 'Components/molecules/ContentBlockImage',
  component: ContentBlockImageItem,
} as Meta

const Template: Story<ContentBlockImageItemComponentType> = (args) => (
  <ContentBlockImageItem {...args} />
)

export const Default = Template.bind({})

Default.args = {
  heading: 'Lorem ipsum dolor sit amet',
  text: 'Lorem ipsum dolor sit amet, **consetetur sadipscing** elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.',
  image: {
    type: 'img',
    alt: 'Alt text image',
    src: 'https://cdn.media.amplience.net/i/alghanim/iphone_white',
  },
}
