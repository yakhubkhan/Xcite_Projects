import { useTranslation } from 'next-i18next'
import {
  ButtonVariantEnum,
  HeadingEnum,
  NavigationItemType,
} from '../../../types/content'
import Button from '../../atoms/Button'
import Heading from '../../atoms/Heading'
import { ArrowLeftIcon } from '../../atoms/Icon'
import Link from '../../atoms/Link'
import styles from './Header.module.css'

export default function SubFlyout({
  isSubFlyoutOpen,
  isSubFlyoutContents,
  mobileSubFlyoutHandler,
  className,
}: {
  isSubFlyoutOpen: boolean
  isSubFlyoutContents?: NavigationItemType
  mobileSubFlyoutHandler: () => void
  className?: string
}): JSX.Element {
  const { t } = useTranslation()

  return (
    <>
      {isSubFlyoutOpen && isSubFlyoutContents && (
        <div className={`${styles.navigationSubFlyout} ${className}`}>
          <Button
            variant={ButtonVariantEnum.textLink}
            onClick={() => mobileSubFlyoutHandler()}
            className={`sp:hidden`}
          >
            <ArrowLeftIcon
              className="w-5 h-5 -mr-2 ml-[-5px]"
              stroke="#185e8f"
            />
            <span>{t('user_form_generic_back_label')}</span>
          </Button>
          <div className="flex flex-col sp:flex-col-reverse">
            <div className="py-4">
              <Heading type={HeadingEnum.h2} className={`sp:hidden`}>
                {isSubFlyoutContents.title}
              </Heading>
              <Link
                to={isSubFlyoutContents.href || ''}
                className={`${styles.textLink}`}
              >
                {t('header_categories_subflyout_all_products_label', {
                  title: isSubFlyoutContents.title,
                })}
              </Link>
            </div>
            <div className="flex flex-col sp:flex-row sp:justify-between flex-wrap gap-8">
              {isSubFlyoutContents.children
                ?.slice(0, 12)
                .map((item: NavigationItemType, index) => {
                  return (
                    <div className="py-2 w-52" key={`${index}-sub`}>
                      <Link to={item.href || ''}>
                        <div
                          className={`typography-default-strong ${styles.headLink}`}
                        >
                          {item.title}
                        </div>
                      </Link>
                      {item.children?.slice(0, 3).map((value, index) => {
                        return (
                          <Link
                            to={value.href || ''}
                            className={`${styles.textLink}`}
                            key={`${index}-sub`}
                          >
                            <div className="my-2">{value.title}</div>
                          </Link>
                        )
                      })}
                      <Link
                        to={item.href || ''}
                        className={`${styles.textLink}`}
                      >
                        <div className="my-2">
                          {t('header_categories_subflyout_view_all_label')}
                        </div>
                      </Link>
                    </div>
                  )
                })}
            </div>
          </div>
        </div>
      )}
    </>
  )
}
