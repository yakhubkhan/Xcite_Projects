import React from 'react'
import Header from './Header'
import { Meta, Story } from '@storybook/react'
import { NamedLinks } from '../../../types/content'

export default {
  title: 'Components/molecules/Header',
  component: Header,
} as Meta

const Template: Story = (args) => (
  <Header namedLinks={args.namedLinks} {...args} />
)

export const Default = Template.bind({})

const namedLinks: NamedLinks = {
  cart: '',
  confirmation: '',
  delivery: '',
  home: '',
  payment: '',
  profile: '',
  orderHistory: '',
  review: '',
  search: '',
  shipping: '',
  summary: '',
  wishlist: '',
  login: '',
}

Default.args = {
  namedLinks,
}

Default.argTypes = {
  namedLinks: { control: { disable: true } },
}
