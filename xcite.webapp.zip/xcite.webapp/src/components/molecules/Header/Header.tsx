import { useTranslation } from 'next-i18next'
import { useRouter } from 'next/router'
import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useWindowSize } from '../../../hooks'
import {
  authListener,
  currentAuthenticatedUser,
  removeAuthListener,
} from '../../../lib/api/clients/authClient'
import {
  getUserProfileThunk,
  setAnonymousUserAction,
  userProfileSelector,
} from '../../../redux/slices/profile'
import {
  HeadingEnum,
  NamedLinks,
  NavigationItemType,
  LoginRegisterStateEnum,
} from '../../../types/content'
import Heading from '../../atoms/Heading'
import {
  ArrowDropDownIcon,
  ArrowLeftIcon,
  NavigationMenu,
  ProfileIcon,
} from '../../atoms/Icon'
import Link from '../../atoms/Link'
import SearchBox from '../../atoms/SearchBox'
import LoginRegister from '../../organisms/LoginRegister'
import CartIcon from '../CartIcon'
import LanguageSelector from '../LanguageSelector'
import styles from './Header.module.css'
import SubFlyout from './SubFlyout'
import Modal from '../../atoms/Modal'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import {
  freshchatLoginUser,
  freshchatLogoutUser,
} from '../../../util/freshchatUtils'
import gtmDatalayer from '../../../util/gtmUtils'
import CookieBanner from '../CookieBanner'

type Props = {
  namedLinks: NamedLinks
  navigation?: NavigationItemType[]
  isPreview?: boolean
}

export enum ProtectedRoutesEnum {
  confirmation = '/checkout/confirmation',
  payment = '/checkout/payment',
  login = '/login',
  profile = '/profile',
  orderHistory = '/profile/order-history',
  review = '/checkout/review-order',
  shipping = '/checkout/shipping',
  summary = '/checkout/summary',
}

const FlyoutList = ({
  child,
  openSubFlyout,
  navHandler,
  flyoutContents,
}: {
  child: NavigationItemType
  openSubFlyout: (data) => void
  navHandler: () => void
  flyoutContents?: NavigationItemType
}): JSX.Element => {
  const openInNewTab = (url) => {
    const newWindow = window.open(url, '_self', 'noopener,noreferrer')
    if (newWindow) newWindow.opener = null
  }
  return (
    <>
      {child.children?.map((sub, index) => {
        if (sub.href && sub.children) {
          return (
            <li
              className={`py-3 sp:px-5 cursor-pointer active:bg-primary-50 rounded ${
                sub.title === flyoutContents?.title
                  ? 'bg-primary-50'
                  : 'bg-white'
              }`}
              onClick={() => openSubFlyout(sub)}
              key={`${index}-sub`}
            >
              <div className={`flex flex-row justify-between items-center`}>
                <Heading type={HeadingEnum.h5}>{sub.title}</Heading>
                <ArrowLeftIcon className="text-black w-8 h-4 stroke-current ltr:rotate-180" />
              </div>
            </li>
          )
        }
        if (sub.href && !sub.children) {
          return sub.href &&
            (sub?.href === '/flyer' ||
              sub?.href === '/stores' ||
              sub?.href === '/laptop-finder') ? (
            <li className="mb-5 last:mb-0" key={`${index}-sub`}>
              <a
                href="#"
                className={`${styles.navigationLinkSub}`}
                onClick={() => openInNewTab(sub.href)}
              >
                {sub.title}
              </a>
            </li>
          ) : (
            <li className="mb-5 last:mb-0" key={`${index}-sub`}>
              <Link
                to={sub.href}
                className={`${styles.navigationLinkSub}`}
                onClick={navHandler}
              >
                {sub.title}
              </Link>
            </li>
          )
        }
      })}
    </>
  )
}

export default function Header({
  namedLinks,
  navigation,
  isPreview = false,
}: Props): JSX.Element {
  const router = useRouter()
  const { width: windowWidth } = useWindowSize()
  const user = useSelector(userProfileSelector)
  const [toggleLoginRegister, setToggleLoginRegister] = useState(false)
  const [toggleMobileNav, setToggleMobileNav] = useState(false)
  const [openTopLevelNav, setOpenTopLevelNav] = useState('')
  const [isPageScrolled, setIsPageScrolled] = useState(false)
  const [isSubFlyoutOpen, setIsSubFlyoutOpen] = useState(false)
  const [isSubFlyoutContents, setIsSubFlyoutContents] =
    useState<NavigationItemType>()
  const [isCategory, setIsCategory] = useState(false)
  const [loginModalViewMode, setLoginModalViewMode] = useState('')
  const [isUserLoggedInFreshchat, setIsUserLoggedInFreshchat] = useState(false)

  const dispatch = useDispatch()
  const { t } = useTranslation()

  const { q: searchQuery } = router.query
  const { iso_639_1: language } = localesFactory.createFromHrefLang(
    router.locale
  ).current

  const profileHandler = () => {
    setToggleLoginRegister(true)
    desktopNavHandler()
    setToggleMobileNav(false)
    setIsSubFlyoutOpen(false)
    gtmDatalayer('navigation_menu', 'navigation_menu', 'Login Profile')
  }

  const navHandler = () => {
    desktopNavHandler()
    mobileNavHandler()
  }

  const mobileNavHandler = () => {
    setToggleMobileNav(!toggleMobileNav)
    setToggleLoginRegister(false)
    setIsSubFlyoutOpen(false)
  }

  const desktopNavHandler = (item?) => {
    if (isTopLevelNavOpen(item) || typeof item === 'undefined') {
      setOpenTopLevelNav('')
    } else {
      setOpenTopLevelNav(item)
      isTopLevelNavOpen(item)
      setToggleLoginRegister(false)
      setIsSubFlyoutOpen(false)
    }
  }
  const childChecker = (value) => {
    value.find((value) => value.children)
      ? setIsCategory(true)
      : setIsCategory(false)
  }

  const isTopLevelNavOpen = (item) => {
    return openTopLevelNav === item
  }

  const onPageScroll = () => {
    if (document.body.scrollTop > 0 || document.documentElement.scrollTop > 0) {
      setIsPageScrolled(true)
    } else {
      setIsPageScrolled(false)
    }
  }

  const flyoutCloseHandler = () => {
    setToggleLoginRegister(false)
    desktopNavHandler()
    setToggleMobileNav(false)
    setIsSubFlyoutOpen(false)
  }

  const openSubFlyout = (data) => {
    setIsSubFlyoutContents(data)
    setIsSubFlyoutOpen(true)
    setToggleMobileNav(false)
  }

  const mobileSubFlyoutHandler = () => {
    setIsSubFlyoutOpen(false)
    setToggleMobileNav(true)
  }

  useEffect(() => {
    if (!isSubFlyoutOpen) {
      setIsSubFlyoutContents(undefined)
    }
  }, [isSubFlyoutOpen, isSubFlyoutContents])

  useEffect(() => {
    flyoutCloseHandler()
  }, [router.asPath])

  useEffect(() => {
    authListener()
    currentAuthenticatedUser()
      .then(async (authenticatedUser) => {
        dispatch(getUserProfileThunk(authenticatedUser?.username))
      })
      .catch(() => {
        dispatch(setAnonymousUserAction())
      })
    return () => {
      removeAuthListener()
    }
  }, [dispatch])

  useEffect(() => {
    onPageScroll()

    window.onscroll = function () {
      onPageScroll()
    }
  }, [])

  useEffect(() => {
    if (
      windowWidth &&
      windowWidth < 768 &&
      (toggleMobileNav || isSubFlyoutOpen)
    ) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = 'unset'
    }
  }, [toggleMobileNav, isSubFlyoutOpen, windowWidth])

  useEffect(() => {
    if (user.authenticated && !isUserLoggedInFreshchat) {
      setIsUserLoggedInFreshchat(true)
      setTimeout(() => freshchatLoginUser(user, language), 600)
    }
    if (!user.authenticated && isUserLoggedInFreshchat) {
      setIsUserLoggedInFreshchat(false)
      freshchatLogoutUser()
    }
  }, [isUserLoggedInFreshchat, language, user])

  return (
    <header
      className={`${styles.headerWrapper} ${
        isPageScrolled ? styles.scrolledSticky : ''
      }`}
    >
      {openTopLevelNav !== '' && (
        <div
          className={`fixed z-40 inset-0 w-full opacity-30 bg-gray-900 hidden sp:block`}
          onClick={() => {
            setToggleLoginRegister(false)
            desktopNavHandler()
            setIsSubFlyoutOpen(false)
          }}
        ></div>
      )}
      {(toggleMobileNav || isSubFlyoutOpen) && (
        <div
          className={`fixed z-40 inset-0 w-full opacity-30 bg-gray-900 sp:hidden`}
          onClick={() => {
            setToggleLoginRegister(false)
            setToggleMobileNav(false)
            setIsSubFlyoutOpen(false)
          }}
        ></div>
      )}
      <div className={`${styles.header}`}>
        <div className={`w-9 sp:w-28 flex-none z-50 ${styles.headerLogo}`}>
          <a
            href={`/${
              language === 'en'
                ? ''
                : '/' + router?.locale == '/ar-KW'
                ? router?.locale
                : language
            }`}
            onClick={() =>
              gtmDatalayer('logo_click', 'navigation_menu', 'Logo Click')
            }
          >
            <img
              src={
                language === 'ar'
                  ? '/assets/icons/logoAr.svg'
                  : '/assets/icons/logo.svg'
              }
              alt="X-Cite Logo"
              width="1178"
              height="402"
            />
          </a>
        </div>
        {navigation && (
          <>
            <button
              className={`${styles.headerMenu}`}
              onClick={mobileNavHandler}
            >
              <NavigationMenu className="w-6 h-6" stroke="white" />
            </button>
            <div
              className={`${toggleMobileNav ? 'block' : 'hidden'} ${
                styles.navigationWrapper
              }`}
            >
              <div className="sm:hidden text-black mb-5 flex justify-end">
                <LanguageSelector className="border-[1px] border-primary-900 rounded text-primary-900 inline-block px-3 py-2 text-3xl" />
              </div>
              {navigation.map((child, index) => {
                return child.href ? (
                  <div key={`${index}-top`}>
                    <Link
                      to={child.href}
                      className={`${styles.navigationLink} hidden sp:block`}
                      onClick={navHandler}
                    >
                      {child.title}
                    </Link>
                    <span
                      className={`${styles.navigationLink} mb-0 block sp:hidden`}
                    >
                      {child.title}
                    </span>
                    <Link
                      to={child.href}
                      className={`${styles.navigationTextlink} block sp:hidden`}
                      onClick={navHandler}
                    >
                      {t('header_navigation_show_all_label')}
                    </Link>
                  </div>
                ) : (
                  child?.children && child.children.length > 0 && (
                    <div key={`${index}-top`}>
                      <div
                        className={`${styles.navigationLink} ${
                          styles.navigationLinkWithChildren
                        } ${
                          isTopLevelNavOpen(index) &&
                          `bg-white bg-opacity-10 ${styles.arrowUp}`
                        } hidden sp:block`}
                        onClick={() => {
                          desktopNavHandler(index)
                          childChecker(child.children)
                        }}
                      >
                        {child.title}
                        <ArrowDropDownIcon className="text-white w-6 h-6 stroke-current hidden sp:block" />
                      </div>
                      <span
                        className={`${styles.navigationLink} ${
                          isTopLevelNavOpen(index) &&
                          `bg-white bg-opacity-10 ${styles.arrowUp}`
                        } block sp:hidden`}
                      >
                        {child.title}
                      </span>
                      <div
                        className={`${styles.navigationFlyout} ${
                          isTopLevelNavOpen(index) && !isCategory
                            ? 'sp:block'
                            : 'sp:hidden'
                        }`}
                      >
                        <div className="bg-white sp:px-10 sp:py-12 sp:min-w-[480px]">
                          <ul className="mb-5">
                            <FlyoutList
                              child={child}
                              navHandler={navHandler}
                              openSubFlyout={openSubFlyout}
                            />
                          </ul>
                        </div>
                      </div>
                    </div>
                  )
                )
              })}
            </div>
            {isSubFlyoutContents && (
              <SubFlyout
                className={`block sp:hidden`}
                isSubFlyoutOpen={isSubFlyoutOpen}
                isSubFlyoutContents={isSubFlyoutContents}
                mobileSubFlyoutHandler={mobileSubFlyoutHandler}
              />
            )}
            {navigation && isCategory && (
              <>
                {navigation.map((child, index) => {
                  return child.children?.find((child) => child.children)
                    ?.children ? (
                    <div
                      className={`${styles.navigationCategoryFlyout} ${
                        isSubFlyoutOpen ? 'ltr:right-0 rtl:left-0' : ''
                      } hidden ${
                        isTopLevelNavOpen(index) ? 'sp:block' : 'sp:hidden'
                      }`}
                      key={`${index}-flyout`}
                    >
                      <div className="sp:flex sp:flex-row sp:gap-[1px]">
                        <div className="bg-white sp:px-10 sp:py-12 sp:w-[480px] sp:block hidden flex-none">
                          <ul className="mb-5">
                            <FlyoutList
                              child={child}
                              navHandler={navHandler}
                              openSubFlyout={openSubFlyout}
                              flyoutContents={isSubFlyoutContents}
                            />
                          </ul>
                        </div>
                        {isSubFlyoutContents && (
                          <SubFlyout
                            className={`hidden sp:block sp:w-full`}
                            isSubFlyoutOpen={isSubFlyoutOpen}
                            isSubFlyoutContents={isSubFlyoutContents}
                            mobileSubFlyoutHandler={mobileSubFlyoutHandler}
                          />
                        )}
                      </div>
                    </div>
                  ) : null
                })}
              </>
            )}
          </>
        )}
        <div
          className={`w-full z-50 ${styles.headerSearch}`}
          onClick={() => flyoutCloseHandler()}
        >
          <SearchBox
            placeholder={t('header_search_input_placeholder')}
            searchVal={searchQuery?.toString()}
          />
        </div>
        <nav
          className={`flex gap-4 sm:gap-6 lg:gap-8 justify-end items-center ${styles.headerUserMenu}`}
        >
          <div className="hidden sm:block">
            <LanguageSelector className="text-white" />
          </div>
          <div
            className={`relative z-50 ${
              toggleLoginRegister
                ? 'sp:bg-white sp:bg-opacity-10 sp:rounded'
                : ''
            }`}
          >
            <button className="block self-end p-1" onClick={profileHandler}>
              <ProfileIcon className="w-6 h-6" stroke="white" />
            </button>
          </div>
          <CartIcon pageLink={namedLinks?.cart} />
          {toggleLoginRegister && (
            <Modal
              emptyDivClasses={`${styles.loginModalArrowUp}`}
              className={`bg-white ${styles.loginModalWrapper}`}
              extraCloseClasses={
                loginModalViewMode === LoginRegisterStateEnum.welcome
                  ? styles.loginModalBackBtnClose
                  : ''
              }
              extraCloseBtnClasses="px-5 py-2 -mr-5"
              handleModal={setToggleLoginRegister}
              showClose={loginModalViewMode === LoginRegisterStateEnum.welcome}
            >
              <LoginRegister
                handleModal={setToggleLoginRegister}
                handleViewMode={setLoginModalViewMode}
                headingLevel={HeadingEnum.h4}
              />
            </Modal>
          )}
        </nav>
      </div>
      {!isPreview && <CookieBanner />}
    </header>
  )
}
