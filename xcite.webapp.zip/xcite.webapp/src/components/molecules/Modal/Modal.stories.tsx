import React from 'react'

import { Story, Meta } from '@storybook/react'

import Modal, { Props } from './Modal'
import Button from '../../atoms/Button'
import Grid from '../../atoms/Grid'
import { useModal } from '../../../hooks'

export default {
  title: 'Components/molecules/Modal',
  component: Modal,
} as Meta

const Template: Story<Props> = (args) => {
  const { isShowing: isShowingModal, toggle: toggleModal } = useModal()

  return (
    <Grid>
      <div className="col-span-full py-4 flex flex-col gap-4 items-center">
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque
          pharetra porta leo quis lobortis. In eros odio, consequat ut risus id,
          commodo elementum lectus. Maecenas sed dapibus orci, id tempus quam.
          Nam vel porta mauris. Etiam et condimentum neque, nec ornare lacus.
          Pellentesque sed pellentesque neque. Vestibulum ante ipsum primis in
          faucibus orci luctus et ultrices posuere cubilia curae; Nam porta
          placerat nisi, vitae consequat neque laoreet sed. Mauris lacinia massa
          vel est malesuada venenatis. Vivamus sed lectus eget erat mattis
          laoreet at condimentum metus. Mauris tempus vitae leo vitae tincidunt.
          Vivamus sagittis accumsan nisl vel fringilla. Phasellus condimentum
          volutpat imperdiet. Donec euismod non augue eget sodales. Aliquam
          hendrerit consequat cursus.
        </p>
        <p>
          Fusce at ante tincidunt, aliquam libero ac, venenatis dolor. Aliquam
          malesuada diam quis orci ultricies, eu auctor mauris viverra. Ut
          sollicitudin libero efficitur, fringilla nunc ac, fringilla nunc.
          Pellentesque pulvinar porttitor congue. Nullam sem dolor, aliquam quis
          enim ut, ullamcorper gravida risus. Nulla facilisi. Maecenas nec erat
          quis leo vestibulum venenatis.
        </p>
        <p>
          Mauris aliquam mi orci, eget tempor dolor condimentum nec. Curabitur
          varius at quam nec feugiat. Nullam vitae scelerisque sem. Cras
          ultrices nunc non lectus tristique, id eleifend mi viverra. Curabitur
          vitae felis non nulla luctus euismod. Aliquam in dolor vitae nibh
          mattis facilisis. Vestibulum lobortis id nibh hendrerit tempus.
          Praesent erat nisl, volutpat at mauris id, efficitur viverra dolor.
          Donec et nisl enim. Sed auctor mi at diam bibendum venenatis. In quis
          sapien vel metus efficitur luctus volutpat vel nulla. In commodo est
          justo, vitae malesuada arcu pulvinar vestibulum. Vestibulum mattis nec
          lectus a consequat. Curabitur ultrices ipsum in libero imperdiet
          egestas. Nulla facilisi. Praesent posuere turpis id dolor tempor
          blandit.
        </p>
        <Button onClick={toggleModal}>Show Modal</Button>
        <Modal {...args} isShowing={isShowingModal} hide={toggleModal}>
          {args.children}
        </Modal>
      </div>
    </Grid>
  )
}

export const Default = Template.bind({})

Default.args = {
  children: (
    <div>
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque
      pharetra porta leo quis lobortis. In eros odio, consequat ut risus id,
      commodo elementum lectus. Maecenas sed dapibus orci, id tempus quam. Nam
      vel porta mauris. Etiam et condimentum neque, nec ornare lacus.
      Pellentesque sed pellentesque neque. Vestibulum ante ipsum primis in
      faucibus orci luctus et ultrices posuere cubilia curae; Nam porta placerat
      nisi, vitae consequat neque laoreet sed. Mauris lacinia massa vel est
      malesuada venenatis. Vivamus sed lectus eget erat mattis laoreet at
      condimentum metus. Mauris tempus vitae leo vitae tincidunt. Vivamus
      sagittis accumsan nisl vel fringilla. Phasellus condimentum volutpat
      imperdiet. Donec euismod non augue eget sodales. Aliquam hendrerit
      consequat cursus.
    </div>
  ),
}

export const WithBackLink = Template.bind({})

WithBackLink.args = {
  children: (
    <div>
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque
      pharetra porta leo quis lobortis. In eros odio, consequat ut risus id,
      commodo elementum lectus. Maecenas sed dapibus orci, id tempus quam. Nam
      vel porta mauris. Etiam et condimentum neque, nec ornare lacus.
      Pellentesque sed pellentesque neque. Vestibulum ante ipsum primis in
      faucibus orci luctus et ultrices posuere cubilia curae; Nam porta placerat
      nisi, vitae consequat neque laoreet sed. Mauris lacinia massa vel est
      malesuada venenatis. Vivamus sed lectus eget erat mattis laoreet at
      condimentum metus. Mauris tempus vitae leo vitae tincidunt. Vivamus
      sagittis accumsan nisl vel fringilla. Phasellus condimentum volutpat
      imperdiet. Donec euismod non augue eget sodales. Aliquam hendrerit
      consequat cursus.
    </div>
  ),
  backButton: true,
  onBackClicked: () => console.log('back button clicked'),
}
