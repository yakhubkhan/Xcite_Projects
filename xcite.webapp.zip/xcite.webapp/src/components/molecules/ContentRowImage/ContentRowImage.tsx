import React, { useEffect, useState, useRef } from 'react'
import { ContentRowImageBlocks } from '../../../types/content/component'
import { useRouter } from 'next/router'
import Image from '../../atoms/Image'

export default function ContentRowImage(
  props: ContentRowImageBlocks
): JSX.Element {
  const { imageBlocks } = props
  const router = useRouter()
  const imageRef = useRef<HTMLDivElement>(null)
  const [imageHeight, setImageHeight] = useState(0)

  const handleClick = (link) => {
    if (link?.url) {
      if (link?.isExternal) {
        window.open(link?.url, '_ blank')
      } else {
        router.push(link?.url)
      }
    }
  }

  useEffect(() => {
    const imageRatio = imageBlocks.length > 1 ? [16, 9] : [4, 1]

    const defineImageHeight = () => {
      setImageHeight(
        imageRef.current
          ? (imageRef.current?.offsetWidth / imageRatio[0]) * imageRatio[1]
          : imageHeight
      )
    }
    defineImageHeight()
    window.onresize = defineImageHeight
  }, [imageBlocks, imageHeight])

  return (
    <>
      {imageBlocks && (
        <div
          className={`flex flex-col gap-5 sm:flex-row xl:container xl:mx-auto`}
        >
          {imageBlocks.map((item, index) => (
            <div key={index} className={`w-full flex flex-col gap-2`}>
              <span
                className={`relative ${item.link?.url ? 'cursor-pointer' : ''}`}
                style={{ height: imageHeight + 'px' }}
                ref={imageRef}
              >
                <Image
                  src={item.image.src}
                  alt={item.image.alt}
                  layout="fill"
                  objectFit="cover"
                  className={`${item.link?.url && 'cursor-pointer'}`}
                  onClick={() => handleClick(item.link)}
                />
              </span>
            </div>
          ))}
        </div>
      )}
    </>
  )
}
