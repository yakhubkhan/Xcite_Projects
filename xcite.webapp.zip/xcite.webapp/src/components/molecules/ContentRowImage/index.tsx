export { default } from './ContentRowImage'
