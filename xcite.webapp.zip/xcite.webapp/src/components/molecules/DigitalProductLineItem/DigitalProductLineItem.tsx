import { useTranslation } from 'next-i18next'
import React from 'react'
import {
  HeadingEnum,
  OrderReprint,
  OrderLineItem,
  ReprintStatusEnum,
  StatusMessageEnum,
} from '../../../types/content'
import Heading from '../../atoms/Heading'
import Image from '../../atoms/Image'
import LoadingIndicatorDot from '../../atoms/LoadingIndicatorDot'
import StatusMessage from '../../atoms/StatusMessage'

const DigitalProductLineItem = ({
  lineItem,
  reprintLineItem,
}: {
  lineItem: OrderLineItem
  reprintLineItem: OrderReprint
}): JSX.Element => {
  const { t } = useTranslation()
  return (
    <>
      <div className="col-span-3 flex flex-col bg-white gap-2 items-center justify-center sm:gap-4">
        <Image
          src={lineItem.image.src}
          alt={lineItem.image.alt}
          width={185}
          height={185}
          objectFit="contain"
        />
      </div>
      <div className="col-span-4 bg-white">
        <div className="flex flex-col gap-4 py-10 ml-4 mr-6">
          <div>
            <Heading type={HeadingEnum.h5}>{lineItem.name}</Heading>
          </div>

          {reprintLineItem?.status ===
            ReprintStatusEnum.ERROR_WHILE_PRINTING && (
            <div className="animate-appearFromAbove">
              <StatusMessage
                type={StatusMessageEnum.Error}
                className="leading-2 typography-label"
              >
                <div className="typography-small-strong text-functional-red-800">
                  {t('checkout_order_confirmation_show_code_error_title')}
                </div>
                <div className="typography-small pt-2">
                  {t('checkout_order_confirmation_show_code_error_label')}
                </div>
              </StatusMessage>
            </div>
          )}
          {reprintLineItem?.status !==
            ReprintStatusEnum.ERROR_WHILE_PRINTING && (
            <div className="bg-gray-50 p-3">
              <div className="text-sm">
                {t('checkout_order_confirmation_product_code_message')}
              </div>
              {reprintLineItem?.status ===
                ReprintStatusEnum.WAITING_FOR_RESULT && (
                <LoadingIndicatorDot>
                  {t('codeLoadingIndicator_label')}
                </LoadingIndicatorDot>
              )}
              {reprintLineItem?.status === ReprintStatusEnum.NOT_APPLICABLE && (
                <div>{t('checkout_order_confirmation_show_code_na_label')}</div>
              )}
              {reprintLineItem?.status === ReprintStatusEnum.OK && (
                <Heading type={HeadingEnum.h2}>
                  {reprintLineItem.activationCode}
                </Heading>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  )
}

export default DigitalProductLineItem
