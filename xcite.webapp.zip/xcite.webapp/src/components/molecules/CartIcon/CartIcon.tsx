import { useRouter } from 'next/router'
import React, { useCallback, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'

import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import {
  cartStatusSelector,
  cartTotalItemsSelector,
  cartUserSelector,
  loadCartThunk,
} from '../../../redux/slices/cart'
import {
  profileStatusSelector,
  userProfileSelector,
} from '../../../redux/slices/profile'
import { AsyncResponseStatusEnum } from '../../../types/content'
import Link from '../../atoms/Link'
import { CartIcon as Icon } from '../../atoms/Icon'

type Props = {
  pageLink: string
}

const MAX_ITEMS_CART_ICON = 9

const CartIcon = ({ pageLink }: Props): JSX.Element => {
  const { locale } = useRouter()

  const dispatch = useDispatch()
  const user = useSelector(userProfileSelector)
  const cartStatus = useSelector(cartStatusSelector)
  const cartTotalItems = useSelector(cartTotalItemsSelector)
  const profileStatus = useSelector(profileStatusSelector)
  const cartUser = useSelector(cartUserSelector)

  const {
    iso_639_1: language,
    country: { ctStore: store },
    hreflang,
  } = localesFactory.createFromHrefLang(locale).current

  const onLoadCart = useCallback(
    (user, store, language, hreflang) => {
      dispatch(
        loadCartThunk({
          user,
          store,
          language,
          locale: hreflang,
        })
      )
    },
    [dispatch]
  )

  // Initial loading of the cart (on page load)
  useEffect(() => {
    if (user.id && cartStatus === AsyncResponseStatusEnum.idle) {
      onLoadCart(user, store, language, hreflang)
    }
  }, [
    onLoadCart,
    cartStatus,
    user,
    store,
    language,
    hreflang,
    cartUser,
    profileStatus,
  ])

  // Load the cart when the user is changed (after sign in/out, sing up...)
  useEffect(() => {
    if (
      user.id &&
      user.id !== cartUser &&
      cartStatus === AsyncResponseStatusEnum.succeeded
    ) {
      onLoadCart(user, store, language, hreflang)
    }
  }, [
    onLoadCart,
    cartStatus,
    user,
    store,
    language,
    cartUser,
    profileStatus,
    hreflang,
  ])

  return (
    <Link to={pageLink} className="block p-1 relative z-50">
      <Icon className="w-6 h-6" stroke="white" />
      {cartTotalItems > 0 && (
        <span className="absolute bg-functional-blue-200 h-4 -right-2 rtl:-left-2 rtl:right-auto rounded-2xl text-center text-primary-900 -top-2 typography-caption w-4">
          {cartTotalItems > MAX_ITEMS_CART_ICON
            ? `${MAX_ITEMS_CART_ICON}+`
            : cartTotalItems}
        </span>
      )}
    </Link>
  )
}

export default CartIcon
