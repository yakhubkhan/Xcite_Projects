import React from 'react'
import { HeadingEnum } from '../../../types/content'
import Heading from '../../atoms/Heading'
import Link from '../../atoms/Link'
import { FooterComponent } from '../../../types/content/footer'
import Image from '../../atoms/Image'
import Grid from '../../atoms/Grid'
import NewsletterSubscribe from '../NewsletterSubscribe'
import StoreCard from '../StoreCard'
import CountrySelector from '../CountrySelector'

type Props = {
  footerContent?: FooterComponent
}

export default function Footer({ footerContent }: Props): JSX.Element {
  const { top, middle, bottom } = footerContent || {}
  const xciteLogo = middle?.firstSection?.contentBlock?.image
  const openInNewTab = (url) => {
    const newWindow = window.open(url, '_blank', 'noopener,noreferrer')
    if (newWindow) newWindow.opener = null
  }

  return (
    <>
      {footerContent && (
        <footer className="bg-primary-900 text-white">
          <Grid className="pt-10 pb-12 sm:py-12 sm:flex">
            {top?.mobileAppBlock && <StoreCard top={top} />}
            <NewsletterSubscribe />
          </Grid>

          {middle && (
            <div className="py-12 border-t border-darkblue-60 sm:py-20">
              <Grid className="gap-y-12 sm:gap-y-20">
                <div className="col-span-full grid grid-cols-4 gap-y-12 sm:col-start-4 sm:col-span-9 sm:row-start-1 sm:grid-cols-9">
                  {middle?.firstSection?.navigation?.map((data) => {
                    return (
                      <div
                        key={data.title}
                        className="col-span-2 sm:col-span-3"
                      >
                        <ul className="flex flex-col gap-y-4">
                          <li>
                            <span className="typography-default-strong">
                              {data.title}
                            </span>
                          </li>
                          {data?.children?.map((child) => {
                            return child.href && child.href === '/flyer' ? (
                              <li
                                key={child.title}
                                className="typography-default"
                                onClick={() => openInNewTab(child.href)}
                              >
                                <a href="#">{child.title}</a>
                              </li>
                            ) : (
                              <li
                                key={child.title}
                                className="typography-default"
                              >
                                {child.href ? (
                                  <Link to={child.href}>{child.title}</Link>
                                ) : (
                                  child.title
                                )}
                              </li>
                            )
                          })}
                        </ul>
                      </div>
                    )
                  })}
                </div>
                <div className="col-span-full sm:col-start-1 sm:col-span-3 sm:row-start-1 md:col-span-2">
                  <Image
                    src={xciteLogo?.src || ''}
                    alt={xciteLogo?.alt}
                    width={120}
                    height={41}
                    className="mb-4"
                  />
                  <p className="typography-small">
                    {middle?.firstSection?.contentBlock?.text}
                  </p>
                </div>
                <div className="col-span-full sm:row-start-2">
                  <Heading type={HeadingEnum.h5} className="mb-4">
                    {middle?.secondSection?.paymentOptions?.title}
                  </Heading>
                  <div className="flex flex-row gap-2">
                    {middle?.secondSection?.paymentOptions?.icons.map(
                      (data, index) => {
                        return (
                          <Image
                            src={data.src}
                            alt={data.alt}
                            width={35}
                            height={24}
                            key={index}
                          ></Image>
                        )
                      }
                    )}
                  </div>
                </div>
              </Grid>
            </div>
          )}
          {bottom && (
            <div className="py-12 pb-32 sm:pt-10 sm:pb-24 border-t border-darkblue-60">
              <Grid className="sm:flex">
                <div className="col-span-full sm:flex-1">
                  <ul className="flex flex-col sm:flex-row gap-4">
                    <li className="sm:pr-8">
                      <span className="typography-small">
                        {bottom.copyright}
                      </span>
                    </li>
                    {bottom?.links.map((item) => (
                      <li key={item.title}>
                        <Link to={item.href || ''} className="typography-small">
                          {item.title}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="col-span-full pt-4 sm:pt-0">
                  <CountrySelector />
                </div>
              </Grid>
            </div>
          )}
        </footer>
      )}
    </>
  )
}
