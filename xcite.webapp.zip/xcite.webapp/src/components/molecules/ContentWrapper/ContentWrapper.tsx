import React, { useEffect, useState } from 'react'

const ContentWrapper = ({
  children,
  isEditorialPage = false,
}: {
  children: React.ReactNode
  isEditorialPage: boolean
}): JSX.Element => {
  const [bodyHeight, setBodyHeight] = useState('auto')
  useEffect(() => {
    const header = document.querySelector('header')
    const footer = document.querySelector('footer')

    if (header && footer) {
      const substract = header?.offsetHeight + footer?.offsetHeight
      setBodyHeight(`calc(100vh - ${substract}px)`)
    }
  }, [])

  return (
    <main
      className={`flex flex-col${isEditorialPage ? ' gap-5' : ''}`}
      style={{ minHeight: bodyHeight }}
    >
      {children}
    </main>
  )
}

export default ContentWrapper
