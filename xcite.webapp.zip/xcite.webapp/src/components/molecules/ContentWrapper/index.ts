export { default } from './ContentWrapper'
