import { useRouter } from 'next/router'
import { useTranslation } from 'next-i18next'
import React from 'react'

import {
  CountryCodeEnum,
  PaymentSummaryDetailsType,
} from '../../../types/content'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'

export default function PaymentSummary({
  isCart = false,
  paymentSummaryDetails,
}: {
  isCart?: boolean
  paymentSummaryDetails: PaymentSummaryDetailsType
}): JSX.Element {
  const { t } = useTranslation()
  const { locale } = useRouter()

  const {
    country: { id: countryId },
  } = localesFactory.createFromHrefLang(locale).current

  return (
    <ul className="w-full typography-small flex flex-col gap-2">
      <li className={`${isCart ? '' : 'flex justify-between'}`}>
        <span>{t('cart_checkout_subtotal_label')}</span>
        <span className={`${isCart ? 'sm:hidden' : 'hidden'}`}>: </span>
        <span className={`${isCart ? 'font-bold sm:font-normal' : ''}`}>
          {paymentSummaryDetails.totalWithoutDelivery}
        </span>
      </li>
      {paymentSummaryDetails.cashOnDeliveryCharge && (
        <li className={`${isCart ? '' : 'flex justify-between'}`}>
          <span>{t('cart_checkout_cash_on_delivery_label')}</span>
          <span className={`${isCart ? 'sm:hidden' : 'hidden'}`}>: </span>
          <span className={`${isCart ? 'font-bold sm:font-normal' : ''}`}>
            {paymentSummaryDetails.cashOnDeliveryCharge}
          </span>
        </li>
      )}
      {paymentSummaryDetails.deliveryCharge && (
        <li className={`${isCart ? '' : 'flex justify-between'}`}>
          <span>
            {t('cart_checkout_delivery_label')}
            <span className={`${isCart ? 'sm:hidden' : 'hidden'}`}>: </span>
          </span>
          <span
            className={`${isCart ? 'font-bold sm:font-normal' : 'font-normal'}`}
          >
            {paymentSummaryDetails.deliveryCharge === ''
              ? t('cart_checkout_delivery_type_free')
              : paymentSummaryDetails.deliveryCharge}
          </span>
        </li>
      )}
      {paymentSummaryDetails.handlingCost && (
        <li className={`${isCart ? '' : 'flex justify-between'}`}>
          <span>{t('cart_checkout_shipping_and_handling_label')}</span>
          <span className={`${isCart ? 'sm:hidden' : 'hidden'}`}>: </span>
          <span className={`${isCart ? 'font-bold sm:font-normal' : ''}`}>
            {paymentSummaryDetails.handlingCost}
          </span>
        </li>
      )}
      {paymentSummaryDetails.installationCharge && (
        <li className={`${isCart ? '' : 'flex justify-between'}`}>
          <span>{t('cart_checkout_installation_label')}</span>
          <span className={`${isCart ? 'sm:hidden' : 'hidden'}`}>: </span>
          <span className={`${isCart ? 'font-bold sm:font-normal' : ''}`}>
            {paymentSummaryDetails.installationCharge}
          </span>
        </li>
      )}
      {paymentSummaryDetails.discountPrice && (
        <li
          className={`${
            isCart ? '' : 'flex justify-between'
          } text-functional-red-800`}
        >
          <span>{t('cart_checkout_discount_label')}</span>
          <span className={`${isCart ? 'sm:hidden' : 'hidden'}`}>: </span>
          <span className={`${isCart ? 'font-bold sm:font-normal' : ''}`}>
            -{paymentSummaryDetails.discountPrice}
          </span>
        </li>
      )}
      {countryId === CountryCodeEnum.SaudiArabia &&
        paymentSummaryDetails.taxAmount && (
          <li className={`${isCart ? 'sm:flex' : 'flex justify-between'}`}>
            <span>{t('checkout_shipping_taxes_label')}</span>
            <span className={`${isCart ? 'sm:hidden' : 'hidden'}`}>: </span>
            <span className={`${isCart ? 'font-bold sm:font-normal' : ''}`}>
              {paymentSummaryDetails.taxAmount}
            </span>
          </li>
        )}
      <li
        className={`${
          isCart ? 'sm:py-3 sm:border-y' : 'flex justify-between py-3 border-y'
        }`}
      >
        <span>
          {isCart
            ? t('checkout_shipping_Esttotal_label')
            : t('checkout_shipping_total_label')}
          <span className={`${isCart ? 'sm:hidden' : 'hidden'}`}>: </span>
        </span>
        <span
          className={`${
            isCart ? 'font-bold sm:text-lg' : ' font-bold text-lg'
          }`}
        >
          {paymentSummaryDetails.totalPrice}
        </span>
      </li>
    </ul>
  )
}
