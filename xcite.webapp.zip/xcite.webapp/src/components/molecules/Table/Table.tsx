import TableRow from './TableRow'
import { ProductSpecificationAttributesType } from '../../../types/content'

export default function Table({
  tbodyData,
}: {
  tbodyData: ProductSpecificationAttributesType[]
}): JSX.Element {
  return (
    <div className="flex flex-col -mx-5 sm:mx-0">
      <table className="min-w-full">
        <tbody>
          {tbodyData.map((item: ProductSpecificationAttributesType, i) => {
            return item.label.length>0?<TableRow key={item.label + i} data={item} />:''
          })}
        </tbody>
      </table>
    </div>
  )
}
