import { ProductSpecificationAttributesType } from '../../../types/content'

const TableRow = ({ data }: { data: ProductSpecificationAttributesType }) => {
  const contents = Object.values(data)
  return (
    <tr className="border-b border-b-gray-300 flex flex-row">
      {contents.map((data: string, index) => {
        return (
          <td
            className="typography-default flex-1 px-5 py-4 align-top first:typography-default-strong"
            key={index}
          >
            {data}
          </td>
        )
      })}
    </tr>
  )
}

export default TableRow
