import React from 'react'

import { ComponentType } from '../../types/content'
import { ComponentRegistry } from '../registry/ComponentRegistry'

interface Props {
  components: ComponentType[]
  registry: ComponentRegistry
}

const ComponentsRenderer = ({ components, registry }: Props): JSX.Element => {
  return (
    <>
      {components.map((componentData, index) => {
        const ComponentType = registry.getComponent(componentData.type)
        if (ComponentType) {
          return (
            <section className={componentData.type} key={index}>
              <ComponentType key={index} {...componentData} />
            </section>
          )
        } else {
          console.error(`unknown component type: ${componentData.type}`)
          return <div key={index}></div>
        }
      })}
    </>
  )
}

export default ComponentsRenderer
