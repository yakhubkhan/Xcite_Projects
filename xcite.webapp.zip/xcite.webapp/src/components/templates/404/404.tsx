import Head from 'next/head'
import { NavigationItemType } from '../../../types/content'
import Error404 from '../../molecules/Error404'

const Template404 = (props: {
  homeLinkHref: string
  optionalPageLink?: NavigationItemType
}): JSX.Element => {
  return (
    <>
      <Head>
        <meta name="robots" content="noindex" />
      </Head>
      <main className="bg-product-ice-50 flex items-center sm:py-24">
        <Error404 {...props} />
      </main>
    </>
  )
}

export default Template404
