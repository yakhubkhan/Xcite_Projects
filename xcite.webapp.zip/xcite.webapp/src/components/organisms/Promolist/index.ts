export { default } from './Promolist'
