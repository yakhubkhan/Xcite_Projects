import React, { useCallback, useEffect } from 'react'
import { HeadingEnum } from '../../../types/content'
import Modal from '../../atoms/Modal'
import Heading from '../../atoms/Heading'
import MarkDown from '../../atoms/MarkDown'

export default function Promolist({
  promoHeading,
  promoDetail,
  termHeading,
  termDetail,
  onCloseModal,
}: {
  promoHeading?: string
  promoDetail?: string
  termHeading?: string
  termDetail?: string
  onCloseModal: () => void
}): JSX.Element {
  return (
    <div style={{ paddingBottom: '50px', height: '100%' }}>
      <Modal
        className={`bg-white rounded-t-lg justify-center 
      items-center fixed left-0 w-full bottom-0 px-5 py-7 sm:top-2/4 sm:left-2/4 
      sm:max-w-[633px]  sm:rounded-xl sm:-translate-x-1/2 
      sm:-translate-y-1/2 sm:px-8 sm:pb-7 sm:pt-8 overflow-scroll h-full`}
        extraCloseClasses={`pb-4`}
        handleModal={onCloseModal}
        showClose={true}
      >
        <div>
          <Heading type={HeadingEnum.h4} className="mb-4">
            {promoHeading}
          </Heading>
          <MarkDown>{promoDetail}</MarkDown>
          <br />
          <Heading type={HeadingEnum.h4} className="mb-4">
            {termHeading}
          </Heading>
          <MarkDown>{termDetail}</MarkDown>
        </div>
      </Modal>
    </div>
  )
}
