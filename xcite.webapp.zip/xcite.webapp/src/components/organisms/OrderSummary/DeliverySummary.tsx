import { useTranslation } from 'next-i18next'
import React from 'react'
import {
  ButtonVariantEnum,
  CartGroup,
  DeliveryMethodType,
} from '../../../types/content'
import Button from '../../atoms/Button'
import DeliveryDetails from '../../molecules/DeliveryDetails'

type Props = {
  deliveryGroups: CartGroup[]
  onChangeDeliveryRequested: () => void
}

const DeliverySummary = ({
  deliveryGroups,
  onChangeDeliveryRequested,
}: Props): JSX.Element => {
  const { t } = useTranslation()

  const getDeliveryGroupNumber = (slug: string) => {
    const groupSlugParts = slug.split('_')
    return Number(groupSlugParts[1])
  }

  const getDeliveryText = (
    deliveryMethod: DeliveryMethodType,
    localizedDate?: string
  ) => {
    if (deliveryMethod.name === 'ScheduledDelivery' && localizedDate) {
      return localizedDate
    }

    const deliveryMethodDetails = DeliveryDetails(deliveryMethod)

    if (!deliveryMethodDetails) {
      return null
    }

    const deliveryName = t(deliveryMethodDetails?.translationKey)

    return deliveryName
  }

  return (
    <div>
      <div className="flex mb-4">
        <div className="flex-1 typography-small-strong">
          {t('cart_checkout_delivery_label')}
        </div>
        <Button
          onClick={onChangeDeliveryRequested}
          variant={ButtonVariantEnum.textLink}
        >
          {t('checkout_summary_address_button_change')}
        </Button>
      </div>
      <div className="bg-gray-100 p-3 rounded">
        <ul className="flex flex-col gap-4">
          {deliveryGroups.map((group) => {
            const { slug, selectedDeliveryMethod } = group

            return selectedDeliveryMethod ? (
              <li
                className={`typography-small leading-2 flex gap-4 justify-between ${
                  group.completed ? 'text-gray-600' : 'text-gray-300'
                }`}
                key={slug}
              >
                <span>
                  {t('checkout_delivery_group_heading')}{' '}
                  {getDeliveryGroupNumber(slug)}
                </span>
                <span className="flex-1 ltr:text-right rtl:text-left">
                  {group.completed
                    ? getDeliveryText(
                        selectedDeliveryMethod.deliveryMethod,
                        selectedDeliveryMethod.deliveryDetails?.localizedDate
                      )
                    : '-'}
                </span>
              </li>
            ) : null
          })}
        </ul>
      </div>
    </div>
  )
}

export default DeliverySummary
