import React, { useEffect, useState } from 'react'
import { useRouter } from 'next/router'
import { useSelector } from 'react-redux'
import { useTranslation } from 'next-i18next'
import styles from './OrderSummary.module.css'
import {
  cartStatusSelector,
  paymentBNPLSelector,
  paymentSummaryDetailsSelector,
} from '../../../redux/slices/cart'
import {
  Address,
  AsyncResponseStatusEnum,
  ButtonVariantEnum,
  CartGroup,
  CountryCodeEnum,
  HeadingEnum,
  PaymentMethodType,
  PaymentTypeEnum,
  PickupStoreType,
  ProductGroupEnum,
} from '../../../types/content'
import Button from '../../atoms/Button'
import PaymentMethodIcon from '../../atoms/PaymentMethodIcon'
import {
  DeliveryRegularIcon,
  ReceiptSlipIcon,
  ShoppingBagIcon,
} from '../../atoms/Icon'
import { namedLinksSelector } from '../../../redux/slices/navigation'
import Heading from '../../atoms/Heading'
import PaymentSummary from '../../molecules/PaymentSummary'
import AddDiscount from '../../molecules/AddDiscount'
import gtmDatalayer from '../../../util/gtmUtils'
import TermsAndConditionToggle from '../../molecules/TermsAndConditionToggle'
import DeliverySummary from './DeliverySummary'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'

declare type OrderSummaryProps = {
  btnOrderSummaryLabel: string
  btnVariant?: ButtonVariantEnum
  orderSummaryFrom?: string
  orderSummaryStatus: boolean
  selectedPaymentMethod?: PaymentMethodType
  billingAddress?: Address
  shippingAddress?: Address
  cartGroups?: CartGroup[]
  onClickCheckout?: () => void
  addressDisplayRequired?: boolean
}

const OrderSummary = (props: OrderSummaryProps): JSX.Element => {
  const { locale } = useRouter()
  const { t } = useTranslation()
  const router = useRouter()
  const namedLinks = useSelector(namedLinksSelector)
  const cartStatus = useSelector(cartStatusSelector)
  const paymentSummarydetails = useSelector(paymentSummaryDetailsSelector)
  const bnplTypes = useSelector(paymentBNPLSelector)
  const [isCart, setIsCart] = useState(false)
  const [isOrderReview, setIsOrderReview] = useState(false)
  const [isTermsAndConditionsChecked, setIsTermsAndConditionsChecked] =
    useState(true)
  const [hasCartPickUpStoreItem, setIfCartHasPickUpStoreItem] = useState(false)
  const [pickUpStoreInformation, setPickUpStoreInformation] = useState<
    { items: number; pickUpStore?: PickupStoreType }[]
  >([])
  const [hasPickUpItemsCombined, setHasPickUpItemsCombined] = useState(false)
  const {
    btnOrderSummaryLabel,
    btnVariant,
    orderSummaryFrom,
    orderSummaryStatus,
    selectedPaymentMethod,
    onClickCheckout,
    billingAddress,
    shippingAddress,
    cartGroups,
    addressDisplayRequired,
  } = props

  const handleToggle = () => {
    setIsTermsAndConditionsChecked(!isTermsAndConditionsChecked)
  }

  const {
    country: { id: countryId },
    hreflang,
  } = localesFactory.createFromHrefLang(locale).current

  const bnpl = JSON.parse(JSON.stringify(bnplTypes))

  useEffect(() => {
    if (cartGroups && !hasCartPickUpStoreItem) {
      setPickUpStoreInformation([])
      for (let i = 0; i < cartGroups.length; i++) {
        if (cartGroups[i].slug === 'clickAndCollect') {
          const pickUpItems = cartGroups[i].items
          setIfCartHasPickUpStoreItem(true)

          for (let i = 0; i < pickUpItems.length; i++) {
            setPickUpStoreInformation((pickUpStoreInformation) => [
              ...pickUpStoreInformation,
              {
                items: pickUpItems[i].quantity,
                pickUpStore: pickUpItems[i].pickupStore,
              },
            ])
          }
        }
      }
    }
  }, [cartGroups, hasCartPickUpStoreItem])

  useEffect(() => {
    const combinePickUpItems = (pickUpItems) => {
      const result = pickUpItems.reduce((itemsList, currentItem) => {
        let found = false
        for (let i = 0; i < itemsList.length; i++) {
          if (
            itemsList[i].pickUpStore.name === currentItem.pickUpStore.name &&
            itemsList[i].pickUpStore.firstName.trim() ===
              currentItem.pickUpStore.firstName.trim() &&
            itemsList[i].pickUpStore.lastName.trim() ===
              currentItem.pickUpStore.lastName.trim()
          ) {
            found = true
            itemsList[i].items = itemsList[i].items + currentItem.items
          }
        }
        if (!found) {
          itemsList.push(currentItem)
        }
        return itemsList
      }, [])

      return result
    }

    if (pickUpStoreInformation.length > 0 && !hasPickUpItemsCombined) {
      setPickUpStoreInformation(combinePickUpItems(pickUpStoreInformation))
      setHasPickUpItemsCombined(true)
    }
  }, [hasPickUpItemsCombined, pickUpStoreInformation])

  useEffect(() => {
    if (orderSummaryFrom === 'cart') {
      setIsCart(true)
    }
    if (orderSummaryFrom === 'revieworder') {
      setIsOrderReview(true)
    }
  }, [orderSummaryFrom])

  const deliveryGroups = cartGroups?.filter((group) =>
    group.slug.includes(ProductGroupEnum.HomeDelivery)
  )

  return (
    <div
      className={`${
        isCart
          ? styles.cartWrapper
          : orderSummaryFrom === 'shipping'
          ? styles.shippingWrapper
          : orderSummaryFrom === 'delivery'
          ? styles.deliveryWrapper
          : orderSummaryFrom === 'payment'
          ? styles.paymentWrapper
          : orderSummaryFrom === 'revieworder'
          ? styles.reviewOrderWrapper
          : ''
      } ${styles.wrapper}`}
    >
      {btnOrderSummaryLabel && isOrderReview && (
        <Button
          className="hidden sm:flex"
          variant={btnVariant}
          onClick={onClickCheckout}
          disabled={
            orderSummaryStatus ||
            cartStatus === AsyncResponseStatusEnum.loading ||
            (isOrderReview && !isTermsAndConditionsChecked)
          }
        >
          {btnOrderSummaryLabel}
        </Button>
      )}
      {countryId === CountryCodeEnum.SaudiArabia &&
        bnpl &&
        bnpl.includes(PaymentTypeEnum.Tamara) && (
          <div className={styles.showDesktop}>
            <div
              className="tamara-product-widget "
              data-lang={hreflang && hreflang.startsWith('ar') ? 'ar' : 'en'}
              data-price={JSON.stringify(paymentSummarydetails.totalPrice)}
              data-currency="SAR"
              data-country-code="SA"
              data-color-type="default"
              data-show-border="true"
              data-payment-type="installment"
              data-number-of-installments="3"
              data-disable-installment="false"
              data-disable-paylater="true"
            />
          </div>
        )}
      <Heading
        type={HeadingEnum.h4}
        className={`${isCart ? 'hidden' : ''} sm:block`}
      >
        {t('cart_checkout_summary_label')}
      </Heading>
      {shippingAddress && addressDisplayRequired && (
        <div>
          <div className="flex mb-4">
            <div className="flex-1 typography-small-strong">
              {t('cart_checkout_shippingAddress_label')}
            </div>
            <Button
              onClick={() => router.push(namedLinks.shipping)}
              variant={ButtonVariantEnum.textLink}
            >
              {t('checkout_summary_address_button_change')}
            </Button>
          </div>
          <div className="min-h-[3rem] cmn-flex-items-center bg-gray-100 px-3 rounded">
            <DeliveryRegularIcon className="h-6 w-6 stroke-current" />
            <span className="flex-1 typography-small text-gray-600 leading-2 pt-2 pb-2  pl-2 rtl:pr-2">
              {shippingAddress?.formattedAddress}
            </span>
          </div>
        </div>
      )}
      {billingAddress && (
        <div>
          <div className="flex mb-4">
            <div className="flex-1 typography-small-strong">
              {t('cart_checkout_billingAddress_label')}
            </div>
            <Button
              onClick={() => router.push(`${namedLinks.shipping}#billing`)}
              variant={ButtonVariantEnum.textLink}
            >
              {t('checkout_summary_address_button_change')}
            </Button>
          </div>
          <div className="min-h-[3rem] cmn-flex-items-center bg-gray-100 px-3 rounded">
            <ReceiptSlipIcon className="h-6 w-6 stroke-current" />
            <span className="flex-1 typography-small text-gray-600 leading-2 pt-2 pb-2  pl-2 rtl:pr-2">
              {billingAddress?.formattedAddress}
            </span>
          </div>
        </div>
      )}
      {deliveryGroups && (
        <DeliverySummary
          deliveryGroups={deliveryGroups}
          onChangeDeliveryRequested={() => router.push(namedLinks.delivery)}
        />
      )}

      {pickUpStoreInformation.length > 0 && (
        <div>
          <div className="flex mb-4">
            <div className="flex-1 typography-small-strong">
              {t('cart_checkout_clickAndCollectAddress_label')}
            </div>
            <Button
              onClick={() => router.push(namedLinks.cart)}
              variant={ButtonVariantEnum.textLink}
            >
              {t('checkout_summary_address_button_change')}
            </Button>
          </div>
          {pickUpStoreInformation.map(
            (
              entry: { items: number; pickUpStore?: PickupStoreType },
              index
            ) => (
              <div
                className="min-h-[3rem] cmn-flex-items-center bg-gray-100 px-3 rounded mb-2 last:mb-0"
                key={index}
              >
                <ShoppingBagIcon className="h-6 w-6 stroke-current" />
                <span className="flex-1 typography-small text-gray-600 leading-2 pt-2 pb-2 pl-2 rtl:pr-2">
                  {entry.items > 1
                    ? t(
                        'cart_checkout_clickAndCollectAddress_textMultipleItems',
                        {
                          itemAmount: entry.items,
                        }
                      )
                    : t(
                        'cart_checkout_clickAndCollectAddress_textSingeItem'
                      )}{' '}
                  <span className="font-bold">{entry.pickUpStore?.name}</span>
                  <br />
                  {entry.pickUpStore?.firstName} {entry.pickUpStore?.lastName}
                </span>
              </div>
            )
          )}
        </div>
      )}
      {selectedPaymentMethod && (
        <div>
          <div className="flex mb-4">
            <div className="flex-1 typography-small-strong">
              {t('cart_checkout_payment_label')}
            </div>
            <Button
              onClick={() => router.push(namedLinks.payment)}
              variant={ButtonVariantEnum.textLink}
            >
              {t('checkout_summary_payment_button_change')}
            </Button>
          </div>
          <div className="h-12 cmn-flex-items-center bg-gray-100 px-3 rounded">
            <PaymentMethodIcon
              methodName={selectedPaymentMethod.name}
              disabled={false}
            />

            <span className="flex-1 typography-small text-gray-600 leading-2 pt-2 pb-2 pl-2 rtl:pr-2">
              {selectedPaymentMethod.label}
            </span>
          </div>
        </div>
      )}
      {!isCart && <AddDiscount />}
      <PaymentSummary
        isCart={isCart}
        paymentSummaryDetails={paymentSummarydetails}
      />
      {isOrderReview && (
        <TermsAndConditionToggle
          handleToggle={handleToggle}
          checked={isTermsAndConditionsChecked}
        />
      )}
      {btnOrderSummaryLabel && (
        <Button
          variant={btnVariant}
          onClick={onClickCheckout}
          disabled={
            orderSummaryStatus ||
            cartStatus === AsyncResponseStatusEnum.loading ||
            (isOrderReview && !isTermsAndConditionsChecked)
          }
        >
          {btnOrderSummaryLabel}
        </Button>
      )}
    </div>
  )
}

export default OrderSummary
