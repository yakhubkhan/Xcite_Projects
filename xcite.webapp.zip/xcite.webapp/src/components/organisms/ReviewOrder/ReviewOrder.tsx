import { useRouter } from 'next/router'
import { useTranslation } from 'next-i18next'
import React, { useCallback, useEffect, useState } from 'react'

import {
  AsyncResponseStatusEnum,
  ButtonVariantEnum,
  HeadingEnum,
  PaymentErrorEnum,
  PaymentMethodName,
  ToastDuration,
  ToastType,
} from '../../../types/content'
import OrderSummary from '../OrderSummary'
import { useDispatch, useSelector } from 'react-redux'
import {
  cartBillingAddressSelector,
  cartGroupSelector,
  cartMessagesSelector,
  cartPaymentMethodSelector,
  cartShippingAddressSelector,
  cartStatusSelector,
  cartVersionSelector,
  cartAddressDisplayRequiredSelector,
  checkoutPaymentSelector,
  orderIdSelector,
  paymentCODThunk,
  paymentWithGatweayRedirectThunk,
  paymentCheckoutThunk,
  cartItemsSelector,
  resetCartMessagesAction,
  resetCnCAvailabilityAction,
  scheduledDeliveryInOrderSelector,
  isDeliverySelectionCompletedSelector,
} from '../../../redux/slices/cart'
import { userProfileSelector } from '../../../redux/slices/profile'
import { namedLinksSelector } from '../../../redux/slices/navigation'
import Heading from '../../atoms/Heading'
import CheckoutPageWrapper from '../../molecules/CheckoutPageWrapper'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import Toaster from '../../atoms/Toaster'
import DeliveryGroup from '../DeliverySelection/DeliveryGroup'
import {
  reserveTimeSlotThunk,
  scheduledDeliverySelector,
} from '../../../redux/slices/scheduledDelivery'
import VerifyCartWrapper from '../../molecules/VerifyCartWrapper'

export const getErrorTextKeyFromErrorCode = (errorCode: string): string => {
  switch (errorCode) {
    case PaymentErrorEnum.SoftDecline:
      return 'checkout_summary_payment_soft_decline_message'
    case PaymentErrorEnum.HardDecline:
      return 'checkout_summary_payment_hard_decline_message'
    case PaymentErrorEnum.Risk:
      return 'checkout_summary_payment_risk_decline_message'
    case PaymentErrorEnum.Exception:
      return 'checkout_summary_payment_exception_message'
    default:
      return 'checkout_summary_payment_failed_message'
  }
}

const ReviewOrder = (): JSX.Element => {
  const { t } = useTranslation()
  const router = useRouter()
  const dispatch = useDispatch()
  const cartItems = useSelector(cartItemsSelector)
  const selectedPaymentMethod = useSelector(cartPaymentMethodSelector)
  const shippingAddress = useSelector(cartShippingAddressSelector)
  const billingAddress = useSelector(cartBillingAddressSelector)
  const cartGroups = useSelector(cartGroupSelector)
  const addressDisplayRequired = useSelector(cartAddressDisplayRequiredSelector)
  const cartVersion = useSelector(cartVersionSelector)
  const namedLinks = useSelector(namedLinksSelector)
  const user = useSelector(userProfileSelector)
  const { paymentGatewayUrl } = useSelector(checkoutPaymentSelector)
  const cartMessages = useSelector(cartMessagesSelector)
  const cartStatus = useSelector(cartStatusSelector)
  const orderId = useSelector(orderIdSelector)
  const scheduledDeliveryInOrder = useSelector(scheduledDeliveryInOrderSelector)
  const { reserveSlotStatus, reserveSlotsError } = useSelector(
    scheduledDeliverySelector
  )
  const isDeliverySelectionCompleted = useSelector(
    isDeliverySelectionCompletedSelector
  )

  const [errorMsg, setErrorMsg] = useState('')

  const {
    iso_639_1: language,
    country: { ctStore: store },
    hreflang,
  } = localesFactory.createFromHrefLang(router.locale).current

  const generateRedirectUrl = useCallback(
    (redirectPath: string) => {
      const currentDomain = router.domainLocales?.find(
        (locale) => locale.domain === window.location.hostname
      )
      const localePathSegment =
        currentDomain?.defaultLocale === router.locale
          ? ''
          : `/${router.locale}`
      return `${window.location.origin}${localePathSegment}${redirectPath}`
    },
    [router.domainLocales, router.locale]
  )

  const onClickPayBtn = () => {
    if (scheduledDeliveryInOrder) {
      dispatch(
        reserveTimeSlotThunk({
          language,
          user,
          store,
          locale: hreflang,
        })
      )
    } else {
      onPaymentRequested()
    }
  }

  const paymentWithCOD = useCallback(() => {
    dispatch(
      paymentCODThunk({
        cartVersion,
        deviceType: 'web',
        user,
        store,
        language,
      })
    )
  }, [cartVersion, dispatch, language, store, user])

  const paymentWithGatewayRedirect = useCallback(
    (selectedPaymentMethod) => {
      dispatch(
        paymentWithGatweayRedirectThunk({
          paymentOption: selectedPaymentMethod.name.toLowerCase(),
          user,
          cartVersion,
          deviceType: 'web',
          errorUrl: generateRedirectUrl(namedLinks.review),
          receiptUrl: generateRedirectUrl(namedLinks.confirmation),
          store,
          language,
        })
      )
    },
    [
      cartVersion,
      dispatch,
      generateRedirectUrl,
      language,
      namedLinks.confirmation,
      namedLinks.review,
      store,
      user,
    ]
  )

  const paymentWithCheckoutDotCom = useCallback(() => {
    dispatch(
      paymentCheckoutThunk({
        user,
        store,
        language,
        cartVersion,
        deviceType: 'web',
        failureUrl: generateRedirectUrl(namedLinks.payment),
        successUrl: generateRedirectUrl(namedLinks.confirmation),
        paymentToken: localStorage.getItem('card_token') || '',
      })
    )
  }, [
    cartVersion,
    dispatch,
    generateRedirectUrl,
    language,
    namedLinks.confirmation,
    namedLinks.payment,
    store,
    user,
  ])

  const onPaymentRequested = useCallback(() => {
    switch (selectedPaymentMethod?.name) {
      case PaymentMethodName.CashOnDelivery:
        return paymentWithCOD()
      case PaymentMethodName.Knet:
        case PaymentMethodName.Tamara:
      case PaymentMethodName.Paypal:
        return paymentWithGatewayRedirect(selectedPaymentMethod)
      case PaymentMethodName.CreditCard:
        return paymentWithCheckoutDotCom()
    }
  }, [
    paymentWithCOD,
    paymentWithCheckoutDotCom,
    paymentWithGatewayRedirect,
    selectedPaymentMethod,
  ])

  useEffect(() => {
    const errorCode = router?.query?.errorText as string
    if (errorCode) {
      setErrorMsg(t(getErrorTextKeyFromErrorCode(errorCode)))
      history.pushState(null, '', location.pathname)
    }
  }, [router, t])

  useEffect(() => {
    const onPaymentRequested = async () => {
      if (cartStatus === AsyncResponseStatusEnum.succeeded) {
        if (paymentGatewayUrl) {
          await router.push(paymentGatewayUrl)
        }
        if (orderId)
          router.push({
            pathname: namedLinks.confirmation,
            query: { orderId },
          })
      }
    }
    onPaymentRequested()
  }, [namedLinks, cartStatus, paymentGatewayUrl, orderId, router])

  useEffect(() => {
    cartItems.length === 0
      ? (dispatch(resetCartMessagesAction()),
        dispatch(resetCnCAvailabilityAction()))
      : null
  }, [cartItems, dispatch])

  useEffect(() => {
    if (
      reserveSlotStatus === AsyncResponseStatusEnum.succeeded &&
      scheduledDeliveryInOrder
    ) {
      onPaymentRequested()
    }
  }, [onPaymentRequested, reserveSlotStatus, scheduledDeliveryInOrder])

  return (
    <CheckoutPageWrapper>
      <VerifyCartWrapper>
        {cartStatus === AsyncResponseStatusEnum.failed &&
          user.authenticated && (
            <Toaster
              className="orp-toast"
              duration={ToastDuration}
              toastMsg={t('checkout_summary_payment_failed_message')}
              type={ToastType.error}
            />
          )}
        {reserveSlotStatus === AsyncResponseStatusEnum.failed &&
          reserveSlotsError &&
          user.authenticated && (
            <Toaster
              className="orp-toast"
              duration={ToastDuration}
              toastMsg={t(reserveSlotsError)}
              type={ToastType.error}
            />
          )}
        {errorMsg && (
          <Toaster
            className="orp-toast"
            duration={ToastDuration}
            toastMsg={errorMsg}
            type={ToastType.error}
          />
        )}
        <>
          <div className="grid col-span-full sm:col-span-7 sm:pb-8 md:col-start-2 md:col-span-6">
            <div className="border-b border-gray-300 sm:border-none">
              <Heading
                type={HeadingEnum.h4}
                className="pb-8 sm:bg-white sm:pt-8 sm:pb-4 sm:px-8"
              >
                {t('checkout_review_order_heading')}
              </Heading>
              <div className="flex flex-col gap-8">
                {cartGroups?.map((group) =>
                  group.items.length > 0 ? (
                    <DeliveryGroup
                      key={group.slug}
                      group={group}
                      isReviewPage={true}
                    />
                  ) : null
                )}
              </div>
            </div>
          </div>

          <OrderSummary
            btnOrderSummaryLabel={t('checkout_summary_payment_button_pay')}
            btnVariant={ButtonVariantEnum.primaryCta}
            orderSummaryFrom="revieworder"
            orderSummaryStatus={
              !!cartMessages.length ||
              !selectedPaymentMethod ||
              !isDeliverySelectionCompleted
            }
            onClickCheckout={onClickPayBtn}
            selectedPaymentMethod={selectedPaymentMethod}
            shippingAddress={shippingAddress}
            billingAddress={billingAddress}
            cartGroups={cartGroups}
            addressDisplayRequired={addressDisplayRequired}
          />
        </>
      </VerifyCartWrapper>
    </CheckoutPageWrapper>
  )
}

export default ReviewOrder
