import getConfig from 'next/config'
import { useTranslation } from 'next-i18next'
import React, { useEffect, useState } from 'react'
import { useDispatch } from 'react-redux'

import environment from '../../../lib/environment'
import { resetSelectedWarrantyAction } from '../../../redux/slices/warranty'
import { WarrantyReduxType } from '../../../types/content'
import gtmDatalayer from '../../../util/gtmUtils'
import { RectangleBadge } from '../../atoms/Badge'
import { ThreeDotIcon } from '../../atoms/Icon'
import ProductWarrantyModal from './ProductWarrantyModal'

type Props = {
  sku: string
  warrantyDetails: WarrantyReduxType
}

const ProductWarranty = ({
  warrantyDetails: { selectedWarranty },
  warrantyDetails,
}: Props): JSX.Element => {
  const { t } = useTranslation()

  const dispatch = useDispatch()

  const [isWarrantyNone, setIsWarrantyNone] = useState(true)
  const [isWarrantySelected, setIsWarrantySelected] = useState(false)
  const [warrantyModalOpen, setWarrantyModalOpen] = useState(false)
  const [slideIndex, setSlideIndex] = useState(1)

  const makeWarrantyNone = () => {
    dispatch(resetSelectedWarrantyAction())
    setIsWarrantySelected(false)
    setIsWarrantyNone(true)
  }

  const selectWarranty = () => {
    setWarrantyModalOpen(true)
  }
  const handleModal = () => {
    setWarrantyModalOpen(false)
  }

  useEffect(() => {
    warrantyModalOpen
      ? (document.body.style.overflow = 'hidden')
      : (document.body.style.overflow = 'unset')
  }, [warrantyModalOpen])

  useEffect(() => {
    if (selectedWarranty?.warranty.warrantyType) {
      setIsWarrantyNone(false)
      setIsWarrantySelected(true)
      gtmDatalayer(
        'warranty_opted',
        'product_detail_page_interaction',
        selectedWarranty?.warranty.warrantyType
      )
    }
    if (!selectedWarranty?.warranty.warrantyType) {
      setIsWarrantySelected(false)
      setIsWarrantyNone(true)
      gtmDatalayer(
        'warranty_opted',
        'product_detail_page_interaction',
        'warranty_none'
      )
    }
  }, [selectedWarranty])
  useEffect(() => {
    const selectedWarrantIndex = warrantyDetails.packages.findIndex(
      (pkg) => pkg.typeName === selectedWarranty?.warranty.typeName
    )
    if (selectedWarrantIndex !== -1) {
      setSlideIndex(selectedWarrantIndex)
    }
  }, [selectedWarranty, warrantyDetails])

  return (
    <div>
      <div className="typography-default-strong mb-3">
        {t('pdp_product_warranty_label')}:
      </div>
      <div className="flex gap-3 items-center">
        <RectangleBadge onClick={makeWarrantyNone} selected={isWarrantyNone}>
          <span>{t('pdp_product_warranty_none_label')}</span>
        </RectangleBadge>
        <RectangleBadge onClick={selectWarranty} selected={isWarrantySelected}>
          {selectedWarranty?.warranty.typeName ? (
            <div className="flex items-center flex-row gap-3">
              <span className="w-16 h-5">
                <img
                  src={`${
                    getConfig().publicRuntimeConfig.amplience.dam.baseUrl
                  }/i/${
                    getConfig().publicRuntimeConfig.amplience.dam.hubname
                  }/${selectedWarranty.icon.name}`}
                  alt={`${selectedWarranty.icon.name}`}
                />
              </span>
              <span className="flex flex-row truncate">
                <p className="truncate hover:text-clip">
                  {selectedWarranty?.warranty?.year}
                  {selectedWarranty?.warranty?.year &&
                  ~~selectedWarranty?.warranty?.year <= 1
                    ? warrantyDetails.translationLabels.year
                    : warrantyDetails.translationLabels.years}{' '}
                  {selectedWarranty?.warranty.vendor}{' '}
                  <span className="font-normal">
                    {selectedWarranty?.formattedPrice.formattedPrice}
                  </span>
                </p>
              </span>
              <span>
                <ThreeDotIcon className="w-6 h-6" />
              </span>
            </div>
          ) : (
            <div className="flex flex-row gap-3">
              <span className="text-gray-600 truncate hover:text-clip">
                {t('pdp_product_warranty_select_label')}
              </span>
              <span>
                <ThreeDotIcon className="w-6 h-6" />
              </span>
            </div>
          )}
        </RectangleBadge>
      </div>
      {warrantyModalOpen && (
        <ProductWarrantyModal
          handleModal={handleModal}
          warrantyDetails={warrantyDetails}
          slideIndex={slideIndex}
        />
      )}
    </div>
  )
}

export default ProductWarranty
