import React, { useEffect, useState } from 'react'
import Modal from '../../atoms/Modal'
import { HeadingEnum, Warranty } from '../../../types/content'
import Heading from '../../atoms/Heading'
import ProductWarrantyDetails from './ProductWarrantyDetails'
import ProductWarrantyExclusions from './ProductWarrantyExclusions'
import ProductWarrantyCards from './ProductWarrantyCards'
import { useDispatch, useSelector } from 'react-redux'
import SwiperCore, { Pagination } from 'swiper'
import {
  resetWarrantyAction,
  selectedWarrantyDetailsSelector,
} from '../../../redux/slices/warranty'
import { Swiper, SwiperSlide } from 'swiper/react'
import Grid from '../../atoms/Grid'
import LoadingIndicator from '../../atoms/LoadingIndicator'
import { useTranslation } from 'next-i18next'

const ProductWarrantyModal = ({
  handleModal,
  warrantyDetails,
  slideIndex,
  pliFrom,
  cartWarrantyDetails,
}: {
  handleModal: () => void
  warrantyDetails: Warranty
  slideIndex: number
  pliFrom?: string
  cartWarrantyDetails?: (d) => void
}): JSX.Element => {
  SwiperCore.use([Pagination])
  const dispatch = useDispatch()
  const { t } = useTranslation()
  const selectedWarranty = useSelector(selectedWarrantyDetailsSelector)

  const [isLoading, setIsLoading] = useState(true)

  const pagination = {
    clickable: true,
    el: '.warranty-swiper-pagination',
    renderBullet: function (index, className) {
      return `<button class="${className}">
        ${
          warrantyDetails?.packages?.length > 0
            ? warrantyDetails.packages[index]?.heading
            : ''
        }
        </button>`
    },
    bulletClass:
      'w-full font-bold text-lg leading-tight order-x-0 border-t-0 border-b-2 border-transparent px-4 py-3 rounded-2xl hover:bg-gray-200 focus:border-transparent active:bg-gray-200 ',
  }

  useEffect(() => {
    warrantyDetails.packages.length > 0
      ? setIsLoading(false)
      : setIsLoading(true)
  }, [warrantyDetails])

  useEffect(() => {
    return () => {
      if (pliFrom === 'cart') {
        dispatch(resetWarrantyAction())
      }
    }
  }, [dispatch, pliFrom])

  return (
    <Modal
      className="fixed inset-0 bg-gray-50 h-full w-full"
      extraCloseClasses="bg-gray-50 p-5"
      handleModal={handleModal}
      backButton={
        <div className="relative">
          <Heading type={HeadingEnum.h3} className={`mx-4 hidden sp:block`}>
            {warrantyDetails.heading}
          </Heading>
          <div className="warranty-swiper-pagination flex sp:hidden gap-4"></div>
        </div>
      }
    >
      {isLoading ? (
        <LoadingIndicator>{t('loadingIndicator_label')}</LoadingIndicator>
      ) : (
        <Grid>
          <div className="col-span-full justify-between">
            <Swiper
              initialSlide={slideIndex}
              threshold={5}
              spaceBetween={10}
              breakpoints={{
                '1': {
                  slidesPerView: 'auto',
                  centeredSlides: true,
                },
                '1024': {
                  slidesPerView:
                    warrantyDetails?.packages.length <= 3
                      ? warrantyDetails?.packages.length
                      : 3.5,
                  centeredSlides: false,
                  initialSlide: 0,
                },
              }}
              pagination={pagination}
              modules={[Pagination]}
              className={`h-full pb-6 px-2 ${
                warrantyDetails?.packages.length <= 3
                  ? 'product-warranty-swiper'
                  : ''
              }`}
            >
              {warrantyDetails?.packages?.map((details) => {
                return (
                  <SwiperSlide
                    key={details.typeName}
                    className="w-full rounded-lg shadow-md bg-white p-6 max-w-[380px] sm:max-w-[480px]"
                  >
                    <ProductWarrantyCards
                      key={details.typeName}
                      warrantyPackages={details}
                      closeModal={handleModal}
                      translationLabels={warrantyDetails.translationLabels}
                      selectedWarranty={selectedWarranty}
                      pliFrom={pliFrom}
                      cartWarrantyDetails={cartWarrantyDetails}
                    />
                  </SwiperSlide>
                )
              })}
            </Swiper>
          </div>
          <ProductWarrantyDetails firstSection={warrantyDetails.firstSection} />
          <ProductWarrantyExclusions
            secondSection={warrantyDetails.secondSection}
          />
        </Grid>
      )}
    </Modal>
  )
}

export default ProductWarrantyModal
