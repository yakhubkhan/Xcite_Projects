import { FirstSectionType, HeadingEnum } from '../../../types/content'
import Heading from '../../atoms/Heading'
import { CheckInCircleFilledIcon } from '../../atoms/Icon'

const ProductWarrantyDetails = ({
  firstSection,
}: {
  firstSection: FirstSectionType
}): JSX.Element => {
  const { heading, items } = firstSection

  return (
    <div className="col-span-full px-5 sm:px-0 sm:border-b mt-16">
      <Heading type={HeadingEnum.h4} className={`pb-5`}>
        {heading}
      </Heading>
      <ul className="flex flex-wrap pb-5">
        {items.map((item, index) => {
          return (
            <li className="flex w-full sm:w-1/3 pb-5" key={index}>
              <div className="px-4">
                <CheckInCircleFilledIcon className="w-5 h-5 text-functional-green-600 fill-current" />
              </div>
              <div className="flex-1 typography-small">
                <span className="font-bold">{item.heading}</span>
                <br />
                <span className="">{item.subline}</span>
              </div>
            </li>
          )
        })}
      </ul>
    </div>
  )
}

export default ProductWarrantyDetails
