import React from 'react'
import {
  ButtonVariantEnum,
  HeadingEnum,
  ProductSpecificationAttributesType,
} from '../../../types/content'
import Grid from '../../atoms/Grid'
import Heading from '../../atoms/Heading'
import { useTranslation } from 'next-i18next'
import Table from '../../molecules/Table'
import Button from '../../atoms/Button'

const ProductSpecifications = ({
  description,
  attributes,
  productname,
}: {
  description?: string
  attributes?: ProductSpecificationAttributesType[]
  productname: string
}): JSX.Element => {
  const { t } = useTranslation()
  const [attributesData, setAttributesData] = React.useState(
    attributes?.slice(0, 10)
  )
  const [showAll, setShowAll] = React.useState(false)

  const showAllData = () => {
    setAttributesData(attributes)
    setShowAll(true)
  }

  const showLessData = () => {
    setAttributesData(attributes?.slice(0, 10))
    setShowAll(false)
  }

  React.useEffect(() => {
    showAll
      ? setAttributesData(attributes)
      : setAttributesData(attributes?.slice(0, 10))
  }, [attributes, showAll])

  return (
    <Grid>
      <div className="col-span-6">
        <Heading
          type={HeadingEnum.h2}
          className="typography-decorative-bold mb-10"
        >
          {t('pdp_product_sections_specifications_heading')}
        </Heading>
      </div>
      <div className="col-span-6">
        <Heading type={HeadingEnum.h2} className="mb-4">
          {t('pdp_product_sections_specifications_information')} {productname}
        </Heading>
        <div className="mb-4">
          <p>{description}</p>
        </div>
        <Table tbodyData={attributesData ? attributesData : []} />
        {!showAll && (
          <Button
            variant={ButtonVariantEnum.textLink}
            onClick={showAllData}
            className={`sm:mx-5 my-4`}
          >
            {t('pdp_product_sections_specifications_showall')}
          </Button>
        )}
        {showAll && (
          <Button
            variant={ButtonVariantEnum.textLink}
            onClick={showLessData}
            className={`sm:mx-5 my-4`}
          >
            {t('pdp_product_sections_specifications_showless')}
          </Button>
        )}
      </div>
    </Grid>
  )
}

export default ProductSpecifications
