import React from 'react'
import { HeadingEnum, ProductDescriptionType } from '../../../types/content'
import { ComponentTypeEnum } from '../../../types/content/component'
import Grid from '../../atoms/Grid'
import Heading from '../../atoms/Heading'
import { HtmlComponent } from '../../content'
import ContentBlockImage from '../../molecules/ContentBlockImage/ContentBlockImage'
import ContentBlockVideo from '../../molecules/ContentBlockVideo'
import FlixMedia from './FlixMedia'

const ProductDescription = (props: ProductDescriptionType): JSX.Element => {
 
  return (
    <div>
      <div className="col-span-full">
        {props.heading && (
          <Heading
            type={HeadingEnum.h2}
            className="typography-decorative-bold mb-10"
          >
            {props.heading}
          </Heading>
        )}

        {props.descriptionContent &&
          props.descriptionContent.map((contentItem, index) => {
            switch (contentItem?.type) {
              case ComponentTypeEnum.contentBlockImage:
                return (
                  <ContentBlockImage
                    key={`description-block-${index}`}
                    type={contentItem.type}
                    imageTextBlocks={contentItem.imageTextBlocks}
                  />
                )
              case ComponentTypeEnum.youtubeVideoBlock:
                return (
                  <ContentBlockVideo
                    key={`description-block-${index}`}
                    type={contentItem.type}
                    youtubeLink={contentItem.youtubeLink}
                    title={contentItem.title}
                  />
                )
              case ComponentTypeEnum.htmlComponent:
                return (
                  <HtmlComponent
                    key={`description-html-${index}`}
                    type={contentItem.type}
                    html={contentItem.html}
                  />
                )
            }
          })}
      </div>
      <Grid>
      <FlixMedia eanNumber={props?.eanNumber} brand={props?.brand} modelNumber={props?.modelNumber}/>
      </Grid>
      {/* Personyze Similar Products Widget Template Start */}
      <Grid>
        <div className="col-span-full">
          <div id="similarProducts" />
        </div>
      </Grid>
      {/* Personyze Similar Products Widget Template End */}
    </div>
  )
}

export default ProductDescription
