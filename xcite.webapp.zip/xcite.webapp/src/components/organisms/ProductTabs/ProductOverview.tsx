import Grid from '../../atoms/Grid'

const ProductOverviewInfo = (): JSX.Element => {
  return (
    <>
      {/* Personyze Widget Template Start */}
      <Grid>
        <div className="col-span-full">
          <div id="frequentlyBroughtTogether" />
        </div>
      </Grid>
      {/* Personyze Widget Template End */}
    </>
  )
}
export default ProductOverviewInfo
