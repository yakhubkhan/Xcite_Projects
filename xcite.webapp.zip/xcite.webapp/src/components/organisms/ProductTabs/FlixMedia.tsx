import React from 'react'
import { FlixMediaType } from '../../../types/content'
import Script from 'next/script'
import { useRouter } from 'next/router'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import getConfig from 'next/config'
import { useTranslation } from 'next-i18next'
import { useCallback, useEffect } from 'react'

const FlixMedia = (props: FlixMediaType): JSX.Element => {
  const { locale } = useRouter()
  const { t } = useTranslation()
  const {
    country: { id: countryId },
    hreflang,
  } = localesFactory.createFromHrefLang(locale).current

  // Langugae code
  const languageLGArray: { key: string; value: string }[] = [
    { key: 'en-KW', value: 'd2' },
    { key: 'ar-KW', value: 'ae' },
    { key: 'en-SA', value: 'd2' },
    { key: 'ar-SA', value: 'ae' },
  ]

  const languageAllArray: { key: string; value: string }[] = [
    { key: 'en-KW', value: 'k1' },
    { key: 'ar-KW', value: 'ae' },
    { key: 'en-SA', value: 'u1' },
    { key: 'ar-SA', value: 'ar' },
  ]

  const languageID = (brand) => {
    if (brand == 'LG') {
      const languageID = languageLGArray.find(
        (language) => language.key === hreflang
      )
      return languageID?.value
    } else {
      const languageID = languageAllArray.find(
        (language) => language.key === hreflang
      )
      return languageID?.value
    }
  }

  // Fallback language Code
  const falllbackLanguageLGArray: { key: string; value: string }[] = [
    { key: 'en-KW', value: 'u1' },
    { key: 'ar-KW', value: 'ar' },
    { key: 'en-SA', value: 'u1' },
    { key: 'ar-SA', value: 'ar' },
  ]

  const falllbackLanguageASUSArray: { key: string; value: string }[] = [
    { key: 'en-KW', value: 'd2' },
    { key: 'ar-KW', value: 'ar' },
    { key: 'en-SA', value: 'd2' },
    { key: 'ar-SA', value: 'ae' },
  ]

  const falllbackLanguageAllArray: { key: string; value: string }[] = [
    { key: 'en-KW', value: 'en' },
    { key: 'ar-KW', value: 'ar' },
    { key: 'en-SA', value: 'en' },
    { key: 'ar-SA', value: 'ae' },
  ]

  const fallbackLanguageID = (brand) => {
    if (brand == 'LG') {
      const languageID = falllbackLanguageLGArray.find(
        (language) => language.key === hreflang
      )
      return languageID?.value
    } else if (brand == 'ASUS') {
      const languageID = falllbackLanguageASUSArray.find(
        (language) => language.key === hreflang
      )
      return languageID?.value
    } else {
      const languageID = falllbackLanguageAllArray.find(
        (language) => language.key === hreflang
      )
      return languageID?.value
    }
  }
  let distributerId: any = ''
  if (hreflang == 'en-KW' || hreflang == 'ar-KW') {
    distributerId = getConfig().publicRuntimeConfig.flixmedia.kwDistributerId
  } else if (hreflang == 'en-SA' || hreflang == 'ar-SA') {
    distributerId = getConfig().publicRuntimeConfig.flixmedia.saDistributerId
  }

  const showFlixMediaContent = () => {
    return Function(`var product_mpn = "${props?.modelNumber}"
    var product_ean = "${props?.eanNumber}"
    var product_brand = "${props?.brand}"
    var distributor = "${distributerId}"
    var language = "${languageID(props?.brand)}"
    var fallbackLanguage = "${fallbackLanguageID(props?.brand)}"
    var headID = document.getElementsByTagName("head")[0];
    jQuery("#flix-inpage").hide();
    var flixScript = document.createElement('script');
    flixScript.type = 'text/javascript';
    flixScript.defer = true;
    flixScript.setAttribute('data-flix-distributor', distributor);
    flixScript.setAttribute('data-flix-language', language);
    flixScript.setAttribute('data-flix-fallback-language', fallbackLanguage);
    flixScript.setAttribute('data-flix-brand', product_brand);
    flixScript.setAttribute('data-flix-ean', product_ean);
    flixScript.setAttribute('data-flix-mpn', product_mpn);
    flixScript.setAttribute('data-flix-inpage', 'flix-inpage');
    headID.appendChild(flixScript);
    flixScript.onload=function(){
    if (typeof(flixJsCallbacks)==="object"){
    flixJsCallbacks.setLoadCallback(function(){
    try {
    console.log("flixmedia content loaded start");
    
    jQuery("#flix-inpage").hide();
    jQuery(".flix-minisite-show").show();
    }catch(e){ }
    }, 'inpage');
    }
    };
    flixScript.src = '//media.flixfacts.com/js/loader.js'`)()
  }

  const manageReadMore = () => {
    return Function(`jQuery(document).ready(function(){
      jQuery("#flix-inpage").hide();
      jQuery(".flix-minisite-show").hide();
      jQuery(".flix-minisite-hide").hide();
      
    });
    jQuery(".flix-minisite-show").click(function(){
      jQuery("#flix-inpage").show();
      jQuery(".flix-minisite-show").hide();
      jQuery(".flix-minisite-hide").show();
    });	
    jQuery(".flix-minisite-hide").click(function(){
      jQuery("#flix-inpage").hide();
      jQuery(".flix-minisite-show").show();
      jQuery(".flix-minisite-hide").hide();
    });	`)()
  }
  useEffect(() => {
    manageReadMore()
    showFlixMediaContent()
  })
  return (
    <>
      <div className="col-span-full">
        <div id="flix-minisite" className="flix-minisite-show">
          <div className="w-full text-center">
            <button className="button primaryOnLight flex-1 mt-6">
              <span className="flex flex-row gap-3 justify-between items-center">
                {t('read_more')}
              </span>
            </button>
          </div>
          <p className="text-xs">{t('flix_content_disclaimer')}</p>
        </div>
        <div id="flix-minisite" className="flix-minisite-hide">
          <div className="w-full text-center">
            <button className="button primaryOnLight flex-1 mt-6">
              <span className="flex flex-row gap-3 justify-between items-center">
                {t('read_less')}
              </span>
            </button>
          </div>
          <p className="text-xs">{t('flix_content_disclaimer')}</p>
        </div>
        <div id="flix-inpage"></div>
      </div>
    </>
  )
}

export default FlixMedia
