import { useTranslation } from 'next-i18next'
import React, { useEffect, useState } from 'react'

import { HeadingEnum, ProductDetailsSectionsType } from '../../../types/content'
import gtmDatalayer from '../../../util/gtmUtils'
import Tabs from '../../molecules/Tabs'
import { TabType } from '../../molecules/Tabs/Tabs'
import ProductDescription from './ProductDescription'
import ProductSpecifications from './ProductSpecifications'
import Heading from '../../atoms/Heading'
import Grid from '../../atoms/Grid'
import ProductOverviewInfo from './ProductOverview'

const ProductTabs = ({
  sections,
  productname,
  brand,
  modelNumber,
  eanNumber,
}: {
  sections: ProductDetailsSectionsType
  productname: string
  brand?:string
  modelNumber?:string
  eanNumber?:string
}): JSX.Element => {
  const [productTabs, setProductTabs] = useState<TabType[]>([])
  const { t } = useTranslation()
  const getTabsContent = (sections: ProductDetailsSectionsType) => {
    const tabsContent: TabType[] = []
    const { description, specifications, descriptionHTMLComp } = sections
   
    {
      /* For Personyze Widget Template */
    }
    tabsContent.push({
      component: <ProductOverviewInfo />,
      id: 'product-overview',
      title: t('pdp_product_sections_overview_sectionTitle'),
    })

    if (specifications) {
      tabsContent.push({
        component: (
          <ProductSpecifications
            productname={productname}
            {...specifications}
          />
        ),
        id: specifications.id,
        title: t('pdp_product_sections_specifications_sectionTitle'),
      })
    }
    if (description?.descriptionContent) {
      tabsContent.push({
        component: (
          <Grid>
            <div className="col-span-full">
              <ProductDescription eanNumber={eanNumber} brand={brand} modelNumber={modelNumber} {...description} />
            </div>
          </Grid>
        ),
        id: description.id,
        title: t('pdp_product_sections_description_sectionTitle'),
      })
    } else if (descriptionHTMLComp?.descriptionContent) {
      tabsContent.push({
        component: (
          <Grid>
            <div className="col-span-full">
              <ProductDescription eanNumber={eanNumber} brand={brand} modelNumber={modelNumber} {...descriptionHTMLComp} />
            </div>
          </Grid>
        ),
        id: descriptionHTMLComp.id,
        title: t('pdp_product_sections_description_sectionTitle'),
      })
    }
    tabsContent.push({
      component: (
        <Grid>
          <div className="col-span-full">
            <Heading
              type={HeadingEnum.h2}
              className="typography-decorative-bold mb-10"
            >
              {t('pdp_product_sections_reviews_sectionTitle')}
            </Heading>
            <div id="testfreaks-reviews"></div>
          </div>
        </Grid>
      ),
      id: 'product-review',
      title: t('pdp_product_sections_reviews_sectionTitle'),
    })
    tabsContent.push({
      component: (
        <Grid>
          <div className="col-span-full">
            <Heading
              type={HeadingEnum.h2}
              className="typography-decorative-bold mb-10"
            >
              {t('pdp_product_sections_qa_sectionTitle')}
            </Heading>
            <div id="testfreaks-qa"></div>
          </div>
        </Grid>
      ),
      id: 'product-qa',
      title: t('pdp_product_sections_qa_sectionTitle'),
    })

    return tabsContent
  }

  useEffect(() => {
    setProductTabs(getTabsContent(sections))
  }, [sections])

  return (
    <Tabs
      tabs={productTabs}
      wrapperClasses="px-5 sm:px-10 lg:px-20 xl:container"
    />
  )
}

export default ProductTabs
