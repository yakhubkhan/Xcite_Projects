import React from 'react'
import { HeadingEnum, ServicesType } from '../../../types/content'
import Grid from '../../atoms/Grid'
import Heading from '../../atoms/Heading'
import { useTranslation } from 'next-i18next'

const ProductServices = (props: ServicesType): JSX.Element => {
  const { t } = useTranslation()
  return (
    <Grid>
      <div className="col-span-full">
        <Heading
          type={HeadingEnum.h2}
          className="typography-decorative-bold mb-10"
        >
          {t('pdp_product_sections_services_heading')}
        </Heading>
        <div>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean
            accumsan ipsum vitae dolor luctus, ut pellentesque diam vehicula.
            Nam tincidunt, libero a bibendum iaculis, felis quam sagittis quam,
            a gravida eros nulla eu leo. Suspendisse efficitur, mauris at
            efficitur fringilla, odio risus cursus nibh, lobortis molestie orci
            risus in eros. Nullam gravida nunc ut mollis cursus. Cras feugiat
            elit vel dui vulputate tempor. In cursus sit amet quam a congue.
            Curabitur hendrerit aliquet odio quis molestie. Suspendisse ac velit
            blandit, rhoncus nunc vel, viverra tellus. Pellentesque ante sem,
            luctus in porta mattis, facilisis ut est. In porta nisi massa, et
            pharetra enim mollis sed. Duis elementum eleifend justo, id
            convallis tellus dictum in. Nullam in auctor tellus. In sollicitudin
            sem non erat blandit aliquet. Suspendisse potenti. Sed varius rutrum
            est vel sollicitudin.
          </p>

          <p>
            Nulla sit amet risus justo. Praesent ac est at tortor suscipit
            consectetur sit amet sed nunc. Morbi luctus risus et massa sodales
            accumsan. Aliquam metus turpis, molestie vitae facilisis quis,
            venenatis auctor tortor. Vivamus nunc mi, lobortis vitae arcu vel,
            iaculis scelerisque magna. Pellentesque blandit ex et augue cursus,
            ac mollis odio convallis. In blandit, urna id venenatis semper, leo
            metus facilisis ante, eget interdum nibh neque quis odio. Nulla at
            dolor tortor. Sed convallis odio et erat interdum, ac auctor ante
            molestie. Vivamus consectetur mi non porttitor laoreet. Vestibulum
            non egestas neque. Curabitur congue odio nulla, a cursus massa
            aliquam et. Aliquam ac scelerisque neque. Curabitur facilisis, magna
            non aliquet dignissim, arcu ex convallis elit, lobortis dignissim
            metus tellus vitae elit.
          </p>

          <p>
            Vestibulum eleifend risus tellus, et mattis lacus porttitor et.
            Nulla sed dui a sapien fermentum venenatis scelerisque sit amet
            eros. Nam sodales tristique ligula non viverra. Ut pharetra vehicula
            dolor, et sodales lectus auctor in. Vestibulum mattis magna orci.
            Phasellus aliquam venenatis tincidunt. Proin odio leo, rutrum sit
            amet felis eu, accumsan ornare mi. Cras sollicitudin orci et ligula
            gravida maximus. Etiam faucibus mattis dui, facilisis venenatis odio
            molestie sit amet.
          </p>
        </div>
      </div>
    </Grid>
  )
}

export default ProductServices
