import React from 'react'
import { Meta, Story } from '@storybook/react'
import ProductDetails from './ProductDetails'
import { ProductDetailsComponentType } from '../../../types/content'

export default {
  title: 'Components/organisms/ProductDetails',
  component: ProductDetails,
} as Meta

const Template: Story<ProductDetailsComponentType> = (args) => (
  <ProductDetails {...args} />
)

export const Default = Template.bind({})

Default.args = {
  product: {
    productType: 'key',
    name: 'Sony TV 75 4K Android LED KD-75X8000H',
    magentoProductId: '151554',
    productId: 'c2714d52-229f-4901-9159-c61641e25f03',
    sku: '640122',
    brand: 'SONY',
    price: {
      value: 449.9,
      valueUnmodified: 0,
      formattedPrice: '',
      formattedPriceUnmodified: '',
      formattedCredit: '',
      currency: 'KD',
    },
    sections: {
      description: {
        id: 'description',
      },
      quickOverview: {
        content: {
          details: {
            id: 'productDetails',
            content:
              '* Processor: Intel Core i7 11th Generation\n* RAM: 16GB\n* Storage: 1TB SSD\n* Graphics: Nvidia Geforce RTX 3050 4GB\n* Refresh Rate: 144Hz\n* Display: 15.6" Full HD\n* Operating System: Windows 10 Home\n',
          },
          shipping: {
            id: 'overview-shipping',
            deliveryMethods: [
              {
                name: 'FreeDelivery',
                countryCode: 'kw',
                surcharge: null,
              },
              {
                name: '1-Hour-Express',
                countryCode: 'kw',
                surcharge: null,
              },
              {
                name: '3-Hours-Express',
                countryCode: 'kw',
                surcharge: null,
              },
              {
                name: 'ClickAndCollect',
                countryCode: 'kw',
                surcharge: null,
              },
            ],
          },
        },
        id: 'overview',
      },
      specifications: {
        id: 'specifications',
        attributes: [
          { label: 'Model Number', value: 'SM-G781BZBGMEA' },
          { label: 'Article Number', value: '530802' },
          { label: 'Brand', value: 'SAMSUNG' },
          { label: 'Colour', value: 'Blue' },
          { label: 'Device Type', value: 'S20 FE' },
          { label: 'Processor', value: 'Snapdragon 865' },
          { label: 'Operating System', value: 'Android 10' },
          {
            label: 'Sensors',
            value:
              'Accelerometer, Barometer, Fingerprint, Geomagnetic, Gyro, Hall, Proximity, RGB light',
          },
          { label: 'Phone Memory (RAM)', value: '8 GB' },
          { label: 'Storage Capacity', value: '128GB' },
          { label: 'Expandable Memory', value: 'Yes' },
          { label: 'Phone Display Size', value: '6.5-inch' },
          { label: 'Rear Camera', value: 'Yes' },
          { label: 'Phone Rear Camera', value: '12 MP + 12 MP + 8MP' },
          { label: 'Front Camera', value: 'Yes' },
          { label: 'Front Camera Resolution', value: '32 Megapixels' },
          { label: 'Flash', value: 'Yes' },
          { label: 'Battery Size', value: '4500 mAh' },
          { label: 'Cellular Connectivity', value: '5G' },
          { label: 'Wi-Fi', value: 'Yes' },
          { label: 'Number of SIM Cards', value: '-' },
          { label: 'Total Number of Slots', value: '-' },
          { label: 'Slot Details', value: '-' },
          { label: 'GPS', value: 'Yes' },
          {
            label: 'In the Box',
            value: 'The device does not comes with the earphones',
          },
        ],
      },
    },
    media: [
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
    ],
    selfCanonical: '',
    customCanonicalUrl: '',
    metaRobots: '',
    productPromotions: [],
  },
}

export const DetailsWithThreeMedia = Template.bind({})
DetailsWithThreeMedia.args = {
  product: {
    productType: 'key',
    name: 'Sony TV 75 4K Android LED KD-75X8000H',
    magentoProductId: '151554',
    productId: 'c2714d52-229f-4901-9159-c61641e25f03',
    sku: 'Manufacturer, SONY, SKU: 529576',
    brand: 'SONY',
    price: {
      value: 449.9,
      valueUnmodified: 0,
      formattedPrice: '',
      formattedPriceUnmodified: '',
      formattedCredit: '',
      currency: 'KD',
    },
    sections: {
      description: {
        id: 'description',
      },
      quickOverview: {
        content: {
          details: {
            id: 'productDetails',
            content:
              '* Processor: Intel Core i7 11th Generation\n* RAM: 16GB\n* Storage: 1TB SSD\n* Graphics: Nvidia Geforce RTX 3050 4GB\n* Refresh Rate: 144Hz\n* Display: 15.6" Full HD\n* Operating System: Windows 10 Home\n',
          },
          shipping: {
            id: 'overview-shipping',
            deliveryMethods: [
              {
                name: 'FreeDelivery',
                countryCode: 'kw',
                surcharge: null,
              },
              {
                name: '1-Hour-Express',
                countryCode: 'kw',
                surcharge: null,
              },
              {
                name: '3-Hours-Express',
                countryCode: 'kw',
                surcharge: null,
              },
              {
                name: 'ClickAndCollect',
                countryCode: 'kw',
                surcharge: null,
              },
            ],
          },
        },
        id: 'overview',
      },
    },
    media: [
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
    ],
    selfCanonical: '',
    customCanonicalUrl: '',
    metaRobots: '',
    productPromotions: [],
  },
}

export const DetailsWithFourMedia = Template.bind({})
DetailsWithFourMedia.args = {
  product: {
    productType: 'key',
    name: 'Sony TV 75 4K Android LED KD-75X8000H',
    magentoProductId: '151554',
    productId: 'c2714d52-229f-4901-9159-c61641e25f03',
    sku: 'Manufacturer, SONY, SKU: 529576',
    brand: 'SONY',
    price: {
      value: 449.9,
      valueUnmodified: 0,
      formattedPrice: '',
      formattedPriceUnmodified: '',
      formattedCredit: '',
      currency: 'KD',
    },
    sections: {
      description: {
        id: 'description',
      },
      quickOverview: {
        content: {
          details: {
            id: 'productDetails',
            content:
              '* Processor: Intel Core i7 11th Generation\n* RAM: 16GB\n* Storage: 1TB SSD\n* Graphics: Nvidia Geforce RTX 3050 4GB\n* Refresh Rate: 144Hz\n* Display: 15.6" Full HD\n* Operating System: Windows 10 Home\n',
          },
          shipping: {
            id: 'overview-shipping',
            deliveryMethods: [
              {
                name: 'FreeDelivery',
                countryCode: 'kw',
                surcharge: null,
              },
              {
                name: '1-Hour-Express',
                countryCode: 'kw',
                surcharge: null,
              },
              {
                name: '3-Hours-Express',
                countryCode: 'kw',
                surcharge: null,
              },
              {
                name: 'ClickAndCollect',
                countryCode: 'kw',
                surcharge: null,
              },
            ],
          },
        },
        id: 'overview',
      },
    },
    media: [
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
    ],
    selfCanonical: '',
    customCanonicalUrl: '',
    metaRobots: '',
    productPromotions: [],
  },
}

export const DetailsWithFiveMedia = Template.bind({})
DetailsWithFiveMedia.args = {
  product: {
    productType: 'key',
    name: 'Sony TV 75 4K Android LED KD-75X8000H',
    magentoProductId: '151554',
    productId: 'c2714d52-229f-4901-9159-c61641e25f03',
    sku: 'Manufacturer, SONY, SKU: 529576',
    brand: 'SONY',
    price: {
      value: 449.9,
      valueUnmodified: 0,
      formattedPrice: '',
      formattedPriceUnmodified: '',
      formattedCredit: '',
      currency: 'KD',
    },
    sections: {
      description: {
        id: 'description',
      },
      quickOverview: {
        content: {
          details: {
            id: 'productDetails',
            content:
              '* Processor: Intel Core i7 11th Generation\n* RAM: 16GB\n* Storage: 1TB SSD\n* Graphics: Nvidia Geforce RTX 3050 4GB\n* Refresh Rate: 144Hz\n* Display: 15.6" Full HD\n* Operating System: Windows 10 Home\n',
          },
          shipping: {
            id: 'overview-shipping',
            deliveryMethods: [
              {
                name: 'FreeDelivery',
                countryCode: 'kw',
                surcharge: null,
              },
              {
                name: '1-Hour-Express',
                countryCode: 'kw',
                surcharge: null,
              },
              {
                name: '3-Hours-Express',
                countryCode: 'kw',
                surcharge: null,
              },
              {
                name: 'ClickAndCollect',
                countryCode: 'kw',
                surcharge: null,
              },
            ],
          },
        },
        id: 'overview',
      },
    },
    media: [
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
    ],
    selfCanonical: '',
    customCanonicalUrl: '',
    metaRobots: '',
    productPromotions: [],
  },
}

export const DetailsWithTenMedia = Template.bind({})
DetailsWithTenMedia.args = {
  product: {
    productType: 'key',
    name: 'Sony TV 75 4K Android LED KD-75X8000H',
    magentoProductId: '151554',
    productId: 'c2714d52-229f-4901-9159-c61641e25f03',
    sku: 'Manufacturer, SONY, SKU: 529576',
    brand: 'SONY',
    price: {
      value: 449.9,
      valueUnmodified: 0,
      formattedPrice: '',
      formattedPriceUnmodified: '',
      formattedCredit: '',
      currency: 'KD',
    },
    sections: {
      description: {
        id: 'description',
      },
      quickOverview: {
        content: {
          details: {
            id: 'productDetails',
            content:
              '* Processor: Intel Core i7 11th Generation\n* RAM: 16GB\n* Storage: 1TB SSD\n* Graphics: Nvidia Geforce RTX 3050 4GB\n* Refresh Rate: 144Hz\n* Display: 15.6" Full HD\n* Operating System: Windows 10 Home\n',
          },
          shipping: {
            id: 'overview-shipping',
            deliveryMethods: [
              {
                name: 'FreeDelivery',
                countryCode: 'kw',
                surcharge: null,
              },
              {
                name: '1-Hour-Express',
                countryCode: 'kw',
                surcharge: null,
              },
              {
                name: '3-Hours-Express',
                countryCode: 'kw',
                surcharge: null,
              },
              {
                name: 'ClickAndCollect',
                countryCode: 'kw',
                surcharge: null,
              },
            ],
          },
        },
        id: 'overview',
      },
    },
    media: [
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
      {
        type: 'img',
        alt: 'Product Image',
        src: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRazXh4RxB7z7CGYeh_cWejDefJP4in449NcjFL0eWeVEguGYr86A&usqp=CAc',
      },
    ],
    selfCanonical: '',
    customCanonicalUrl: '',
    metaRobots: '',
    productPromotions: [],
  },
}
