import { useRouter } from 'next/router'
import React from 'react'
import { ProductDetailsType } from '../../../types/content'
import { getRouterDomainInfo } from '../../../util/routerUtils'
import { createUrl, rewritePath } from '../../../util/seoUtils'

type Props = {
  product: ProductDetailsType
}

const ProductDetailsStructuredData = ({ product }: Props): JSX.Element => {
  const router = useRouter()
  const { asPath } = router
  const path = rewritePath(asPath)

  const { domain, currentLocale } = getRouterDomainInfo(router)

  const url = createUrl(currentLocale, '/', domain)

  return (
    <span itemScope itemType="https://schema.org/Product">
      <meta itemProp="name" content={product.name} />
      <meta
        itemProp="description"
        content={product.sections.quickOverview?.content.details?.content}
      />
      <meta itemProp="sku" content={product.sku} />
      <span itemProp="brand" itemType="https://schema.org/Brand" itemScope>
        <meta itemProp="name" content={product.brand} />
      </span>
      <meta
        itemProp="image"
        content={`[${product.media.map((e) => `\"${e.src}\"`)}]`}
      />
      <span itemProp="offers" itemScope itemType="https://schema.org/Offer">
        <meta itemProp="price" content={product.price?.value.toString()} />
        <meta itemProp="priceCurrency" content={product.price?.currency} />
        <meta itemProp="url" content={`${url}${path}`} />
        <meta
          itemProp="itemCondition"
          content="https://schema.org/NewCondition"
        />
        <meta itemProp="availability" content="https://schema.org/InStock" />
        <span
          itemProp="seller"
          itemScope
          itemType="https://schema.org/Organization"
        >
          <meta itemProp="name" content="Xcite" />
        </span>
      </span>
    </span>
  )
}

export default ProductDetailsStructuredData
