export { default } from './ProductDetails'
