import { useRouter } from 'next/router'
import { useTranslation } from 'next-i18next'
import React, { useCallback, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'

import {
  AsyncResponseStatusEnum,
  ButtonVariantEnum,
  HeadingEnum,
  PickupStoresType,
} from '../../../types/content'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import useUserLocation from '../../../hooks/useUserLocation'
import Button from '../../atoms/Button'
import Modal from '../../atoms/Modal'
import { ShoppingBagIcon } from '../../atoms/Icon'
import Heading from '../../atoms/Heading'
import SelectionBox from '../../atoms/SelectionBox'
import { userProfileSelector } from '../../../redux/slices/profile'
import styles from './Storelist.module.css'
import Field from '../../atoms/Field'
import {
  updateStorePickupDetails,
  addToCartStatusSelector,
  updateStoreDetailsStatusSelector,
  resetAddToCartStatusAction,
  resetUpdateStoreDetailsStatusAction,
} from '../../../redux/slices/cart'
import { CommercetoolsClickAndCollectOption } from '../../../types/api'
import BackButton from '../../molecules/BackButton'
import BFFClient from '../../../lib/api/clients/BFF/bffClient'
import { selectedWarrantyDetailsSelector } from '../../../redux/slices/warranty'
import AddToCart from '../AddToCart'
import { civilIdValidationRegex } from '../../../util/formValidation'

export default function Storelist({
  sku,
  onCloseModal,
  skuLineItemId,
  onConfirmModalClose,
}: {
  sku: string
  onCloseModal: () => void
  skuLineItemId: string
  onConfirmModalClose: () => void
}): JSX.Element {
  const { locale } = useRouter()

  const { t } = useTranslation()
  const dispatch = useDispatch()
  const user = useSelector(userProfileSelector)
  const selectedWarrantyDetails = useSelector(selectedWarrantyDetailsSelector)
  const addToCartStatus = useSelector(addToCartStatusSelector)
  const updateStoreDetailsStatus = useSelector(updateStoreDetailsStatusSelector)
  const {
    iso_639_1: language,
    country: { ctStore: store, id: countryId },
    hreflang,
  } = localesFactory.createFromHrefLang(locale).current
  const userLocation = useUserLocation()
  const initialState: CommercetoolsClickAndCollectOption = {
    sapSite: '',
    firstName: '',
    lastName: '',
    civilID: '',
  }

  const [availableToPickup, setAvailableToPickup] = React.useState(false)
  const [availableStores, setAvailableStores] =
    React.useState<PickupStoresType>([])
  const [pickupForm, setPickupForm] = React.useState(false)
  const [pickupDetails, setPickupDetails] = React.useState(initialState)
  const [formErrors, setFormErrors] = React.useState(
    {} as CommercetoolsClickAndCollectOption
  )
  const [isLoading, setIsLoading] = React.useState(true)

  const loadStoresForItem = useCallback(async () => {
    try {
      const stores = await BFFClient.inventory.loadStoresToPickup(
        sku,
        language,
        store,
        hreflang,
        userLocation
      )
      setIsLoading(false)
      if (stores?.length > 0) {
        setAvailableToPickup(true)
        setAvailableStores(stores)
      }
    } catch (error) {
      console.error(error)
    }
  }, [hreflang, language, sku, store, userLocation])

  useEffect(() => {
    loadStoresForItem()
  }, [loadStoresForItem])

  const pickupDataform = (event: React.ChangeEvent<HTMLInputElement>) => {
    setPickupDetails((prevState) => ({
      ...prevState,
      [event.target.name]: event.target.value,
    }))
  }

  const SubmitStoreDetails = () => setPickupForm(true)

  const backToStoreSelect = () => {
    setPickupForm(false)
    setPickupDetails((prevState) => ({
      ...initialState,
      sapSite: prevState.sapSite,
    }))
    setFormErrors(initialState)
  }

  const validate = (details: CommercetoolsClickAndCollectOption) => {
    const errors = {} as CommercetoolsClickAndCollectOption
    const namePattern = new RegExp('^[a-zA-Z\\s]+$')
    const civilIdPattern = civilIdValidationRegex[countryId]
    if (!details.firstName) {
      errors.firstName = t('cart_store_modal_validation_firstname_required')
    } else if (!namePattern.test(details.firstName)) {
      errors.firstName = t('cart_store_modal_validation_name_pattern')
    }
    if (!details.lastName) {
      errors.lastName = t('cart_store_modal_validation_lastname_required')
    } else if (!namePattern.test(details.lastName)) {
      errors.lastName = t('cart_store_modal_validation_name_pattern')
    }
    if (!details.civilID) {
      errors.civilID = t('cart_store_modal_validation_civilid_required')
    } else if (!details.civilID.match(civilIdPattern)) {
      errors.civilID = t('cart_store_modal_validation_civilid_pattern')
    }

    setFormErrors(errors)
    return errors
  }

  useEffect(() => {
    if (
      updateStoreDetailsStatus === AsyncResponseStatusEnum.succeeded ||
      updateStoreDetailsStatus === AsyncResponseStatusEnum.failed ||
      addToCartStatus === AsyncResponseStatusEnum.succeeded ||
      addToCartStatus === AsyncResponseStatusEnum.failed
    ) {
      onConfirmModalClose()
      dispatch(resetUpdateStoreDetailsStatusAction())
      dispatch(resetAddToCartStatusAction())
    }
  }, [updateStoreDetailsStatus, addToCartStatus, onConfirmModalClose])

  return (
    <Modal
      className={`bg-white rounded-t-lg justify-center items-center fixed left-0 w-full bottom-0 px-5 py-7 sm:top-2/4 sm:left-2/4 sm:max-w-[633px] sm:h-[fit-content] sm:rounded-xl sm:-translate-x-1/2 sm:-translate-y-1/2 sm:px-8 sm:pb-7 sm:pt-8 ${styles.modal}`}
      extraCloseClasses={`pb-4`}
      handleModal={onCloseModal}
      showClose={true}
      backButton={
        pickupForm ? (
          <BackButton onClick={backToStoreSelect} className="" />
        ) : null
      }
    >
      {isLoading ? (
        <Heading type={HeadingEnum.h4}>Loading...</Heading>
      ) : (
        <>
          {availableToPickup ? (
            <div className="sm:px-12">
              {!pickupForm && (
                <>
                  <Heading type={HeadingEnum.h4} className="mb-4">
                    {t('cart_store_modal_heading')}
                  </Heading>
                  <ul className="overflow-y-auto sm:max-h-64 flex flex-col gap-3 mb-8">
                    {availableStores.map((store) => (
                      <li key={store.name}>
                        <SelectionBox
                          value={store.id}
                          onValChange={pickupDataform}
                          checked={store.id === pickupDetails.sapSite}
                          inputName="sapSite"
                          inputId={`${store.id}`}
                          extraClassName="items-start"
                        >
                          <ShoppingBagIcon
                            className={`h-6 w-6 stroke-current `}
                          />
                          <div className="flex-1">
                            <div className="typography-small-strong">
                              {store.name}
                            </div>
                            <div className="typography-small">
                              {store.openingHours}
                            </div>
                            <div className="typography-small">
                              {store.address}
                            </div>
                          </div>
                        </SelectionBox>
                      </li>
                    ))}
                  </ul>
                  <Button
                    variant={ButtonVariantEnum.primaryOnLight}
                    className={`w-full`}
                    disabled={!pickupDetails.sapSite}
                    onClick={SubmitStoreDetails}
                  >
                    {t('cart_store_modal_confirmStore')}
                  </Button>
                </>
              )}
              {pickupForm && (
                <div className="flex flex-col gap-9">
                  <Heading type={HeadingEnum.h4}>
                    {t('cart_store_modal_pickup_heading')}
                  </Heading>
                  <Field
                    labelText={t(
                      'checkout_clickandcollect_storelist_form_firstname_label'
                    )}
                    placeholder={t(
                      'checkout_clickandcollect_storelist_form_firstname_label'
                    )}
                    id="firstName"
                    onChange={pickupDataform}
                    value={pickupDetails.firstName}
                    errorMessage={formErrors.firstName}
                  />
                  <Field
                    labelText={t(
                      'checkout_clickandcollect_storelist_form_lastname_label'
                    )}
                    placeholder={t(
                      'checkout_clickandcollect_storelist_form_lastname_label'
                    )}
                    id="lastName"
                    onChange={pickupDataform}
                    value={pickupDetails.lastName}
                    errorMessage={formErrors.lastName}
                  />
                  <Field
                    labelText={t(
                      'checkout_clickandcollect_storelist_form_civilid_label'
                    )}
                    placeholder={t(
                      'checkout_clickandcollect_storelist_form_civilid_label'
                    )}
                    id="civilID"
                    onChange={pickupDataform}
                    value={pickupDetails.civilID}
                    errorMessage={formErrors.civilID}
                  />
                  {skuLineItemId === 'noSku' ? (
                    <AddToCart
                      sku={sku}
                      buttonVariant={ButtonVariantEnum.primaryOnLight}
                      className={`w-full`}
                      pageType="Store List"
                      onValidateBeforeAddToCart={() => {
                        return Object.keys(validate(pickupDetails)).length === 0
                      }}
                      warranty={selectedWarrantyDetails?.warranty}
                      cartClickAndCollectOption={pickupDetails}
                    >
                      {t('addToCart_button_label')}
                    </AddToCart>
                  ) : (
                    <Button
                      variant={ButtonVariantEnum.primaryOnLight}
                      className={`w-full`}
                      disabled={
                        updateStoreDetailsStatus ===
                        AsyncResponseStatusEnum.loading
                      }
                      onClick={() => {
                        if (Object.keys(validate(pickupDetails)).length === 0) {
                          dispatch(
                            updateStorePickupDetails({
                              lineItemId: skuLineItemId,
                              store,
                              user,
                              language,
                              locale: hreflang,
                              cartSetClickAndCollectOptionsDTO: pickupDetails,
                            })
                          )
                        }
                      }}
                    >
                      {t('cart_store_modal_confirmStore')}
                    </Button>
                  )}
                </div>
              )}
            </div>
          ) : (
            <>
              <Heading type={HeadingEnum.h3}>
                {t('cart_store_modal_notavailable')}
              </Heading>
              <Button
                variant={ButtonVariantEnum.primaryOnLight}
                className={`w-full my-8`}
                onClick={onCloseModal}
              >
                {t('cart_store_modal_close')}
              </Button>
            </>
          )}
        </>
      )}
    </Modal>
  )
}
