import { useRouter } from 'next/router'
import { useTranslation } from 'next-i18next'
import React, { useCallback, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import getConfig from 'next/config'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import {
  cartItemsSelector,
  cartMessagesSelector,
  cartStatusSelector,
  cncAvailabilityDetailsSelector,
  resetCartMessagesAction,
  resetCnCAvailabilityAction,
  potentialPromotionSelector,
  paymentBNPLSelector,
  paymentSummaryDetailsSelector,
} from '../../../redux/slices/cart'
import { namedLinksSelector } from '../../../redux/slices/navigation'
import { resetOrderAction } from '../../../redux/slices/order'
import { userProfileSelector } from '../../../redux/slices/profile'
import styles from './Cart.module.css'
import {
  AsyncResponseStatusEnum,
  AvailableWarranties,
  ButtonVariantEnum,
  StatusMessageEnum,
  CountryCodeEnum,
  PaymentTypeEnum,
} from '../../../types/content'
import ProductLineItem from '../ProductLineItem'
import OrderSummary from '../OrderSummary'
import CartLoginRegister from '../CartLoginRegister'
import BFFClient from '../../../lib/api/clients/BFF/bffClient'
import AddDiscount from '../../molecules/AddDiscount'
import gtmDatalayer from '../../../util/gtmUtils'
import StatusMessage from '../../atoms/StatusMessage'
import { ButtonLink } from '../../atoms/Button/Button'
import CheckoutPageWrapper from '../../molecules/CheckoutPageWrapper'
import VerifyCartWrapper from '../../molecules/VerifyCartWrapper'

const Cart = (): JSX.Element => {
  const router = useRouter()
  const { locale } = router

  const dispatch = useDispatch()
  const items = useSelector(cartItemsSelector)
  const cartMessages = useSelector(cartMessagesSelector)
  const cardStatus = useSelector(cartStatusSelector)
  const namedLinks = useSelector(namedLinksSelector)
  const user = useSelector(userProfileSelector)
  const cncAvailableDetails = useSelector(cncAvailabilityDetailsSelector)
  const potentialPromotions = useSelector(potentialPromotionSelector)
  const paymentSummarydetails = useSelector(paymentSummaryDetailsSelector)
  const bnplTypes = useSelector(paymentBNPLSelector)
  const [toggleLoginRegister, setToggleLoginRegister] = React.useState(false)
  const [availableWarranties, setAvailableWarranties] = React.useState<
    AvailableWarranties[]
  >([])

  const {
    country: { ctStore: store, id: countryId },
    hreflang,
  } = localesFactory.createFromHrefLang(locale).current
  const bnpl = JSON.parse(JSON.stringify(bnplTypes))
  const { t } = useTranslation()
  const checkoutCartHandler = () => {
    gtmDatalayer('checkout_started', 'cart_events', 'checkout_started')
    if (user.authenticated && cartMessages.length === 0) {
      router.push(namedLinks.shipping)
    } else {
      setToggleLoginRegister(true)
    }
  }

  const loadAvailableWarranties = useCallback(async (skus, store) => {
    const data = { skus, store }
    try {
      const warrantyAvailability = await BFFClient.warranty.getWarranties(data)
      setAvailableWarranties(warrantyAvailability)
    } catch (error) {
      console.error(error)
    }
  }, [])

  const getCnCAvailability = (sku) => {
    return cncAvailableDetails.some((data) => {
      if (data.sku === sku) {
        return data.available
      }
    })
  }

  useEffect(() => {
    const lineItemId = router.query.lineItemId as string
    const lineItemSection = document.getElementById(lineItemId)
    lineItemSection?.scrollIntoView({ behavior: 'smooth' })
    gtmDatalayer('navigation_menu', 'navigation_menu', 'My Cart')
    if (items.length > 0) {
      gtmDatalayer('view_cart', 'CartView', 'CartPage')
    }
  }, [items.length, router.query])

  useEffect(() => {
    dispatch(resetOrderAction())
  }, [dispatch])

  useEffect(() => {
    if (items.length > 0 && availableWarranties.length === 0) {
      const skus = Array.from(new Set(items.map((item) => item.sku)))
      loadAvailableWarranties(skus, store)
    }
  }, [loadAvailableWarranties, availableWarranties, items, store])

  useEffect(() => {
    items.length === 0
      ? (dispatch(resetCartMessagesAction()),
        dispatch(resetCnCAvailabilityAction()))
      : null
  }, [dispatch, items])
  const tabbykey = getConfig().publicRuntimeConfig.tabby.publickey
  const tabbyPromo = () => {
    return Function(`new TabbyPromo({
      currency: 'SA',
      selector: '#TabbyCart',
      price: '${parseInt(
        paymentSummarydetails?.totalPrice?.split(' ')[0]?.replace(/\,/g, '')
      )}',
      installmentsCount: 4,
      lang:  '${hreflang && hreflang.startsWith('ar') ? 'ar' : 'en'}',
      source: 'product',
      publicKey: '${tabbykey}',
      merchantCode: 'XciteWeb'
    })`)()
  }
  useEffect(() => {
    tabbyPromo()
  })
  return (
    <CheckoutPageWrapper>
      <VerifyCartWrapper>
        {toggleLoginRegister && (
          <CartLoginRegister
            handleModal={setToggleLoginRegister}
          ></CartLoginRegister>
        )}
        <>
          <div className="col-span-4 sm:col-span-7 sm:mb-12 md:col-start-2 md:col-span-6 sm:pr-4 mb-56">
            {potentialPromotions.length > 0 && (
              <div className="flex flex-col gap-2">
                {potentialPromotions.map((promotion, index) => (
                  <StatusMessage
                    key={index}
                    type={StatusMessageEnum.Offer}
                    className="text-xs animate-appearFromAbove"
                  >
                    {locale == 'ar-KW' || locale == 'ar-SA'
                      ? promotion?.messageAr
                      : promotion?.messageEn}{' '}
                    <ButtonLink
                      variant={ButtonVariantEnum.textLink}
                      href={`/${promotion.slug}`}
                      className="text-xs"
                    >
                      {t('cart_potential_promotion_link_text')}
                    </ButtonLink>
                  </StatusMessage>
                ))}
              </div>
            )}
            <ul>
              {items.map((item) => (
                <li
                  key={item.id}
                  id={item.id}
                  className="border-b border-b-gray-300 py-10 sm:py-12"
                >
                  <ProductLineItem
                    item={item}
                    pliFrom="cart"
                    cartMessages={cartMessages}
                    cncAvailability={getCnCAvailability(item.sku)}
                    isWarrantyAvailable={
                      availableWarranties?.find(
                        (warranty) => warranty.sku === item.sku
                      )?.warrantyExists || false
                    }
                  />
                </li>
              ))}
            </ul>
            <div className="my-12">
              <AddDiscount />
            </div>
            <div className={styles.hide}>
              {countryId === CountryCodeEnum.SaudiArabia &&
                bnpl &&
                bnpl.includes(PaymentTypeEnum.Tamara) && (
                  <div
                    className="tamara-product-widget"
                    data-lang={
                      hreflang && hreflang.startsWith('ar') ? 'ar' : 'en'
                    }
                    data-price={JSON.stringify(
                      paymentSummarydetails.totalPrice
                    )}
                    data-currency="SAR"
                    data-country-code="SA"
                    data-color-type="default"
                    data-show-border="true"
                    data-payment-type="installment"
                    data-number-of-installments="3"
                    data-disable-installment="false"
                    data-disable-paylater="true"
                  />
                )}
            </div>
            <div className={styles.hide}>
              {countryId === CountryCodeEnum.SaudiArabia &&
                bnpl &&
                bnpl.includes(PaymentTypeEnum.Tabby) && (
                  <div style={{ marginTop: '25px' }} id="TabbyCart"></div>
                )}
            </div>
          </div>
          <OrderSummary
            btnOrderSummaryLabel={t('cart_checkout_button_label')}
            btnVariant={ButtonVariantEnum.primaryOnLight}
            onClickCheckout={checkoutCartHandler}
            orderSummaryFrom="cart"
            orderSummaryStatus={
              cardStatus === AsyncResponseStatusEnum.loading ||
              !!cartMessages.length
            }
          />
        </>
        {/* Personyze You may Like Widget Template Start */}
        <div className="col-span-full">
          <div id="youMayLike" />
        </div>
        {/* Personyze You may Like Widget Template End */}
      </VerifyCartWrapper>
    </CheckoutPageWrapper>
  )
}

export default Cart
