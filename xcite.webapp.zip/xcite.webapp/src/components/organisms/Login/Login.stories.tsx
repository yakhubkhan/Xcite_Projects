import React from 'react'
import { Meta, Story } from '@storybook/react'
import { LoginComponentType } from '../../../types/content'
import Login from './Login'

export default {
  title: 'Components/organisms/Login',
  component: Login,
} as Meta

const Template: Story<LoginComponentType> = (args) => <Login {...args} />

export const Default = Template.bind({})

Default.args = {
  type: 'Login',
}
