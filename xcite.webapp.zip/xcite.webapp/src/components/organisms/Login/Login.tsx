import { useTranslation } from 'next-i18next'
import React from 'react'
import { LoginComponentType, HeadingEnum } from '../../../types/content'
import Grid from '../../atoms/Grid'
import Heading from '../../atoms/Heading'
import LoginRegister from '../LoginRegister'

const Login: React.FunctionComponent<LoginComponentType> = () => {
  const { t } = useTranslation()
  return (
    <Grid className="items-start gap-x-0 sm:gap-x-10 py-10 sm:py-20 w-full">
      <div
        className={`col-span-full sm:col-start-4 sm:col-span-6 md:col-start-5 md:col-span-4 mb-10 sm:mb-14`}
      >
        <div className="border border-functional-yellow-700 rounded-lg p-2 mb-9 sm:-mx-8">
          <Heading type={HeadingEnum.h4}>
            {t('user_form_login_page_heading')}
          </Heading>
        </div>
        <LoginRegister headingLevel={HeadingEnum.h4} />
      </div>
    </Grid>
  )
}

export default Login
