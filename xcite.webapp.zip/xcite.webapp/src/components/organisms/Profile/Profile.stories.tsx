import React from 'react'
import { Meta, Story } from '@storybook/react'
import { ProfileComponentType } from '../../../types/content'
import Profile from './Profile'

export default {
  title: 'Components/organisms/Profile',
  component: Profile,
} as Meta

const Template: Story<ProfileComponentType> = (args) => <Profile {...args} />

export const Default = Template.bind({})

Default.args = {
  type: 'Profile',
}
