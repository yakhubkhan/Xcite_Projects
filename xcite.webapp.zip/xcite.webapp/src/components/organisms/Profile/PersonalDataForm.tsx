import React from 'react'
import {
  AsyncResponseStatusEnum,
  ButtonVariantEnum,
  HeadingEnum,
  InputTypeEnum,
} from '../../../types/content'
import Button from '../../atoms/Button'
import Field from '../../atoms/Field'
import Heading from '../../atoms/Heading'
import { useTranslation } from 'next-i18next'
import { ArrowLeftIcon } from '../../atoms/Icon'
import { getPreviousDateYYYYMMDD } from '../../../util/dateUtils'

const arrowDownIcon = (
  <ArrowLeftIcon className="w-6 h-6 -mt-1 -rotate-90" stroke="#181818" />
)

// eslint-disable-next-line
export const PersonalDataForm = ({
  dateOfBirth,
  firstName,
  email,
  gender,
  handlePersonalDataFormSubmit,
  lastName,
  maritalStatus,
  nationality,
  profileEnum,
  profileStatus,
  setDateOfBirth,
  setFirstName,
  setGender,
  setLastName,
  setMaritalStatus,
  setNationality,
}): JSX.Element => {
  const { t } = useTranslation()
  return (
    <>
      <Heading type={HeadingEnum.h1} className="mb-4">
        {t('user_form_personal_data_privacy_label')}
      </Heading>
      <p className="typography-small mb-8 sm:mb-10">
        {t('user_form_welcome_body')}
      </p>
      <form onSubmit={handlePersonalDataFormSubmit}>
        <div className="col-span-full flex flex-col gap-8 pt-5">
          <Field
            labelText={t('user_form_generic_firstname_label')}
            id="firstName"
            onChange={(e) => {
              setFirstName(e.target.value)
            }}
            placeholder={t('user_form_generic_firstname_placeholder')}
            value={firstName}
          />
          <Field
            labelText={t('user_form_generic_lastname_label')}
            id="lastName"
            onChange={(e) => {
              setLastName(e.target.value)
            }}
            placeholder={t('user_form_generic_lastname_placeholder')}
            value={lastName}
          />
          <Field
            labelText={t('user_form_generic_email_label')}
            id="email"
            value={email}
            readOnly
          />
          <Field
            labelText={t('user_form_generic_nationality_label')}
            id="nationality"
            onChange={(e) => {
              setNationality(e.target.value)
            }}
            placeholder={t('user_form_generic_nationality_placeholder')}
            rightIconTag={arrowDownIcon}
            selectOptions={profileEnum?.nationality}
            type={InputTypeEnum.select}
            value={nationality}
          />
          <Field
            labelText={t('user_form_generic_gender_label')}
            id="gender"
            onChange={(e) => {
              setGender(e.target.value)
            }}
            placeholder={t('user_form_generic_gender_placeholder')}
            rightIconTag={arrowDownIcon}
            selectOptions={profileEnum?.gender}
            type={InputTypeEnum.select}
            value={gender}
          />
          <Field
            labelText={t('user_form_generic_maritalStatus_label')}
            id="maritalStatus"
            onChange={(e) => {
              setMaritalStatus(e.target.value)
            }}
            placeholder={t('user_form_generic_maritalStatus_placeholder')}
            rightIconTag={arrowDownIcon}
            selectOptions={profileEnum?.['marital-status']}
            type={InputTypeEnum.select}
            value={maritalStatus}
          />
          <Field
            labelText={t('user_form_generic_dateOfBirth_label')}
            id="dateOfBirth"
            onChange={(e) => {
              setDateOfBirth(e.target.value)
            }}
            type={InputTypeEnum.date}
            value={dateOfBirth}
            min="1900-01-01"
            max={getPreviousDateYYYYMMDD()}
          />
          <Button
            variant={ButtonVariantEnum.primaryOnLight}
            type="submit"
            className="w-full"
            disabled={profileStatus === AsyncResponseStatusEnum.loading}
          >
            {t('user_form_welcome_submit_label')}
          </Button>
        </div>
      </form>
    </>
  )
}
