import { useRouter } from 'next/router'
import { useTranslation } from 'next-i18next'
import React, { useEffect } from 'react'

import { getEnumByResource } from '../../../lib/api/clients/customer'
import {
  AsyncResponseStatusEnum,
  HeadingEnum,
  ProfileComponentType,
  ProfileViewState,
  ResourceEnumType,
  ToastDuration,
  ToastType,
  UserProfileType,
} from '../../../types/content'
import Grid from '../../atoms/Grid'
import Heading from '../../atoms/Heading'
import { PersonalDataForm } from './PersonalDataForm'
import { useDispatch, useSelector } from 'react-redux'
import {
  postUserProfileThunk,
  profileStatusSelector,
  userProfileSelector,
} from '../../../redux/slices/profile'
import BackButton from '../../molecules/BackButton'
import { ArrowLeftIcon } from '../../atoms/Icon'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import gtmDatalayer from '../../../util/gtmUtils'
import Toaster from '../../atoms/Toaster'

const arrowRightIcon = (
  <ArrowLeftIcon
    className="w-6 h-6 ltr:-rotate-180 rtl:pt-1"
    stroke="#181818"
  />
)

const Profile: React.FunctionComponent<ProfileComponentType> = () => {
  const { locale } = useRouter()

  const { t } = useTranslation()
  const dispatch = useDispatch()
  const [firstName, setFirstName] = React.useState('')
  const [lastName, setLastName] = React.useState('')
  const [nationality, setNationality] = React.useState('')
  const [gender, setGender] = React.useState('')
  const [maritalStatus, setMaritalStatus] = React.useState('')
  const [dateOfBirth, setDateOfBirth] = React.useState('')
  const [profileEnum, setProfileEnum] = React.useState<ResourceEnumType>()
  const [rightSection, setRightSection] = React.useState(0)
  const [personalDataSubmit, setPersonalDataSubmit] = React.useState(false)
  const [currViewState, setCurrViewState] = React.useState(
    ProfileViewState.left
  )
  const [currUser, setCurrUser] = React.useState<UserProfileType>(
    {} as UserProfileType
  )
  const user = useSelector(userProfileSelector)
  const profileStatus = useSelector(profileStatusSelector)
  const accountNavItems = [t('user_form_personal_data_privacy_label')]
  const { hreflang: localeKey } =
    localesFactory.createFromHrefLang(locale).current

  const rightSectionProvider = (type) => {
    switch (type) {
      case 0:
        return (
          <PersonalDataForm
            dateOfBirth={dateOfBirth || ''}
            firstName={firstName || ''}
            gender={gender || ''}
            email={user?.email || ''}
            handlePersonalDataFormSubmit={handlePersonalDataFormSubmit}
            lastName={lastName || ''}
            maritalStatus={maritalStatus || ''}
            nationality={nationality || ''}
            profileEnum={profileEnum}
            profileStatus={profileStatus}
            setDateOfBirth={setDateOfBirth}
            setFirstName={setFirstName}
            setGender={setGender}
            setLastName={setLastName}
            setMaritalStatus={setMaritalStatus}
            setNationality={setNationality}
          />
        )
    }
  }

  const handlePersonalDataFormSubmit = async (e) => {
    e.preventDefault()
    try {
      const profileData = {
        dateOfBirth: dateOfBirth || null,
        firstName: firstName || null,
        gender: gender || null,
        lastName: lastName || null,
        maritalStatus: maritalStatus || null,
        nationality: nationality || null,
      }
      const payload = {
        ctUserName: currUser?.id,
        profileData,
      }
      await dispatch(postUserProfileThunk(payload))
      setPersonalDataSubmit(true)
      setTimeout(() => setPersonalDataSubmit(false), 5000)
    } catch (err) {}
  }

  useEffect(() => {
    const getEnumCustomerEffect = async () => {
      if (user.authenticated) {
        const query =
          'enumAttribute=gender&enumAttribute=nationality&enumAttribute=marital-status'
        const enumData = await getEnumByResource({
          localeKey: localeKey,
          resourceId: 'customer',
          query: query,
        })
        setProfileEnum(enumData)
      }
    }
    getEnumCustomerEffect()
  }, [localeKey, user])

  useEffect(() => {
    setCurrUser(user)
    setDateOfBirth(user?.dateOfBirth || '')
    setFirstName(user?.firstName || '')
    setGender(user?.gender || '')
    setLastName(user?.lastName || '')
    setMaritalStatus(user?.maritalStatus || '')
    setNationality(user?.nationality || '')
    gtmDatalayer('sign_up_success', 'new account', 'Submit')
  }, [user])

  return (
    <Grid className="w-full bg-gray-50 items-start px-0 sm:py-20">
      {profileStatus === AsyncResponseStatusEnum.failed &&
        user.authenticated && (
          <Toaster
            toastMsg={`${t('user_form_profile_failed_message')}`}
            duration={ToastDuration}
            className="profile-toast"
            type={ToastType.error}
          />
        )}
      {personalDataSubmit &&
        profileStatus === AsyncResponseStatusEnum.succeeded &&
        user.authenticated && (
          <Toaster
            toastMsg={`${t('user_form_profile_success_message')}`}
            duration={ToastDuration}
            className="profile-toast"
            type={ToastType.success}
          />
        )}
      {user.authenticated && (
        <>
          <div
            className={`relative col-span-4 sm:col-span-4 sm:mb-12 md:col-start-2 md:col-span-4 ltr:sm:pr-4 rtl:sm:pl-4`}
          >
            <div className="absolute w-full p-10 sm:p-0">
              <div className="col-span-full mb-4 md:col-start-2 md:col-span-10">
                <Heading type={HeadingEnum.h2}>
                  {t('user_form_profile_account_heading')}
                </Heading>
              </div>
              {accountNavItems && accountNavItems.length > 0 ? (
                <div>
                  <div className="col-span-4 sm:col-span-7 sm:mb-12 md:col-start-2 md:col-span-6 ltr:sm:pr-4 rtl:sm:pl-4">
                    <ul>
                      {accountNavItems.map((item, index) => (
                        <li
                          key={index}
                          className={`font-semibold px-3 md:pl-6 py-2 cursor-pointer ${
                            index === rightSection
                              ? 'bg-primary-100 rounded'
                              : ''
                          }`}
                          onClick={() => {
                            setRightSection(index)
                            setCurrViewState(ProfileViewState.right)
                          }}
                        >
                          <div className="cmn-flex-items-center">
                            <div className="flex-1">{item}</div>
                            <div className={`rtl:pr-2`}>{arrowRightIcon}</div>
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ) : (
                <></>
              )}
            </div>
          </div>
          <div
            className={`col-span-4 sm:col-span-8 sm:mb-12 md:col-span-6 bg-white p-10 transition duration-100 ease ${
              currViewState === ProfileViewState.left
                ? 'translate-x-[-200%]'
                : 'translate-x-0'
            } sm:transform-none`}
          >
            <div className="relative mb-8 block sm:hidden">
              <div className="absolute">
                <BackButton
                  onClick={() => setCurrViewState(ProfileViewState.left)}
                />
              </div>
            </div>
            {rightSectionProvider(rightSection)}
          </div>
        </>
      )}
    </Grid>
  )
}

export default Profile
