import { NextRouter, useRouter } from 'next/router'
import getConfig from 'next/config'
import React, { useEffect, useRef, useState } from 'react'
import { Configure, InstantSearch } from 'react-instantsearch-dom'
import { Provider } from 'react-redux'
import qs from 'qs'

import { AlgoliaSearchProps, AlgoliaSearchState } from '../../../types/algolia'
import store from '../../../redux/store'
import ProductList from '../ProductList'
import {
  MultipleQueriesOptions,
  MultipleQueriesQuery,
  MultipleQueriesResponse,
} from '@algolia/client-search'
import { RequestOptions } from '@algolia/transporter'

const DEBOUNCE_TIME = 400
const categoryPageUrlRegExp = /^\/([^\/]+)\/c$/

interface AlgoliaSearchable {
  readonly search: <TObject>(
    queries: readonly MultipleQueriesQuery[],
    requestOptions?: RequestOptions & MultipleQueriesOptions
  ) => Readonly<Promise<MultipleQueriesResponse<TObject>>>
}

type SearchProps = AlgoliaSearchProps & {
  searchClient: AlgoliaSearchable
}

const redirectToNewState = (router: NextRouter, urlState: string) => {
  const isCategoryPage = categoryPageUrlRegExp.test(router.asPath.split('?')[0])
  const pathname = isCategoryPage
    ? window.location.pathname.split('?')[0]
    : router.pathname
  const href = `${pathname}${urlState ? `?${urlState}` : ''}`
  router.push(href, undefined, { scroll: false })
}

const checkEmptyRefinementList = (refinementList: Record<string, string[]>) => {
  let emptyFacets = true
  Object.keys(refinementList).map((facet) => {
    if (refinementList[facet]) {
      emptyFacets = false
    }
  })
  return emptyFacets
}

const AlgoliaSearch = (props: SearchProps): JSX.Element => {
  const router = useRouter()
  const [searchState, setSearchState] = useState({})
  const [prevRouter, setPrevRouter] = useState({})
  const debouncedSetStateRef: { current: NodeJS.Timeout | null } = useRef(null)

  const defaultSort = props.indexName

  function onSearchStateChange(updatedSearchState: AlgoliaSearchState) {
    const urlSearchParams = new URLSearchParams(window.location.search)
    const searchQueryParam = urlSearchParams.get('q')
    const { asPath: prevRouterAsPath } = prevRouter as NextRouter
    let reducedSearchState: any = { q: searchQueryParam || undefined }
    if (
      updatedSearchState?.q === reducedSearchState.q &&
      prevRouterAsPath.indexOf(router.asPath) === 0
    ) {
      reducedSearchState = {
        ...reducedSearchState,
        hierarchicalMenu:
          updatedSearchState?.hierarchicalMenu &&
          updatedSearchState?.hierarchicalMenu['categories.lvl0']?.length
            ? updatedSearchState.hierarchicalMenu
            : undefined,
        refinementList:
          updatedSearchState.refinementList &&
          checkEmptyRefinementList(updatedSearchState.refinementList)
            ? undefined
            : updatedSearchState.refinementList,
        range: updatedSearchState.range,
        toggle: updatedSearchState.toggle,
        page:
          updatedSearchState.page === 1 ? undefined : updatedSearchState.page,
        sortBy:
          updatedSearchState.sortBy !== defaultSort
            ? updatedSearchState.sortBy
            : undefined,
      }
    }

    if (debouncedSetStateRef.current) {
      clearTimeout(debouncedSetStateRef.current)
    }

    debouncedSetStateRef.current = setTimeout(() => {
      const urlState = updatedSearchState
        ? `${qs.stringify(reducedSearchState)}`
        : ''
      redirectToNewState(router, urlState)
    }, DEBOUNCE_TIME)

    setSearchState(updatedSearchState)
  }

  useEffect(() => {
    const url = new URL(window.location.href)
    if (router !== prevRouter) {
      const searchState = url.search.includes('?')
        ? qs.parse(url.search.substring(url.search.indexOf('?') + 1))
        : {}
      if (searchState['reset'] === 'list') {
        const routerAsPath = router.asPath
        delete searchState['reset']
        delete searchState['refinementList']
        router.replace({
          pathname: routerAsPath.substring(0, routerAsPath.indexOf('?')),
          query: qs.stringify(searchState),
        })
      }
      setPrevRouter(router)
      setSearchState(searchState)
    }
  }, [router, prevRouter, defaultSort])

  return (
    <Provider store={store}>
      <InstantSearch
        onSearchStateChange={onSearchStateChange}
        searchState={searchState}
        resultsState={props.resultsState}
        {...props}
      >
        <Configure
          clickAnalytics={true}
          query={props.searchQuery}
          hitsPerPage={getConfig().publicRuntimeConfig.algolia.pageResults}
          facets={['*']}
        />
        <ProductList
          categoryName={props.categoryName}
          hrefLang={props.hrefLang}
          algoliaSortIndexNames={props.algoliaSortIndexNames}
          defaultSort={props.indexName}
          query={
            searchState['sortBy'] !== undefined
              ? JSON.stringify(searchState['sortBy'])
              : defaultSort
          }
          facets={props.resultsState?.rawResults[0].facets}
        />
      </InstantSearch>
    </Provider>
  )
}

export default AlgoliaSearch
