export { default } from './AlgoliaSearch'
