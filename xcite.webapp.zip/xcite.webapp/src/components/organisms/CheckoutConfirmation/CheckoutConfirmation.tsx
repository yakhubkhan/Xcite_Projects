import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useRouter } from 'next/router'

import { resetCartAction } from '../../../redux/slices/cart'
import { userProfileSelector } from '../../../redux/slices/profile'
import {
  getOrderDetailsThunk,
  getOrderReprintThunk,
  orderStateSelector,
} from '../../../redux/slices/order'
import { AsyncResponseStatusEnum, HeadingEnum } from '../../../types/content'
import Grid from '../../atoms/Grid'
import Heading from '../../atoms/Heading'
import { CheckInCircleIcon } from '../../atoms/Icon'

import { useTranslation } from 'next-i18next'
import { nl2br } from '../../../util/templateUtils'
import DigitalProductLineItem from '../../molecules/DigitalProductLineItem'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import gtmDatalayer from '../../../util/gtmUtils'
import getConfig from 'next/config'

const checkInCircleIcon = <CheckInCircleIcon className="w-20 h-20" />
const RETRY_REPRINT_FOR_WAITING_RESULT = 1000

const CheckoutConfirmation = (): JSX.Element => {
  const router = useRouter()
  const { t } = useTranslation()
  const dispatch = useDispatch()
  const user = useSelector(userProfileSelector)
  const {
    status: orderStatus,
    error: orderError,
    id: orderId,
    orderNumber,
    paymentMethod,
    paymentProviderId,
    paymentID,
    lineItems,
    reprint,
    waitingReprint,
    reprintStatus,
  } = useSelector(orderStateSelector)
  const { orderId: orderIdQueryParam } = router.query
  const {
    iso_639_1: language,
    hreflang,
    country: { ctStore: store },
  } = localesFactory.createFromHrefLang(router?.locale).current
  const algoliaIndex = `${
    getConfig().publicRuntimeConfig.algolia.indexDefault
  }${store}_${language}_relevancy`

  useEffect(() => {
    if (user.id && typeof orderIdQueryParam === 'string') {
      gtmDatalayer('placeOrderClicked', 'Payment', 'Pay Now')
      dispatch(
        getOrderDetailsThunk({
          user,
          orderId: orderIdQueryParam,
          store,
          orderNumber,
          language,
          locale: hreflang,
        })
      )
    }
  }, [
    user,
    dispatch,
    orderIdQueryParam,
    orderNumber,
    language,
    hreflang,
    store,
  ])

  useEffect(() => {
    const digitalProdIds = lineItems
      .filter((lineItem) => lineItem.digitalProduct)
      .map((digitalProduct) => digitalProduct.id)
    if (
      user.id &&
      orderNumber &&
      orderStatus === AsyncResponseStatusEnum.succeeded &&
      reprintStatus === AsyncResponseStatusEnum.idle
    ) {
      dispatch(
        getOrderReprintThunk({
          user,
          lineItemIds: digitalProdIds,
          store,
          orderNumber,
          language,
        })
      )
    }
  }, [
    dispatch,
    language,
    lineItems,
    orderNumber,
    orderStatus,
    reprintStatus,
    store,
    user,
  ])

  useEffect(() => {
    if (
      user.id &&
      orderNumber &&
      orderStatus === AsyncResponseStatusEnum.succeeded &&
      reprintStatus === AsyncResponseStatusEnum.succeeded
    ) {
      const waitingDigitalProdIds = waitingReprint.map(
        (digitalProduct) => digitalProduct.lineitemId
      )
      if (waitingDigitalProdIds.length) {
        setTimeout(
          () =>
            dispatch(
              getOrderReprintThunk({
                user,
                lineItemIds: waitingDigitalProdIds,
                store,
                orderNumber,
                language,
              })
            ),
          RETRY_REPRINT_FOR_WAITING_RESULT
        )
      }
      gtmDatalayer('dh_purchase', 'OrderSuccessView', 'Sales Confirmation Page')
    }
  }, [
    dispatch,
    language,
    orderNumber,
    orderStatus,
    reprintStatus,
    store,
    user,
    waitingReprint,
  ])

  useEffect(() => {
    if (orderStatus === AsyncResponseStatusEnum.succeeded) {
      dispatch(resetCartAction())
    }
  }, [dispatch, orderId, orderStatus])

  const renderOrderStatus = () => {
    if (orderStatus === AsyncResponseStatusEnum.loading) {
      return <p className="px-4 py-8">Loading...</p>
    }
    if (orderStatus === AsyncResponseStatusEnum.failed) {
      return <p>{orderError}</p>
    }
    if (orderStatus === AsyncResponseStatusEnum.succeeded) {
      return (
        <div
          className="bg-functional-green-50"
          data-insights-index={algoliaIndex}
        >
          <Grid>
            <div className="col-span-full py-8">
              <div className="cmn-flex-items-center flex-col px-4">
                {checkInCircleIcon}
                <Heading
                  type={HeadingEnum.h1}
                  className="col-span-full typography-h3 sm:typography-h1 mb-6"
                >
                  {t('checkout_order_confirmation_orderplaced')}
                </Heading>

                {paymentMethod === 'Knet' ? (
                  <p className="text-center">
                    {nl2br(
                      t('knet_order_confirmation_order_message', {
                        orderNumber: orderNumber,
                        paymentProviderId: paymentProviderId,
                        paymentID: paymentID,
                      })
                    )}
                  </p>
                ) : paymentMethod === 'Tamara' ? (
                  <p className="text-center">
                    {nl2br(
                      t('checkout_order_confirmation_order_message', {
                        orderNumber: orderNumber,
                      })
                    )}
                    <br />
                    {t('tamara_order_confirmation_order_message')}
                  </p>
                ) : paymentMethod === 'Tabby' ? (
                  <p className="text-center">
                    {nl2br(
                      t('checkout_order_confirmation_order_message', {
                        orderNumber: orderNumber,
                      })
                    )}
                    <br />
                    {t('tabby_order_confirmation_order_message')}
                  </p>
                ) : (
                  <p className="text-center">
                    {nl2br(
                      t('checkout_order_confirmation_order_message', {
                        orderNumber: orderNumber,
                      })
                    )}
                  </p>
                )}
              </div>
              {lineItems.length > 0 && (
                <div className="grid grid-gap gap-y-8">
                  {lineItems.map((lineItem, index) => {
                    const reprintLineItem = [
                      ...reprint,
                      ...waitingReprint,
                    ].find((item) => item.lineitemId === lineItem.id)
                    if (lineItem.digitalProduct && reprintLineItem) {
                      return (
                        <div key={lineItem.id}>
                          {index === 0 && (
                            <p className="text-center mt-4 mb-6">
                              {t(
                                'checkout_order_confirmation_digital_prod_title'
                              )}
                            </p>
                          )}
                          <div className="grid grid-cols-7 m-auto max-w-[580px]">
                            <DigitalProductLineItem
                              lineItem={lineItem}
                              reprintLineItem={reprintLineItem}
                            />
                          </div>
                        </div>
                      )
                    }
                  })}
                </div>
              )}
            </div>
          </Grid>
        </div>
      )
    }
  }

  return (
    <>
      {orderIdQueryParam ? (
        renderOrderStatus()
      ) : (
        <Grid>
          <div className="col-span-full">
            <p>Sorry, but you did not complete any order yet.</p>
          </div>
        </Grid>
      )}
    </>
  )
}

export default CheckoutConfirmation
