import React from 'react'
import { Meta, Story } from '@storybook/react'

import productCarousel from '../../../mocks/staticPages/partials/productCarousel'
import ProductCarousel from './ProductCarousel'
import { ProductCarouselComponentType } from '../../../types/content/component'

export default {
  title: 'Components/organisms/ProductCarousel',
  component: ProductCarousel,
} as Meta

//👇 We create a “template” of how args map to rendering
const Template: Story<ProductCarouselComponentType> = (args) => (
  <ProductCarousel {...args} />
)

//👇 Each story then reuses that template
export const Default = Template.bind({})

Default.args = productCarousel()
