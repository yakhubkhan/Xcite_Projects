import React, { useEffect, useState } from 'react'
import { Hub } from 'aws-amplify'
import { useDispatch, useSelector } from 'react-redux'
import { useTranslation } from 'next-i18next'
import { useRouter } from 'next/router'

import {
  confirmSignUp,
  forgotPassword,
  forgotPasswordSubmit,
  signIn,
  signOut,
  signUp,
} from '../../../lib/api/clients/authClient'
import { getCustomerExists } from '../../../lib/api/clients/customer'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import {
  getUserProfileThunk,
  setAnonymousUserAction,
  userProfileSelector,
} from '../../../redux/slices/profile'
import { cartMessagesSelector } from '../../../redux/slices/cart'
import { namedLinksSelector } from '../../../redux/slices/navigation'
import {
  ButtonVariantEnum,
  LoginRegisterStateEnum,
  UserProfileType,
  HeadingEnum,
} from '../../../types/content'
import Modal from '../../atoms/Modal'
import Button from '../../atoms/Button'
import BackButton from '../../molecules/BackButton'
import styles from './CartLoginRegister.module.css'
import { LoginRegisterForm } from '../LoginRegister/LoginRegisterForm'
import { emailValidationRegex } from '../../../util/formValidation'
import gtmDatalayer from '../../../util/gtmUtils'
import CtStore from '../../../lib/api/l18n/CtStore'

const initAuthData = {
  field: '',
  message: '',
  type: '',
}

// eslint-disable-next-line
const CartLoginRegister = ({ handleModal }): JSX.Element => {
  const router = useRouter()
  const { locale } = router

  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [togglePassword, setTogglePassword] = useState(true)
  const [usernameErrorMessage, setUsernameErrorMessage] = useState('')
  const [authenticationCode, setAuthenticationCode] = useState('')
  const [authDataPayload, setAuthDataPayload] = useState(initAuthData)
  const [viewMode, setViewMode] = useState(LoginRegisterStateEnum.init)
  const [currUser, setCurrUser] = useState<UserProfileType>(
    {} as UserProfileType
  )
  const [displayFPSuccess, setDisplayFPSuccess] = useState(false)
  const [mfaMethod, setMfaMethod] = useState('')
  const dispatch = useDispatch()
  const cartMessages = useSelector(cartMessagesSelector)
  const namedLinks = useSelector(namedLinksSelector)
  const user = useSelector(userProfileSelector)
  const onSignOut = async () => {
    await signOut()
    handleModal()
    dispatch(setAnonymousUserAction())
  }
  const backBtnCondition = () =>
    viewMode !== LoginRegisterStateEnum.init &&
    viewMode !== LoginRegisterStateEnum.checkout

  const {
    country: { ctStore: store, id: currentCountry },
  } = localesFactory.createFromHrefLang(locale).current

  const getUserProfile = (signedUser) => {
    const profilePromise = new Promise(async function (resolve, reject) {
      await resolve(dispatch(getUserProfileThunk(signedUser?.username)))
    })
    profilePromise.then(
      (result) => {
        gtmDatalayer('login', 'login', 'login')
      },
      function (error) {
        console.log(error)
      }
    )
  }

  useEffect(() => {
    setCurrUser(user)
    const authListenerErrorHandler = async (authChannelData) => {
      const {
        data: { name, message, codeDeliveryDetails },
        event,
      } = authChannelData.payload
      if (event === 'signUp') {
        codeDeliveryDetails && setMfaMethod(codeDeliveryDetails?.DeliveryMedium)
      }
      if (event === 'forgotPasswordSubmit') {
        setDisplayFPSuccess(true)
      }
      if (name === 'UsernameExistsException') {
        setAuthDataPayload({ field: 'username', message: message, type: 'err' })
      } else if (name === 'InvalidPasswordException') {
        setAuthDataPayload({ field: 'password', message: message, type: 'err' })
      } else if (name === 'CodeMismatchException') {
        setAuthDataPayload({
          field: 'regverify',
          message: message,
          type: 'err',
        })
      } else {
        setAuthDataPayload({ field: 'all', message: message, type: '' })
      }
    }

    Hub.listen('authChannel', authListenerErrorHandler)
    return () => {
      Hub.remove('authChannel', authListenerErrorHandler)
    }
  }, [user])

  const handleLoginRegisterFormSubmit = async (e) => {
    setAuthDataPayload(initAuthData)
    e.preventDefault()
    const anonymousId = user.authenticated
      ? localStorage.getItem('anonymousId') || ''
      : user.id

    if (
      !username.match(emailValidationRegex) &&
      viewMode !== LoginRegisterStateEnum.checkout
    ) {
      setUsernameErrorMessage(t('user_form_login_username_validation_message'))
      return
    }
    setUsernameErrorMessage('')
    if (viewMode === LoginRegisterStateEnum.init) {
      try {
        const custStatus = await getCustomerExists(username)
        if (custStatus?.mfaMethod) setMfaMethod(custStatus.mfaMethod)
        if (custStatus.customerStatus.toUpperCase() === 'UNKNOWN') {
          setViewMode(LoginRegisterStateEnum.register)
        } else if (custStatus.customerStatus.toUpperCase() === 'UNCONFIRMED') {
          setViewMode(LoginRegisterStateEnum.regVerify)
        } else {
          setViewMode(LoginRegisterStateEnum.login)
        }
      } catch (err) {}
    } else if (viewMode === LoginRegisterStateEnum.login) {
      try {
        const userProfile = await signIn({
          username,
          password,
          anonymousId,
          store,
        })
        setPassword('')
        getUserProfile(userProfile?.username)
        setUsername(userProfile?.username)
        setViewMode(LoginRegisterStateEnum.checkout)
      } catch (err) {
        console.log(err)
      }
    } else if (viewMode === LoginRegisterStateEnum.register) {
      try {
        await signUp({ username, password, anonymousId, store })
        setPassword('')
        setViewMode(LoginRegisterStateEnum.regVerify)
      } catch (err) {}
    } else if (viewMode === LoginRegisterStateEnum.regVerify) {
      try {
        await confirmSignUp({
          username,
          authenticationCode,
        })
        setViewMode(LoginRegisterStateEnum.login)
      } catch (err) {
        if (err instanceof Error) {
          setAuthDataPayload({
            field: 'regverify',
            message: err?.message,
            type: 'err',
          })
        }
      }
    } else if (viewMode === LoginRegisterStateEnum.checkout) {
      handleModal()
      if (cartMessages.length === 0) {
        router.push(namedLinks.shipping)
      }
    } else if (viewMode === LoginRegisterStateEnum.forgotPassword) {
      try {
        await forgotPassword({
          username,
        })
        setViewMode(LoginRegisterStateEnum.fpVerify)
      } catch (err) {
        console.log(err)
      }
    } else if (viewMode === LoginRegisterStateEnum.fpVerify) {
      try {
        await forgotPasswordSubmit({
          username,
          authenticationCode,
          password,
        })
        setViewMode(LoginRegisterStateEnum.login)
      } catch (err) {}
    }
  }

  const modalBack = async () => {
    setViewMode(LoginRegisterStateEnum.init)
    setAuthDataPayload(initAuthData)
  }
  const { t } = useTranslation()

  return (
    <Modal
      className={`bg-white ${styles.wrapper}`}
      extraCloseBtnClasses={`${
        backBtnCondition() ? 'absolute' : ''
      } px-5 py-2 ltr:-mr-8 ltr:md:-mr-14 rtl:-ml-8 rtl:md:-ml-14 -mt-8`}
      handleModal={handleModal}
      showClose={true}
    >
      <div className="relative">
        {backBtnCondition() && (
          <div className="absolute -mt-4">
            <BackButton onClick={modalBack} />
          </div>
        )}
        {viewMode === LoginRegisterStateEnum.checkout && (
          <div className="absolute mt-3 ltr:right-0 rtl:left-0">
            <Button variant={ButtonVariantEnum.textLink} onClick={onSignOut}>
              {t('user_form_generic_logout_label')}
            </Button>
          </div>
        )}
      </div>
      <LoginRegisterForm
        authDataPayload={authDataPayload}
        authenticationCode={authenticationCode}
        mfaMethod={mfaMethod}
        displayFPSuccess={displayFPSuccess}
        displayWelcome={false}
        handleLoginRegisterFormSubmit={handleLoginRegisterFormSubmit}
        initAuthData={initAuthData}
        loginRegisterFrom="cartloginregister"
        password={password}
        setAuthDataPayload={setAuthDataPayload}
        setAuthenticationCode={setAuthenticationCode}
        setPassword={setPassword}
        setUsername={setUsername}
        setViewMode={setViewMode}
        setTogglePassword={setTogglePassword}
        togglePassword={togglePassword}
        username={username}
        viewMode={viewMode}
        headingLevel={HeadingEnum.h4}
        usernameErrorMessage={usernameErrorMessage}
      />
    </Modal>
  )
}

export default CartLoginRegister
