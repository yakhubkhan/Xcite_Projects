import React from 'react'
import { Meta, Story } from '@storybook/react'
import { OrderHistoryComponentType } from '../../../types/content'
import OrderHistory from './OrderHistory'

export default {
  title: 'Components/organisms/OrderHistory',
  component: OrderHistory,
} as Meta

const Template: Story<OrderHistoryComponentType> = (args) => (
  <OrderHistory {...args} />
)

export const Default = Template.bind({})

Default.args = {
  type: 'OrderHistory',
}
