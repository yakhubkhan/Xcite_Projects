import React from 'react'
import { useTranslation } from 'next-i18next'
import { connectStateResults, HierarchicalMenu } from 'react-instantsearch-dom'
import { useSelector } from 'react-redux'
import { facetsHeadingsSelector } from '../../../redux/slices/app'
import { AccordionItem } from '../../molecules/Accordion/Accordion'

const CategoryWrapper = ({
  name,
  attributes,
  categoryName,
  getFacetHeading,
  facets,
}: {
  name: string
  attributes: string[]
  categoryName: string
  getFacetHeading: (facetsHeadings, name) => string
  facets: Record<string, Record<string, number>>
}): JSX.Element => {
  const { t } = useTranslation()
  const facetsHeadings = useSelector(facetsHeadingsSelector)
  const StateResults = ({ allSearchResults }) => {
    const rawResults = allSearchResults._rawResults
    return (
      <p className="pl-1 rtl:pr-1 rtl:pl-0">
        ({rawResults[rawResults.length - 1].nbHits})
      </p>
    )
  }
  const CustomStateResults = connectStateResults(StateResults)

  const getCategoryRootPath = () => {
    let categoryRootPath = ''

    Object.keys(facets).forEach((facetName) => {
      if (categoryRootPath) return
      if (attributes.includes(facetName)) {
        const categoryFacet = facets[facetName]

        categoryRootPath = Object.keys(categoryFacet).filter(
          (categoryFacetName) => categoryFacetName.includes(categoryName)
        )[0]
      }
    })

    return categoryRootPath
  }

  return (
    <AccordionItem
      key={name}
      item={{
        id: name,
        title: getFacetHeading(facetsHeadings, name),
        content: (
          <>
            <span className="typography-default-strong flex mb-1">
              {categoryName || t('search_category_facets_all_products')}
              <CustomStateResults />
            </span>
            <HierarchicalMenu
              attributes={attributes}
              rootPath={categoryName !== '' ? getCategoryRootPath() : ''}
              showMore
              limit={10}
              showMoreLimit={1000}
              translations={{
                showMore(expanded) {
                  return expanded
                    ? t('search_facets_brand_showLess')
                    : t('search_facets_brand_showMore')
                },
              }}
            />
          </>
        ),
        isOpen: true,
      }}
    ></AccordionItem>
  )
}

export default CategoryWrapper
