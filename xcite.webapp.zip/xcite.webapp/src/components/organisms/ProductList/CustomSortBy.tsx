import React from 'react'
import { connectSortBy } from 'react-instantsearch-dom'

import { AlgoliaSortType } from '../../../types/algolia'
import Sort from '../../molecules/Sort'
import { useTranslation } from 'next-i18next'

const CustomSort = connectSortBy(Sort)

const tempSortLookupTable: AlgoliaSortType = {
  relevancy: 'search_sort_relevancy',
  newArrivals: 'search_sort_new_label',
  priceAsc: 'search_sort_priceAsc_label',
  priceDesc: 'search_sort_priceDesc_label',
  biggestOffer: 'search_sort_biggestOffer_label',
}

const CustomSortBy = (props: {
  sortOptions: AlgoliaSortType
  defaultSort: string
}): JSX.Element => {
  const { t } = useTranslation()

  return (
    <div className="cmn-flex-items-center justify-between">
      <span className="typography-default-strong pr-3 w-32">
        {t('search_sort_dropdown_label')}
      </span>
      <CustomSort
        defaultRefinement={props.defaultSort}
        items={Object.keys(props.sortOptions).map((sortIndexKey) => ({
          value: props.sortOptions[sortIndexKey],
          label: t(tempSortLookupTable[sortIndexKey]),
        }))}
      />
      <hr />
    </div>
  )
}

export default CustomSortBy
