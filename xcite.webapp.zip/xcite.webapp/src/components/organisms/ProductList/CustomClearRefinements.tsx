import React from 'react'
import { connectCurrentRefinements } from 'react-instantsearch-dom'

import { ButtonVariantEnum } from '../../../types/content'
import Button from '../../atoms/Button'
import { useTranslation } from 'next-i18next'

const ClearRefinements = ({ items, refine }) => {
  const { t } = useTranslation()
  return (
    <Button onClick={() => refine(items)} variant={ButtonVariantEnum.textLink}>
      {t('search_facets_reset_button_label')}
    </Button>
  )
}

export default connectCurrentRefinements(ClearRefinements)
