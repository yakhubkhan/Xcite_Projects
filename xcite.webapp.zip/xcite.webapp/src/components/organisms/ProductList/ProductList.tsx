import React, { useCallback, useEffect, useState } from 'react'
import { useTranslation } from 'next-i18next'

import { AlgoliaSortType } from '../../../types/algolia'
import { useWindowSize } from '../../../hooks'
import Grid from '../../atoms/Grid'
import { FilterSortIcon } from '../../atoms/Icon'
import styles from '../ProductList/ProductList.module.css'
import CustomHits from './CustomHits'
import CustomStats from './CustomStats'
import Facets from './Facets'
import CustomSortBy from './CustomSortBy'

const ProductList = ({
  hrefLang,
  categoryName = '',
  algoliaSortIndexNames,
  defaultSort,
  query,
  facets,
}: {
  hrefLang: string
  categoryName?: string
  algoliaSortIndexNames: AlgoliaSortType
  defaultSort: string
  query: string
  facets: Record<string, Record<string, number>>
}): JSX.Element => {
  const { width: windowWidth } = useWindowSize()
  const [showFacets, setShowFacets] = useState(false)
  const { t } = useTranslation()

  const toggleScrollBlocking = useCallback(() => {
    if (windowWidth && windowWidth < 768 && showFacets) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = 'unset'
    }
  }, [showFacets, windowWidth])

  useEffect(() => {
    if (showFacets) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = 'unset'
    }
    return () => {
      document.body.style.overflow = 'unset'
    }
  }, [showFacets])

  useEffect(() => {
    window.addEventListener('resize', toggleScrollBlocking)
    return () => {
      window.removeEventListener('resize', toggleScrollBlocking)
    }
  }, [toggleScrollBlocking])

  return (
    <>
      <Grid className={styles.listWrapper}>
        <Facets
          showFacets={showFacets}
          onCloseFacets={() => setShowFacets(false)}
          sortOptions={algoliaSortIndexNames}
          defaultSort={defaultSort}
          categoryName={categoryName}
          facets={facets}
        />
        <div
          data-insights-index={query}
          className="col-span-full flex justify-between items-end md:col-span-9 md:px-5"
        >
          <CustomStats categoryName={categoryName} />
          <div className="hidden md:block">
            <CustomSortBy
              sortOptions={algoliaSortIndexNames}
              defaultSort={defaultSort}
            />
          </div>
          <button
            className="typography-small text-gray-900 flex items-center gap-x-2 md:hidden"
            onClick={() => setShowFacets(true)}
          >
            {t('search_facets_heading_label')}
            <FilterSortIcon className="w-6 h-6 fill-current" />
          </button>
        </div>
        <div className="col-span-4 sm:col-span-12 md:col-span-9">
          <CustomHits hrefLang={hrefLang} facets={facets} query={query} />
        </div>
      </Grid>
    </>
  )
}

export default ProductList
