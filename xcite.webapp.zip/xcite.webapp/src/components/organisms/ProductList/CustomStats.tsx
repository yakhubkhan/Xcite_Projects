import { useTranslation } from 'next-i18next'
import React from 'react'
import { connectStats } from 'react-instantsearch-dom'
import { HeadingEnum } from '../../../types/content'
import Heading from '../../atoms/Heading'

const Stats = ({ nbHits, nbSortedHits, categoryName }) => {
  const { t } = useTranslation()
  const displayedHitsAmount = nbSortedHits ? nbSortedHits : nbHits
  return (
    <div>
      <Heading type={HeadingEnum.h1} className="text-xl leading-4">
        {categoryName
          ? categoryName
          : displayedHitsAmount <= 0
          ? t('search_results_heading_label_no_results')
          : t('search_results_heading_label')}
      </Heading>
      <p className="typography-small text-gray-600">
        {t('search_results_products_label', { hits: displayedHitsAmount })}
      </p>
    </div>
  )
}

export default connectStats(Stats)
