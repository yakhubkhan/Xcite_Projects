import { useTranslation } from 'next-i18next'
import React from 'react'
import {
  connectRange,
  connectToggleRefinement,
  DynamicWidgets,
  Panel,
  RefinementList,
} from 'react-instantsearch-dom'
import { useSelector } from 'react-redux'
import { AlgoliaSortType } from '../../../types/algolia'
import { AmplienceSpecificationAttribute } from '../../../types/amplience'
import { facetsHeadingsSelector } from '../../../redux/slices/app'
import { AccordionItem } from '../../molecules/Accordion/Accordion'
import RangeSlider from '../../molecules/RangeSlider'
import ToggleRefinement from '../../molecules/ToggleRefinement'
import CustomClearRefinements from './CustomClearRefinements'
import CustomSortBy from './CustomSortBy'
import CustomStatsFacetsBtn from './CustomStatsFacetsBtn'
import CategoryWrapper from './CategoryWrapper'

const CustomRangeSlider = connectRange(RangeSlider)
const CustomToggleRefinement = connectToggleRefinement(ToggleRefinement)
let usedFacets

const Facets = (props: {
  showFacets: boolean
  onCloseFacets: () => void
  sortOptions: AlgoliaSortType
  defaultSort: string
  categoryName: string
  facets: Record<string, Record<string, number>>
}): JSX.Element => {
  usedFacets = props.facets

  return (
    <div
      className={`${
        props.showFacets ? 'block' : 'hidden'
      } fixed top-0 right-0 left-0 bottom-0 bg-white z-20 overflow-x-hidden overflow-y-auto md:static md:block md:col-span-3 md:row-span-2 md:px-2 md:z-auto md:bg-gray-50 search-facets`}
    >
      <div className="flex justify-between items-center bg-gray-50 py-6 px-5 md:bg-transparent md:px-0 md:pb-0">
        <CustomClearRefinements />
        <CustomStatsFacetsBtn onCloseFacets={props.onCloseFacets} />
      </div>
      <div className="px-5 pb-6 md:p-0">
        <div className="py-8 border-b border-b-gray-300 md:hidden">
          <CustomSortBy
            sortOptions={props.sortOptions}
            defaultSort={props.defaultSort}
          />
        </div>
        <DynamicWidgets
          fallbackComponent={FallbackComponent}
          attributesToRender={['*']}
        >
          <CategoryWrapper
            name={'categoryNames'}
            attributes={[
              'categories.lvl0',
              'categories.lvl1',
              'categories.lvl2',
              'categories.lvl3',
            ]}
            categoryName={props.categoryName}
            getFacetHeading={getFacetHeading}
            facets={props.facets}
          />
          <PriceWrapper attribute="price" />
          <StockWrapper attribute="inStock" />
        </DynamicWidgets>
      </div>
    </div>
  )
}

const getFacetHeading = (
  facetsHeadings: AmplienceSpecificationAttribute[] | undefined,
  attribute: string
) => facetsHeadings?.find((facet) => facet.key === attribute)?.heading || ''

function PriceWrapper({ attribute }) {
  const facetsHeadings = useSelector(facetsHeadingsSelector)
  return (
    <AccordionItem
      key={attribute}
      item={{
        id: attribute,
        title: getFacetHeading(facetsHeadings, attribute),
        content: <CustomRangeSlider attribute={attribute} />,
        isOpen: true,
      }}
    ></AccordionItem>
  )
}

function StockWrapper({ attribute }) {
  const { t } = useTranslation()
  const facetsHeadings = useSelector(facetsHeadingsSelector)
  return (
    <div
      key={attribute}
      className="cmn-flex-items-center justify-between py-8 border-b border-b-gray-300"
    >
      <span className="typography-default-strong pr-3">
        {getFacetHeading(facetsHeadings, attribute)}
      </span>
      <CustomToggleRefinement
        attribute="inStock"
        label={t('search_facets_onlyInStock_label')}
        value="true"
      />
    </div>
  )
}

function FallbackComponent({ attribute }) {
  const { t } = useTranslation()
  const facetsHeadings = useSelector(facetsHeadingsSelector)
  const currentHeading = getFacetHeading(facetsHeadings, attribute)
  const currentFacet = usedFacets[attribute]
  const isFacetUsed = currentFacet && currentHeading

  return isFacetUsed ? (
    <Panel>
      <AccordionItem
        key={attribute}
        item={{
          id: attribute,
          title: currentHeading,
          content: (
            <RefinementList
              key={attribute}
              attribute={attribute}
              searchable
              showMore={Object.entries(currentFacet).length > 10 ? true : false}
              translations={{
                noResults: t('search_facets_brand_search_noResults'),
                placeholder: t('search_facets_brand_search_placeholder'),
              }}
            />
          ),
          isOpen: true,
        }}
      />
    </Panel>
  ) : null
}

export default Facets
