import { useTranslation } from 'next-i18next'
import React from 'react'
import { connectStats } from 'react-instantsearch-dom'

import { ButtonVariantEnum } from '../../../types/content'
import Button from '../../atoms/Button'

const CustomStatsFacetsBtn = ({ nbHits, onCloseFacets }) => {
  const { t } = useTranslation()
  return (
    <Button
      variant={ButtonVariantEnum.primaryOnLight}
      className="rounded-full py-2 md:hidden"
      onClick={onCloseFacets}
    >
      <p>{t('search_facets_results_button_label', { hits: nbHits })}</p>
    </Button>
  )
}

export default connectStats(CustomStatsFacetsBtn)
