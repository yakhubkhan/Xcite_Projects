import { useTranslation } from 'next-i18next'
import React from 'react'
import { CartShippingDetails } from '../../../types/content'
import SelectionBox from '../../atoms/SelectionBox'
import DeliveryDetails from '../../molecules/DeliveryDetails'

type Props = {
  shippingDetails: CartShippingDetails
  onSelectDeliveryMethod: () => void
}

const DeliveryMethod = ({
  shippingDetails,
  onSelectDeliveryMethod,
}: Props): JSX.Element => {
  const { t } = useTranslation()
  const detail = DeliveryDetails(shippingDetails.deliveryMethod)
  if (!detail) {
    return <></>
  }
  const icon = React.createElement(detail.icon, {
    className: 'h-6 w-6 stroke-current',
  })

  return (
    <SelectionBox
      value={shippingDetails.key}
      disabled={!shippingDetails.enabled}
      checked={shippingDetails?.selected || false}
      onValChange={() => onSelectDeliveryMethod()}
      extraClassName="items-start"
    >
      <span className="flex gap-3 typography-small items-start">
        {icon}
        <div className="flex-1">
          <div className="typography-small">{t(detail.translationKey)}</div>
          <div className="typography-small-strong">
            {shippingDetails.deliveryCharge?.formattedPrice
              ? `+${shippingDetails.deliveryCharge?.formattedPrice}`
              : t('deliveryMethod_free')}
          </div>
        </div>
      </span>
    </SelectionBox>
  )
}

export default DeliveryMethod
