import { useTranslation } from 'next-i18next'
import React, { useState } from 'react'
import { CartShippingDetails } from '../../../types/content'
import SelectionBox from '../../atoms/SelectionBox'
import DeliveryDetails from '../../molecules/DeliveryDetails'
import Promolist from '../Promolist/Promolist'
type Props = {
  shippingDetails: CartShippingDetails
  onSelectDeliveryMethod: () => void
}

const DeliveryMethod = ({
  shippingDetails,
  onSelectDeliveryMethod,
}: Props): JSX.Element => {
  const { t } = useTranslation()
  const detail = DeliveryDetails(shippingDetails.deliveryMethod)
  const [showTooltip, setShowTooltip] = useState(false)
  if (!detail) {
    return <></>
  }
  const icon = React.createElement(detail.icon, {
    className: 'h-6 w-6 stroke-current',
  })
  // const [showTooltip, setShowTooltip] = useState(false)
  const imageClick = () => {
    setShowTooltip(!showTooltip)
  }
  return (
    <SelectionBox
      value={shippingDetails.key}
      disabled={!shippingDetails.enabled}
      checked={shippingDetails?.selected || false}
      onValChange={() => onSelectDeliveryMethod()}
      extraClassName="items-start"
    >
      <span className="flex gap-3 typography-small items-start">
        {icon}
        <div className="flex-1">
          <div className="typography-small">{t(detail.translationKey)}</div>
          <div className="typography-small-strong">
            {shippingDetails.deliveryCharge?.formattedPrice
              ? `+${shippingDetails.deliveryCharge?.formattedPrice}`
              : t('deliveryMethod_free')}
          </div>
        </div>
        <div>
          {shippingDetails.deliveryMethod?.name.indexOf('Express') > 0 && (
            <img
              alt="movieposter"
              src={'/assets/icons/information-circle.svg'}
              className="d-flex justify-content-start m-3"
              id="movie"
              onClick={() => imageClick()}
            />
          )}
        </div>
        {showTooltip && (
          <Promolist
            promoHeading=""
            promoDetail={
              shippingDetails.deliveryMethod?.name.indexOf('1-Hour-Express') >
              -1
                ? t('pdp_product_shipping_express_delivery_1hrs_content')
                : shippingDetails.deliveryMethod?.name.indexOf(
                    '2-Hours-Express'
                  ) > -1
                ? t('pdp_product_shipping_express_delivery_2hrs_content')
                : shippingDetails.deliveryMethod?.name.indexOf(
                    '3-Hours-Express'
                  ) > -1
                ? t('pdp_product_shipping_express_delivery_2hrs_content')
                : ''
            }
            termHeading=""
            termDetail=""
            onCloseModal={() => setShowTooltip(false)}
          />
        )}
      </span>
    </SelectionBox>
  )
}

export default DeliveryMethod
