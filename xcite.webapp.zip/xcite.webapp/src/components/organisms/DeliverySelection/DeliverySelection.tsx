import { useTranslation } from 'next-i18next'
import { useRouter } from 'next/router'
import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import {
  cartAddressDisplayRequiredSelector,
  cartGroupSelector,
  cartOverviewThunk,
  cartTotalItemsSelector,
  updateShippingMethodThunk,
  groupingCartStatusSelector,
  resetGroupingStatusAction,
  cartShippingAddressSelector,
  cartBillingAddressSelector,
  isDeliverySelectionCompletedSelector,
  cartMessagesSelector,
  cartVersionSelector,
  isCartVerified,
} from '../../../redux/slices/cart'
import { namedLinksSelector } from '../../../redux/slices/navigation'
import { userProfileSelector } from '../../../redux/slices/profile'
import {
  AsyncResponseStatusEnum,
  ButtonVariantEnum,
  HeadingEnum,
} from '../../../types/content'
import gtmDatalayer from '../../../util/gtmUtils'
import Button from '../../atoms/Button'
import Heading from '../../atoms/Heading'
import LoadingIndicator from '../../atoms/LoadingIndicator'
import Segment from '../../atoms/Segment'
import CheckoutPageWrapper from '../../molecules/CheckoutPageWrapper'
import VerifyCartWrapper from '../../molecules/VerifyCartWrapper'
import OrderSummary from '../OrderSummary'
import DeliveryGroup from './DeliveryGroup'

const DeliverySelection = (): JSX.Element => {
  const router = useRouter()
  
  const { t } = useTranslation()
  
  const dispatch = useDispatch()
  const addressDisplayRequired = useSelector(cartAddressDisplayRequiredSelector)
  const cartGroups = useSelector(cartGroupSelector)
  const user = useSelector(userProfileSelector)
  const totalItems = useSelector(cartTotalItemsSelector)
  const groupingCartStatus = useSelector(groupingCartStatusSelector)
  const shippingAddress = useSelector(cartShippingAddressSelector)
  const billingAddress = useSelector(cartBillingAddressSelector)
  const namedLinks = useSelector(namedLinksSelector)
  const isDeliverySelectionCompleted = useSelector(
    isDeliverySelectionCompletedSelector
  )
  const cartMessages = useSelector(cartMessagesSelector)
  const isCardVerfied = useSelector(isCartVerified)
  const {
    iso_639_1: language,
    country: { ctStore: store },
    hreflang,
  } = localesFactory.createFromHrefLang(router.locale).current
  
  const updateShippingMethod = (key: string, slug: string) => {
    dispatch(
      updateShippingMethodThunk({
        store,
        user,
        language,
        locale: hreflang,
        deliveryKey: key,
        groupSlug: slug,
      })
    )
  }
  
  useEffect(() => {
    return () => {
      dispatch(resetGroupingStatusAction())
    }
  }, [dispatch])

  useEffect(() => {
    if (
      user.id &&
      store &&
      totalItems > 0 &&
      groupingCartStatus === AsyncResponseStatusEnum.idle &&
      isCardVerfied == true
    ) {
      dispatch(cartOverviewThunk({ user, store, language, locale: hreflang }))
    }
  }, [
    dispatch,
    user,
    store,
    language,
    hreflang,
    totalItems,
    groupingCartStatus,
    isCardVerfied,
  ])
  const paymentOptionsToGtm = () => {
    gtmDatalayer('payment_options', 'Payment Options View', 'payment_options')
  }
  return (
    <CheckoutPageWrapper>
      <VerifyCartWrapper>
        <div className="col-span-4 leading-6 hidden sm:block lg:leading-8 sm:col-span-7 md:col-start-2 md:col-span-6">
          <Segment
            segments={[
              {
                value: addressDisplayRequired
                  ? t('checkout_shipping_segment_label')
                  : t('cart_checkout_billingAddress_label'),
                actionUri: '/checkout/shipping',
                completed: true,
              },
              {
                value: t('checkout_delivery_segment_label'),
                actionUri: '/checkout/delivery',
              },
              {
                value: t('checkout_payment_segment_label'),
                actionUri: '/checkout/payment',
                disabled: true,
              },
            ]}
            openSeg={1}
          />
        </div>
        <>
          {groupingCartStatus === AsyncResponseStatusEnum.loading && (
            <div className="grid col-span-full sm:col-span-7 sm:pb-8 md:col-start-2 md:col-span-6">
              <LoadingIndicator>{t('loadingIndicator_label')}</LoadingIndicator>
            </div>
          )}
          {groupingCartStatus === AsyncResponseStatusEnum.succeeded && (
            <>
              <div className="grid col-span-full sm:col-span-7 sm:pb-8 md:col-start-2 md:col-span-6">
                <div className="border-b border-gray-300 sm:border-none">
                  <Heading
                    type={HeadingEnum.h4}
                    className="pb-8 sm:bg-white sm:pt-8 sm:pb-4 sm:px-8"
                  >
                    {t('checkout_delivery_heading')}
                  </Heading>
                  <div className="flex flex-col gap-8">
                    {cartGroups?.map((group) =>
                      group.items.length > 0 ? (
                        <DeliveryGroup
                          key={group.slug}
                          group={group}
                          onUpdateShippingMethod={updateShippingMethod}
                        />
                      ) : null
                    )}
                  </div>
                  <div className="bg-white py-8 sm:p-8">
                    <Button
                      variant={ButtonVariantEnum.primaryOnLight}
                      className="w-full"
                      onClick={() => {
                        paymentOptionsToGtm(), router.push(namedLinks.payment)
                      }}
                      disabled={
                        !isDeliverySelectionCompleted || cartMessages.length > 0
                      }
                    >
                      {t('checkout_delivery_submit_button')}
                    </Button>
                  </div>
                </div>
              </div>
              <OrderSummary
                btnOrderSummaryLabel={t('checkout_summary_payment_button_pay')}
                btnVariant={ButtonVariantEnum.primaryCta}
                orderSummaryFrom="delivery"
                orderSummaryStatus={true}
                shippingAddress={shippingAddress}
                billingAddress={billingAddress}
                addressDisplayRequired={addressDisplayRequired}
              />
            </>
          )}
          {groupingCartStatus === AsyncResponseStatusEnum.failed && (
            <div className="grid col-span-full p-8 sm:col-span-7 md:col-start-2 md:col-span-6 bg-white">
              <p className="text-functional-red-800 mb-4">
                {t('checkout_delivery_grouping_failed_message')}
              </p>
              <Button
                variant={ButtonVariantEnum.secondaryOnLight}
                onClick={() =>
                  dispatch(
                    cartOverviewThunk({
                      user,
                      store,
                      language,
                      locale: hreflang,
                    })
                  )
                }
              >
                {t('checkout_delivery_grouping_failed_button')}
              </Button>
            </div>
          )}
        </>
      </VerifyCartWrapper>
    </CheckoutPageWrapper>
  )
}

export default DeliverySelection
