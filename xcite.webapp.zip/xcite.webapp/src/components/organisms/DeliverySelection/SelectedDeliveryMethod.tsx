import { useTranslation } from 'next-i18next'
import React from 'react'
import { CartShippingDetails } from '../../../types/content'
import DeliveryDetails from '../../molecules/DeliveryDetails'

type Props = { selectedMethod: CartShippingDetails }

const SelectedDeliveryMethod = ({ selectedMethod }: Props): JSX.Element => {
  const { t } = useTranslation()
  const detail = DeliveryDetails(selectedMethod.deliveryMethod)

  if (!detail) return <></>

  const icon = React.createElement(detail.icon, {
    className: 'inline-flex h-6 w-6 stroke-current',
  })

  const deliveryMethodName = t(detail.translationKey)

  const deliveryDate =
    selectedMethod.deliveryMethod.name === 'ScheduledDelivery' &&
    selectedMethod.deliveryDetails
      ? `${selectedMethod.deliveryDetails.localizedDate}, `
      : ''

  const deliveryCosts = selectedMethod.deliveryCharge?.formattedPrice
    ? `+${selectedMethod.deliveryCharge?.formattedPrice}`
    : t('cart_checkout_delivery_type_free')

  return (
    <div className="flex-1 ltr:text-right rtl:text-left typography-small">
      <span className="ltr:mr-2 rtl:ml-2">{icon}</span>
      <span>
        {deliveryMethodName},{' '}
        <strong>
          {deliveryDate}
          {deliveryCosts}
        </strong>
      </span>
    </div>
  )
}

export default SelectedDeliveryMethod
