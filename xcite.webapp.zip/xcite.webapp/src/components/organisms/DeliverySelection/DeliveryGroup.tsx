import { useTranslation } from 'next-i18next'
import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux'
import {
  cartMessagesSelector,
  cncAvailabilityDetailsSelector,
  expressSelectStatusStatusSelector,
  expressClickedGroupStatusSelector,
  expressDeliveryKeyStatusSelector,
} from '../../../redux/slices/cart'
import {
  CartGroup,
  StatusMessageEnum,
  AsyncResponseStatusEnum,
} from '../../../types/content'
import StatusMessage from '../../atoms/StatusMessage'
import ProductLineItem from '../ProductLineItem'
import DeliveryGroupHeading from './DeliveryGroupHeading'
import DeliveryMethods from './DeliveryMethods'
import SelectedDeliveryMethod from './SelectedDeliveryMethod'

type Props = {
  group: CartGroup
  onUpdateShippingMethod?: (key: string, slug: string) => void
  isReviewPage?: boolean
}

const DeliveryGroup = ({
  group,
  group: { items: groupItems },
  onUpdateShippingMethod,
  isReviewPage = false,
}: Props): JSX.Element => {
  const { t } = useTranslation()

  const cartMessages = useSelector(cartMessagesSelector)
  const cncAvailableDetails = useSelector(cncAvailabilityDetailsSelector)
  const expressSelectedMaxError = useSelector(expressSelectStatusStatusSelector)
  const expressClickedGroupSelector = useSelector(
    expressClickedGroupStatusSelector
  )
  const expressDeliverykeySelector = useSelector(
    expressDeliveryKeyStatusSelector
  )

  const [errorsInGroup, setErrorsInGroup] = useState(false)

  const getCnCAvailability = (sku: string) => {
    return cncAvailableDetails.some((data) => {
      if (data.sku === sku) {
        return data.available ? true : false
      }
    })
  }

  useEffect(() => {
    groupItems.forEach((item) => {
      cartMessages.forEach((message) => {
        if (message.skus.includes(item.sku)) {
          setErrorsInGroup(true)
        }
      })
    })
  }, [cartMessages, groupItems])

  return (
    <div className="pb-8 border-b border-gray-300 last:border-none sm:bg-white sm:border-none sm:p-8">
      <div className="flex justify-between mb-4 gap-8">
        <DeliveryGroupHeading groupSlug={group.slug} />

        {expressDeliverykeySelector == 'shipping-method-express-1h' &&
          group.slug === expressClickedGroupSelector &&
          expressSelectedMaxError === AsyncResponseStatusEnum.failed && (
            <p className="flex-1 typography-small text-functional-red-800">
              {t('shipping_method_express_1h_max_limit_error')}
            </p>
          )}
        {expressDeliverykeySelector == 'shipping-method-express-3h' &&
          group.slug === expressClickedGroupSelector &&
          expressSelectedMaxError === AsyncResponseStatusEnum.failed && (
            <p className="flex-1 typography-small text-functional-red-800">
              {t('shipping_method_express_3h_max_limit_error')}
            </p>
          )}
        {isReviewPage && group.selectedDeliveryMethod && group.completed && (
          <SelectedDeliveryMethod
            selectedMethod={group.selectedDeliveryMethod}
          />
        )}
      </div>
      {isReviewPage && group.selectedDeliveryMethod && !group.completed && (
        <StatusMessage
          type={StatusMessageEnum.Warning}
          className="mb-4"
          showIcon={true}
        >
          {t('checkout_summary_delivery_missing_slots_message')}
        </StatusMessage>
      )}
      <div
        className={`flex flex-col gap-6 sm:gap-12 ${
          !group.completed && isReviewPage ? 'opacity-10' : ''
        }`}
      >
        {!isReviewPage &&
          !errorsInGroup &&
          group.shippingDetails &&
          onUpdateShippingMethod && (
            <DeliveryMethods
              groupSlug={group.slug}
              enabled={group.enabled}
              deliveryTeam={group.deliveryTeam}
              shippingDetails={group.shippingDetails}
              onUpdateShippingMethod={onUpdateShippingMethod}
            />
          )}
        <ul className="flex flex-col gap-8">
          {groupItems.map((item) => (
            <li key={item.id}>
              <ProductLineItem
                item={item}
                pliFrom="revieworder" // TODO LMD: Check why pliFrom is needed
                cartMessages={cartMessages}
                cncAvailability={getCnCAvailability(item.sku)}
              />
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

export default DeliveryGroup
