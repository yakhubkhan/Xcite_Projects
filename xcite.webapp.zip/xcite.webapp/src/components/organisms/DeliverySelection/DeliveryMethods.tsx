import { useTranslation } from 'next-i18next'
import React from 'react'
import { CartShippingDetails, StatusMessageEnum } from '../../../types/content'
import StatusMessage from '../../atoms/StatusMessage'
import DeliveryMethod from './DeliveryMethod'
import ScheduledDeliveryMethod from './ScheduledDeliveryMethod'

type Props = {
  groupSlug: string
  enabled: boolean
  deliveryTeam: string
  shippingDetails: CartShippingDetails[]
  onUpdateShippingMethod: (key: string, slug: string) => void
}

const DeliveryMethods = ({
  groupSlug,
  enabled,
  deliveryTeam,
  shippingDetails,
  onUpdateShippingMethod,
}: Props): JSX.Element => {
  const { t } = useTranslation()

  return (
    <div className="relative">
      {!enabled && (
        <StatusMessage
          type={StatusMessageEnum.Warning}
          className="mb-4"
          showIcon={true}
        >
          {t('checkout_delivery_method_disabled_message')}
        </StatusMessage>
      )}
      <div
        className={`flex flex-col md:flex-row gap-3 ${
          enabled ? '' : 'opacity-10 pointer-events-none'
        }`}
      >
        {shippingDetails.map((details) => {
          return (
            <div key={details.key} className="flex flex-1/3">
              {details.deliveryChargeLimits ? (
                <ScheduledDeliveryMethod
                  shippingDetails={details}
                  minPrice={
                    details.deliveryChargeLimits.min.formattedPrice ||
                    t('deliveryMethod_free')
                  }
                  maxPrice={details.deliveryChargeLimits.max.formattedPrice}
                  deliveryTeam={deliveryTeam}
                  onSelectDeliveryMethod={() =>
                    onUpdateShippingMethod(details.key, groupSlug)
                  }
                  deliveryGroupSlug={groupSlug}
                />
              ) : (
                <DeliveryMethod
                  key={details.key}
                  shippingDetails={details}
                  onSelectDeliveryMethod={() =>
                    onUpdateShippingMethod(details.key, groupSlug)
                  }
                />
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}

export default DeliveryMethods
