import { useTranslation } from 'next-i18next'
import React from 'react'
import { HeadingEnum, ProductGroupEnum } from '../../../types/content'
import Heading from '../../atoms/Heading'

type Props = {
  groupSlug: string
}

const DeliveryGroupHeading = ({ groupSlug }: Props): JSX.Element => {
  const { t } = useTranslation()

  const groupNameMap = {
    [ProductGroupEnum.ClickAndCollect]: t('cart_store_available'),
    [ProductGroupEnum.DigitalProducts]: t('cart_checkout_digital_prod_label'),
    [ProductGroupEnum.HomeDelivery]: t('checkout_delivery_group_heading'),
  }

  const getGroupHeading = (slug: string) => {
    if (slug.includes(ProductGroupEnum.HomeDelivery)) {
      const groupSlugParts = slug.split('_')
      const groupName = groupSlugParts[0]
      const groupNumber = Number(groupSlugParts[1])
      return `${groupNameMap[groupName]} ${groupNumber}`
    }

    return groupNameMap[slug]
  }

  return <Heading type={HeadingEnum.h4}>{getGroupHeading(groupSlug)}</Heading>
}

export default DeliveryGroupHeading
