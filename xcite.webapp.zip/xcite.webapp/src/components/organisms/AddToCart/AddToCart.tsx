import { useRouter } from 'next/router'
import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'

import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import {
  addToCartThunk,
  cartItemsSelector,
  addToCartStatusSelector,
  resetAddToCartStatusAction,
} from '../../../redux/slices/cart'
import { resetSelectedWarrantyAction } from '../../../redux/slices/warranty'
import { userProfileSelector } from '../../../redux/slices/profile'
import {
  AsyncResponseStatusEnum,
  ButtonVariantEnum,
  ProductLineItemType,
  ToastType,
  ToastDuration,
} from '../../../types/content'
import Button from '../../atoms/Button'
import { CommercetoolsWarrantyItem } from '../../../types/raw/ctProduct'
import gtmDataLayer from '../../../util/gtmUtils'
import { CommercetoolsClickAndCollectOption } from '../../../types/api'
import Toaster from '../../atoms/Toaster'
import { useTranslation } from 'next-i18next'

type AddToCartProps = {
  children?: React.ReactNode
  buttonVariant?: ButtonVariantEnum
  className?: string
  pageType: string
  sku: string
  quantity?: number
  warranty?: CommercetoolsWarrantyItem
  onValidateBeforeAddToCart?: () => boolean
  disabled?: boolean
  cartClickAndCollectOption?: CommercetoolsClickAndCollectOption
}

const AddToCart = ({
  children,
  buttonVariant = ButtonVariantEnum.primaryCta,
  className = '',
  pageType,
  sku,
  quantity = 1,
  warranty = undefined,
  onValidateBeforeAddToCart = undefined,
  disabled = false,
  cartClickAndCollectOption = undefined,
}: AddToCartProps): JSX.Element => {
  const { t } = useTranslation()
  const router = useRouter()

  const dispatch = useDispatch()
  const user = useSelector(userProfileSelector)
  const addToCartStatus = useSelector(addToCartStatusSelector)
  const cartItems = useSelector(cartItemsSelector)

  const [maxQuantityReached, setMaxQuantityReached] = useState(false)
  const [isAddToCartClicked, setIsAddToCartClicked] = useState(false)
  const [showToastMsg, setShowToastMsg] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const {
    iso_639_1: language,
    country: { ctStore: store },
    hreflang,
  } = localesFactory.createFromHrefLang(router?.locale).current

  const getQuantitiesSum = (cartItems: ProductLineItemType[], sku: string) => {
    return cartItems
      .filter((item) => {
        return item.sku === sku
      })
      .reduce((currentValue, item) => {
        return currentValue + item.quantity
      }, 0)
  }

  const onAddToCart = (e: React.MouseEvent<HTMLInputElement>) => {
    e.preventDefault()
    let isValid = true
    if (onValidateBeforeAddToCart) {
      isValid = onValidateBeforeAddToCart()
    }
    if (isValid) {
      dispatch(
        addToCartThunk({
          sku,
          quantity,
          store,
          locale: hreflang,
          user,
          language,
          warranty,
          cartClickAndCollectOption,
        })
      )
      setIsAddToCartClicked(true)
    }
  }

  useEffect(() => {
    const currentItem = cartItems.find((item) => item.sku === sku)
    if (addToCartStatus === AsyncResponseStatusEnum.idle) {
      if (currentItem) {
        setMaxQuantityReached(
          getQuantitiesSum(cartItems, sku) >= currentItem.maxQuantity
        )
      } else if (typeof currentItem === 'undefined') {
        setMaxQuantityReached(false)
      }
    }
    if (
      addToCartStatus === AsyncResponseStatusEnum.succeeded &&
      isAddToCartClicked
    ) {
      setIsSuccess(true)
      setShowToastMsg(true)
      dispatch(resetSelectedWarrantyAction())
      dispatch(resetAddToCartStatusAction())
      setIsAddToCartClicked(false)

      if (cartItems) {
        if (currentItem) {
          const eventAction = { item: currentItem, eventAction: pageType }
          gtmDataLayer(
            'dh_add_to_cart',
            'product_detail_page_events',
            JSON.stringify(eventAction)
          )
          setMaxQuantityReached(
            getQuantitiesSum(cartItems, sku) >= currentItem.maxQuantity
          )
        } else if (typeof currentItem === 'undefined') {
          setMaxQuantityReached(false)
        }
      }
    }

    if (
      addToCartStatus === AsyncResponseStatusEnum.failed &&
      isAddToCartClicked
    ) {
      setIsSuccess(false)
      setShowToastMsg(true)
      dispatch(resetAddToCartStatusAction())
      setIsAddToCartClicked(false)
    }
  }, [addToCartStatus, cartItems, dispatch, isAddToCartClicked, sku])

  useEffect(() => {
    if (showToastMsg) {
      setTimeout(() => setShowToastMsg(false), ToastDuration)
    }
  }, [showToastMsg])

  return (
    <>
      <Button
        onClick={onAddToCart}
        variant={buttonVariant}
        disabled={
          addToCartStatus === AsyncResponseStatusEnum.loading ||
          maxQuantityReached ||
          disabled
        }
        className={className}
      >
        {children}
      </Button>
      {showToastMsg && (
        <Toaster
          toastMsg={
            isSuccess
              ? `${t('add_to_cart_success_message')}`
              : `${t('add_to_cart_failure_message')}`
          }
          duration={ToastDuration}
          className={`cmn-toast`}
          type={isSuccess ? ToastType.success : ToastType.error}
        />
      )}
    </>
  )
}

export default AddToCart
