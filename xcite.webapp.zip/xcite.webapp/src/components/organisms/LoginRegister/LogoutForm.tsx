import React from 'react'
import { useSelector } from 'react-redux'
import { namedLinksSelector } from '../../../redux/slices/navigation'
import { signOut } from '../../../lib/api/clients/authClient'
import { ButtonVariantEnum } from '../../../types/content'
import Button from '../../atoms/Button'
import Heading from '../../atoms/Heading'
import { CartIcon, ProfileIcon } from '../../atoms/Icon'
import { useTranslation } from 'next-i18next'

// eslint-disable-next-line
export const LogoutForm = ({
  handleModal,
  router,
  onSignOut,
  headingLevel,
}): JSX.Element => {
  const { t } = useTranslation()
  const namedLinks = useSelector(namedLinksSelector)
  return (
    <div>
      <Heading className="pb-5" type={headingLevel}>
        {t('user_form_login_message_success')}
      </Heading>
      <div className="my-5">
        <Button
          variant={ButtonVariantEnum.textLink}
          onClick={() => {
            if (handleModal) {
              handleModal()
            }
            router.push(namedLinks.profile)
          }}
          className="font-lexend no-underline text-base text-gray-900 font-bold"
        >
          <ProfileIcon className="w-6 h-6 stroke-gray-900" />
          {t('user_form_profile_account_heading')}
        </Button>
      </div>
      <div className="my-5">
        <Button
          variant={ButtonVariantEnum.textLink}
          onClick={() => {
            if (handleModal) {
              handleModal()
            }
            router.push(namedLinks.orderHistory)
          }}
          className="font-lexend no-underline text-base text-gray-900 font-bold"
        >
          <CartIcon className="stroke-gray-900" width={24} />
          {t('user_form_profile_orders_heading')}
        </Button>
      </div>
      <Button
        variant={ButtonVariantEnum.primaryOnLight}
        className="mt-5 w-full"
        onClick={async () => {
          await signOut()
          if (handleModal) {
            handleModal()
          }
          await onSignOut()
          // TODO need to enhance routing
          await router.push('/')
        }}
      >
        {t('user_form_generic_logout_label')}
      </Button>
    </div>
  )
}
