import React, { useEffect, useState } from 'react'
import { Hub } from 'aws-amplify'
import { useDispatch, useSelector } from 'react-redux'
import { useRouter } from 'next/router'
import { useTranslation } from 'next-i18next'

import {
  confirmSignUp,
  forgotPassword,
  forgotPasswordSubmit,
  signIn,
  signUp,
} from '../../../lib/api/clients/authClient'
import {
  getCustomerExists,
  getEnumByResource,
} from '../../../lib/api/clients/customer'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import {
  getUserProfileThunk,
  postUserProfileThunk,
  setAnonymousUserAction,
  userProfileSelector,
} from '../../../redux/slices/profile'
import { namedLinksSelector } from '../../../redux/slices/navigation'
import {
  LoginRegisterStateEnum,
  UserProfileType,
  HeadingEnum,
  ResourceEnumType,
} from '../../../types/content'
import {
  emailValidationRegex,
  phoneValidationRegex,
} from '../../../util/formValidation'
import { moengageUtils } from '../../../util/moengageUtils'
import BackButton from '../../molecules/BackButton'
import { LoginRegisterForm } from './LoginRegisterForm'
import { WelcomeForm } from './WelcomeForm'
import { LogoutForm } from './LogoutForm'
import gtmDatalayer from '../../../util/gtmUtils'
import CtStore from '../../../lib/api/l18n/CtStore'

const initAuthData = {
  field: '',
  message: '',
  type: '',
}

const LoginRegister = ({
  handleModal,
  handleViewMode,
  headingLevel,
}: {
  handleModal?: (value: any) => void | undefined
  handleViewMode?: (value: string) => void | undefined
  headingLevel?: HeadingEnum
}): JSX.Element => {
  const router = useRouter()
  const { locale } = router
  const { t } = useTranslation()

  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [email, setEmail] = useState('')
  const [emailErrorMessage, setEmailErrorMessage] = useState('')
  const [phoneErrorMessage, setPhoneErrorMessage] = useState('')
  const [usernameErrorMessage, setUsernameErrorMessage] = useState('')
  const [phonenumber, setPhonenumber] = useState('')
  const [nationality, setNationality] = useState('')
  const [gender, setGender] = useState('')
  const [maritalStatus, setMaritalStatus] = useState('')
  const [dateOfBirth, setDateOfBirth] = useState('')
  const [togglePassword, setTogglePassword] = useState(true)
  const [authenticationCode, setAuthenticationCode] = useState('')
  const [authDataPayload, setAuthDataPayload] = useState(initAuthData)
  const [viewMode, setViewMode] = useState(LoginRegisterStateEnum.init)
  const [currUser, setCurrUser] = useState<UserProfileType>(
    {} as UserProfileType
  )
  const [displayWelcome, setDisplayWelcome] = useState(false)
  const [disableWelcomeSubmitBtn, setDisableWelcomeSubmitBtn] = useState(true)
  const [displayFPSuccess, setDisplayFPSuccess] = useState(false)
  const [mfaMethod, setMfaMethod] = useState('')
  const [profileEnum, setProfileEnum] = useState<ResourceEnumType>()
  const [moEngageToggle, setMoEngageToggle] = useState(false)
  const dispatch = useDispatch()
  const user = useSelector(userProfileSelector)
  const namedLinks = useSelector(namedLinksSelector)

  const onSignOut = () => dispatch(setAnonymousUserAction())
  const {
    hreflang: localeKey,
    country: { ctStore: store, id: currentCountry },
  } = localesFactory.createFromHrefLang(locale).current

  const getUserProfile = (signedUser) => {
    const profilePromise = new Promise(function (resolve, reject) {
      resolve(dispatch(getUserProfileThunk(signedUser?.username)))
    })
    profilePromise.then(
      (result) => {
        gtmDatalayer('login', 'login', 'login')
      },
      function (error) {
        console.log(error)
      }
    )
  }

  useEffect(() => {
    setCurrUser(user)
    setDateOfBirth(user?.dateOfBirth || '')
    setEmail(user?.email || '')
    setFirstName(user?.firstName || '')
    setGender(user?.gender || '')
    setLastName(user?.lastName || '')
    setMaritalStatus(user?.maritalStatus || '')
    setNationality(user?.nationality || '')
    setPhonenumber(user?.phonenumber || '')
    const authListenerErrorHandler = async (authChannelData) => {
      const {
        data: { name, message, codeDeliveryDetails },
        event,
      } = authChannelData.payload
      if (event === 'signUp') {
        codeDeliveryDetails && setMfaMethod(codeDeliveryDetails?.DeliveryMedium)
      }
      if (event === 'confirm_signup') {
        setDisplayWelcome(true)
      }
      if (event === 'forgotPasswordSubmit') {
        setDisplayFPSuccess(true)
      }
      if (name === 'UsernameExistsException') {
        setAuthDataPayload({
          field: 'username',
          message: t('username_exists_exception_error'),
          type: 'err',
        })
      } else if (name === 'InvalidPasswordException') {
        setAuthDataPayload({ field: 'password', message: message, type: 'err' })
      } else if (
        name === 'CodeMismatchException' ||
        name === 'ExpiredCodeException'
      ) {
        setAuthDataPayload({
          field: 'regverify',
          message: message,
          type: 'err',
        })
      } else if (event === 'forgotPasswordSubmit_failure') {
        setAuthDataPayload({ field: 'password', message: message, type: 'err' })
      } else {
        setAuthDataPayload({
          field: 'all',
          message:
            message === 'Incorrect username or password.'
              ? t('invalid_user_name_password')
              : authDataPayload.message,
          type: '',
        })
      }
    }

    Hub.listen('authChannel', authListenerErrorHandler)
    return () => {
      Hub.remove('authChannel', authListenerErrorHandler)
    }
  }, [user])

  useEffect(() => {
    if (handleViewMode) {
      handleViewMode(viewMode)
    }
  }, [handleViewMode, viewMode])

  const handleLoginRegisterFormSubmit = async (e) => {
    setAuthDataPayload(initAuthData)
    e.preventDefault()
    const anonymousId = user.authenticated
      ? localStorage.getItem('anonymousId') || ''
      : user.id

    if (!username.match(emailValidationRegex)) {
      setUsernameErrorMessage(t('user_form_login_username_validation_message'))
      return
    }
    setUsernameErrorMessage('')

    if (viewMode === LoginRegisterStateEnum.init) {
      try {
        const custStatus = await getCustomerExists(username)
        if (custStatus?.mfaMethod) setMfaMethod(custStatus.mfaMethod)
        if (custStatus.customerStatus.toUpperCase() === 'UNKNOWN') {
          setViewMode(LoginRegisterStateEnum.register)
        } else if (custStatus.customerStatus.toUpperCase() === 'UNCONFIRMED') {
          setViewMode(LoginRegisterStateEnum.regVerify)
        } else {
          setViewMode(LoginRegisterStateEnum.login)
        }
      } catch (err) {}
    } else if (viewMode === LoginRegisterStateEnum.login) {
      try {
        const signedUser = await signIn({
          username,
          password,
          anonymousId,
          store,
        })
        if (!displayWelcome && router.asPath.indexOf(namedLinks.login) === 0) {
          await router.push(namedLinks.home)
        }
        setPassword('')
        getUserProfile(signedUser)
        if (displayWelcome) {
          const query =
            'enumAttribute=gender&enumAttribute=nationality&enumAttribute=marital-status'
          const enumData = await getEnumByResource({
            localeKey: localeKey,
            resourceId: 'customer',
            query: query,
          })
          setProfileEnum(enumData)
          setViewMode(LoginRegisterStateEnum.welcome)
        } else {
          if (handleModal) {
            handleModal(undefined)
          }
        }
      } catch (err) {
        console.log(err)
      }
    } else if (viewMode === LoginRegisterStateEnum.register) {
      try {
        await signUp({ username, password, anonymousId, store })
        setPassword('')
        setViewMode(LoginRegisterStateEnum.regVerify)
      } catch (err) {}
    } else if (viewMode === LoginRegisterStateEnum.regVerify) {
      try {
        await confirmSignUp({
          username,
          authenticationCode,
        })
        setViewMode(LoginRegisterStateEnum.login)
      } catch (err) {
        if (err instanceof Error) {
          if (err?.name === 'LimitExceededException') {
            setAuthDataPayload({
              field: 'regverify',
              message: t('invalid_limit_exceeded_exception_verification_code'),
              type: 'err',
            })
          } else if (err?.name === 'CodeMismatchException') {
            setAuthDataPayload({
              field: 'regverify',
              message: t('invalid_verification_code'),
              type: 'err',
            })
          } else {
            setAuthDataPayload({
              field: 'regverify',
              message: err?.message,
              type: 'err',
            })
          }
        }
      }
    } else if (viewMode === LoginRegisterStateEnum.forgotPassword) {
      try {
        await forgotPassword({
          username,
        })
        setViewMode(LoginRegisterStateEnum.fpVerify)
      } catch (err) {
        console.log(err)
      }
    } else if (viewMode === LoginRegisterStateEnum.fpVerify) {
      try {
        await forgotPasswordSubmit({
          username,
          authenticationCode,
          password,
        })
        setViewMode(LoginRegisterStateEnum.login)
      } catch (err) {
        if (err instanceof Error) {
          if (err?.name === 'LimitExceededException') {
            setAuthDataPayload({
              field: 'regverify',
              message: t('invalid_limit_exceeded_exception_verification_code'),
              type: 'err',
            })
          } else if (err?.name === 'CodeMismatchException') {
            console.log(err?.name)
            setAuthDataPayload({
              field: 'regverify',
              message: t('invalid_verification_code'),
              type: 'err',
            })
          } else {
            setAuthDataPayload({
              field: 'regverify',
              message: err?.message,
              type: 'err',
            })
          }
        }
      }
    }
  }

  const handleWelcomeFormSubmit = async (e) => {
    e.preventDefault()
    if (
      (!email || email.match(emailValidationRegex)) &&
      (!phonenumber || phonenumber.match(phoneValidationRegex[currentCountry]))
    ) {
      setEmailErrorMessage('')
      setPhoneErrorMessage('')
      try {
        const profileData = {
          dateOfBirth: dateOfBirth || null,
          email: email || null,
          firstName: firstName || null,
          gender: gender || null,
          lastName: lastName || null,
          maritalStatus: maritalStatus || null,
          nationality: nationality || null,
          phonenumber: phonenumber || null,
        }
        const payload = {
          ctUserName: currUser?.id,
          profileData,
        }
        await dispatch(postUserProfileThunk(payload))
        moEngageToggle && moengageUtils(profileData)
        if (router.asPath.indexOf(namedLinks.login) === 0) {
          router.push(namedLinks.home)
        } else if (handleModal) {
          handleModal(undefined)
        } else {
          setViewMode(LoginRegisterStateEnum.init)
          setDisplayWelcome(false)
        }
      } catch (err) {}
    } else {
      if (email && !email.match(emailValidationRegex)) {
        setEmailErrorMessage(t('checkout_shipping_address_validation_email'))
      }
      if (
        phonenumber &&
        !phonenumber.match(phoneValidationRegex[currentCountry])
      ) {
        setPhoneErrorMessage(
          t('checkout_shipping_address_validation_primary_phone')
        )
      }
    }
  }

  useEffect(() => {
    if (moEngageToggle && email.length <= 0) {
      setDisableWelcomeSubmitBtn(true)
    } else {
      setDisableWelcomeSubmitBtn(false)
    }
  }, [email.length, moEngageToggle])

  const modalBack = async () => {
    setViewMode(LoginRegisterStateEnum.init)
    setAuthDataPayload(initAuthData)
  }

  return (
    <>
      {viewMode !== LoginRegisterStateEnum.init &&
        viewMode !== LoginRegisterStateEnum.welcome &&
        !currUser.authenticated && (
          <div className="relative">
            <div className="absolute">
              <BackButton onClick={modalBack} />
            </div>
          </div>
        )}
      {!currUser.authenticated &&
        viewMode !== LoginRegisterStateEnum.welcome && (
          <LoginRegisterForm
            authDataPayload={authDataPayload}
            authenticationCode={authenticationCode}
            mfaMethod={mfaMethod}
            displayFPSuccess={displayFPSuccess}
            displayWelcome={displayWelcome}
            handleLoginRegisterFormSubmit={handleLoginRegisterFormSubmit}
            initAuthData={initAuthData}
            loginRegisterFrom="loginregister"
            password={password}
            setAuthDataPayload={setAuthDataPayload}
            setAuthenticationCode={setAuthenticationCode}
            setPassword={setPassword}
            setUsername={setUsername}
            setViewMode={setViewMode}
            setTogglePassword={setTogglePassword}
            togglePassword={togglePassword}
            username={username}
            viewMode={viewMode}
            headingLevel={headingLevel}
            usernameErrorMessage={usernameErrorMessage}
          />
        )}
      {currUser.authenticated &&
        viewMode === LoginRegisterStateEnum.welcome && (
          <WelcomeForm
            dateOfBirth={dateOfBirth || ''}
            email={email || ''}
            emailVerified={currUser.emailVerified || false}
            firstName={firstName || ''}
            gender={gender || currUser.gender || ''}
            handleWelcomeFormSubmit={handleWelcomeFormSubmit}
            lastName={lastName || ''}
            maritalStatus={maritalStatus || ''}
            moEngageToggle={moEngageToggle}
            nationality={nationality || ''}
            phonenumber={phonenumber || ''}
            phoneNumberVerified={currUser.phoneNumberVerified || false}
            profileEnum={profileEnum}
            setDateOfBirth={setDateOfBirth}
            setEmail={setEmail}
            setFirstName={setFirstName}
            setGender={setGender}
            setLastName={setLastName}
            setMaritalStatus={setMaritalStatus}
            setMoEngageToggle={setMoEngageToggle}
            setNationality={setNationality}
            setPhonenumber={setPhonenumber}
            disableWelcomeSubmitBtn={disableWelcomeSubmitBtn}
            emailErrorMessage={emailErrorMessage}
            phoneErrorMessage={phoneErrorMessage}
          />
        )}
      {currUser.authenticated &&
        !displayWelcome &&
        viewMode !== LoginRegisterStateEnum.welcome && (
          <LogoutForm
            handleModal={handleModal}
            router={router}
            onSignOut={onSignOut}
            headingLevel={headingLevel}
          />
        )}
    </>
  )
}

export default LoginRegister
