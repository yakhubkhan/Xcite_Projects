import React, { useEffect } from 'react'
import {
  ButtonVariantEnum,
  HeadingEnum,
  InputTypeEnum,
} from '../../../types/content'
import Button from '../../atoms/Button'
import Field from '../../atoms/Field'
import Heading from '../../atoms/Heading'
import {
  ArrowLeftIcon,
  CheckInCircleFilledIcon,
  CheckInCircleIcon,
  ProfileIcon,
} from '../../atoms/Icon'
import { useTranslation } from 'next-i18next'
import { getPreviousDateYYYYMMDD } from '../../../util/dateUtils'
import ToggleSwitch from '../../atoms/ToggleSwitch'
import gtmDatalayer from '../../../util/gtmUtils'

const checkInCircleIcon = <CheckInCircleIcon className="w-10 h-10" />
const profileIcon = <ProfileIcon className="w-6 h-6" />
export const checkInCircleFilledIcon = (
  <CheckInCircleFilledIcon
    className="w-5 h-5"
    fill="#639448"
    stroke="#639448"
  />
)
const arrowDownIcon = (
  <ArrowLeftIcon className="w-6 h-6 -mt-1 -rotate-90" stroke="#181818" />
)

// eslint-disable-next-line
export const WelcomeForm = ({
  dateOfBirth,
  email,
  emailVerified,
  firstName,
  gender,
  handleWelcomeFormSubmit,
  lastName,
  maritalStatus,
  moEngageToggle,
  nationality,
  phonenumber,
  phoneNumberVerified,
  profileEnum,
  setDateOfBirth,
  setEmail,
  setFirstName,
  setGender,
  setLastName,
  setMaritalStatus,
  setMoEngageToggle,
  setNationality,
  setPhonenumber,
  disableWelcomeSubmitBtn,
  emailErrorMessage,
  phoneErrorMessage,
}): JSX.Element => {
  const { t } = useTranslation()
  useEffect(() => {
    gtmDatalayer('login', 'login', 'create account')
  }, [])
  return (
    <>
      <div className="cmn-inline-center mb-4">
        <div className="pr-3">{checkInCircleIcon}</div>
        <Heading type={HeadingEnum.h1}>
          {t('user_form_welcome_heading')}
        </Heading>
      </div>
      <div className="typography-small mb-8 sm:mb-10">
        {t('user_form_welcome_body')}
      </div>
      <form onSubmit={handleWelcomeFormSubmit}>
        <div className="col-span-full flex flex-col gap-8 pt-5">
          <Field
            labelText={t('user_form_generic_firstname_label')}
            id="firstName"
            onChange={(e) => {
              setFirstName(e.target.value)
            }}
            placeholder={t('user_form_generic_firstname_placeholder')}
            value={firstName}
          />
          <Field
            labelText={t('user_form_generic_lastname_label')}
            id="lastName"
            onChange={(e) => {
              setLastName(e.target.value)
            }}
            placeholder={t('user_form_generic_lastname_placeholder')}
            value={lastName}
          />
          <Field
            className={emailVerified ? 'bg-functional-green-50' : ''}
            confirmed={emailVerified}
            labelText={t('user_form_generic_email_label')}
            leftIconTag={profileIcon}
            id="email"
            onChange={(e) => {
              setEmail(e.target.value)
            }}
            placeholder={t('user_form_generic_email_placeholder')}
            value={email}
            errorMessage={emailErrorMessage}
          />
          <div className="-mt-4 mb-2">
            <ToggleSwitch
              onChange={() => setMoEngageToggle(!moEngageToggle)}
              checked={moEngageToggle}
              label={t('user_form_newsletter_signup_label')}
            />
          </div>
          <div className="mb-5">
            <Field
              className={`${
                phoneNumberVerified ? 'bg-functional-green-50' : ''
              } rtl:text-right rtl:[direction:ltr]`}
              labelText={t('user_form_generic_phone_label')}
              confirmed={phoneNumberVerified}
              id="phonenumber"
              onChange={(e) => {
                setPhonenumber(e.target.value)
              }}
              placeholder={t('user_form_generic_phone_placeholder')}
              value={phonenumber}
              errorMessage={phoneErrorMessage}
            />
          </div>
          <Field
            labelText={t('user_form_generic_nationality_label')}
            id="nationality"
            onChange={(e) => {
              setNationality(e.target.value)
            }}
            placeholder={t('user_form_generic_nationality_placeholder')}
            rightIconTag={arrowDownIcon}
            selectOptions={profileEnum?.nationality}
            type={InputTypeEnum.select}
            value={nationality}
          />
          <Field
            labelText={t('user_form_generic_gender_label')}
            id="gender"
            onChange={(e) => {
              setGender(e.target.value)
            }}
            placeholder={t('user_form_generic_gender_placeholder')}
            rightIconTag={arrowDownIcon}
            selectOptions={profileEnum?.gender}
            type={InputTypeEnum.select}
            value={gender}
          />

          <Field
            labelText={t('user_form_generic_maritalStatus_label')}
            id="maritalStatus"
            onChange={(e) => {
              setMaritalStatus(e.target.value)
            }}
            placeholder={t('user_form_generic_maritalStatus_placeholder')}
            rightIconTag={arrowDownIcon}
            selectOptions={profileEnum?.['marital-status']}
            type={InputTypeEnum.select}
            value={maritalStatus}
          />
          <Field
            labelText={t('user_form_generic_dateOfBirth_label')}
            id="dateOfBirth"
            onChange={(e) => {
              setDateOfBirth(e.target.value)
            }}
            type={InputTypeEnum.date}
            value={dateOfBirth}
            min="1900-01-01"
            max={getPreviousDateYYYYMMDD()}
          />
          <Button
            variant={ButtonVariantEnum.primaryOnLight}
            disabled={disableWelcomeSubmitBtn}
            type="submit"
            className="w-full"
          >
            {t('user_form_welcome_submit_label')}
          </Button>
        </div>
      </form>
    </>
  )
}
