import React, { useState } from 'react'
import {
  forgotPassword,
  resendSignUp,
} from '../../../lib/api/clients/authClient'
import {
  ButtonVariantEnum,
  LoginRegisterStateEnum,
  InputTypeEnum,
  ToastType,
  ToastDuration,
} from '../../../types/content'
import Button from '../../atoms/Button'
import Field from '../../atoms/Field'
import Heading from '../../atoms/Heading'
import {
  AlarmClockIcon,
  EyeCloseIcon,
  EyeOpenIcon,
  LockIcon,
  ProfileIcon,
} from '../../atoms/Icon'
import { useTranslation } from 'next-i18next'
import { checkInCircleFilledIcon } from './WelcomeForm'
import gtmDataLayer from '../../../util/gtmUtils'
import Toaster from '../../atoms/Toaster'
import TermsAndConditionToggle from '../../molecules/TermsAndConditionToggle'
import { passwordValidationRegex } from '../../../util/formValidation'

const alarmClockIcon = <AlarmClockIcon className="w-6 h-6" />
const lockIcon = <LockIcon className="w-6 h-6" />
const profileIcon = <ProfileIcon className="w-6 h-6" />
const eyeCloseIcon = <EyeCloseIcon className="w-6 h-5" />
const eyeOpenIcon = <EyeOpenIcon className="w-6 h-5" />

// eslint-disable-next-line
export const LoginRegisterForm = ({
  authDataPayload,
  authenticationCode,
  mfaMethod,
  displayFPSuccess,
  displayWelcome,
  handleLoginRegisterFormSubmit,
  initAuthData,
  loginRegisterFrom,
  password,
  setAuthDataPayload,
  setAuthenticationCode,
  setPassword,
  setUsername,
  setViewMode,
  setTogglePassword,
  togglePassword,
  username,
  viewMode,
  headingLevel,
  usernameErrorMessage,
}): JSX.Element => {
  const [isTermsAndConditionChecked, setIsTermsAndConditionChecked] =
    useState(false)

  const handleTermsAndConditionToggle = () => {
    setIsTermsAndConditionChecked(!isTermsAndConditionChecked)
  }

  const loginViewDisplayCondition = () =>
    (viewMode === LoginRegisterStateEnum.init ||
      viewMode === LoginRegisterStateEnum.login) &&
    loginRegisterFrom === 'loginregister'
  const loginCartViewDisplayCondition = () =>
    (viewMode === LoginRegisterStateEnum.init ||
      viewMode === LoginRegisterStateEnum.login) &&
    loginRegisterFrom === 'cartloginregister'
  const passwordFieldDisplayCondition = () =>
    (viewMode === LoginRegisterStateEnum.login && username.length > 0) ||
    viewMode === LoginRegisterStateEnum.register ||
    viewMode === LoginRegisterStateEnum.fpVerify
  const backBtnCondition = () =>
    viewMode !== LoginRegisterStateEnum.init &&
    viewMode !== LoginRegisterStateEnum.welcome &&
    viewMode !== LoginRegisterStateEnum.checkout
  const submitButtonText = () =>
    loginViewDisplayCondition()
      ? t('user_form_login_submit_label')
      : loginCartViewDisplayCondition()
      ? t('user_form_continue_label')
      : viewMode === LoginRegisterStateEnum.register
      ? t('user_form_signup_submit_label')
      : viewMode === LoginRegisterStateEnum.checkout
      ? t('user_form_checkout_submit_label')
      : viewMode === LoginRegisterStateEnum.forgotPassword
      ? t('user_form_continue_label')
      : viewMode === LoginRegisterStateEnum.fpVerify
      ? t('user_form_generic_confirm_new_password_label')
      : t('user_form_verification_submit_label')
  const submitButtonDisableCondition = () =>
    (viewMode === LoginRegisterStateEnum.init && username.length === 0) ||
    (viewMode === LoginRegisterStateEnum.login && password.length === 0) ||
    (viewMode === LoginRegisterStateEnum.regVerify &&
      authenticationCode.length === 0) ||
    (viewMode === LoginRegisterStateEnum.register &&
      (username.length === 0 ||
        !password.match(passwordValidationRegex) ||
        !isTermsAndConditionChecked)) ||
    (viewMode === LoginRegisterStateEnum.forgotPassword &&
      username.length === 0) ||
    (viewMode === LoginRegisterStateEnum.fpVerify &&
      (authenticationCode.length === 0 ||
        !password.match(passwordValidationRegex)))
  const errMsgElm = () => (
    <span className="typography-label text-functional-red-800">
      {authDataPayload.message}
    </span>
  )
  const createAccountHandler = () => {
    setViewMode(LoginRegisterStateEnum.register)
  }
  const forgotPasswordHandler = () => {
    setViewMode(LoginRegisterStateEnum.forgotPassword)
    setAuthDataPayload(initAuthData)
    gtmDataLayer('login', 'login', 'forgot password')
  }
  const { t } = useTranslation()
  const translateMfaMethod = () =>
    mfaMethod === 'EMAIL'
      ? t('user_form_verification_mfaMethod_email')
      : mfaMethod === 'SMS'
      ? t('user_form_verification_mfaMethod_sms')
      : mfaMethod

  return (
    <>
      {viewMode === LoginRegisterStateEnum.login && displayWelcome && (
        <Toaster
          toastMsg={`${t('user_form_verification_message_success')}`}
          duration={ToastDuration}
          className={`cmn-toast`}
          type={ToastType.success}
        />
      )}
      {viewMode === LoginRegisterStateEnum.login && displayFPSuccess && (
        <Toaster
          toastMsg={`${t('user_form_password_reset_message_success')}`}
          duration={ToastDuration}
          className={`cmn-toast`}
          type={ToastType.success}
        />
      )}
      <Heading
        type={headingLevel}
        className={`${backBtnCondition() ? 'py-10' : 'pt-3 pb-9 sm:pb-8'}`}
      >
        {viewMode === LoginRegisterStateEnum.init ||
        viewMode === LoginRegisterStateEnum.checkout
          ? t('user_form_login_register_heading')
          : viewMode === LoginRegisterStateEnum.login
          ? t('user_form_login_heading')
          : viewMode === LoginRegisterStateEnum.forgotPassword ||
            viewMode === LoginRegisterStateEnum.fpVerify
          ? t('user_form_generic_password_recovery_label')
          : t('user_form_signup_heading')}
      </Heading>
      <form onSubmit={handleLoginRegisterFormSubmit} autoComplete="off">
        <div className="col-span-full flex flex-col gap-8 ">
          <div
            className={`${
              viewMode === LoginRegisterStateEnum.fpVerify ? 'hidden' : ''
            }`}
          >
            <Field
              className={
                viewMode === LoginRegisterStateEnum.checkout
                  ? 'bg-functional-green-50'
                  : ''
              }
              labelText={t('user_form_generic_username_label')}
              leftIconTag={profileIcon}
              id="username"
              onChange={(e) => {
                setAuthDataPayload(initAuthData)
                setUsername(e.target.value)
              }}
              placeholder={t('user_form_generic_username_placeholder')}
              rightIconTag={
                viewMode === LoginRegisterStateEnum.checkout
                  ? checkInCircleFilledIcon
                  : undefined
              }
              confirmed={viewMode === LoginRegisterStateEnum.checkout}
              errorMessage={
                (authDataPayload.field === 'username' &&
                  authDataPayload.message) ||
                usernameErrorMessage
              }
            />
          </div>
          {(viewMode === LoginRegisterStateEnum.regVerify ||
            viewMode === LoginRegisterStateEnum.fpVerify) && (
            <div>
              <Field
                id="regverify"
                labelText={t('user_form_verification_verify_label')}
                leftIconTag={alarmClockIcon}
                onChange={(e) => {
                  setAuthDataPayload(initAuthData)
                  setAuthenticationCode(e.target.value)
                }}
                placeholder={t('user_form_verification_verify_placeholder')}
                errorMessage={
                  authDataPayload.field === 'regverify' &&
                  authDataPayload.message
                }
              />
            </div>
          )}
          {(viewMode === LoginRegisterStateEnum.regVerify ||
            viewMode === LoginRegisterStateEnum.fpVerify) && (
            <div className="typography-label -mt-4 pb-3 text-gray-400">
              <span>
                {t('user_form_verification_message_confirm', {
                  mfaMethod: translateMfaMethod(),
                })}{' '}
                <span
                  className="text-primary-700 hover:border-b hover:border-primary-700 cursor-pointer"
                  onClick={async () => {
                    try {
                      if (viewMode === LoginRegisterStateEnum.regVerify) {
                        await resendSignUp({ username })
                      } else if (viewMode === LoginRegisterStateEnum.fpVerify) {
                        await forgotPassword({ username })
                      }
                    } catch (err: any) {
                      err?.name &&
                        err?.message &&
                        setAuthDataPayload({
                          field: 'all',
                          message:
                            err?.name == 'LimitExceededException'
                              ? t(
                                  'invalid_limit_exceeded_exception_verification_code'
                                )
                              : err?.message,
                          type: '',
                        })
                    }
                  }}
                >
                  {t('user_form_verification_resend_label')}
                </span>
              </span>
            </div>
          )}
          {passwordFieldDisplayCondition() && (
            <div>
              <Field
                id="password"
                labelText={t('user_form_generic_password_label')}
                leftIconTag={lockIcon}
                onChange={(e) => {
                  setAuthDataPayload(initAuthData)
                  setPassword(e.target.value)
                }}
                placeholder={
                  viewMode === LoginRegisterStateEnum.login
                    ? t('user_form_login_password_placeholder')
                    : t('user_form_signup_password_placeholder')
                }
                rightIconAction={() => setTogglePassword(!togglePassword)}
                rightIconTag={togglePassword ? eyeOpenIcon : eyeCloseIcon}
                type={
                  togglePassword ? InputTypeEnum.password : InputTypeEnum.text
                }
                errorMessage={
                  authDataPayload.field === 'password' &&
                  authDataPayload.message
                }
              />
            </div>
          )}
          {viewMode === LoginRegisterStateEnum.login && (
            <div className="-mt-4">
              <Button
                variant={ButtonVariantEnum.textLink}
                onClick={forgotPasswordHandler}
              >
                {t('user_form_generic_forgot_password_label')}
              </Button>
            </div>
          )}
          {authDataPayload.field === 'all' &&
            authDataPayload.message &&
            errMsgElm()}

          {(viewMode === LoginRegisterStateEnum.register ||
            viewMode === LoginRegisterStateEnum.fpVerify) && (
            <div className="typography-small text-gray-600 -mt-4 -mb-4 ">
              {t('user_form_password_policy_message')}
            </div>
          )}
          {viewMode === LoginRegisterStateEnum.register && (
            <TermsAndConditionToggle
              handleToggle={handleTermsAndConditionToggle}
              checked={isTermsAndConditionChecked}
            />
          )}
          <div>
            <Button
              variant={ButtonVariantEnum.primaryOnLight}
              type="submit"
              disabled={submitButtonDisableCondition()}
              className="w-full"
            >
              {submitButtonText()}
            </Button>
          </div>
        </div>

        {viewMode === LoginRegisterStateEnum.init && (
          <>
            <div className="pt-4 typography-small-strong text-center">
              {t('user_form_generic_heading')}
              <div className="pt-2">
                <Button
                  variant={ButtonVariantEnum.textLink}
                  onClick={createAccountHandler}
                >
                  {t('user_form_generic_cta_label')}
                </Button>
              </div>
            </div>
          </>
        )}
      </form>
    </>
  )
}
