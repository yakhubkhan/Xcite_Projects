import { useTranslation } from 'next-i18next'
import React, { useEffect, useState, useRef } from 'react'
import {
  setShippingCitiesForRegionAction,
  setBillingCitiesForRegionAction,
} from '../../../redux/slices/cart'
import {
  Address,
  AsyncResponseStatusEnum,
  ButtonVariantEnum,
  HeadingEnum,
  InputTypeEnum,
  RegionCityListItem,
} from '../../../types/content'
import {
  emailValidationRegex,
  phoneValidationRegex,
  phoneMagentoImportValidationRegex,
  numberOnlyValidationRrgex,
} from '../../../util/formValidation'
import Button from '../../atoms/Button'
import Heading from '../../atoms/Heading'
import ToggleSwitch from '../../atoms/ToggleSwitch'
import { PencilIcon, PinIcon, ArrowDropDownIcon } from '../../atoms/Icon'
import Field from '../../atoms/Field'
import { useDispatch } from 'react-redux'
import { CommercetoolsRegion } from '../../../types/raw/ctAddress'
import gtmDatalayer from '../../../util/gtmUtils'

interface Props {
  formattedShippingAddress: string
  formattedBillingAddress: string
  shippingAddress?: Address
  billingAddress?: Address
  currentCountry: string
  onRefreshMapLocation: (type) => void
  onSaveAddress: (shippingAddress: Address, addressBilling: Address) => void
  onBillingAddressToggle: () => void
  isBillingAdresseSameAsShippingAddress: boolean
  cartStatus: AsyncResponseStatusEnum
  addresses: Address[]
  openSavedAddress: (address) => void
  onlyBillingAddressRequired?: boolean
  addNewAddress: (address) => void
  shippingRegionList: RegionCityListItem[]
  shippingAreaList: RegionCityListItem[]
  shippingCityList: RegionCityListItem[]
  billingRegionList: RegionCityListItem[]
  billingCityList: RegionCityListItem[]
  shippingRegionCityList: CommercetoolsRegion[]
  billingRegionCityList: CommercetoolsRegion[]
  locale: string
  modeOfCommunicationOpts: {
    key: string
    label: string
  }[]
}

const ShippingAddressForm = ({
  formattedShippingAddress,
  formattedBillingAddress,
  shippingAddress,
  billingAddress,
  currentCountry,
  onSaveAddress,
  onBillingAddressToggle,
  isBillingAdresseSameAsShippingAddress,
  cartStatus,
  addresses,
  openSavedAddress,
  onlyBillingAddressRequired,
  addNewAddress,
  shippingRegionList,
  shippingAreaList,
  shippingCityList,
  billingRegionList,
  billingCityList,
  shippingRegionCityList,
  billingRegionCityList,
  locale,
  modeOfCommunicationOpts,
}: Props): JSX.Element => {
  const { t } = useTranslation()
  const dispatch = useDispatch()

  const [errorsShippingAddress, setErrorsShippingAddress] = useState({
    blockError: '',
    areaError: '',
    regionError: '',
    streetNameError: '',
    cityError: '',
    firstNameError: '',
    lastNameError: '',
    emailError: '',
    primaryPhoneError: '',
    secondaryPhoneError: '',
    paciNumberError:''
  })

  const [errorsBillingAddress, setErrorsBillingAddress] = useState({
    locationBillingError: '',
    blockBillingError: '',
    areaBillingError: '',
    regionBillingError: '',
    streetNameBillingError: '',
    cityBillingError: '',
    firstNameBillingError: '',
    lastNameBillingError: '',
    primaryPhoneBillingError: '',
    paciNumberBillingError: '',
    secondaryPhoneBillingError: '',
    emailBillingError: '',
  })

  const [showAdditionalFields, setShowAdditionalFields] = useState(false)
  const [showAdditionalFieldsBilling, setShowAdditionalFieldsBilling] =
    useState(false)
  const [showSecondaryPhone, setShowSecondaryPhone] = useState(false)
  const [showSecondaryPhoneBilling, setShowSecondaryPhoneBilling] =
    useState(false)
  const [addressInputsShipping, setAddressInputsShipping] = useState<
    Address | undefined
  >(shippingAddress)
  const [addressInputsBilling, setAddressInputsBilling] = useState<
    Address | undefined
  >(billingAddress)
  const billingAddressFormRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (
      addressInputsShipping?.avenue ||
      addressInputsShipping?.building ||
      addressInputsShipping?.flat ||
      addressInputsShipping?.floor
    ) {
      setShowAdditionalFields(true)
    }
    if (addressInputsShipping?.secondaryPhoneNumber) {
      setShowSecondaryPhone(true)
    }
  }, [addressInputsShipping])

  useEffect(() => {
    if (
      addressInputsBilling?.avenue ||
      addressInputsBilling?.building ||
      addressInputsBilling?.flat ||
      addressInputsBilling?.floor
    ) {
      setShowAdditionalFieldsBilling(true)
    }
    if (addressInputsBilling?.secondaryPhoneNumber) {
      setShowSecondaryPhoneBilling(true)
    }
  }, [addressInputsBilling])

  useEffect(() => {
    setAddressInputsShipping(shippingAddress)
  }, [shippingAddress])

  useEffect(() => {
    setAddressInputsBilling(billingAddress)
  }, [billingAddress])

  const optionalLabel = `(${t('checkout_shipping_address_field_optional')})`

  const handleChangePersonalAddress = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    setAddressInputsShipping((prevState) => {
      if (prevState) {
        return {
          ...prevState,
          [e.target.name]: e.target.value,
        }
      }
    })
  }

  useEffect(() => {
    const urlHash = window.location.hash

    if (
      urlHash.substring(1) === 'billing' &&
      !isBillingAdresseSameAsShippingAddress &&
      billingAddressFormRef.current
    ) {
      billingAddressFormRef.current.scrollIntoView({
        behavior: 'smooth',
      })
    }
  }, [isBillingAdresseSameAsShippingAddress])

  const handleChangeBillingAddress = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    setAddressInputsBilling((prevState) => {
      if (prevState) {
        return {
          ...prevState,
          [e.target.name]: e.target.value,
        }
      }
    })
  }

  const handleChangeLocatedAddress = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    if (e.target.name === 'region') {
      dispatch(
        setShippingCitiesForRegionAction({
          locale,
          region: e.target.value,
          shippingRegionCityList,
        })
      )
    }
    setAddressInputsShipping((prevState) => {
      if (prevState) {
        return {
          ...prevState,
          address: {
            ...prevState.address,
            [e.target.name]: e.target.value,
          },
        }
      }
    })
  }

  const handleChangeLocatedBillingAddress = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    if (e.target.name === 'region') {
      dispatch(
        setBillingCitiesForRegionAction({
          locale,
          region: e.target.value,
          billingRegionCityList,
        })
      )
    }
    setAddressInputsBilling((prevState) => {
      if (prevState) {
        return {
          ...prevState,
          address: {
            ...prevState.address,
            [e.target.name]: e.target.value,
          },
        }
      }
    })
  }

  const validateForm = (inputs: Address | undefined, type: string) => {
    let firstNameError = ''
    let lastNameError = ''
    let emailError = ''
    let primaryPhoneError = ''
    let secondaryPhoneError = ''
    let blockError = ''
    let areaError = ''
    let regionError = ''
    let streetNameError = ''
    let cityError = ''
    let paciNumberError=''
    let paciNumberBillingError =''
    let locationBillingError = ''
    let firstNameBillingError = ''
    let lastNameBillingError = ''
    let primaryPhoneBillingError = ''
    let secondaryPhoneBillingError = ''
    let blockBillingError = ''
    let areaBillingError = ''
    let regionBillingError = ''
    let streetNameBillingError = ''
    let cityBillingError = ''
    let emailBillingError = ''

    if (typeof inputs === 'undefined' || !inputs.address) {
      if (type === 'billing') {
        locationBillingError = t(
          'checkout_shipping_address_validation_required'
        )
      }
    }
    if (typeof inputs === 'undefined' || !inputs.firstName) {
      if (type === 'shipping') {
        firstNameError = t('checkout_shipping_address_validation_required')
      } else if (type === 'billing') {
        firstNameBillingError = t(
          'checkout_shipping_address_validation_required'
        )
      }
    }
    if (typeof inputs === 'undefined' || !inputs.lastName) {
      if (type === 'shipping') {
        lastNameError = t('checkout_shipping_address_validation_required')
      } else if (type === 'billing') {
        lastNameBillingError = t(
          'checkout_shipping_address_validation_required'
        )
      }
    }
    if (typeof inputs === 'undefined' || !inputs?.email) {
      if (type === 'shipping') {
        emailError = t('checkout_shipping_address_validation_required')
      } else if (type === 'billing' && onlyBillingAddressRequired) {
        emailBillingError = t('checkout_shipping_address_validation_required')
      }
    }
    if (inputs?.email && !inputs.email.match(emailValidationRegex)) {
      if (type === 'shipping') {
        emailError = t('checkout_shipping_address_validation_email')
      } else if (type === 'billing' && onlyBillingAddressRequired) {
        emailBillingError = t('checkout_shipping_address_validation_email')
      }
    }
    if (typeof inputs === 'undefined' || !inputs.primaryPhoneNumber) {
      if (type === 'shipping') {
        primaryPhoneError = t('checkout_shipping_address_validation_required')
      } else if (type === 'billing') {
        primaryPhoneBillingError = t(
          'checkout_shipping_address_validation_required'
        )
      }
    }
    if (
      typeof inputs === 'undefined' ||
      (!inputs.primaryPhoneNumber.match(phoneValidationRegex[currentCountry]) &&
        !inputs.primaryPhoneNumber.match(
          phoneMagentoImportValidationRegex[currentCountry]
        ))
    ) {
      if (type === 'shipping') {
        primaryPhoneError = t(
          'checkout_shipping_address_validation_primary_phone'
        )
      } else if (type === 'billing') {
        primaryPhoneBillingError = t(
          'checkout_shipping_address_validation_primary_phone'
        )
      }
    }
    if (
      typeof inputs === 'undefined' ||
      (inputs.secondaryPhoneNumber &&
        !inputs.secondaryPhoneNumber.match(
          phoneValidationRegex[currentCountry]
        ) &&
        !inputs.secondaryPhoneNumber.match(
          phoneMagentoImportValidationRegex[currentCountry]
        ))
    ) {
      if (type === 'shipping') {
        secondaryPhoneError = t(
          'checkout_shipping_address_validation_secondary_phone'
        )
      } else if (type === 'billing') {
        secondaryPhoneBillingError = t(
          'checkout_shipping_address_validation_secondary_phone'
        )
      }
    }

    if (
      typeof inputs === 'undefined' ||
      (inputs.paciNumber &&
        !inputs.paciNumber.match(
          numberOnlyValidationRrgex
        ) )
    ) {
      if (type === 'shipping') {
        paciNumberError = t(
          'checkout_shipping_address_validation_paci_number'
        )
      } else if (type === 'billing') {
        paciNumberBillingError = t(
          'checkout_shipping_address_validation_paci_number'
        )
      }
    }

    if (typeof inputs === 'undefined' || !inputs.address.streetName) {
      if (type === 'shipping') {
        streetNameError = t('checkout_shipping_address_validation_required')
      } else if (type === 'billing') {
        streetNameBillingError = t(
          'checkout_shipping_address_validation_required'
        )
      }
    }
    if (currentCountry === 'kw') {
      if (typeof inputs === 'undefined' || !inputs.address.area) {
        if (type === 'shipping') {
          areaError = t('checkout_shipping_address_validation_required')
        } else if (type === 'billing') {
          areaBillingError = t('checkout_shipping_address_validation_required')
        }
      }
      if (typeof inputs === 'undefined' || !inputs.address.block) {
        if (type === 'shipping') {
          blockError = t('checkout_shipping_address_validation_required')
        } else if (type === 'billing') {
          blockBillingError = t('checkout_shipping_address_validation_required')
        }
      }
    }
    if (currentCountry === 'sa') {
      if (typeof inputs === 'undefined' || !inputs.address.region) {
        if (type === 'shipping') {
          regionError = t('checkout_shipping_address_validation_required')
        } else if (type === 'billing') {
          regionBillingError = t(
            'checkout_shipping_address_validation_required'
          )
        }
      }
      if (typeof inputs === 'undefined' || !inputs.address.city) {
        if (type === 'shipping') {
          cityError = t('checkout_shipping_address_validation_required')
        } else if (type === 'billing') {
          cityBillingError = t('checkout_shipping_address_validation_required')
        }
      }
    }

    if (type === 'shipping') {
      setErrorsShippingAddress({
        firstNameError,
        lastNameError,
        emailError,
        primaryPhoneError,
        secondaryPhoneError,
        paciNumberError,
        blockError,
        areaError,
        regionError,
        streetNameError,
        cityError,
      })

      if (
        firstNameError ||
        lastNameError ||
        emailError ||
        primaryPhoneError ||
        secondaryPhoneError ||
        paciNumberError ||
        blockError ||
        areaError ||
        regionError ||
        streetNameError ||
        cityError
      ) {
        return false
      }
    } else if (type === 'billing') {
      setErrorsBillingAddress({
        locationBillingError,
        firstNameBillingError,
        lastNameBillingError,
        primaryPhoneBillingError,
        secondaryPhoneBillingError,
        paciNumberBillingError,
        blockBillingError,
        areaBillingError,
        regionBillingError,
        streetNameBillingError,
        cityBillingError,
        emailBillingError,
      })

      if (
        firstNameBillingError ||
        lastNameBillingError ||
        primaryPhoneBillingError ||
        secondaryPhoneBillingError ||
        paciNumberBillingError ||
        blockBillingError ||
        areaBillingError ||
        regionBillingError ||
        streetNameBillingError ||
        cityBillingError ||
        emailBillingError
      ) {
        return false
      }
    }

    return true
  }

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const shippingAddressDetails = onlyBillingAddressRequired
      ? addressInputsBilling
      : addressInputsShipping

    const billingAddressDetails =
      isBillingAdresseSameAsShippingAddress && !onlyBillingAddressRequired
        ? addressInputsShipping
        : addressInputsBilling
    if (shippingAddressDetails) {
      const isShippingValid = validateForm(shippingAddressDetails, 'shipping')
      let isBillingValid = true
      if (!isBillingAdresseSameAsShippingAddress) {
        isBillingValid = validateForm(billingAddressDetails, 'billing')
      } else if (onlyBillingAddressRequired) {
        isBillingValid = validateForm(shippingAddressDetails, 'billing')
      }
      if (isShippingValid && isBillingValid && billingAddressDetails) {
        onSaveAddress(shippingAddressDetails, billingAddressDetails)
      } else {
        setTimeout(function () {
          document
            .querySelector('.fieldHasError')
            ?.scrollIntoView({ behavior: 'smooth', block: 'center' })
        }, 0)
      }
      const eventActionObj = '{"eventAction": "DeliveryOptions"}'
      gtmDatalayer('delivery_options', 'Delivery Options View', eventActionObj)
    }
  }

  return (
    <form noValidate onSubmit={handleSubmit}>
      <div className="col-span-full flex flex-col gap-8">
        {!onlyBillingAddressRequired && (
          <>
            <Heading type={HeadingEnum.h4}>
              {t('checkout_shipping_form_heading')}
            </Heading>
            <Field
              id="location"
              value={
                !formattedShippingAddress
                  ? shippingAddress?.formattedAddress
                  : formattedShippingAddress
              }
              labelText={t('checkout_shipping_address_location_label')}
              placeholder={t('checkout_shipping_address_location_label')}
              readOnly
              leftIconTag={
                <PinIcon className="w-6 h-6 text-gray-600 stroke-current" />
              }
              rightIconTag={
                addresses.length > 1 ? (
                  <ArrowDropDownIcon className="w-6 h-6 text-gray-600 stroke-current" />
                ) : (
                  <PencilIcon className="w-6 h-6 text-gray-600 stroke-current" />
                )
              }
              rightIconAction={
                addresses.length > 1
                  ? () => openSavedAddress('shipping')
                  : () => addNewAddress('shipping')
              }
            />
            {currentCountry === 'kw' && (
              <>
                {!shippingAddress?.address?.area && (
                  <div>
                    <Field
                      id="area"
                      type={InputTypeEnum.select}
                      value={addressInputsShipping?.address?.area || ''}
                      labelText={t('checkout_shipping_address_area_label')}
                      placeholder={t('checkout_shipping_address_area_label')}
                      onChange={handleChangeLocatedAddress}
                      errorMessage={errorsShippingAddress.areaError}
                      selectOptions={shippingAreaList}
                    />
                  </div>
                )}
                {!shippingAddress?.address?.block && (
                  <div>
                    <Field
                      id="block"
                      value={addressInputsShipping?.address?.block || ''}
                      labelText={t('checkout_shipping_address_block_label')}
                      placeholder={t('checkout_shipping_address_block_label')}
                      onChange={handleChangeLocatedAddress}
                      errorMessage={errorsShippingAddress.blockError}
                    />
                  </div>
                )}
              </>
            )}
            {currentCountry === 'sa' && (
              <>
                {!shippingAddress?.address?.region && (
                  <div>
                    <Field
                      id="region"
                      type={InputTypeEnum.select}
                      value={addressInputsShipping?.address?.region || ''}
                      labelText={t('checkout_shipping_address_region_label')}
                      placeholder={t('checkout_shipping_address_region_label')}
                      onChange={handleChangeLocatedAddress}
                      errorMessage={errorsShippingAddress.regionError}
                      selectOptions={shippingRegionList}
                    />
                  </div>
                )}
                {!shippingAddress?.address?.city && (
                  <div>
                    <Field
                      id="city"
                      type={InputTypeEnum.select}
                      value={addressInputsShipping?.address?.city || ''}
                      labelText={t('checkout_shipping_address_city_label')}
                      placeholder={t('checkout_shipping_address_city_label')}
                      onChange={handleChangeLocatedAddress}
                      errorMessage={errorsShippingAddress.cityError}
                      selectOptions={shippingCityList}
                    />
                  </div>
                )}
              </>
            )}
            {!shippingAddress?.address?.streetName && (
              <div>
                <Field
                  id="streetName"
                  value={addressInputsShipping?.address?.streetName || ''}
                  labelText={t('checkout_shipping_address_streetName_label')}
                  placeholder={t('checkout_shipping_address_streetName_label')}
                  onChange={handleChangeLocatedAddress}
                  errorMessage={errorsShippingAddress.streetNameError}
                />
              </div>
            )}
            {currentCountry === 'kw' && (
              <Field
                id="paciNumber"
                labelText={`${t(
                  'checkout_shipping_address_paciNumber_label'
                )} ${optionalLabel}`}
                placeholder={`${t(
                  'checkout_shipping_address_paciNumber_label'
                )} ${optionalLabel}`}
                onChange={handleChangePersonalAddress}
                value={addressInputsShipping?.paciNumber}
                errorMessage={errorsShippingAddress.paciNumberError}
              />
            )}
            {!showAdditionalFields && (
              <Button
                variant={ButtonVariantEnum.textLink}
                className="self-start"
                onClick={() => setShowAdditionalFields(true)}
              >
                {t('checkout_shipping_address_show_extra_fields')}.
              </Button>
            )}
            {showAdditionalFields && (
              <>
                <div className="flex flex-col gap-8 pt-5 md:flex-row md:gap-2">
                  <div className="md:flex-1">
                    <Field
                      id="avenue"
                      labelText={`${t(
                        'checkout_shipping_address_avenue_label'
                      )} ${optionalLabel}`}
                      placeholder={`${t(
                        'checkout_shipping_address_avenue_label'
                      )} ${optionalLabel}`}
                      onChange={handleChangePersonalAddress}
                      value={addressInputsShipping?.avenue || ''}
                    />
                  </div>
                  <div className="md:flex-1">
                    <Field
                      id="building"
                      labelText={`${t(
                        'checkout_shipping_address_buildingNumber_label'
                      )} ${optionalLabel}`}
                      placeholder={`${t(
                        'checkout_shipping_address_buildingNumber_label'
                      )} ${optionalLabel}`}
                      onChange={handleChangePersonalAddress}
                      value={addressInputsShipping?.building || ''}
                    />
                  </div>
                </div>
                <div className="flex flex-col gap-8 pb-5 md:flex-row md:gap-2">
                  <div className="md:flex-1">
                    <Field
                      id="floor"
                      labelText={`${t(
                        'checkout_shipping_address_floorNumber_label'
                      )} ${optionalLabel}`}
                      placeholder={`${t(
                        'checkout_shipping_address_floorNumber_label'
                      )} ${optionalLabel}`}
                      onChange={handleChangePersonalAddress}
                      value={addressInputsShipping?.floor || ''}
                    />
                  </div>
                  <div className="md:flex-1">
                    <Field
                      id="flat"
                      labelText={`${t(
                        'checkout_shipping_address_flatNumber_label'
                      )} ${optionalLabel}`}
                      placeholder={`${t(
                        'checkout_shipping_address_flatNumber_label'
                      )} ${optionalLabel}`}
                      onChange={handleChangePersonalAddress}
                      value={addressInputsShipping?.flat || ''}
                    />
                  </div>
                </div>
              </>
            )}
            <div className="flex flex-col gap-8 md:flex-row md:gap-2">
              <div className="md:flex-1">
                <Field
                  id="firstName"
                  labelText={t('checkout_shipping_address_firstName_label')}
                  placeholder={t('checkout_shipping_address_firstName_label')}
                  onChange={handleChangePersonalAddress}
                  value={addressInputsShipping?.firstName || ''}
                  errorMessage={errorsShippingAddress.firstNameError}
                />
              </div>
              <div className="md:flex-1">
                <Field
                  id="lastName"
                  labelText={t('checkout_shipping_address_lastName_label')}
                  placeholder={t('checkout_shipping_address_lastName_label')}
                  onChange={handleChangePersonalAddress}
                  value={addressInputsShipping?.lastName || ''}
                  errorMessage={errorsShippingAddress.lastNameError}
                />
              </div>
            </div>
            <div>
              <Field
                id="email"
                type={InputTypeEnum.email}
                labelText={t('checkout_shipping_address_email_label')}
                placeholder={t('checkout_shipping_address_email_label')}
                onChange={handleChangePersonalAddress}
                value={addressInputsShipping?.email || ''}
                errorMessage={errorsShippingAddress.emailError}
              />
            </div>
            <div>
              <Field
                id="primaryPhoneNumber"
                labelText={t('checkout_shipping_address_phone1_label')}
                placeholder={t('checkout_shipping_address_phone1_label')}
                onChange={handleChangePersonalAddress}
                value={addressInputsShipping?.primaryPhoneNumber || ''}
                errorMessage={errorsShippingAddress.primaryPhoneError}
                className={`rtl:text-right rtl:[direction:ltr]`}
              />
            </div>
            {!showSecondaryPhone && (
              <Button
                variant={ButtonVariantEnum.textLink}
                className="self-start"
                onClick={() => setShowSecondaryPhone(true)}
              >
                {t('checkout_shipping_address_show_secondary_phone')}
              </Button>
            )}
            {showSecondaryPhone && (
              <div className="py-5">
                <Field
                  id="secondaryPhoneNumber"
                  labelText={`${t(
                    'checkout_shipping_address_phone2_label'
                  )} ${optionalLabel}`}
                  placeholder={`${t(
                    'checkout_shipping_address_phone2_label'
                  )} ${optionalLabel}`}
                  onChange={handleChangePersonalAddress}
                  value={addressInputsShipping?.secondaryPhoneNumber || ''}
                  errorMessage={errorsShippingAddress.secondaryPhoneError}
                  className={`rtl:text-right rtl:[direction:ltr]`}
                />
              </div>
            )}
            <Field
              id="deliveryInstruction"
              labelText={`${t(
                'checkout_shipping_address_deliveryInstructions_label'
              )} (${t('checkout_shipping_address_field_optional')})`}
              placeholder={`${t(
                'checkout_shipping_address_deliveryInstructions_label'
              )} (${t('checkout_shipping_address_field_optional')})`}
              onChange={handleChangePersonalAddress}
              value={addressInputsShipping?.deliveryInstruction || ''}
            />
            
              <Field
                labelText={t(
                  'checkout_shipping_address_mode_of_communication_label'
                )}
                id="modeOfCommunication"
                placeholder={t(
                  'checkout_shipping_address_mode_of_communication_placeholder'
                )}
                onChange={handleChangePersonalAddress}
                selectOptions={modeOfCommunicationOpts}
                type={InputTypeEnum.select}
                value={addressInputsShipping?.modeOfCommunication || ''}
              />
            
            <ToggleSwitch
              onChange={onBillingAddressToggle}
              checked={isBillingAdresseSameAsShippingAddress}
              label={t('checkout_billing_address_toggle_label')}
            />
          </>
        )}

        {(!isBillingAdresseSameAsShippingAddress ||
          onlyBillingAddressRequired) && (
          <>
            <Heading type={HeadingEnum.h4} ref={billingAddressFormRef}>
              {t('checkout_billing_address_form_heading')}
            </Heading>
            <div>
              <Field
                id="locationBilling"
                name="locatiom"
                value={
                  !formattedBillingAddress
                    ? billingAddress?.formattedAddress
                    : formattedBillingAddress
                }
                labelText={t('checkout_shipping_address_location_label')}
                placeholder={t('checkout_shipping_address_location_label')}
                readOnly
                leftIconTag={
                  <PinIcon className="w-6 h-6 text-gray-600 stroke-current" />
                }
                rightIconTag={
                  addresses.length > 1 ? (
                    <ArrowDropDownIcon className="w-6 h-6 text-gray-600 stroke-current" />
                  ) : (
                    <PencilIcon className="w-6 h-6 text-gray-600 stroke-current" />
                  )
                }
                rightIconAction={
                  addresses.length > 1
                    ? () => openSavedAddress('billing')
                    : () => addNewAddress('billing')
                }
                errorMessage={errorsBillingAddress.locationBillingError}
              />
            </div>

            {currentCountry === 'kw' && (
              <>
                {!billingAddress?.address?.area && (
                  <div>
                    <Field
                      id="areaBilling"
                      name="area"
                      value={addressInputsBilling?.address?.area}
                      labelText={t('checkout_shipping_address_area_label')}
                      placeholder={t('checkout_shipping_address_area_label')}
                      onChange={handleChangeLocatedBillingAddress}
                      errorMessage={errorsBillingAddress.areaBillingError}
                    />
                  </div>
                )}
                {!billingAddress?.address?.block && (
                  <div>
                    <Field
                      id="blockBilling"
                      name="block"
                      value={addressInputsBilling?.address?.block}
                      labelText={t('checkout_shipping_address_block_label')}
                      placeholder={t('checkout_shipping_address_block_label')}
                      onChange={handleChangeLocatedBillingAddress}
                      errorMessage={errorsBillingAddress.blockBillingError}
                    />
                  </div>
                )}
              </>
            )}
            {currentCountry === 'sa' && (
              <>
                {!billingAddress?.address?.region && (
                  <div>
                    <Field
                      id="regionBilling"
                      name="region"
                      type={InputTypeEnum.select}
                      value={addressInputsBilling?.address?.region || ''}
                      labelText={t('checkout_shipping_address_region_label')}
                      placeholder={t('checkout_shipping_address_region_label')}
                      onChange={handleChangeLocatedBillingAddress}
                      errorMessage={errorsBillingAddress.regionBillingError}
                      selectOptions={billingRegionList}
                    />
                  </div>
                )}
                {!billingAddress?.address?.city && (
                  <div>
                    <Field
                      id="cityBilling"
                      name="city"
                      type={InputTypeEnum.select}
                      value={addressInputsBilling?.address?.city || ''}
                      labelText={t('checkout_shipping_address_city_label')}
                      placeholder={t('checkout_shipping_address_city_label')}
                      onChange={handleChangeLocatedBillingAddress}
                      errorMessage={errorsBillingAddress.cityBillingError}
                      selectOptions={billingCityList}
                    />
                  </div>
                )}
              </>
            )}
            {!billingAddress?.address?.streetName && (
              <div>
                <Field
                  id="streetNameBilling"
                  name="streetName"
                  value={addressInputsBilling?.address?.streetName}
                  labelText={t('checkout_shipping_address_streetName_label')}
                  placeholder={t('checkout_shipping_address_streetName_label')}
                  onChange={handleChangeLocatedBillingAddress}
                  errorMessage={errorsBillingAddress.streetNameBillingError}
                />
              </div>
            )}
            {currentCountry === 'kw' && (
              <Field
                id="paciNumberBilling"
                name="paciNumber"
                labelText={`${t(
                  'checkout_shipping_address_paciNumber_label'
                )} ${optionalLabel}`}
                placeholder={`${t(
                  'checkout_shipping_address_paciNumber_label'
                )} ${optionalLabel}`}
                onChange={handleChangeBillingAddress}
                value={addressInputsBilling?.paciNumber}
                errorMessage={errorsBillingAddress.paciNumberBillingError}
              />
            )}
            {!showAdditionalFieldsBilling && (
              <Button
                variant={ButtonVariantEnum.textLink}
                className="self-start"
                onClick={() => setShowAdditionalFieldsBilling(true)}
              >
                {t('checkout_shipping_address_show_extra_fields')}.
              </Button>
            )}
            {showAdditionalFieldsBilling && (
              <>
                <div className="flex flex-col gap-8 pt-5 md:flex-row md:gap-2">
                  <div className="md:flex-1">
                    <Field
                      id="avenueBilling"
                      name="avenue"
                      labelText={`${t(
                        'checkout_shipping_address_avenue_label'
                      )} ${optionalLabel}`}
                      placeholder={`${t(
                        'checkout_shipping_address_avenue_label'
                      )} ${optionalLabel}`}
                      onChange={handleChangeBillingAddress}
                      value={addressInputsBilling?.avenue}
                    />
                  </div>
                  <div className="md:flex-1">
                    <Field
                      id="buildingBilling"
                      name="building"
                      labelText={`${t(
                        'checkout_shipping_address_buildingNumber_label'
                      )} ${optionalLabel}`}
                      placeholder={`${t(
                        'checkout_shipping_address_buildingNumber_label'
                      )} ${optionalLabel}`}
                      onChange={handleChangeBillingAddress}
                      value={addressInputsBilling?.building}
                    />
                  </div>
                </div>
                <div className="flex flex-col gap-8 pb-5 md:flex-row md:gap-2">
                  <div className="md:flex-1">
                    <Field
                      id="floorBilling"
                      name="floor"
                      labelText={`${t(
                        'checkout_shipping_address_floorNumber_label'
                      )} ${optionalLabel}`}
                      placeholder={`${t(
                        'checkout_shipping_address_floorNumber_label'
                      )} ${optionalLabel}`}
                      onChange={handleChangeBillingAddress}
                      value={addressInputsBilling?.floor}
                    />
                  </div>
                  <div className="md:flex-1">
                    <Field
                      id="flatBilling"
                      name="flat"
                      labelText={`${t(
                        'checkout_shipping_address_flatNumber_label'
                      )} ${optionalLabel}`}
                      placeholder={`${t(
                        'checkout_shipping_address_flatNumber_label'
                      )} ${optionalLabel}`}
                      onChange={handleChangeBillingAddress}
                      value={addressInputsBilling?.flat}
                    />
                  </div>
                </div>
              </>
            )}
            <div className="flex flex-col gap-8 md:flex-row md:gap-2">
              <div className="md:flex-1">
                <Field
                  id="firstNameBilling"
                  name="firstName"
                  labelText={t('checkout_shipping_address_firstName_label')}
                  placeholder={t('checkout_shipping_address_firstName_label')}
                  onChange={handleChangeBillingAddress}
                  value={addressInputsBilling?.firstName}
                  errorMessage={errorsBillingAddress.firstNameBillingError}
                />
              </div>
              <div className="md:flex-1">
                <Field
                  id="lastNameBilling"
                  name="lastName"
                  labelText={t('checkout_shipping_address_lastName_label')}
                  placeholder={t('checkout_shipping_address_lastName_label')}
                  onChange={handleChangeBillingAddress}
                  value={addressInputsBilling?.lastName}
                  errorMessage={errorsBillingAddress.lastNameBillingError}
                />
              </div>
            </div>
            {onlyBillingAddressRequired && (
              <div>
                <Field
                  id="emailBilling"
                  name="email"
                  type={InputTypeEnum.email}
                  labelText={t('checkout_shipping_address_email_label')}
                  placeholder={t('checkout_shipping_address_email_label')}
                  onChange={handleChangeBillingAddress}
                  value={addressInputsBilling?.email || ''}
                  errorMessage={errorsBillingAddress.emailBillingError}
                />
              </div>
            )}
            <div>
              <Field
                id="primaryPhoneNumberBilling"
                name="primaryPhoneNumber"
                labelText={t('checkout_shipping_address_phone1_label')}
                placeholder={t('checkout_shipping_address_phone1_label')}
                onChange={handleChangeBillingAddress}
                value={addressInputsBilling?.primaryPhoneNumber}
                errorMessage={errorsBillingAddress.primaryPhoneBillingError}
                className={`rtl:text-right rtl:[direction:ltr]`}
              />
            </div>
            {!showSecondaryPhoneBilling && (
              <Button
                variant={ButtonVariantEnum.textLink}
                className="self-start"
                onClick={() => setShowSecondaryPhoneBilling(true)}
              >
                {t('checkout_shipping_address_show_secondary_phone')}
              </Button>
            )}
            {showSecondaryPhoneBilling && (
              <div className="py-5">
                <Field
                  id="secondaryPhoneNumberBilling"
                  name="secondaryPhoneNumber"
                  labelText={`${t(
                    'checkout_shipping_address_phone2_label'
                  )} ${optionalLabel}`}
                  placeholder={`${t(
                    'checkout_shipping_address_phone2_label'
                  )} ${optionalLabel}`}
                  onChange={handleChangeBillingAddress}
                  value={addressInputsBilling?.secondaryPhoneNumber}
                  errorMessage={errorsBillingAddress.secondaryPhoneBillingError}
                  className={`rtl:text-right rtl:[direction:ltr]`}
                />
              </div>
            )}
          </>
        )}
        <Button
          variant={ButtonVariantEnum.primaryOnLight}
          type="submit"
          disabled={cartStatus === AsyncResponseStatusEnum.loading}
        >
          {isBillingAdresseSameAsShippingAddress && !onlyBillingAddressRequired
            ? t('checkout_shipping_address_submit')
            : t('checkout_billing_address_submit')}
          {}
        </Button>
      </div>
    </form>
  )
}

export default ShippingAddressForm
