import { useRouter } from 'next/router'
import { useTranslation } from 'next-i18next'
import React, { useEffect, useState, useCallback } from 'react'
import { useDispatch, useSelector } from 'react-redux'

import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import {
  Address,
  AsyncResponseStatusEnum,
  MapLocation,
  ButtonVariantEnum,
} from '../../../types/content'
import { RootState } from '../../../redux/reducers'
import {
  convertAddressThunk,
  convertBillingAddressThunk,
  resetAddressStatusAction,
  loadAddressForLoggedInUserThunk,
  addressSelector,
} from '../../../redux/slices/address'
import { userProfileSelector } from '../../../redux/slices/profile'
import {
  addShippingAndBillingAddressToCartThunk,
  cartStatusSelector,
  cartGroupSelector,
  cartAddressDisplayRequiredSelector,
  resetShippingAddressIdAction,
  selectShippingAddressAction,
  selectBillingAddressAction,
  cartTotalItemsSelector,
  resetBillingAddressIdAction,
  addAddressToCartStatusSelector,
  resetAddAddressToCartStatusStatusAction,
} from '../../../redux/slices/cart'
import { namedLinksSelector } from '../../../redux/slices/navigation'
import CheckoutPageWrapper from '../../molecules/CheckoutPageWrapper'
import Segment from '../../atoms/Segment'
import OrderSummary from '../OrderSummary'
import ShippingAddressForm from './ShippingAddressForm'
import Map from '../../molecules/Map'
import Modal from '../../atoms/Modal'
import styles from './ShippingAddress.module.css'
import ShippingAddressList from './ShippingAddressList'
import { getEnumByResource } from '../../../lib/api/clients/customer'

const ShippingAddress = (): JSX.Element => {
  const { t } = useTranslation()

  const router = useRouter()

  const dispatch = useDispatch()
  const user = useSelector(userProfileSelector)
  const cartStatus = useSelector(cartStatusSelector)
  const addAddressToCartStatus = useSelector(addAddressToCartStatusSelector)
  const cartGroups = useSelector(cartGroupSelector)
  const totalItems = useSelector(cartTotalItemsSelector)
  const addressDisplayRequired = useSelector(cartAddressDisplayRequiredSelector)

  const initialAddresses: Address[] = useSelector(addressSelector)
  const shippingAddressSelect = useSelector(
    (state: RootState) => state.cart.shippingAddress
  )
  const shippingCityList = useSelector(
    (state: RootState) => state.cart.shippingCityList
  )
  const shippingRegionList = useSelector(
    (state: RootState) => state.cart.shippingRegionList
  )
  const shippingAreaList = useSelector(
    (state: RootState) => state.cart.shippingAreaList
  )
  const billingAddressSelect = useSelector(
    (state: RootState) => state.cart.billingAddress
  )
  const billingCityList = useSelector(
    (state: RootState) => state.cart.billingCityList
  )
  const billingRegionList = useSelector(
    (state: RootState) => state.cart.billingRegionList
  )
  const shippingRegionCityList = useSelector(
    (state: RootState) => state.cart.shippingRegionCityList
  )
  const billingRegionCityList = useSelector(
    (state: RootState) => state.cart.billingRegionCityList
  )
  const [shippingAddress, setShippingAddress] = useState(shippingAddressSelect)
  const [billingAddress, setBillingAddress] = useState(billingAddressSelect)
  const { mapStatus } = useSelector((state: RootState) => state.address)
  const namedLinks = useSelector(namedLinksSelector)

  const [showMap, setShowMap] = useState(false)
  const [addressType, setAddressType] = useState('shipping')
  const [formattedShippingAddress, setFormattedShippingAddress] = useState('')
  const [formattedBillingAddress, setFormattedBillingAddress] = useState('')
  const [coordinates, setCoordinates] = useState<google.maps.LatLngLiteral>()
  const [formSubmitted, setFormSubmitted] = useState(false)
  const [
    isBillingAdresseSameAsShippingAddress,
    setBillingAdresseSameAsShippingAddress,
  ] = React.useState(true)
  const [
    usedBillingAddressToggleSwitchManually,
    setUsedBillingAddressToggleSwitchManually,
  ] = React.useState(false)
  const [showAddressListModal, setShowAddressListModal] = useState(false)
  const [selectedShippingAddressId, setSelectedShippingAddressId] = useState('')
  const [selectedBillingAddressId, setSelectedBillingAddressId] = useState('')
  const [modeOfCommunicationOpts, setModeOfCommunicationOpts] = useState<
    {
      key: string
      label: string
    }[]
  >([])

  const {
    iso_639_1: language,
    country: { ctStore: store, id: currentCountry },
    hreflang,
  } = localesFactory.createFromHrefLang(router.locale).current

  const loadAddressForUser = useCallback(
    async (user, store) => {
      dispatch(loadAddressForLoggedInUserThunk({ user, store, language }))
    },
    [dispatch, language]
  )

  useEffect(() => {
    shippingAddressSelect &&
      setShippingAddress({
        ...shippingAddressSelect,
        firstName: shippingAddressSelect?.firstName || user?.firstName,
        lastName: shippingAddressSelect?.lastName || user?.lastName,
        email: shippingAddressSelect?.email || user?.email,
        primaryPhoneNumber:
          shippingAddressSelect?.primaryPhoneNumber ||
          user?.phonenumber?.toString() ||
          '',
      } as Address)
    initialAddresses.length &&
      !shippingAddressSelect &&
      setShippingAddress(initialAddresses[initialAddresses.length - 1])
    shippingAddressSelect?.id &&
      setSelectedShippingAddressId(shippingAddressSelect?.id)
  }, [initialAddresses, shippingAddressSelect, user])

  useEffect(() => {
    billingAddressSelect &&
      setBillingAddress({
        ...billingAddressSelect,
        firstName: billingAddressSelect?.firstName || user?.firstName,
        lastName: billingAddressSelect?.lastName || user?.lastName,
        email: billingAddressSelect?.email || user?.email,
        primaryPhoneNumber:
          billingAddressSelect?.primaryPhoneNumber ||
          user?.phonenumber?.toString() ||
          '',
      } as Address)
    initialAddresses.length &&
      !billingAddressSelect &&
      setBillingAddress(initialAddresses[initialAddresses.length - 1])
    billingAddressSelect?.id &&
      setSelectedBillingAddressId(billingAddressSelect?.id)
  }, [billingAddressSelect, initialAddresses, user])

  useEffect(() => {
    if (user.id) {
      loadAddressForUser(user, store)
    }
  }, [loadAddressForUser, user, store])

  useEffect(() => {
    const getEnumCustomerEffect = async () => {
      const query = 'enumAttribute=modeOfCommunication'
      const enumData = await getEnumByResource({
        localeKey: hreflang,
        resourceId: 'address',
        query: query,
      })
      setModeOfCommunicationOpts(enumData['modeOfCommunication'])
    }

    getEnumCustomerEffect()
  }, [hreflang])

  const onSubmitLocation = (selectedLocation: MapLocation) => {
    if (!user.authenticated) {
      return
    }
    setCoordinates(selectedLocation.coordinates)
    const googleMapsAddress = {
      ...selectedLocation.coordinates,
      results: selectedLocation.results,
      userAuthenticated: user.authenticated,
      store,
    }
    if (isBillingAdresseSameAsShippingAddress) {
      setFormattedShippingAddress(selectedLocation.formattedAddress)
      dispatch(convertAddressThunk({ ...googleMapsAddress, locale: hreflang }))
      setFormattedBillingAddress(selectedLocation.formattedAddress)
      dispatch(
        convertBillingAddressThunk({ ...googleMapsAddress, locale: hreflang })
      )
    } else if (addressType === 'shipping') {
      setFormattedShippingAddress(selectedLocation.formattedAddress)
      dispatch(convertAddressThunk({ ...googleMapsAddress, locale: hreflang }))
    } else if (addressType === 'billing') {
      setFormattedBillingAddress(selectedLocation.formattedAddress)
      dispatch(
        convertBillingAddressThunk({ ...googleMapsAddress, locale: hreflang })
      )
    }
  }

  const onRefreshMapLocation = (type) => {
    setAddressType(type)
    setShowMap(true)
    dispatch(resetAddressStatusAction())
    setShowAddressListModal(false)
  }

  const addNewAddress = async (address) => {
    setAddressType(address)
    if (address === 'shipping') {
      dispatch(resetShippingAddressIdAction())
    }
    if (address === 'billing') {
      dispatch(resetBillingAddressIdAction())
    }
    onRefreshMapLocation(address)
  }

  const onSaveAddress = (shippingAddress: Address, billingAddress: Address) => {
    dispatch(
      addShippingAndBillingAddressToCartThunk({
        user,
        store,
        addresses: {
          shippingAddress: shippingAddress,
          billingAddress: billingAddress,
        },
        language,
        locale: hreflang,
      })
    )
  }

  const toggleBillingAddress = () => {
    setBillingAdresseSameAsShippingAddress(
      !isBillingAdresseSameAsShippingAddress
    )
    setUsedBillingAddressToggleSwitchManually(true)
  }

  const onSubmitAddressfromList = (event: React.FormEvent) => {
    event.preventDefault()
    const [selectedAddress] = initialAddresses.filter((address) => {
      const addressId =
        addressType === 'billing'
          ? selectedBillingAddressId
          : selectedShippingAddressId
      return address.id === addressId
    })

    if (isBillingAdresseSameAsShippingAddress) {
      dispatch(selectBillingAddressAction(selectedAddress))
      dispatch(selectShippingAddressAction(selectedAddress))
    } else {
      addressType === 'billing'
        ? dispatch(selectBillingAddressAction(selectedAddress))
        : dispatch(selectShippingAddressAction(selectedAddress))
    }

    selectedAddress?.address?.latitude &&
      setCoordinates({
        lat: selectedAddress.address.latitude,
        lng: selectedAddress.address.longitude,
      })

    if (selectedAddress?.formattedAddress) {
      addressType === 'billing'
        ? setFormattedBillingAddress(selectedAddress.formattedAddress)
        : setFormattedShippingAddress(selectedAddress.formattedAddress)
    }

    setShowAddressListModal(false)
  }

  const selectAddressfromList = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    addressType === 'billing'
      ? setSelectedBillingAddressId(event.target.value)
      : setSelectedShippingAddressId(event.target.value)
  }

  const openSavedAddress = (address) => {
    setAddressType(address)
    setShowAddressListModal(true)
  }

  useEffect(() => {
    if (!usedBillingAddressToggleSwitchManually) {
      if (
        billingAddress &&
        shippingAddress &&
        (billingAddress.formattedAddress !== shippingAddress.formattedAddress ||
          billingAddress.firstName !== shippingAddress.firstName ||
          billingAddress.lastName !== shippingAddress.lastName ||
          billingAddress.primaryPhoneNumber !==
            shippingAddress.primaryPhoneNumber ||
          billingAddress.secondaryPhoneNumber !==
            shippingAddress.secondaryPhoneNumber)
      ) {
        setBillingAdresseSameAsShippingAddress(false)
      } else {
        setBillingAdresseSameAsShippingAddress(true)
      }
    }
  }, [billingAddress, shippingAddress, usedBillingAddressToggleSwitchManually])

  useEffect(() => {
    if (cartStatus === AsyncResponseStatusEnum.succeeded) {
      shippingAddress?.address === undefined &&
        !initialAddresses.length &&
        setShowMap(true)
      shippingAddress?.address && setShowMap(false)
      if (
        shippingAddress?.address?.latitude &&
        shippingAddress?.address?.longitude
      ) {
        setCoordinates({
          lat: shippingAddress?.address?.latitude,
          lng: shippingAddress?.address?.longitude,
        })
      }
    }
  }, [cartStatus, initialAddresses.length, shippingAddress?.address])

  useEffect(() => {
    if (mapStatus === AsyncResponseStatusEnum.succeeded) {
      setShowMap(false)
    }
  }, [mapStatus])

  useEffect(() => {
    if (cartStatus === AsyncResponseStatusEnum.failed) {
      setFormSubmitted(false)
    }
  }, [cartStatus])

  useEffect(() => {
    if (addAddressToCartStatus === AsyncResponseStatusEnum.succeeded) {
      setFormSubmitted(true)
    }
  }, [addAddressToCartStatus, formSubmitted])

  useEffect(() => {
    if (formSubmitted) {
      router.push(namedLinks.delivery)
    }
  }, [formSubmitted, router, namedLinks])

  useEffect(() => {
    return () => {
      dispatch(resetAddAddressToCartStatusStatusAction())
    }
  }, [dispatch])

  useEffect(() => {
    return () => {
      onRefreshMapLocation(addressType)
    }
  }, [])

  return (
    <CheckoutPageWrapper>
      <div className="col-span-4 leading-6 hidden sm:block lg:leading-8 sm:col-span-7 md:col-start-2 md:col-span-6">
        <Segment
          segments={[
            {
              value: addressDisplayRequired
                ? t('checkout_shipping_segment_label')
                : t('cart_checkout_billingAddress_label'),
              actionUri: '/checkout/shipping',
            },
            {
              value: t('checkout_delivery_segment_label'),
              actionUri: '/checkout/delivery',
              disabled: true,
            },
            {
              value: t('checkout_payment_segment_label'),
              actionUri: '/checkout/payment',
              disabled: true,
            },
          ]}
          openSeg={0}
        />
      </div>
      {(cartStatus === AsyncResponseStatusEnum.succeeded ||
        formSubmitted ||
        cartStatus === AsyncResponseStatusEnum.failed) && (
        <div className="col-span-4 sm:col-span-7 sm:bg-white sm:p-6 md:py-8 md:px-12 md:col-start-2 md:col-span-6">
          <div className={showMap ? 'hidden' : 'block'}>
            <ShippingAddressForm
              formattedShippingAddress={formattedShippingAddress}
              formattedBillingAddress={formattedBillingAddress}
              shippingAddress={shippingAddress}
              billingAddress={billingAddress}
              currentCountry={currentCountry}
              onRefreshMapLocation={(type) => onRefreshMapLocation(type)}
              onSaveAddress={onSaveAddress}
              onBillingAddressToggle={toggleBillingAddress}
              cartStatus={cartStatus}
              isBillingAdresseSameAsShippingAddress={
                isBillingAdresseSameAsShippingAddress
              }
              addresses={initialAddresses}
              openSavedAddress={(address) => openSavedAddress(address)}
              onlyBillingAddressRequired={!addressDisplayRequired}
              addNewAddress={(address) => addNewAddress(address)}
              shippingCityList={shippingCityList}
              shippingRegionList={shippingRegionList}
              shippingAreaList={shippingAreaList}
              billingCityList={billingCityList}
              billingRegionList={billingRegionList}
              shippingRegionCityList={shippingRegionCityList}
              billingRegionCityList={billingRegionCityList}
              locale={hreflang}
              modeOfCommunicationOpts={modeOfCommunicationOpts}
            />
          </div>
          {showMap && (
            <Map
              coordinates={coordinates}
              formattedAddress={
                addressType === 'shipping'
                  ? formattedShippingAddress
                  : formattedBillingAddress
              }
              locale={hreflang}
              onSubmit={onSubmitLocation}
              mapStatus={mapStatus}
              mapType={addressType}
            />
          )}
        </div>
      )}
      <OrderSummary
        btnOrderSummaryLabel={t('checkout_summary_payment_button_pay')}
        btnVariant={ButtonVariantEnum.primaryCta}
        orderSummaryFrom="shipping"
        orderSummaryStatus={true}
        addressDisplayRequired={addressDisplayRequired}
      />
      {showAddressListModal && (
        <Modal
          className={`bg-white rounded-t-lg justify-center items-center fixed left-0 w-full bottom-0 px-5 py-7 sm:top-2/4 sm:left-2/4 sm:max-w-[633px] sm:h-[fit-content] sm:rounded-xl sm:-translate-x-1/2 sm:-translate-y-1/2 sm:px-8 sm:pb-7 sm:pt-8 ${styles.modal}`}
          extraCloseClasses={`pb-4`}
          handleModal={() => {
            setShowAddressListModal(false)
          }}
          showClose={true}
        >
          <ShippingAddressList
            onSubmitAddressfromList={onSubmitAddressfromList}
            initialAddresses={initialAddresses}
            selectAddressfromList={selectAddressfromList}
            selectedAddressId={
              addressType === 'billing'
                ? selectedBillingAddressId
                : selectedShippingAddressId
            }
            addNewAddress={addNewAddress}
            addressType={addressType}
          />
        </Modal>
      )}
    </CheckoutPageWrapper>
  )
}

export default ShippingAddress
