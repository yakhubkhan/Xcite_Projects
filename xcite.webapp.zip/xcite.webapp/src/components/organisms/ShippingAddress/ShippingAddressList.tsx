import React, { useEffect, useRef } from 'react'
import { useTranslation } from 'next-i18next'
import { Address, ButtonVariantEnum, HeadingEnum } from '../../../types/content'
import Button from '../../atoms/Button'
import Heading from '../../atoms/Heading'
import { PinIcon } from '../../atoms/Icon'
import SelectionBox from '../../atoms/SelectionBox'

const ShippingAddressList = ({
  onSubmitAddressfromList,
  initialAddresses,
  selectAddressfromList,
  selectedAddressId,
  addNewAddress,
  addressType,
}: {
  onSubmitAddressfromList: (event: React.FormEvent) => void
  initialAddresses: Address[]
  selectAddressfromList: (event: React.ChangeEvent<HTMLInputElement>) => void
  selectedAddressId: string
  addNewAddress: (address: string) => void
  addressType: string
}): JSX.Element => {
  const { t } = useTranslation()
  const scrollContainer = useRef<HTMLUListElement>(null)

  useEffect(() => {
    const selectedElement = document.getElementById(selectedAddressId)

    if (selectedElement && scrollContainer.current) {
      selectedElement.scrollIntoView({ behavior: 'smooth', block: 'center' })
    }
  }, [selectedAddressId])

  return (
    <form className="" onSubmit={onSubmitAddressfromList}>
      <Heading type={HeadingEnum.h4} className={`pb-4`}>
        {t('checkout_shipping_modal_address_heading')}
      </Heading>
      <ul
        className="overflow-y-auto sm:max-h-64 scroll-smooth"
        ref={scrollContainer}
      >
        {initialAddresses.map((address) => (
          <li key={address.id} className="mb-3 last:mb-0">
            <SelectionBox
              value={address.id}
              onValChange={selectAddressfromList}
              checked={address.id === selectedAddressId}
              inputName="address"
              inputId={`${address.id}`}
              extraClassName="items-start"
            >
              <PinIcon className={`h-6 w-6 stroke-current `} />
              <div className="flex-1">
                <div className="typography-small-strong">
                  {address.firstName + ' ' + address.lastName}
                </div>
                <div className="typography-small">
                  {address.formattedAddress}
                </div>
              </div>
            </SelectionBox>
          </li>
        ))}
      </ul>
      <div className="py-8">
        <Button
          type="button"
          variant={ButtonVariantEnum.secondaryOnLight}
          className={`w-full`}
          onClick={() => addNewAddress(addressType)}
        >
          {t('checkout_shipping_modal_address_new_address')}
        </Button>
      </div>
      <div className="pb-8">
        <Button
          type="submit"
          variant={ButtonVariantEnum.primaryOnLight}
          className={`w-full`}
          disabled={!selectedAddressId}
        >
          {t('checkout_shipping_modal_address_confirm')}
        </Button>
      </div>
    </form>
  )
}

export default ShippingAddressList
