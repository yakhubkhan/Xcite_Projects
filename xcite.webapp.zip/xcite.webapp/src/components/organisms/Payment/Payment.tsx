import { useRouter } from 'next/router'
import Script from 'next/script'
import { useTranslation } from 'next-i18next'
import React, { useCallback, useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'

import {
  AsyncResponseStatusEnum,
  ButtonVariantEnum,
  PaymentMethodName,
  ToastDuration,
  ToastType,
} from '../../../types/content'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import {
  cartPaymentMethodSelector,
  cartTotalItemsSelector,
  cartShippingAddressSelector,
  cartBillingAddressSelector,
  cartGroupSelector,
  cartAddressDisplayRequiredSelector,
} from '../../../redux/slices/cart'
import { namedLinksSelector } from '../../../redux/slices/navigation'
import {
  loadPaymentMethodsThunk,
  paymentMethodsSelector,
  paymentStatusSelector,
  resetPaymentStatusAction,
  selectPaymentMethodThunk,
} from '../../../redux/slices/payment'
import { userProfileSelector } from '../../../redux/slices/profile'
import { useModal } from '../../../hooks'
import Segment from '../../atoms/Segment'
import CheckoutPageWrapper from '../../molecules/CheckoutPageWrapper'
import Modal from '../../molecules/Modal'
import PaymentCardForm from '../../molecules/PaymentCardForm'
import PaymentMethodForm from '../../molecules/PaymentMethodForm'
import OrderSummary from '../OrderSummary'
import { FrameCardTokenizedEvent } from 'frames-react'
import Toaster from '../../atoms/Toaster'
import { getErrorTextKeyFromErrorCode } from '../ReviewOrder/ReviewOrder'
import gtmDatalayer from '../../../util/gtmUtils'

const Payment = (): JSX.Element => {
  const router = useRouter()

  const { t } = useTranslation()

  const dispatch = useDispatch()
  const user = useSelector(userProfileSelector)
  const totalItems = useSelector(cartTotalItemsSelector)
  const selectedPaymentMethod = useSelector(cartPaymentMethodSelector)
  const shippingAddress = useSelector(cartShippingAddressSelector)
  const billingAddress = useSelector(cartBillingAddressSelector)
  const addressDisplayRequired = useSelector(cartAddressDisplayRequiredSelector)
  const cartGroups = useSelector(cartGroupSelector)
  const paymentMethods = useSelector(paymentMethodsSelector)
  const paymentStatus = useSelector(paymentStatusSelector)
  const namedLinks = useSelector(namedLinksSelector)

  const { isShowing: isShowingCreditCardModal, toggle: toggleCreditCardModal } =
    useModal()

  const [errorMsg, setErrorMsg] = useState('')

  const {
    iso_639_1: language,
    country: { ctStore: store },
    hreflang,
  } = localesFactory.createFromHrefLang(router.locale).current

  const submitPaymentMethod = (paymentMethod?: PaymentMethodName) => {
    if (paymentMethod) {
      if (paymentMethod === PaymentMethodName.CreditCard) {
        toggleCreditCardModal()
        return
      }
      selectPayment(paymentMethod)
    }
  }

  const selectPayment = (
    paymentMethod: PaymentMethodName,
    checkoutComTokenizationResponse?: FrameCardTokenizedEvent
  ) => {
    dispatch(
      selectPaymentMethodThunk({
        user,
        paymentMethod,
        store,
        language,
        locale: hreflang,
        reqBody: {
          checkoutComTokenizationResponse,
        },
      })
    )
    const eventActionObj =
      '{"paymentMethod":' +
      JSON.stringify(paymentMethod) +
      ',"eventAction": "Confirm Payment Type"}'
    gtmDatalayer('add_payment_info', 'Order Review', eventActionObj)
  }

  const onSuccessfulPaymentSubmit = useCallback(() => {
    dispatch(resetPaymentStatusAction())
    router.push(namedLinks.review)
  }, [dispatch, namedLinks, router])

  useEffect(() => {
    if (paymentStatus === AsyncResponseStatusEnum.succeeded) {
      onSuccessfulPaymentSubmit()
    }
  }, [onSuccessfulPaymentSubmit, paymentStatus])

  useEffect(() => {
    const errorCode = router?.query?.errorText as string
    if (errorCode) {
      setErrorMsg(t(getErrorTextKeyFromErrorCode(errorCode)))
      history.pushState(null, '', location.pathname)
    }
  }, [router, t])

  useEffect(() => {
    if (user.id && totalItems > 0) {
      dispatch(
        loadPaymentMethodsThunk({ user, store, language, locale: hreflang })
      )
    }
  }, [dispatch, language, store, totalItems, user, hreflang])

  return (
    <CheckoutPageWrapper>
      <div className="col-span-4 leading-6 hidden sm:block lg:leading-8 sm:col-span-7 md:col-start-2 md:col-span-6">
        <Segment
          segments={[
            {
              value: addressDisplayRequired
                ? t('checkout_shipping_segment_label')
                : t('cart_checkout_billingAddress_label'),
              actionUri: '/checkout/shipping',
              completed: true,
            },
            {
              value: t('checkout_delivery_segment_label'),
              actionUri: '/checkout/delivery',
              completed: true,
            },
            {
              value: t('checkout_payment_segment_label'),
              actionUri: '/checkout/payment',
            },
          ]}
          openSeg={2}
        />
      </div>
      {errorMsg && (
        <Toaster
          className="orp-toast"
          duration={ToastDuration}
          toastMsg={errorMsg}
          type={ToastType.error}
        />
      )}
      <div className="col-span-4 sm:col-span-7 sm:bg-white sm:p-6 md:py-8 md:px-12 md:col-start-2 md:col-span-6">
        <PaymentMethodForm
          key={selectedPaymentMethod?.name}
          paymentMethods={paymentMethods}
          selectedPaymentMethod={selectedPaymentMethod?.name}
          onSubmitPaymentMethod={submitPaymentMethod}
        />
      </div>
      <OrderSummary
        btnOrderSummaryLabel={t('checkout_summary_payment_button_pay')}
        btnVariant={ButtonVariantEnum.primaryCta}
        orderSummaryFrom="payment"
        orderSummaryStatus={true}
        shippingAddress={shippingAddress}
        billingAddress={billingAddress}
        cartGroups={cartGroups}
        addressDisplayRequired={addressDisplayRequired}
      />

      <Modal isShowing={isShowingCreditCardModal} hide={toggleCreditCardModal}>
        <div className="px-5 sm:px-20">
          <PaymentCardForm
            onCardDetailsSubmitted={(checkoutComTokenizationResponse) => {
              selectPayment(
                PaymentMethodName.CreditCard,
                checkoutComTokenizationResponse
              )
            }}
            language={language}
            store={store}
            selectedPaymentLabel={
              paymentMethods.find(
                (method) => method?.name === PaymentMethodName.CreditCard
              )?.label || ''
            }
            availablePaymentMethods={
              paymentMethods.find(
                (method) => method?.name === PaymentMethodName.CreditCard
              )?.acceptedPaymentMethods || []
            }
          />
        </div>
      </Modal>
      <Script src="https://cdn.checkout.com/js/framesv2.min.js" />
    </CheckoutPageWrapper>
  )
}

export default Payment
