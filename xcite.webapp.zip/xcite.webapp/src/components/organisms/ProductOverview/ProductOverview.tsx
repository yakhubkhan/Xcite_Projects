import React from 'react'
import {
  ProductQuickOverviewContentType,
  ProductStatusEnum,
} from '../../../types/content'
import Accordion from '../../molecules/Accordion'
import { AccordionItemType } from '../../molecules/Accordion/Accordion'
import ProductKeyFeatures from './ProductKeyFeatures'
import ProductDeliveryMethods from './ProductDeliveryMethods'
import { useTranslation } from 'next-i18next'

const ProductOverview = ({
  content,
  sku,
  prodStatus,
}: {
  content: ProductQuickOverviewContentType
  sku: string
  prodStatus: ProductStatusEnum | undefined
}): JSX.Element => {
  const { t } = useTranslation()
  const getOverviewContent = (sections: ProductQuickOverviewContentType) => {
    const overviewContent: AccordionItemType[] = []

    const { details, shipping } = sections

    if (details && details.content) {
      overviewContent.push({
        id: details.id,
        title: t(
          'pdp_product_sections_quickOverview_content_details_sectionTitle'
        ),
        content: <ProductKeyFeatures content={details.content} />,
        isOpen: true,
      })
    }
    if (shipping) {
      overviewContent.push({
        id: shipping.id,
        title: t(
          'pdp_product_sections_quickOverview_content_shipping_sectionTitle'
        ),
        content: (
          <ProductDeliveryMethods
            methods={shipping.deliveryMethods}
            sku={sku}
            prodStatus={prodStatus}
            wideDelivery={shipping.wideDelivery}
          />
        ),
        isOpen: true,
      })
    }

    return overviewContent
  }

  return <Accordion items={getOverviewContent(content)}></Accordion>
}

export default ProductOverview
