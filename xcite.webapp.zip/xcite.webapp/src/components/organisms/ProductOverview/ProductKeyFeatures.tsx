import 'react'
import MarkDown from '../../atoms/MarkDown'

import styles from './ProductOverview.module.css'

const ProductKeyFeatures = ({ content }: { content: string }): JSX.Element => {
  return (
    <div className={`${styles.list} typography-small`}>
      <MarkDown>{content}</MarkDown>
    </div>
  )
}

export default ProductKeyFeatures
