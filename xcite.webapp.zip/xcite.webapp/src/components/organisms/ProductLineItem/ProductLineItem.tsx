import { useRouter } from 'next/router'
import { useTranslation } from 'next-i18next'
import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'

import {
  cartItemsSelector,
  cartStatusSelector,
  removeStorePickupDetails,
  removeWarrantyFromCartThunk,
  updateItemQuantity,
  addWarrantyFromCartThunk,
  updateWarrantyFromCartThunk,
} from '../../../redux/slices/cart'
import { userProfileSelector } from '../../../redux/slices/profile'
import {
  AsyncResponseStatusEnum,
  ButtonVariantEnum,
  CartMessageType,
  CartWarrantyItem,
  HeadingEnum,
  ProductLineItemType,
  CountryCodeEnum,
} from '../../../types/content'
import Image from '../../atoms/Image'
import Link from '../../atoms/Link'
import QuantityCounter from '../../molecules/QuantityCounter'
import ToggleSwitch from '../../atoms/ToggleSwitch'
import Storelist from '../Storelist/index'
import localesFactory from '../../../lib/api/l18n/LocalesFactory'
import Heading from '../../atoms/Heading'
import ProductStatusIcon from '../../molecules/ProductStatusIcon'
import Button from '../../atoms/Button'
import ProductWarrantyModal from '../ProductWarranty/ProductWarrantyModal'
import {
  addWarrantyThunk,
  warrantyDetailsSelector,
} from '../../../redux/slices/warranty'
import { CommercetoolsMessageCodeEnum } from '../../../types/commerceTools'
import { ShoppingBagIcon } from '../../atoms/Icon'
import { namedLinksSelector } from '../../../redux/slices/navigation'
import { getDiscountPercantage } from '../../../util/apiUtils'
import gtmDatalayer from '../../../util/gtmUtils'

interface Props {
  item: ProductLineItemType
  pliFrom?: string
  isWarrantyAvailable?: boolean
  cartMessages?: CartMessageType[]
  cncAvailability?: boolean
}

const ProductLineItem = ({
  item,
  pliFrom,
  isWarrantyAvailable,
  cartMessages,
  cncAvailability,
}: Props): JSX.Element => {
  const { locale } = useRouter()

  const dispatch = useDispatch()
  const user = useSelector(userProfileSelector)
  const cartStatus = useSelector(cartStatusSelector)
  const warrantyDetails = useSelector(warrantyDetailsSelector)
  const namedLinks = useSelector(namedLinksSelector)
  const cartItems = useSelector(cartItemsSelector)
  const { t } = useTranslation()
  const router = useRouter()

  const [viewModal, setViewModal] = useState(false)
  const [pickupSelected, setPickupSelected] = useState(false)
  const [deleteStore, setDeleteStore] = useState(false)
  const [inReviewOrderPage, setInReviewOrderPage] = useState(false)
  const [inCartPage, setInCartPage] = useState(false)
  const [selectedWarranty, setSelectedWarranty] = useState<CartWarrantyItem>()
  const [warrantyModalOpen, setWarrantyModalOpen] = useState(false)
  const [isOutOfStock, setIsOutOfStock] = useState(false)
  const [isDiscontinued, setIsDiscontinued] = useState(false)
  const [isInsufficientStock, setIsInsufficientStock] = useState(false)
  const [showCncCta, setShowCncCta] = useState(false)
  const [hideStore, setHideStore] = useState(false)
  const [deliveryCTA, setDeliveryCTA] = useState(false)
  const [totalQty, setTotalQty] = useState(0)
  const isBundleProduct = item.bundleProduct
  const discountValue = item.price
    ? getDiscountPercantage(item.price.value, item.price.valueUnmodified)
    : 0

  const {
    iso_639_1: language,
    country: { id: countryId, ctStore: store },
    hreflang,
  } = localesFactory.createFromHrefLang(locale).current

  const handleToggle = () => {
    if (item.pickupStore?.id && !deleteStore) {
      setPickupSelected(false)
      deleteSelectedStore()
      setDeleteStore(true)
    } else {
      setViewModal(!viewModal)
      setDeleteStore(false)
    }
  }

  const messageCode = cartMessages?.find((message) => {
    if (
      message.code !== CommercetoolsMessageCodeEnum.OUT_OF_STOCK &&
      message.code !== CommercetoolsMessageCodeEnum.INVALID_PRODUCT_STATUS
    ) {
      return message.skus.includes(item.sku) ? message.code : ''
    }
  })

  const routePushToCart = () => {
    router.push(
      {
        query: {
          lineItemId: item.id,
        },
      },
      namedLinks.cart
    )
  }

  const openStorelist = () => {
    if (inReviewOrderPage) {
      routePushToCart()
    }
    if (inCartPage) {
      setViewModal(true)
    }
  }
  const updateWarranty = (sku: string, warranty?: CartWarrantyItem) => {
    try {
      const warrantyPromise = new Promise(function (resolve, reject) {
        resolve(
          dispatch(
            addWarrantyThunk({
              sku: sku,
              locale: hreflang,
            })
          )
        )
      })
      warrantyPromise.then(
        (result) => {
          gtmDatalayer('add_warranty', 'add_warranty', 'add_warranty')
        },
        function (error) {
          console.log(error)
        }
      )
    } catch (e) {
      console.error(e)
    }
    warranty && setSelectedWarranty(warranty)
    !warranty &&
      item?.warranties?.[0] &&
      setSelectedWarranty(item.warranties[0].warrantyItems?.[0])
    setWarrantyModalOpen(true)
  }

  const handleModal = () => setWarrantyModalOpen(false)

  const deleteSelectedStore = async () => {
    if (inReviewOrderPage) {
      routePushToCart()
    }
    if (inCartPage) {
      dispatch(
        removeStorePickupDetails({
          lineItemId: item.id,
          user,
          store,
          language,
          locale: hreflang,
        })
      )
    }
  }

  const removeProduct = () => {
    if (inReviewOrderPage) {
      routePushToCart()
    }
    if (inCartPage && user.id && store) {
      onUpdateQuantity(0)
    }
  }

  const onUpdateQuantity = async (quantity: number) => {
    if (cartItems.length > 0) {
      const removedItem = cartItems.filter((cartItem) => {
        return cartItem.id === item.id
      })
      if (removedItem) {
        gtmDatalayer(
          'dh_remove_from_cart',
          'RemoveCartView',
          '{"item":' +
            JSON.stringify(removedItem) +
            ', "eventAction":"CartView"}'
        )
      }
    }
    const updateReq = {
      lineItemId: item.id,
      quantity,
      user,
      store,
      language,
      locale: hreflang,
    }

    dispatch(updateItemQuantity(updateReq))
  }

  const removeWarranty = async (warranty) => {
    const warrantyPromise = new Promise(function (resolve, reject) {
      resolve(
        dispatch(
          removeWarrantyFromCartThunk({
            lineItemId: warranty.warrantyLineItemId,
            user,
            store,
            language,
            locale: hreflang,
          })
        )
      )
    })
    warrantyPromise.then(
      (result) => {
        gtmDatalayer('remove_warranty', 'remove_warranty', 'remove_warranty')
      },
      function (error) {
        console.log(error)
      }
    )
  }

  const cartWarrantyDetails = async (
    cartWarrantyDTO = { warrantyType: '' }
  ) => {
    const { warrantyType } = cartWarrantyDTO
    if (!item.warranties) {
      try {
        const warrantyPromise = new Promise(function (resolve, reject) {
          resolve(
            dispatch(
              addWarrantyFromCartThunk({
                user,
                store,
                language,
                locale,
                lineItemId: item.id,
                warrantyType: warrantyType,
              })
            )
          )
        })
        warrantyPromise.then(
          (result) => {
            gtmDatalayer('add_warranty', 'add_warranty', 'add_warranty')
          },
          function (error) {
            console.log(error)
          }
        )
      } catch (e) {
        console.error(e)
      }
    } else {
      try {
        const warrantyPromise = new Promise(function (resolve, reject) {
          resolve(
            dispatch(
              updateWarrantyFromCartThunk({
                user,
                store,
                language,
                locale,
                lineItemId: selectedWarranty?.warrantyLineItemId || '',
                warrantyType: warrantyType,
              })
            )
          )
        })
        warrantyPromise.then(
          (result) => {
            gtmDatalayer('add_warranty', 'add_warranty', 'add_warranty')
          },
          function (error) {
            console.log(error)
          }
        )
      } catch (e) {
        console.error(e)
      }
    }
  }

  useEffect(() => {
    if (cartItems && cartItems.length > 0) {
      const uniqueItems = cartItems.filter((items) => items.sku === item.sku)
      let totalCount = 0
      if (uniqueItems && cartItems.length > 0) {
        uniqueItems.forEach(function (chkItemQty) {
          totalCount += chkItemQty.quantity
        })
      }
      setTotalQty(totalCount)
    }
    item.pickupStore?.name ? setPickupSelected(true) : setPickupSelected(false)
  }, [item])

  useEffect(() => {
    setIsOutOfStock(false)
    setHideStore(false)
    setIsInsufficientStock(false)
    setIsDiscontinued(false)
    if (
      messageCode?.code ===
      CommercetoolsMessageCodeEnum.PRODUCT_STATUS_DISCONTINUED
    ) {
      setIsDiscontinued(true)
    } else if (
      messageCode?.code ===
      CommercetoolsMessageCodeEnum.PRODUCT_STATUS_OUT_OF_ONLINE_STOCK
    ) {
      setIsOutOfStock(true)
      cncAvailability ? setShowCncCta(true) : setShowCncCta(false)
    } else if (
      messageCode?.code ===
      CommercetoolsMessageCodeEnum.PRODUCT_STATUS_OUT_OF_CNC_STOCK
    ) {
      setIsOutOfStock(true)
      cncAvailability ? setShowCncCta(true) : setShowCncCta(false)
      item.pickupStore ? setHideStore(true) : setHideStore(false)
    } else if (
      messageCode?.code ===
      CommercetoolsMessageCodeEnum.PRODUCT_STATUS_OUT_OF_CNC_ONLINE_IN_STOCK
    ) {
      setIsOutOfStock(true)
      setDeliveryCTA(true)
      item.pickupStore ? setHideStore(true) : setHideStore(false)
    } else if (
      messageCode?.code ===
      CommercetoolsMessageCodeEnum.PRODUCT_STATUS_OUT_OF_SELECTED_STORE_STOCK
    ) {
      setIsOutOfStock(true)
      cncAvailability ? setShowCncCta(true) : setShowCncCta(false)
      item.pickupStore ? setHideStore(true) : setHideStore(false)
    } else if (
      messageCode?.code ===
        CommercetoolsMessageCodeEnum.INSUFFICIENT_STOCK_CNC ||
      messageCode?.code ===
        CommercetoolsMessageCodeEnum.INSUFFICIENT_STOCK_ONLINE ||
      messageCode?.code === CommercetoolsMessageCodeEnum.SAP_UNCONFIRMED_QTY
    ) {
      setIsInsufficientStock(true)
    }
  }, [item, isDiscontinued, showCncCta, hideStore, deliveryCTA])

  useEffect(() => {
    pliFrom === 'revieworder'
      ? setInReviewOrderPage(true)
      : setInReviewOrderPage(false)
    pliFrom === 'cart' ? setInCartPage(true) : setInCartPage(false)
  }, [pliFrom])

  useEffect(() => {
    warrantyModalOpen
      ? (document.body.style.overflow = 'hidden')
      : (document.body.style.overflow = 'unset')
  }, [warrantyModalOpen])

  return (
    <article
      className={`flex flex-col gap-10 sm:gap-12 ${
        isDiscontinued || isOutOfStock || isInsufficientStock
          ? 'border border-functional-red-800 p-5 rounded-md'
          : ''
      }`}
    >
      <div className="grid grid-cols-6 grid-gap gap-x-5">
        <div className="col-span-2 flex flex-col gap-2 items-center sm:gap-4">
          <Link to={`/${item.slug}/p`}>
            <Image
              alt={item.image.alt}
              src={item.image.src}
              layout="intrinsic"
              width={280}
              height={280}
              objectFit="contain"
            />
          </Link>
          {!isDiscontinued &&
            (!isOutOfStock || showCncCta || deliveryCTA) &&
            !item.warranties &&
            !item.digitalProduct &&
            !inReviewOrderPage && (
              <div className={`w-full max-w-[120px]`}>
                <QuantityCounter
                  quantity={item.quantity}
                  itemTotalQuantity={totalQty}
                  maxQuantity={item.maxQuantity}
                  isLoading={cartStatus === AsyncResponseStatusEnum.loading}
                  onUpdateQuantity={onUpdateQuantity}
                  increaseLabel="increase quantity"
                  decreaseLabel="decrease quantity"
                />
              </div>
            )}
          {!isDiscontinued &&
            (!isOutOfStock || showCncCta || deliveryCTA) &&
            !inReviewOrderPage && (
              <Button
                variant={ButtonVariantEnum.textLink}
                onClick={() => onUpdateQuantity(0)}
              >
                {t('remove_button_label')}
              </Button>
            )}
        </div>
        <div className="col-span-4">
          <div className="flex flex-col gap-4">
            <div>
              <span className="typography-small">{item.brand}</span>
              <Link to={`/${item.slug}/p`}>
                <Heading type={HeadingEnum.h5}>{item.name}</Heading>
              </Link>
            </div>
            {(isOutOfStock || isInsufficientStock) && (
              <div>
                <Heading type={HeadingEnum.h4}>
                  {discountValue > 0 ? (
                    <>
                      <span className={`text-lg line-through mr-2 font-body`}>
                        {item.price?.formattedPriceUnmodified}
                      </span>
                      {'  '}
                      <span className={`text-2xl text-functional-red-800 mr-2`}>
                        {item.price?.formattedPrice}
                      </span>
                    </>
                  ) : (
                    item.price.formattedPrice
                  )}
                </Heading>
                {countryId === CountryCodeEnum.SaudiArabia && (
                  <div className="typography-small">
                    {t('product_inclusive_of_vat_label')}
                  </div>
                )}
              </div>
            )}
            {isInsufficientStock && (
              <ProductStatusIcon methodName={messageCode?.code} />
            )}
            {(isDiscontinued || isOutOfStock) && (
              <>
                <ProductStatusIcon methodName={messageCode?.code} />
                {showCncCta ? (
                  <Button
                    variant={ButtonVariantEnum.secondaryOnLight}
                    className={`w-full sm:max-w-[335px]`}
                    onClick={openStorelist}
                  >
                    <div className="flex flex-row gap-2 justify-center">
                      {messageCode?.code ===
                      CommercetoolsMessageCodeEnum.PRODUCT_STATUS_OUT_OF_SELECTED_STORE_STOCK ? (
                        <span className="">
                          {t('cart_checkout_item_choose_other_store_label')}
                        </span>
                      ) : (
                        <span className="">
                          {t(
                            'pdp_product_sections_quickOverview_content_shipping_chooseStore'
                          )}
                        </span>
                      )}
                      <ShoppingBagIcon className="h-6 w-6 stroke-current" />
                    </div>
                  </Button>
                ) : (
                  <>
                    {deliveryCTA ? (
                      <Button
                        variant={ButtonVariantEnum.secondaryOnLight}
                        className={`w-full sm:max-w-[335px]`}
                        onClick={deleteSelectedStore}
                      >
                        <span className="">
                          {t('cart_checkout_item_have_it_delivered_label')}
                        </span>
                      </Button>
                    ) : (
                      <Button
                        className="sm:w-[160px]"
                        variant={ButtonVariantEnum.redOnLight}
                        onClick={() => removeProduct()}
                        dataTestId="remove-item-btn"
                      >
                        {t('remove_button_label')}
                      </Button>
                    )}
                  </>
                )}
              </>
            )}
            {!isDiscontinued &&
              !isOutOfStock &&
              !isInsufficientStock &&
              inReviewOrderPage &&
              item.quantity > 1 && (
                <div className="typography-small">
                  {t('profile_order_history_tile_quantity', {
                    quantity: item.quantity,
                  })}
                </div>
              )}
            {!isDiscontinued && (
              <>
                {!isOutOfStock && !isInsufficientStock && (
                  <>
                    <div>
                      <Heading type={HeadingEnum.h4}>
                        {discountValue > 0 ? (
                          <>
                            <span
                              className={`text-lg line-through mr-2 font-body`}
                            >
                              {item.price?.formattedPriceUnmodified}
                            </span>
                            {'  '}
                            <span
                              className={`text-2xl text-functional-red-800 mr-2`}
                            >
                              {item.price?.formattedPrice}
                            </span>
                          </>
                        ) : (
                          item.price.formattedPrice
                        )}
                      </Heading>
                      {countryId === CountryCodeEnum.SaudiArabia && (
                        <div className="typography-small">
                          {t('product_inclusive_of_vat_label')}
                        </div>
                      )}
                    </div>

                    {!inReviewOrderPage &&
                      isWarrantyAvailable &&
                      item.warranties === undefined && (
                        <div>
                          {isBundleProduct ? (
                            <Button
                              className="block px-10"
                              variant={ButtonVariantEnum.secondaryOnLight}
                              type="button"
                              onClick={() => cartWarrantyDetails()}
                            >
                              {t('product_add_warranty_button_label')}
                            </Button>
                          ) : (
                            <>
                              <span className="typography-small">
                                {t('pdp_product_warranty_label')}:{' '}
                                {t('pdp_product_warranty_none_label')}
                              </span>
                              <Button
                                className="block"
                                variant={ButtonVariantEnum.textLink}
                                type="button"
                                onClick={() => updateWarranty(item.sku)}
                              >
                                {t('product_add_warranty_label')}
                              </Button>
                            </>
                          )}
                        </div>
                      )}
                  </>
                )}
                {pliFrom === 'revieworder' && pickupSelected && (
                  <div className="flex flex-col gap-2">
                    {t('pickup_from_store_label')}
                    <div className="typography-small-strong">
                      {item.pickupStore?.name}
                    </div>
                    <div className="typography-small">
                      {item.pickupStore?.openingHours}
                      <br />
                      {item.pickupStore?.address}
                    </div>
                  </div>
                )}
                {!inReviewOrderPage && !item.digitalProduct && (
                  <div>
                    {!isOutOfStock && (
                      <ToggleSwitch
                        onChange={handleToggle}
                        checked={pickupSelected}
                        label={t('cart_store_available')}
                        disabled={!cncAvailability}
                      />
                    )}
                    {viewModal && (
                      <Storelist
                        sku={item.sku}
                        onCloseModal={() => {
                          setViewModal(false)
                        }}
                        onConfirmModalClose={() => {
                          setViewModal(false)
                          setPickupSelected(true)
                        }}
                        skuLineItemId={item.id}
                      />
                    )}
                    {pickupSelected && !hideStore && (
                      <div className="flex flex-col gap-1">
                        <div className="typography-small-strong">
                          {item.pickupStore?.name}
                        </div>
                        <div className="typography-small">
                          {item.pickupStore?.openingHours}
                          <br />
                          {item.pickupStore?.address}
                        </div>
                        <div>
                          <Button
                            variant={ButtonVariantEnum.textLink}
                            className="block"
                            onClick={() => {
                              setViewModal(true)
                            }}
                          >
                            {t(
                              'pdp_product_sections_quickOverview_content_shipping_change'
                            )}
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
                {inReviewOrderPage && isInsufficientStock && (
                  <>
                    <Button
                      className="sm:w-[160px]"
                      variant={ButtonVariantEnum.redOnLight}
                      onClick={() => removeProduct()}
                      dataTestId="remove-item-btn"
                    >
                      {t('remove_button_label')}
                    </Button>
                  </>
                )}
              </>
            )}
          </div>
        </div>
      </div>
      {item.warranties &&
        item.warranties?.map((warrantiesObj, i1) => {
          return warrantiesObj.warrantyItems?.map((warranty, i2) => {
            return (
              <div
                className="grid grid-cols-6 grid-gap gap-x-5"
                key={i1 + i2 + 'warranty'}
              >
                {isBundleProduct && (
                  <>
                    <div className="col-span-6 pb-10 sm:pb-12 border-t border-t-gray-300"></div>
                    <div className="col-span-6 pb-10 sm:pb-12">
                      <Heading type={HeadingEnum.h5}>
                        {warrantiesObj?.name}
                      </Heading>
                    </div>
                  </>
                )}
                <div className="col-span-2 flex flex-col gap-2 items-center sm:gap-4">
                  <Image
                    src={warranty?.image.src || ''}
                    alt={warranty?.image.alt}
                    width={198}
                    height={198}
                    objectFit="contain"
                  />
                  <div>
                    {inCartPage && (
                      <Button
                        variant={ButtonVariantEnum.textLink}
                        onClick={() => removeWarranty(warranty)}
                      >
                        {t('remove_button_label')}
                      </Button>
                    )}
                  </div>
                </div>
                <div className="col-span-4">
                  <div className="flex flex-col gap-4">
                    <div>
                      <span className="typography-small">
                        {t('warranty_generic_label')}
                      </span>
                      <Heading type={HeadingEnum.h5}>
                        {warranty?.warrantyDescription}
                      </Heading>
                    </div>
                    <div>
                      <Heading type={HeadingEnum.h4}>
                        {warranty?.price.formattedPrice}
                      </Heading>
                      {countryId === CountryCodeEnum.SaudiArabia && (
                        <div className="typography-small">
                          {t('product_inclusive_of_vat_label')}
                        </div>
                      )}
                    </div>
                    {inCartPage && (
                      <div>
                        <Button
                          variant={ButtonVariantEnum.textLink}
                          onClick={() =>
                            updateWarranty(warrantiesObj.sku, warranty)
                          }
                          className="justify-start"
                        >
                          {t('cart_warranty_change_plan_label')}
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )
          })
        })}
      {warrantyModalOpen && warrantyDetails && (
        <ProductWarrantyModal
          handleModal={handleModal}
          warrantyDetails={warrantyDetails}
          slideIndex={1}
          pliFrom={pliFrom}
          cartWarrantyDetails={cartWarrantyDetails}
        />
      )}
    </article>
  )
}

export default ProductLineItem
