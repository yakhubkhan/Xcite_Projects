import { addResponseHeaders } from './addResponseHeaders'

class ServerResponseStub {
  public statusCode = 200

  public setHeader = () => void 0
}

const serverResponseStub = new ServerResponseStub()

beforeEach(() => jest.resetAllMocks())

describe('should add response headers', () => {
  const OLD_ENV = process.env

  beforeEach(() => {
    jest.resetModules()
    process.env = { ...OLD_ENV }
  })

  afterAll(() => {
    process.env = OLD_ENV
  })

  it('with enabled cache headers', () => {
    process.env.NEXT_PUBLIC_HTTP_ENABLE_CACHE_HEADERS = 'true'
    process.env.NEXT_PUBLIC_HTTP_CACHE_SMAXAGE = '35'
    process.env.NEXT_PUBLIC_HTTP_STALE_WHILE_REVALIDATE = '42'
    process.env.NEXT_PUBLIC_HTTP_STALE_IF_ERROR = '18'
    const spy = jest.spyOn(serverResponseStub, 'setHeader')
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    addResponseHeaders(serverResponseStub)
    expect(spy).toHaveBeenCalledWith(
      'Cache-Control',
      `public, s-maxage=${35 * 60}, stale-while-revalidate=${
        42 * 60
      }, stale-if-error=${18 * 60}`
    )
  })

  it('with disabled cache headers', () => {
    process.env.NEXT_PUBLIC_HTTP_ENABLE_CACHE_HEADERS = 'false'
    const spy = jest.spyOn(serverResponseStub, 'setHeader')
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    addResponseHeaders(serverResponseStub)
    expect(spy).not.toHaveBeenCalled()
  })
})
