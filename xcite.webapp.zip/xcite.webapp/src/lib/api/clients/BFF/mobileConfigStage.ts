import { MobileConfigPayload } from '../../../../types/api'
import { MobileConfig } from '../../../../types/content'
import { reportErrorUtils } from '../../../../util/reportErrorUtils'
import environment from '../../../environment'
import { BaseClient } from './baseClient'

class MobileConfigStageClient extends BaseClient {
  public getMobileStageConfigs = async (
    params: MobileConfigPayload
  ): Promise<MobileConfig> => {
    const { config_env, store_id, locale } = params
    const defualtMobileConfig = {}
    try {
      const enKWMobileConfig = {
        currentAppVersion: '2.0',
        requiredAppVersion: '2.0',
        apiVersion: '2.0',
        enableInstantSearch: false,
        verifyEmail: false,
        showDeal: true,
        countryMobileCode: '+965',
        isFlixMediaEnable:true,
        isPersonyzeEnable:true,
        mobileNumberDigit: '8',
        enableCriteoSDK: true,
        categoryCacheTime: '1',
        enableInAppUpdate: false,
        rootedDetection: true,
        appEnvironment: 'commercetools',
        algoliaIndexPrefix: 'xcite_qa_kw_en',
        enableVat: false,
        freshChatAppID: environment.getFreshchatAppId,
        freshChatAppKey: environment.getFreshchatAppKey,
        freshChatDomain: 'msdk.eu.freshchat.com',
        flixMediaId: environment.getFlixMediaIdKW,
        mapApiKeyiOS: environment.getMapApiKeyIos,
        mapApiKeyAndroid: environment.getMapApiKeyAndroid,
        isCheckoutMapMandate: true,
        showChat: true,
        showChatMore: true,
        showDeliveryMobileNoMessage: false,
        showBeforePrice: true,
        algoliaIndexName: 'xcite_qa_kw_en_main',
        algoliaAppId: environment.apiAlgoliaAppIdPublic,
        algoliaApiKey: environment.apiAlgoliaApiKeyPublic,
        sendAlgoliaEvents: true,
        currentAppVersionAndroid: '110',
        requiredAppVersionAndroid: '110',
        currentAppVersionIOS: '3.2.0',
        requiredAppVersionIOS: '3.2.0',
        currentAppVersionHMS: '98',
        requiredAppVersionHMS: '97',
        huaweiStoreUrl: 'https://appgallery7.huawei.com/#/app/C101524419',
        androidStoreUrl:
          'https://play.google.com/store/apps/details?id=com.developmentnow.xcite',
        iosStoreUrl: 'itms-apps://itunes.apple.com/app/id649610123',
        pageSize: '12',
        baseUrl: 'https://web-qa.xcite.com/',
        currency: 'KWD',
        currencyCode: 'KD',
        countryCode: 'KW',
        language: 'en',
        enableLoginForDeal: false,
        personyzeKey: environment.getPersonyzeKey,
        personyzeUrl: 'https://app.personyze.com/rest/tracker-v1',
        criteoUrl: 'https://widget.as.criteo.com/m/event',
        enableSocialLogin: false,
        facebookLogin: {
          facebookAuthorizeUrl: 'https://www.facebook.com/dialog/oauth/',
          facebookRedirectUrl:
            'https://www.facebook.com/connect/login_success.html',
          facebookIosClientId: environment.getFacebookIosClientID,
          facebookAndroidClientId: environment.getFacebookAndroidClientID,
        },
        googleLogin: {
          googleAuthorizeUrl: 'https://accounts.google.com/o/oauth2/auth',
          googleAccessTokenUrl: 'https://oauth2.googleapis.com/token',
          googleios_clientid: environment.getGoogleIosClientID,
          googleAndroidClientId: environment.getGoogleAndroidClientID,
          googleIosRedirectUri:
            'com.googleusercontent.apps.996053011510-tam6u1rs0nht2jjfqa9gjgl1ue2hf928:/oauth2redirect',
          googleAndroidRedirectUri:
            'com.googleusercontent.apps.996053011510-sb2od9futtc3d7vbb304k0nlh8liic0q:/oauth2redirect',
        },
        twitterLogin: null,
        InstagramLogin: null,
        appleLogin: {
          showAppleLogin: true,
        },
        facebookUrl: 'https://www.facebook.com/XcitebyAlghanim',
        facebookPageId: '117817411581597',
        twitterUrl: 'https://twitter.com/xcitealghanim',
        twitterPageId: 'XcitebyAlghanim',
        gplusPageId: '117993355608468890752',
        instaPageId: 'xcitealghanim',
        youtubeUrl: 'https://www.youtube.com/user/Xcitealghanim',
        youtubePageId: 'Xcitealghanim',
        pintrsestUrl: 'https://www.pinterest.com/xcitealghanim/',
        instaUrl: 'https://www.instagram.com/xcitealghanim/',
        pintrsestPageId: 'xcitealghanim',
        bluecoreToken: 'xcite_ku',
        isDeleteAccountEnable: true
      }

      const arKWMobileConfig = {
        currentAppVersion: '2.0',
        requiredAppVersion: '2.0',
        apiVersion: '2.0',
        enableInstantSearch: false,
        verifyEmail: false,
        showDeal: true,
        countryMobileCode: '+965',
        isFlixMediaEnable:true,
        isPersonyzeEnable:true,
        mobileNumberDigit: '8',
        enableCriteoSDK: true,
        categoryCacheTime: '1',
        enableInAppUpdate: false,
        rootedDetection: true,
        appEnvironment: 'commercetools',
        algoliaIndexPrefix: 'xcite_qa_kw_ar',
        enableVat: false,
        freshChatAppID: environment.getFreshchatAppId,
        freshChatAppKey: environment.getFreshchatAppKey,
        freshChatDomain: 'msdk.eu.freshchat.com',
        flixMediaId: environment.getFlixMediaIdKW,
        mapApiKeyiOS: environment.getMapApiKeyIos,
        mapApiKeyAndroid: environment.getMapApiKeyAndroid,
        isCheckoutMapMandate: true,
        showChat: true,
        showChatMore: true,
        showDeliveryMobileNoMessage: false,
        showBeforePrice: true,
        algoliaIndexName: 'xcite_qa_kw_ar_main',
        algoliaAppId: environment.apiAlgoliaAppIdPublic,
        algoliaApiKey: environment.apiAlgoliaApiKeyPublic,
        sendAlgoliaEvents: true,
        currentAppVersionAndroid: '110',
        requiredAppVersionAndroid: '110',
        currentAppVersionIOS: '3.2.0',
        requiredAppVersionIOS: '3.2.0',
        currentAppVersionHMS: '98',
        requiredAppVersionHMS: '97',
        huaweiStoreUrl: 'https://appgallery7.huawei.com/#/app/C101524419',
        androidStoreUrl:
          'https://play.google.com/store/apps/details?id=com.developmentnow.xcite',
        iosStoreUrl: 'itms-apps://itunes.apple.com/app/id649610123',
        pageSize: '12',
        baseUrl: 'https://web-qa.xcite.com/',
        currency: 'KWD',
        currencyCode: 'د.ك.',
        countryCode: 'KW',
        language: 'ar',
        enableLoginForDeal: false,
        personyzeKey: environment.getPersonyzeKey,
        personyzeUrl: 'https://app.personyze.com/rest/tracker-v1',
        criteoUrl: 'https://widget.as.criteo.com/m/event',
        enableSocialLogin: false,
        facebookLogin: {
          facebookAuthorizeUrl: 'https://www.facebook.com/dialog/oauth/',
          facebookRedirectUrl:
            'https://www.facebook.com/connect/login_success.html',
          facebookIosClientId: environment.getFacebookIosClientID,
          facebookAndroidClientId: environment.getFacebookAndroidClientID,
        },
        googleLogin: {
          googleAuthorizeUrl: 'https://accounts.google.com/o/oauth2/auth',
          googleAccessTokenUrl: 'https://oauth2.googleapis.com/token',
          googleios_clientid: environment.getGoogleIosClientID,
          googleAndroidClientId: environment.getGoogleAndroidClientID,
          googleIosRedirectUri:
            'com.googleusercontent.apps.996053011510-tam6u1rs0nht2jjfqa9gjgl1ue2hf928:/oauth2redirect',
          googleAndroidRedirectUri:
            'com.googleusercontent.apps.996053011510-sb2od9futtc3d7vbb304k0nlh8liic0q:/oauth2redirect',
        },
        twitterLogin: null,
        InstagramLogin: null,
        appleLogin: {
          showAppleLogin: true,
        },
        facebookUrl: 'https://www.facebook.com/XcitebyAlghanim',
        facebookPageId: '117817411581597',
        twitterUrl: 'https://twitter.com/xcitealghanim',
        twitterPageId: 'XcitebyAlghanim',
        gplusPageId: '117993355608468890752',
        instaPageId: 'xcitealghanim',
        youtubeUrl: 'https://www.youtube.com/user/Xcitealghanim',
        youtubePageId: 'Xcitealghanim',
        pintrsestUrl: 'https://www.pinterest.com/xcitealghanim/',
        instaUrl: 'https://www.instagram.com/xcitealghanim/',
        pintrsestPageId: 'xcitealghanim',
        bluecoreToken: 'xcite_ku',
        isDeleteAccountEnable: true
      }

      const enKSAMobileConfig = {
        currentAppVersion: '2.0',
        requiredAppVersion: '2.0',
        apiVersion: '2.0',
        enableInstantSearch: false,
        verifyEmail: false,
        showDeal: true,
        countryMobileCode: '+966',
        isFlixMediaEnable:true,
        isPersonyzeEnable:true,
        mobileNumberDigit: '9',
        enableCriteoSDK: true,
        categoryCacheTime: '1',
        enableInAppUpdate: false,
        rootedDetection: true,
        appEnvironment: 'commercetools',
        algoliaIndexPrefix: 'xcite_qa_sa_en',
        enableVat: true,
        freshChatAppID: environment.getFreshchatAppId,
        freshChatAppKey: environment.getFreshchatAppKey,
        freshChatDomain: 'msdk.eu.freshchat.com',
        flixMediaId: environment.getFlixMediaIdSA,
        mapApiKeyiOS: environment.getMapApiKeyIos,
        mapApiKeyAndroid: environment.getMapApiKeyAndroid,
        isCheckoutMapMandate: false,
        showChat: false,
        showChatMore: false,
        showBeforePrice: true,
        showDeliveryMobileNoMessage: false,
        algoliaIndexName: 'xcite_qa_sa_en_main',
        algoliaAppId: environment.apiAlgoliaAppIdPublic,
        algoliaApiKey: environment.apiAlgoliaApiKeyPublic,
        sendAlgoliaEvents: true,
        currentAppVersionAndroid: '110',
        requiredAppVersionAndroid: '110',
        currentAppVersionIOS: '3.2.0',
        requiredAppVersionIOS: '3.2.0',
        currentAppVersionHMS: '98',
        requiredAppVersionHMS: '97',
        huaweiStoreUrl: 'https://appgallery7.huawei.com/#/app/C101524419',
        androidStoreUrl:
          'https://play.google.com/store/apps/details?id=com.developmentnow.xcite',
        iosStoreUrl: 'itms-apps://itunes.apple.com/app/id649610123',
        pageSize: '12',
        baseUrl: 'https://web-qa.xcite.com.sa/',
        currency: 'SAR',
        currencyCode: 'SR',
        countryCode: 'SA',
        language: 'en',
        enableLoginForDeal: false,
        personyzeKey: environment.getPersonyzeKey,
        personyzeUrl: 'https://app.personyze.com/rest/tracker-v1',
        criteoUrl: 'https://widget.as.criteo.com/m/event',
        enableSocialLogin: false,
        facebookLogin: {
          facebookAuthorizeUrl: 'https://www.facebook.com/dialog/oauth/',
          facebookRedirectUrl:
            'https://www.facebook.com/connect/login_success.html',
          facebookIosClientId: environment.getFacebookIosClientID,
          facebookAndroidClientId: environment.getFacebookAndroidClientID,
        },
        googleLogin: {
          googleAuthorizeUrl: 'https://accounts.google.com/o/oauth2/auth',
          googleAccessTokenUrl: 'https://oauth2.googleapis.com/token',
          googleios_clientid: environment.getGoogleIosClientID,
          googleAndroidClientId: environment.getGoogleAndroidClientID,
          googleIosRedirectUri:
            'com.googleusercontent.apps.996053011510-tam6u1rs0nht2jjfqa9gjgl1ue2hf928:/oauth2redirect',
          googleAndroidRedirectUri:
            'com.googleusercontent.apps.996053011510-sb2od9futtc3d7vbb304k0nlh8liic0q:/oauth2redirect',
        },
        twitterLogin: null,
        InstagramLogin: null,
        appleLogin: {
          showAppleLogin: true,
        },
        facebookUrl: 'https://www.facebook.com/xciteksa',
        facebookPageId: '936541186361669',
        twitterUrl: 'https://twitter.com/xciteksa',
        twitterPageId: 'xciteksa',
        gplusPageId: '117993355608468890752',
        instaPageId: 'xciteksa',
        youtubeUrl: 'https://www.youtube.com/channel/UCcwtfMipIszMxExKGHkg1HA',
        youtubePageId: 'Xcitealghanim',
        pintrsestUrl: 'https://www.pinterest.com/xcitealghanim/',
        instaUrl: 'https://www.instagram.com/xciteksa/',
        pintrsestPageId: 'xcitealghanim',
        bluecoreToken: 'xcite_sa',
        isDeleteAccountEnable: true
      }

      const arKSAMobileConfig = {
        currentAppVersion: '2.0',
        requiredAppVersion: '2.0',
        apiVersion: '2.0',
        enableInstantSearch: false,
        verifyEmail: false,
        showDeal: true,
        countryMobileCode: '+966',
        isFlixMediaEnable:true,
        isPersonyzeEnable:true,
        mobileNumberDigit: '9',
        enableCriteoSDK: true,
        categoryCacheTime: '1',
        enableInAppUpdate: false,
        rootedDetection: true,
        appEnvironment: 'commercetools',
        algoliaIndexPrefix: 'xcite_qa_sa_ar',
        enableVat: true,
        freshChatAppID: environment.getFreshchatAppId,
        freshChatAppKey: environment.getFreshchatAppKey,
        freshChatDomain: 'msdk.eu.freshchat.com',
        flixMediaId: environment.getFlixMediaIdSA,
        mapApiKeyiOS: environment.getMapApiKeyIos,
        mapApiKeyAndroid: environment.getMapApiKeyAndroid,
        isCheckoutMapMandate: false,
        showChat: false,
        showChatMore: false,
        showBeforePrice: true,
        showDeliveryMobileNoMessage: false,
        algoliaIndexName: 'xcite_qa_sa_ar_main',
        algoliaAppId: environment.apiAlgoliaAppIdPublic,
        algoliaApiKey: environment.apiAlgoliaApiKeyPublic,
        sendAlgoliaEvents: true,
        currentAppVersionAndroid: '110',
        requiredAppVersionAndroid: '110',
        currentAppVersionIOS: '3.2.0',
        requiredAppVersionIOS: '3.2.0',
        currentAppVersionHMS: '98',
        requiredAppVersionHMS: '97',
        huaweiStoreUrl: 'https://appgallery7.huawei.com/#/app/C101524419',
        androidStoreUrl:
          'https://play.google.com/store/apps/details?id=com.developmentnow.xcite',
        iosStoreUrl: 'itms-apps://itunes.apple.com/app/id649610123',
        pageSize: '12',
        baseUrl: 'https://web-qa.xcite.com.sa/',
        currency: 'SAR',
        currencyCode: 'ر.س.',
        language: 'en',
        enableLoginForDeal: false,
        personyzeKey: environment.getPersonyzeKey,
        personyzeUrl: 'https://app.personyze.com/rest/tracker-v1',
        criteoUrl: 'https://widget.as.criteo.com/m/event',
        enableSocialLogin: false,
        facebookLogin: {
          facebookAuthorizeUrl: 'https://www.facebook.com/dialog/oauth/',
          facebookRedirectUrl:
            'https://www.facebook.com/connect/login_success.html',
          facebookIosClientId: environment.getFacebookIosClientID,
          facebookAndroidClientId: environment.getFacebookAndroidClientID,
        },
        googleLogin: {
          googleAuthorizeUrl: 'https://accounts.google.com/o/oauth2/auth',
          googleAccessTokenUrl: 'https://oauth2.googleapis.com/token',
          googleios_clientid: environment.getGoogleIosClientID,
          googleAndroidClientId: environment.getGoogleAndroidClientID,
          googleIosRedirectUri:
            'com.googleusercontent.apps.996053011510-tam6u1rs0nht2jjfqa9gjgl1ue2hf928:/oauth2redirect',
          googleAndroidRedirectUri:
            'com.googleusercontent.apps.996053011510-sb2od9futtc3d7vbb304k0nlh8liic0q:/oauth2redirect',
        },
        twitterLogin: null,
        InstagramLogin: null,
        appleLogin: {
          showAppleLogin: true,
        },
        facebookUrl: 'https://www.facebook.com/xciteksa',
        facebookPageId: '936541186361669',
        twitterUrl: 'https://twitter.com/xciteksa',
        twitterPageId: 'xciteksa',
        gplusPageId: '117993355608468890752',
        instaPageId: 'xciteksa',
        youtubeUrl: 'https://www.youtube.com/channel/UCcwtfMipIszMxExKGHkg1HA',
        youtubePageId: 'Xcitealghanim',
        pintrsestUrl: 'https://www.pinterest.com/xcitealghanim/',
        instaUrl: 'https://www.instagram.com/xciteksa/',
        pintrsestPageId: 'xcitealghanim',
        bluecoreToken: 'xcite_sa',
        isDeleteAccountEnable: true   
      
      }

      if (store_id === '1' || locale === 'en-KW') {
        return enKWMobileConfig
      } else if (store_id === '5' || locale === 'ar-KW') {
        return arKWMobileConfig
      } else if (store_id === '3' || locale === 'en-SA') {
        return enKSAMobileConfig
      } else if (store_id === '4' || locale === 'ar-SA') {
        return arKSAMobileConfig
      }

      return defualtMobileConfig
    } catch (error) {
      if (error instanceof Error) {
        return reportErrorUtils(error)
      }
      throw error
    }
  }
}

export default MobileConfigStageClient
