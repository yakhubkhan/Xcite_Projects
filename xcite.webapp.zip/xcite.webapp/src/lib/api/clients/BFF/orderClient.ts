import {
  CommerceToolsOrderPayload,
  CommerceToolsOrderReprintByTxnIdPayload,
  CommerceToolsOrderReprintPayload,
} from '../../../../types/api'
import { Order, OrderReprint } from '../../../../types/content'
import { reportErrorUtils } from '../../../../util/reportErrorUtils'
import { BaseClient, userUrlParams } from './baseClient'

class OrderClient extends BaseClient {
  public getOrderDetails = async (
    params: CommerceToolsOrderPayload
  ): Promise<Order> => {
    const { store, user, language, orderId, locale } = params

    const config = await this.setHeaders(user.authenticated)

    try {
      const response = await this.client.get(
        `/com/orders/${orderId}?${userUrlParams(
          user
        )}store=${store}&language=${language}&locale=${locale}`,
        config
      )
      return response.data
    } catch (error) {
      if (error instanceof Error) {
        return reportErrorUtils(error)
      }
      throw error
    }
  }

  public getOrdersReprint = async (
    params: CommerceToolsOrderReprintPayload
  ): Promise<OrderReprint[]> => {
    const { store, user, language, orderNumber, lineItemIds } = params

    const config = await this.setHeaders(user.authenticated)

    try {
      const response = await this.client.post(
        `/com/orders/reprint?${userUrlParams(
          user
        )}store=${store}&language=${language}`,
        {
          orderNumber,
          lineItemIds,
        },
        config
      )
      return response.data
    } catch (error) {
      if (error instanceof Error) {
        return reportErrorUtils(error)
      }
      throw error
    }
  }

  public reprintByTxnId = async (
    params: CommerceToolsOrderReprintByTxnIdPayload
  ): Promise<OrderReprint> => {
    const { store, user, txnId, sku } = params

    const config = await this.setHeaders(user.authenticated)

    try {
      const response = await this.client.post(
        `/orders/reprintByTxnId?${userUrlParams(
          user
        )}store=${store}&txnid=${txnId}&sku=${sku}`,
        {},
        config
      )
      return response.data
    } catch (error) {
      if (error instanceof Error) {
        return reportErrorUtils(error)
      }
      throw error
    }
  }
}

export default OrderClient
