import {
  CommerceToolsPaymentAddMethodPayload,
  CommerceToolsPaymentCheckout,
  CommerceToolsPaymentCODPayload,
  CommerceToolsPaymentRedirectPayload,
  CommercetoolsUserStorePayload,
} from '../../../../types/api'
import { BaseClient, userUrlParams } from './baseClient'
import { CartType, PaymentMethodType } from '../../../../types/content'
import { reportErrorUtils } from '../../../../util/reportErrorUtils'

class PaymentClient extends BaseClient {
  public startPayment = async (
    payload: CommerceToolsPaymentRedirectPayload
  ): Promise<string> => {
    const {
      paymentOption,
      cartVersion,
      errorUrl,
      language,
      deviceType,
      receiptUrl,
      store,
      user,
    } = payload
    const config = await this.setHeaders(user.authenticated)
    try {
      const response = await this.client.post(
        `/payments/${paymentOption}?${userUrlParams(
          user
        )}cartVersion=${cartVersion}&errorUrl=${errorUrl}&language=${language}&receiptUrl=${receiptUrl}&store=${store}&deviceType=${deviceType}`,
        {},
        config
      )
      return response.data
    } catch (error) {
      if (error instanceof Error) {
        return reportErrorUtils(error)
      }
      throw error
    }
  }

  public paymentCheckout = async (
    payload: CommerceToolsPaymentCheckout
  ): Promise<{ orderId?: string; redirectUrl?: string }> => {
    const {
      store,
      deviceType,
      language,
      user,
      cartVersion,
      paymentToken,
      failureUrl,
      successUrl,
    } = payload
    const config = await this.setHeaders(user.authenticated)

    try {
      const endpointUrl = `/payments/checkout/token?${userUrlParams(
        user
      )}store=${store}&cartVersion=${cartVersion}&deviceType=${deviceType}&language=${language}`
      const reqBody = {
        token: paymentToken,
        successUrl: successUrl,
        failureUrl: failureUrl,
      }

      const response = await this.client.post(endpointUrl, reqBody, config)

      return response.data
    } catch (error) {
      if (error instanceof Error) {
        return reportErrorUtils(error)
      }
      throw error
    }
  }

  public paymentCOD = async (
    payload: CommerceToolsPaymentCODPayload
  ): Promise<{ orderId: string }> => {
    const { cartVersion, deviceType, language, store, user } = payload
    const config = await this.setHeaders(user.authenticated)
    try {
      const response = await this.client.post(
        `/payments/cod?${userUrlParams(
          user
        )}store=${store}&cartVersion=${cartVersion}&deviceType=${deviceType}&language=${language}`,
        {},
        config
      )
      return { orderId: response.data.id }
    } catch (error) {
      if (error instanceof Error) {
        return reportErrorUtils(error)
      }
      throw error
    }
  }

  public getPaymentMethods = async (
    payload: CommercetoolsUserStorePayload
  ): Promise<PaymentMethodType[]> => {
    const { language, store, user, locale, deviceType } = payload
    const config = await this.setHeaders(user.authenticated)
    try {
      const response = await this.client.get(
        `/com/payment/getMethods?${userUrlParams(
          user
        )}store=${store}&language=${language}&locale=${locale}&deviceType=${deviceType}`,
        config
      )
      return response.data
    } catch (error) {
      if (error instanceof Error) {
        return reportErrorUtils(error)
      }
      throw error
    }
  }

  public addPaymentToCart = async (
    payload: CommerceToolsPaymentAddMethodPayload
  ): Promise<CartType> => {
    const { language, store, user, paymentMethod, locale, reqBody } = payload
    const config = await this.setHeaders(user.authenticated)
    try {
      const response = await this.client.post(
        `/com/payment/addPaymentToCart?${userUrlParams(
          user
        )}method=${paymentMethod}&store=${store}&locale=${locale}&language=${language}`,
        reqBody,
        config
      )
      return response.data
    } catch (error) {
      if (error instanceof Error) {
        return reportErrorUtils(error)
      }
      throw error
    }
  }
}

export default PaymentClient
