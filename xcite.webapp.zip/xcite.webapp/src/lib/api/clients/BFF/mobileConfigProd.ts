import { MobileConfigPayload } from '../../../../types/api'
import { MobileConfig } from '../../../../types/content'
import { reportErrorUtils } from '../../../../util/reportErrorUtils'
import environment from '../../../environment'
import { BaseClient } from './baseClient'

class MobileConfigProdClient extends BaseClient {
  public getMobileProdConfigs = async (
    params: MobileConfigPayload
  ): Promise<MobileConfig> => {
    const { config_env, store_id, locale } = params
    const defualtMobileConfig = {}
    try {
      const enKWMobileConfig = {
        algoliaAppId: environment.apiAlgoliaAppIdPublic,
        algoliaApiKey: environment.apiAlgoliaApiKeyPublic,
        algoliaIndexPrefix: 'xcite_prod_kw_en',
        androidStoreUrl:
          'https://play.google.com/store/apps/details?id=com.developmentnow.xcite',
        apiVersion: '2.0',
        appEnvironment: 'commercetools',
        appleLogin: {
          showAppleLogin: true,
        },
        baseUrl: 'https://www.xcite.com/',
        countryCode: 'KW',
        countryMobileCode: '+965',
        currency: 'KWD',
        currencyCode: 'KD',
        enableInAppUpdate: false,
        enableInstantSearch: false,
        enableSocialLogin: false,
        enableVat: false,
        facebookAppSecretId: '645df0de280a5191b5bfa8a9ce6c7b9f',
        facebookLogin: {
          facebookIosClientId: environment.getFacebookIosClientID,
          facebookAndroidClientId: environment.getFacebookAndroidClientID,
          facebookAuthorizeUrl: 'https://www.facebook.com/dialog/oauth/',
          facebookRedirectUrl:
            'https://www.facebook.com/connect/login_success.html',
        },
        facebookPageId: '117817411581597',
        facebookUrl: 'https://www.facebook.com/XcitebyAlghanim',
        freshChatAppID: environment.getFreshchatAppId,
        freshChatAppKey: environment.getFreshchatAppKey,
        freshChatDomain: 'msdk.eu.freshchat.com',
        googleLogin: {
          googleAccessTokenUrl: 'https://oauth2.googleapis.com/token',
          googleios_clientid: environment.getGoogleIosClientID,
          googleAndroidClientId: environment.getGoogleAndroidClientID,
          googleAndroidRedirectUri:
            'com.googleusercontent.apps.996053011510-sb2od9futtc3d7vbb304k0nlh8liic0q:/oauth2redirect',
          googleAuthorizeUrl: 'https://accounts.google.com/o/oauth2/auth',
          googleIosRedirectUri:
            'com.googleusercontent.apps.996053011510-tam6u1rs0nht2jjfqa9gjgl1ue2hf928:/oauth2redirect',
        },
        gplusPageId: '117993355608468890752',
        huaweiStoreUrl: 'https://appgallery7.huawei.com/#/app/C101524419',
        InstagramLogin: null,
        instaPageId: 'xcitealghanim',
        instaUrl: 'https://www.instagram.com/xcitealghanim/',
        iosStoreUrl: 'itms-apps://itunes.apple.com/app/id649610123',
        isCheckoutMapMandate: true,
        isDeleteAccountEnable: true,
        language: 'en',
        mapApiKeyiOS: environment.getMapApiKeyIos,
        mapApiKeyAndroid: environment.getMapApiKeyAndroid,
        mobileNumberDigit: '8',
        personyzeKey: '872C8FAE303F8A2C14BF3F4B38A2CCDF8AB2EEAD',
        personyzeUrl: 'https://app.personyze.com/rest/tracker-v1',
        pintrsestPageId: 'xcitealghanim',
        pintrsestUrl: 'https://www.pinterest.com/xcitealghanim/',
        requiredAppVersionAndroid: '131',
        requiredAppVersionHMS: '97',
        requiredAppVersionIOS: '3.4.0',
        rootedDetection: true,
        sendAlgoliaEvents: true,
        showChat: true,
        showDeliveryMobileNoMessage: false,
        twitterLogin: null,
        twitterPageId: 'XcitebyAlghanim',
        twitterUrl: 'https://twitter.com/xcitealghanim',
        verifyEmail: false,
        youtubePageId: 'Xcitealghanim',
        youtubeUrl: 'https://www.youtube.com/user/Xcitealghanim',
      }

      const arKWMobileConfig = {
        algoliaAppId: environment.apiAlgoliaAppIdPublic,
        algoliaApiKey: environment.apiAlgoliaApiKeyPublic,
        algoliaIndexPrefix: 'xcite_prod_kw_ar',
        androidStoreUrl:
          'https://play.google.com/store/apps/details?id=com.developmentnow.xcite',
        apiVersion: '2.0',
        appEnvironment: 'commercetools',
        appleLogin: {
          showAppleLogin: true,
        },
        baseUrl: 'https://www.xcite.com/',
        countryCode: 'KW',
        countryMobileCode: '+965',
        currency: 'KWD',
        currencyCode: 'د.ك.',
        enableInAppUpdate: false,
        enableInstantSearch: false,
        enableSocialLogin: false,
        enableVat: false,
        facebookAppSecretId: '645df0de280a5191b5bfa8a9ce6c7b9f',
        facebookLogin: {
          facebookIosClientId: environment.getFacebookIosClientID,
          facebookAndroidClientId: environment.getFacebookAndroidClientID,
          facebookAuthorizeUrl: 'https://www.facebook.com/dialog/oauth/',
          facebookRedirectUrl:
            'https://www.facebook.com/connect/login_success.html',
        },
        facebookPageId: '117817411581597',
        facebookUrl: 'https://www.facebook.com/XcitebyAlghanim',
        freshChatAppID: environment.getFreshchatAppId,
        freshChatAppKey: environment.getFreshchatAppKey,
        freshChatDomain: 'msdk.eu.freshchat.com',
        googleLogin: {
          googleAccessTokenUrl: 'https://oauth2.googleapis.com/token',
          googleios_clientid: environment.getGoogleIosClientID,
          googleAndroidClientId: environment.getGoogleAndroidClientID,
          googleAndroidRedirectUri:
            'com.googleusercontent.apps.996053011510-sb2od9futtc3d7vbb304k0nlh8liic0q:/oauth2redirect',
          googleAuthorizeUrl: 'https://accounts.google.com/o/oauth2/auth',
          googleIosRedirectUri:
            'com.googleusercontent.apps.996053011510-tam6u1rs0nht2jjfqa9gjgl1ue2hf928:/oauth2redirect',
        },
        gplusPageId: '117993355608468890752',
        huaweiStoreUrl: 'https://appgallery7.huawei.com/#/app/C101524419',
        InstagramLogin: null,
        instaPageId: 'xcitealghanim',
        instaUrl: 'https://www.instagram.com/xcitealghanim/',
        iosStoreUrl: 'itms-apps://itunes.apple.com/app/id649610123',
        isCheckoutMapMandate: true,
        isDeleteAccountEnable: true,
        language: 'ar',
        mapApiKeyiOS: environment.getMapApiKeyIos,
        mapApiKeyAndroid: environment.getMapApiKeyAndroid,
        mobileNumberDigit: '8',
        personyzeKey: '872C8FAE303F8A2C14BF3F4B38A2CCDF8AB2EEAD',
        personyzeUrl: 'https://app.personyze.com/rest/tracker-v1',
        pintrsestPageId: 'xcitealghanim',
        pintrsestUrl: 'https://www.pinterest.com/xcitealghanim/',
        requiredAppVersionAndroid: '131',
        requiredAppVersionHMS: '97',
        requiredAppVersionIOS: '3.4.0',
        rootedDetection: true,
        sendAlgoliaEvents: true,
        showChat: true,
        showDeliveryMobileNoMessage: false,
        twitterLogin: null,
        twitterPageId: 'XcitebyAlghanim',
        twitterUrl: 'https://twitter.com/xcitealghanim',
        verifyEmail: false,
        youtubePageId: 'Xcitealghanim',
        youtubeUrl: 'https://www.youtube.com/user/Xcitealghanim',
      }

      const enKSAMobileConfig = {
        algoliaAppId: environment.apiAlgoliaAppIdPublic,
        algoliaApiKey: environment.apiAlgoliaApiKeyPublic,
        algoliaIndexPrefix: 'xcite_prod_sa_en',
        androidStoreUrl:
          'https://play.google.com/store/apps/details?id=com.developmentnow.xcite',
        apiVersion: '2.0',
        appEnvironment: 'commercetools',
        appleLogin: {
          showAppleLogin: true,
        },
        baseUrl: 'https://www.xcite.com.sa/',
        countryCode: 'SA',
        countryMobileCode: '+966',
        currency: 'SAR',
        currencyCode: 'SR',
        enableInAppUpdate: false,
        enableInstantSearch: false,
        enableSocialLogin: false,
        enableVat: true,
        facebookAppSecretId: '645df0de280a5191b5bfa8a9ce6c7b9f',
        facebookLogin: {
          facebookIosClientId: environment.getFacebookIosClientID,
          facebookAndroidClientId: environment.getFacebookAndroidClientID,
          facebookAuthorizeUrl: 'https://www.facebook.com/dialog/oauth/',
          facebookRedirectUrl:
            'https://www.facebook.com/connect/login_success.html',
        },
        facebookPageId: '936541186361669',
        facebookUrl: 'https://www.facebook.com/xciteksa',
        freshChatAppID: '8a6d6fc6-ace7-4146-b2d9-e8cc71011ebe',
        freshChatAppKey: '4cab4304-64c3-44b1-8c63-a1c9280312ed',
        freshChatDomain: 'msdk.eu.freshchat.com',
        googleLogin: {
          googleAccessTokenUrl: 'https://oauth2.googleapis.com/token',
          googleios_clientid: environment.getGoogleIosClientID,
          googleAndroidClientId: environment.getGoogleAndroidClientID,
          googleAndroidRedirectUri:
            'com.googleusercontent.apps.996053011510-sb2od9futtc3d7vbb304k0nlh8liic0q:/oauth2redirect',
          googleAuthorizeUrl: 'https://accounts.google.com/o/oauth2/auth',
          googleIosRedirectUri:
            'com.googleusercontent.apps.996053011510-tam6u1rs0nht2jjfqa9gjgl1ue2hf928:/oauth2redirect',
        },
        gplusPageId: '117993355608468890752',
        huaweiStoreUrl: 'https://appgallery7.huawei.com/#/app/C101524419',
        InstagramLogin: null,
        instaPageId: 'xciteksa',
        instaUrl: 'https://www.instagram.com/xciteksa/',
        iosStoreUrl: 'itms-apps://itunes.apple.com/app/id649610123',
        isCheckoutMapMandate: true,
        isDeleteAccountEnable: true,
        language: 'en',
        mapApiKeyiOS: environment.getMapApiKeyIos,
        mapApiKeyAndroid: environment.getMapApiKeyAndroid,
        mobileNumberDigit: '9',
        personyzeKey: '872C8FAE303F8A2C14BF3F4B38A2CCDF8AB2EEAD',
        personyzeUrl: 'https://app.personyze.com/rest/tracker-v1',
        pintrsestPageId: 'xcitealghanim',
        pintrsestUrl: 'https://www.pinterest.com/xcitealghanim/',
        requiredAppVersionAndroid: '131',
        requiredAppVersionHMS: '97',
        requiredAppVersionIOS: '3.4.0',
        rootedDetection: true,
        sendAlgoliaEvents: true,
        showChat: false,
        showDeliveryMobileNoMessage: false,
        twitterLogin: null,
        twitterPageId: 'XcitebyAlghanim',
        twitterUrl: 'https://twitter.com/xcitealghanim',
        verifyEmail: false,
        youtubePageId: 'Xcitealghanim',
        youtubeUrl: 'https://www.youtube.com/channel/UCcwtfMipIszMxExKGHkg1HA',
      }

      const arKSAMobileConfig = {
        algoliaAppId: environment.apiAlgoliaAppIdPublic,
        algoliaApiKey: environment.apiAlgoliaApiKeyPublic,
        algoliaIndexPrefix: 'xcite_prod_sa_ar',
        androidStoreUrl:
          'https://play.google.com/store/apps/details?id=com.developmentnow.xcite',
        apiVersion: '2.0',
        appEnvironment: 'commercetools',
        appleLogin: {
          showAppleLogin: true,
        },
        baseUrl: 'https://www.xcite.com.sa/',
        countryCode: 'SA',
        countryMobileCode: '+966',
        currency: 'SAR',
        currencyCode: 'ر.س.',
        enableInAppUpdate: false,
        enableInstantSearch: false,
        enableSocialLogin: false,
        enableVat: true,
        facebookAppSecretId: '645df0de280a5191b5bfa8a9ce6c7b9f',
        facebookLogin: {
          facebookIosClientId: environment.getFacebookIosClientID,
          facebookAndroidClientId: environment.getFacebookAndroidClientID,
          facebookAuthorizeUrl: 'https://www.facebook.com/dialog/oauth/',
          facebookRedirectUrl:
            'https://www.facebook.com/connect/login_success.html',
        },
        facebookPageId: '936541186361669',
        facebookUrl: 'https://www.facebook.com/xciteksa',
        freshChatAppID: '8a6d6fc6-ace7-4146-b2d9-e8cc71011ebe',
        freshChatAppKey: '4cab4304-64c3-44b1-8c63-a1c9280312ed',
        freshChatDomain: 'msdk.eu.freshchat.com',
        googleLogin: {
          googleAccessTokenUrl: 'https://oauth2.googleapis.com/token',
          googleios_clientid: environment.getGoogleIosClientID,
          googleAndroidClientId: environment.getGoogleAndroidClientID,
          googleAndroidRedirectUri:
            'com.googleusercontent.apps.996053011510-sb2od9futtc3d7vbb304k0nlh8liic0q:/oauth2redirect',
          googleAuthorizeUrl: 'https://accounts.google.com/o/oauth2/auth',
          googleIosRedirectUri:
            'com.googleusercontent.apps.996053011510-tam6u1rs0nht2jjfqa9gjgl1ue2hf928:/oauth2redirect',
        },
        gplusPageId: '117993355608468890752',
        huaweiStoreUrl: 'https://appgallery7.huawei.com/#/app/C101524419',
        InstagramLogin: null,
        instaPageId: 'xciteksa',
        instaUrl: 'https://www.instagram.com/xciteksa/',
        iosStoreUrl: 'itms-apps://itunes.apple.com/app/id649610123',
        isCheckoutMapMandate: true,
        isDeleteAccountEnable: true,
        language: 'ar',
        mapApiKeyiOS: environment.getMapApiKeyIos,
        mapApiKeyAndroid: environment.getMapApiKeyAndroid,
        mobileNumberDigit: '9',
        personyzeKey: '872C8FAE303F8A2C14BF3F4B38A2CCDF8AB2EEAD',
        personyzeUrl: 'https://app.personyze.com/rest/tracker-v1',
        pintrsestPageId: 'xcitealghanim',
        pintrsestUrl: 'https://www.pinterest.com/xcitealghanim/',
        requiredAppVersionAndroid: '131',
        requiredAppVersionHMS: '97',
        requiredAppVersionIOS: '3.4.0',
        rootedDetection: true,
        sendAlgoliaEvents: true,
        showChat: false,
        showDeliveryMobileNoMessage: false,
        twitterLogin: null,
        twitterPageId: 'XcitebyAlghanim',
        twitterUrl: 'https://twitter.com/xcitealghanim',
        verifyEmail: false,
        youtubePageId: 'Xcitealghanim',
        youtubeUrl: 'https://www.youtube.com/channel/UCcwtfMipIszMxExKGHkg1HA',
      }

      if (store_id === '1' || locale === 'en-KW') {
        return enKWMobileConfig
      } else if (store_id === '5' || locale === 'ar-KW') {
        return arKWMobileConfig
      } else if (store_id === '3' || locale === 'en-SA') {
        return enKSAMobileConfig
      } else if (store_id === '4' || locale === 'ar-SA') {
        return arKSAMobileConfig
      }

      return defualtMobileConfig
    } catch (error) {
      if (error instanceof Error) {
        return reportErrorUtils(error)
      }
      throw error
    }
  }
}

export default MobileConfigProdClient
