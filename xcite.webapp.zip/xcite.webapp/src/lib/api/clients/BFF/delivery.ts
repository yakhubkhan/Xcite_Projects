import {
  CommercetoolsGetSlotPayload,
  CommercetoolsSoftReserveSlotPayload,
  CommercetoolsUserStorePayload,
} from '../../../../types/api'
import { CartType, TimeSlotSelectionDialog } from '../../../../types/content'
import { BaseClient, userUrlParams } from './baseClient'

class DeliveryClient extends BaseClient {
  public softReserveSlot = async (
    params: CommercetoolsSoftReserveSlotPayload
  ): Promise<CartType> => {
    const { user, locale, store, language } = params

    const config = await this.setHeaders(user.authenticated)

    try {
      const response = await this.client.post(
        `/com/delivery/softReserveSlot?store=${store}&language=${language}&locale=${locale}&${userUrlParams(
          user
        )}`,
        params.reqBody,
        config
      )
      return response.data
    } catch (error) {
      throw error
    }
  }

  public getSlots = async (
    params: CommercetoolsGetSlotPayload
  ): Promise<TimeSlotSelectionDialog> => {
    const { user, locale, store, language, deliveryTeam } = params

    const config = await this.setHeaders(user.authenticated)

    try {
      const response = await this.client.get(
        `/com/delivery/getAvailableSlots?${userUrlParams(
          user
        )}store=${store}&language=${language}&locale=${locale}&deliveryTeam=${deliveryTeam}`,
        config
      )
      return response.data
    } catch (error) {
      throw error
    }
  }

  public reserveSlot = async (
    params: CommercetoolsUserStorePayload
  ): Promise<CartType> => {
    try {
      const { user, locale, store, language } = params

      const config = await this.setHeaders(user.authenticated)

      const response = await this.client.post(
        `/com/delivery/reserveSlot?store=${store}&language=${language}&locale=${locale}&${userUrlParams(
          user
        )}`,
        {},
        config
      )
      return response.data
    } catch (error) {
      throw error
    }
  }
}

export default DeliveryClient
