import { BaseClient, userUrlParams } from './baseClient'
import { CartType, PickupStoresType } from '../../../../types/content'
import { CommercetoolsCartUpdateItemPickupPayload } from '../../../../types/raw/ctInventory'
import { CommerceToolsUpdateLineItemPayload } from '../../../../types/raw/ctCart'

class InventoryClient extends BaseClient {
  public loadStoresToPickup = async (
    sku: string,
    language: string,
    store = 'kw',
    locale: string,
    location?: { lat: number; lng: number }
  ): Promise<PickupStoresType> => {
    try {
      const response = await this.client.get(
        `/com/inventory/stores?sku=${sku}&store=${store}&language=${language}&latitude=${
          location?.lat || ''
        }&longitude=${location?.lng || ''}&locale=${locale}`
      )

      return response.data
    } catch (error) {
      throw error
    }
  }

  public removeStorePickup = async (
    payload: CommerceToolsUpdateLineItemPayload
  ): Promise<any> => {
    const { lineItemId, store = 'kw', user, locale } = payload
    const config = await this.setHeaders(user.authenticated)
    try {
      const response = await this.client.delete(
        `/com/inventory/removeStore?${userUrlParams(
          user
        )}lineItemId=${lineItemId}&store=${store}&locale=${locale}`,
        config
      )
      return response.data
    } catch (err) {
      throw err
    }
  }

  public updateStorePickup = async (
    payload: CommercetoolsCartUpdateItemPickupPayload
  ): Promise<CartType> => {
    const {
      lineItemId,
      store = 'kw',
      user,
      locale,
      cartSetClickAndCollectOptionsDTO,
    } = payload

    const config = await this.setHeaders(user.authenticated)
    try {
      const response = await this.client.post(
        `/com/inventory/updateStore?${userUrlParams(
          user
        )}lineItemId=${lineItemId}&store=${store}&locale=${locale}`,
        cartSetClickAndCollectOptionsDTO,
        config
      )
      return response.data
    } catch (err) {
      throw err
    }
  }
}
export default InventoryClient
