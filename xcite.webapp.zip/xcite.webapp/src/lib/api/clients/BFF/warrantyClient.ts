import { AvailableWarranties, Warranty } from '../../../../types/content'
import { BaseClient } from './baseClient'

class WarrantyClient extends BaseClient {
  public getWarranty = async (params: {
    sku: string
    locale: string
  }): Promise<Warranty> => {
    const { sku, locale } = params
    try {
      const response = await this.client.get(
        `/warranty?sku=${sku}&locale=${locale}`
      )
      return response.data
    } catch (error) {
      throw error
    }
  }

  public getWarranties = async (params: {
    skus: string[]
    store: string
  }): Promise<AvailableWarranties[]> => {
    const { skus, store } = params
    try {
      const response = await this.client.get(
        `com/availableWarranties?skus=${skus}&store=${store}`
      )
      return response.data
    } catch (error) {
      throw error
    }
  }
}

export default WarrantyClient
