import { Auth } from 'aws-amplify'
import axios, { AxiosRequestConfig } from 'axios'
import { UserProfileType } from '../../../../types/content'
import environment from '../../../environment'

export class BaseClient {
  client = axios.create({
    baseURL: environment.apiBFFBaseUrlPublic,
  })

  setHeaders = async (needsToken = false): Promise<AxiosRequestConfig> => {
    const config: AxiosRequestConfig = {}
    if (needsToken) {
      const session = await Auth.currentSession()
      const token = session.getIdToken().getJwtToken()
      config.headers = {
        authorization: `Bearer ${token}`,
      }
    }
    return config
  }
}

export const userUrlParams = (user: UserProfileType): string =>
  user.authenticated ? `` : `anonymousId=${user.id}&`

const baseClient = new BaseClient()

export default baseClient
