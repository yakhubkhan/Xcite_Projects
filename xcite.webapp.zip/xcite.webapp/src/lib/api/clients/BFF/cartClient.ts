import {
  CommerceToolsCartAddItemPayload,
  CommerceToolsCartUpdateItemPayload,
  commercetoolsDiscountPayload,
  CommercetoolsSetAddressesPayload,
  commercetoolsUpdateShippingMethodPayload,
  CommercetoolsUserStorePayload,
} from '../../../../types/api'
import { CartType } from '../../../../types/content'
import { CommercetoolsUpdateWarrantyPayload } from '../../../../types/raw/ctWarranty'
import { reportErrorUtils } from '../../../../util/reportErrorUtils'
import { userUrlParams } from './baseClient'
import { BaseClient } from './baseClient'

class CartClient extends BaseClient {
  public getCart = async (
    params: CommercetoolsUserStorePayload
  ): Promise<CartType> => {
    const { language, store, user, locale } = params

    const config = await this.setHeaders(user.authenticated)

    try {
      const response = await this.client.get(
        `/com/cart?${userUrlParams(
          user
        )}store=${store}&language=${language}&locale=${locale}`,
        config
      )
      return response.data
    } catch (error) {
      throw error
    }
  }

  public getCartOverview = async (
    params: CommercetoolsUserStorePayload
  ): Promise<CartType> => {
    const { language, store, user, locale } = params

    const config = await this.setHeaders(user.authenticated)

    try {
      const response = await this.client.get(
        `/com/cartOverview?${userUrlParams(
          user
        )}store=${store}&language=${language}&locale=${locale}`,
        config
      )
      return response.data
    } catch (error) {
      if (error instanceof Error) {
        return reportErrorUtils(error)
      }
      throw error
    }
  }

  public addToCart = async (
    params: CommerceToolsCartAddItemPayload
  ): Promise<CartType> => {
    const {
      store,
      user,
      sku,
      quantity,
      cartClickAndCollectOption,
      warranty,
      locale,
    } = params

    const config = await this.setHeaders(user.authenticated)

    try {
      const response = await this.client.post(
        `/com/addToCart?${userUrlParams(user)}store=${store}&locale=${locale}`,
        {
          sku,
          quantity,
          cartClickAndCollectOption,
          warranty,
        },
        config
      )
      return response.data
    } catch (error) {
      throw error
    }
  }

  public updateItemQuantity = async (
    params: CommerceToolsCartUpdateItemPayload
  ): Promise<CartType> => {
    const { lineItemId, quantity, store, user, language, locale } = params

    const config = await this.setHeaders(user.authenticated)

    try {
      const response = await this.client.post(
        `/com/updateQuantity?${userUrlParams(
          user
        )}store=${store}&language=${language}&locale=${locale}`,
        {
          lineItemId,
          quantity,
        },
        config
      )
      return response.data
    } catch (error) {
      throw error
    }
  }

  public verifyCart = async (
    params: CommercetoolsUserStorePayload
  ): Promise<CartType> => {
    const { store, user, language, locale } = params

    const config = await this.setHeaders(user.authenticated)

    try {
      const response = await this.client.post(
        `/com/verifyCart?${userUrlParams(
          user
        )}store=${store}&locale=${locale}&language=${language}`,
        {},
        config
      )
      return response.data
    } catch (error) {
      throw error
    }
  }

  public addShippingAndBillingAddressToCart = async (
    params: CommercetoolsSetAddressesPayload
  ): Promise<CartType> => {
    const { store, user, addresses, locale } = params

    const config = await this.setHeaders(user.authenticated)

    try {
      const response = await this.client.post(
        `/com/addShippingAndBillingAddressToCart?${userUrlParams(
          user
        )}store=${store}&locale=${locale}`,
        addresses,
        config
      )
      return response.data
    } catch (error) {
      throw error
    }
  }

  public removeWarrantyFromCart = async (
    params: CommercetoolsUpdateWarrantyPayload
  ): Promise<CartType> => {
    const { lineItemId, store, user, language, locale } = params
    const config = await this.setHeaders(user.authenticated)

    try {
      const response = await this.client.delete(
        `/com/removeWarranty?${userUrlParams(
          user
        )}lineItemId=${lineItemId}&store=${store}&locale=${locale}&language=${language}
      `,
        config
      )
      return response.data
    } catch (error) {
      throw error
    }
  }

  public addWarrantyFromCart = async (
    params: CommercetoolsUpdateWarrantyPayload //TODO
  ): Promise<CartType> => {
    const { lineItemId, store, user, language, locale, warrantyType } = params
    const config = await this.setHeaders(user.authenticated)
    try {
      const response = await this.client.post(
        `/com/addWarranty?${userUrlParams(
          user
        )}lineItemId=${lineItemId}&store=${store}&locale=${locale}&language=${language}&warrantyType=${warrantyType}`,
        {},
        config
      )
      return response.data
    } catch (error) {
      throw error
    }
  }

  public updateWarrantyFromCart = async (
    params: CommercetoolsUpdateWarrantyPayload //TODO
  ): Promise<CartType> => {
    const { lineItemId, store, user, language, locale, warrantyType } = params
    const config = await this.setHeaders(user.authenticated)
    try {
      const response = await this.client.post(
        `/com/updateWarranty?${userUrlParams(
          user
        )}lineItemId=${lineItemId}&store=${store}&locale=${locale}&&language=${language}&warrantyType=${warrantyType}`,
        {},
        config
      )
      return response.data
    } catch (error) {
      throw error
    }
  }

  public addDiscountFromCart = async (
    params: commercetoolsDiscountPayload
  ): Promise<CartType> => {
    const { store, user, language, promocode, locale } = params
    const config = await this.setHeaders(user.authenticated)
    try {
      const response = await this.client.post(
        `/com/addDiscount?${userUrlParams(
          user
        )}store=${store}&promocode=${promocode}&language=${language}&locale=${locale}`,
        {},
        config
      )
      return response.data
    } catch (error) {
      throw error
    }
  }

  public removeDiscountFromCart = async (
    params: commercetoolsDiscountPayload
  ): Promise<CartType> => {
    const { store, user, language, promocode, locale } = params
    const config = await this.setHeaders(user.authenticated)
    try {
      const response = await this.client.delete(
        `/com/removeDiscount?${userUrlParams(
          user
        )}store=${store}&promocode=${promocode}&language=${language}&locale=${locale}`,
        config
      )
      return response.data
    } catch (error) {
      throw error
    }
  }

  public updateShippingMethod = async (
    params: commercetoolsUpdateShippingMethodPayload
  ): Promise<CartType> => {
    const { store, user, language, locale, deliveryKey, groupSlug } = params
    const config = await this.setHeaders(user.authenticated)
    try {
      const response = await this.client.post(
        `/com/updateShippingMethod?${userUrlParams(
          user
        )}store=${store}&language=${language}&locale=${locale}`,
        {
          deliveryKey,
          groupSlug,
        },
        config
      )
      return response.data
    } catch (error) {
      throw error
    }
  }
}

export default CartClient
