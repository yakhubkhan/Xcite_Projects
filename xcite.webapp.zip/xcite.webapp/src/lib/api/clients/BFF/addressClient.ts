import {
  GoogleMapsAddressPayload,
  UserProfileType,
} from '../../../../types/content'
import { BaseClient, userUrlParams } from './baseClient'
import { CommercetoolsGeoAddress } from '../../../../types/raw/ctAddress'
import { reportErrorUtils } from '../../../../util/reportErrorUtils'

class AddressClient extends BaseClient {
  public convert = async (
    payload: GoogleMapsAddressPayload
  ): Promise<CommercetoolsGeoAddress> => {
    const { lat, lng, locale, results, userAuthenticated, store } = payload
    const reqBody = { lat, lng, results }
    try {
      const config = await this.setHeaders(userAuthenticated)
      const response = await this.client.post(
        `/addresses/convertGoogleMapAddress?store=${store}&locale=${locale}`,
        reqBody,
        config
      )
      return response.data
    } catch (error) {
      if (error instanceof Error) {
        return reportErrorUtils(error)
      }
      throw error
    }
  }

  public loadAddressForLoggedInUser = async (params: {
    store: string
    user: UserProfileType
  }): Promise<any> => {
    const { store, user } = params
    const config = await this.setHeaders(user.authenticated)
    try {
      const response = await this.client.get(
        `/customers/me/addresses?${userUrlParams(user)}store=${store}`,
        config
      )
      return response.data
    } catch (error) {
      if (error instanceof Error) {
        return reportErrorUtils(error)
      }
      throw error
    }
  }
}

export default AddressClient
