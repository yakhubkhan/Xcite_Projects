import axios, { AxiosRequestConfig } from 'axios'
import { Auth } from 'aws-amplify'
import { DeliveryMethodType, PaymentMethodType } from '../../../types/content'
import environment from '../../environment'
import {
  CommerceToolsCategoryDetails,
  CommerceToolsDeliveryMethodsResponse,
} from '../../../types/commerceTools'
import transformDeliveryMethods from '../processors/DeliveryMethodsProcessor'
import { Locale } from '../l18n/Locale'

const axiosClient = axios.create({
  baseURL: environment.apiBackendBaseUrlPublic,
})

const fetchBackendData = async (url: string, needsToken = false) => {
  const config: AxiosRequestConfig = {}
  if (needsToken) {
    const session = await Auth.currentSession()
    const token = session.getAccessToken().getJwtToken()
    config.headers = { Authorization: `Bearer ${token}` }
  }
  try {
    const { data } = await axiosClient.get(url, config)
    return data
  } catch (error) {
    throw error
  }
}

export const getProductCategory = async (
  categorySlug: string,
  store: string
): Promise<CommerceToolsCategoryDetails> => {
  const query = `where=${encodeURIComponent(
    `slug(en-${store}="${categorySlug}")`
  )}`
  const { results } = await fetchBackendData(
    `/categories/?${query}&store=${store}`
  )
  if (Array.isArray(results) && results.length > 0) {
    return results[0]
  } else {
    throw new Error(
      `category with slug "${categorySlug}" not found in store "${store}"`
    )
  }
}

export const getProductCategoryByKey = async (
  categoryKey: string,
  store: string
): Promise<CommerceToolsCategoryDetails> => {
  return await fetchBackendData(
    `/categories/key=${encodeURIComponent(categoryKey)}`
  ).catch(() => {
    throw new Error(
      `category with key "${categoryKey}" not found in store "${store}"`
    )
  })
}

export const getDeliveryMethods = async (
  sku: string,
  store: string,
  languageKey: string,
  locale: Locale
): Promise<DeliveryMethodType[]> => {
  try {
    const data: CommerceToolsDeliveryMethodsResponse = await fetchBackendData(
      `/deliveryinfo/${sku}?store=${store}`
    )
    return transformDeliveryMethods(data, store, languageKey, locale)
  } catch (error) {
    throw error
  }
}

export const getOrderPaymentMethodEnum = async (payload: {
  locale: string
}): Promise<PaymentMethodType[]> => {
  const { locale } = payload
  try {
    const enumVal = await fetchBackendData(
      'enumerations/order?enumAttribute=paymentMethod',
      false
    )
    const paymentEnumArr = enumVal.paymentMethod
    return paymentEnumArr.map((payment) => ({
      name: payment.key,
      label: payment.label[locale],
    }))
  } catch (error) {
    throw error
  }
}
