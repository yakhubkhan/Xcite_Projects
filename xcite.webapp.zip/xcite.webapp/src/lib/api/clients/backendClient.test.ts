/* eslint-disable @typescript-eslint/no-var-requires */
import { ensureCartIsValid } from './backendClient'
import { setupServer } from 'msw/node'
import commerceToolsCartStockcheckHandler from '../../../mocks/handler/CommerceToolsCartStockcheckHandler'
import getOrderForUserHandler from '../../../mocks/handler/CommerceToolsGetOrderForUserHandler'

const server = setupServer()

beforeAll(() => {
  server.listen({ onUnhandledRequest: 'error' })
})

afterEach(() => {
  server.resetHandlers()
})

afterAll(() => {
  server.close()
})

describe('Ensure cart is valid', () => {
  it('resolves for empty error list', async () => {
    server.use(commerceToolsCartStockcheckHandler)
    return expect(
      ensureCartIsValid({
        user: { id: 'NO_ERRORS' },
        store: 'kw',
        language: 'en',
      })
    ).resolves.toEqual(undefined)
  })
  it('rejects correctly for stock check errors', async () => {
    server.use(commerceToolsCartStockcheckHandler)
    return expect(
      ensureCartIsValid({
        user: { id: 'STOCK_ERRORS' },
        store: 'kw',
        language: 'en',
      })
    ).rejects.toEqual([
      {
        level: 'ERROR',
        code: 'OUT_OF_STOCK',
        sku: '635860',
      },
      {
        level: 'ERROR',
        code: 'OUT_OF_STOCK',
        sku: '635978',
      },
    ])
  })
  it('rejects correctly for other errors', async () => {
    server.use(commerceToolsCartStockcheckHandler)
    return expect(
      ensureCartIsValid({
        user: { id: 'SERVER_ERROR' },
        store: 'kw',
        language: 'en',
      })
    ).rejects.toEqual('UNKNOWN_ERROR')
  })
})
