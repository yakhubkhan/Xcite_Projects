import { setupServer } from 'msw/node'
import amplienceClient from './amplienceClient'
import {
  amplienceFetchCachedContentHandler,
  amplienceFetchUncachedContentHandler,
} from '../../../mocks/handler/AmplienceFetchContentHandler'
import amplienceFetchContentExceptionHandler from '../../../mocks/handler/AmplienceFetchContentExceptionHandler'
import amplienceDamGetMediaSetHandler from '../../../mocks/handler/AmplienceDamGetMediaSetHandler'

const server = setupServer()
const OLD_ENV = process.env

beforeAll(() => {
  server.listen({ onUnhandledRequest: 'error' })
})

beforeEach(() => {
  process.env = { ...OLD_ENV }
})

afterEach(() => {
  server.resetHandlers()
})

afterAll(() => {
  server.close()
  process.env = OLD_ENV
})

describe('amplienceClient.getContent()', () => {
  it('returns correct result for single key', async () => {
    server.use(amplienceFetchCachedContentHandler)
    await expect(
      amplienceClient.getContents(
        {
          contentData: ['contentElement'],
          headerData: ['nonExistingKey'],
        },
        'en-KW',
        ''
      )
    ).resolves.toStrictEqual({
      contentData: {
        content: {
          _meta: {
            deliveryKey: 'contentElement',
          },
        },
      },
      headerData: null,
    })
  })

  it('returns correct result for multiple keys', async () => {
    server.use(amplienceFetchCachedContentHandler)

    await expect(
      amplienceClient.getContents(
        {
          contentData: ['contentElement1', 'contentElement2'],
          headerData: ['nonExistingKey3', 'contentElement3'],
        },
        'en-KW',
        ''
      )
    ).resolves.toStrictEqual({
      contentData: {
        content: {
          _meta: {
            deliveryKey: 'contentElement1',
          },
        },
      },
      headerData: {
        content: {
          _meta: {
            deliveryKey: 'contentElement3',
          },
        },
      },
    })
  })

  it('uses uncached API if configured', async () => {
    process.env.NEXT_PUBLIC_API_AMPLIENCE_ENABLE_UNCACHED_API = 'true'
    server.use(amplienceFetchUncachedContentHandler)
    await expect(
      amplienceClient.getContents(
        {
          contentData: [],
          headerData: [],
        },
        'en-KW',
        ''
      )
    ).resolves.toBeTruthy()
  })

  it('throws error 500 if request fails', async () => {
    server.use(amplienceFetchContentExceptionHandler)
    await expect(
      amplienceClient.getContents(
        { contentData: [], headerData: [] },
        'en-KW',
        ''
      )
    ).rejects.toEqual(
      expect.objectContaining({
        response: expect.objectContaining({
          status: 500,
        }),
      })
    )
  })
})

describe('amplienceClient.getMediaSetMetaData()', () => {
  it('should load the default media set meta data if no location-specific set defined', async () => {
    server.use(amplienceDamGetMediaSetHandler)
    await expect(
      amplienceClient.getMediaSetMetaData('12345', 'ar-KW')
    ).resolves.toStrictEqual([
      {
        format: 'JPEG',
        height: 1900,
        opaque: 'true',
        src: 'https://cdn.media.amplience.net/i/alghanim/12345_1',
        type: 'img',
        width: 2800,
      },
      {
        format: 'JPEG',
        height: 720,
        opaque: 'true',
        src: 'https://cdn.media.amplience.net/i/alghanim/12345_2',
        type: 'img',
        width: 720,
      },
    ])
  })

  it('should load the location specific media set meta data if exists', async () => {
    server.use(amplienceDamGetMediaSetHandler)
    await expect(
      amplienceClient.getMediaSetMetaData('12345', 'ar-SA')
    ).resolves.toStrictEqual([
      {
        src: 'https://cdn.media.amplience.net/i/alghanim/12345-02',
        width: 600,
        height: 600,
        format: 'JPEG',
        opaque: 'true',
        type: 'img',
      },
      {
        src: 'https://cdn.media.amplience.net/i/alghanim/12345-03',
        width: 600,
        height: 600,
        format: 'JPEG',
        opaque: 'true',
        type: 'img',
      },
    ])
  })
})
