import getConfig from 'next/config'
import { HubPayload } from '@aws-amplify/core'
import Amplify, { Auth, Hub } from 'aws-amplify'
import gtmDatalayer from '../../../util/gtmUtils'

Amplify.configure({ ...getConfig().publicRuntimeConfig.awsConfig, ssr: true })

export const signUp = async ({
  username,
  password,
  anonymousId,
  store,
}: {
  username: string
  password: string
  anonymousId: string
  store: string
}): Promise<string> => {
  try {
    await Auth.signUp({
      username,
      password,
      clientMetadata: {
        anonymousId,
        store,
      },
    })
    return 'success'
  } catch (err) {
    throw err
  }
}

export const confirmSignUp = async ({
  username,
  authenticationCode,
}: {
  username: string
  authenticationCode: string
}): Promise<void | Error> => {
  try {
    await Auth.confirmSignUp(username, authenticationCode)
    const signup: HubPayload = {
      event: 'confirm_signup',
      data: {},
      message: username + ' sign up confirmed',
    }
    Hub.dispatch('authChannel', signup)
  } catch (err) {
    throw err
  }
}

export const signIn = async ({
  username,
  password,
  anonymousId,
  store,
}: {
  username: string
  password: string
  anonymousId: string
  store: string
}): Promise<{ username: string }> => {
  try {
    const user = await Auth.signIn(
      {
        username,
        password,
      },
      undefined,
      { anonymousId, store }
    )
    return user
  } catch (err) {
    throw err
  }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const currentAuthenticatedUser = async (): Promise<any | Error> => {
  try {
    const user = await Auth.currentAuthenticatedUser()
    return user
  } catch (err) {
    throw err
  }
}

export const signOut = async (): Promise<string | Error> => {
  try {
    await Auth.signOut({ global: true })
    gtmDatalayer('log_out', 'account interactions', 'log_out_success')
    localStorage.setItem('customerId', '')
    return 'success'
  } catch (err) {
    throw err
  }
}

export const resendSignUp = async ({
  username,
}: {
  username: string
}): Promise<string | Error> => {
  try {
    await Auth.resendSignUp(username)
    return 'success'
  } catch (err) {
    throw err
  }
}

export const forgotPassword = async ({
  username,
}: {
  username: string
}): Promise<string | Error> => {
  try {
    await Auth.forgotPassword(username)
    return 'success'
  } catch (err) {
    throw err
  }
}

export const forgotPasswordSubmit = async ({
  username,
  authenticationCode,
  password,
}: {
  username: string
  authenticationCode: string
  password: string
}): Promise<string | Error> => {
  try {
    await Auth.forgotPasswordSubmit(username, authenticationCode, password)
    return 'success'
  } catch (err) {
    throw err
  }
}

export const authListener = (): void => {
  Hub.listen('auth', authListenerHandler)
}

export const removeAuthListener = (): void => {
  Hub.remove('auth', authListenerHandler)
}

const authListenerHandler = (data) => {
  switch (data.payload.event) {
    case 'signIn':
      Hub.dispatch('authChannel', data.payload)
      break
    case 'signUp':
      Hub.dispatch('authChannel', data.payload)
      break
    case 'signOut':
      break
    case 'signIn_failure':
      Hub.dispatch('authChannel', data.payload)
      break
    case 'signUp_failure':
      Hub.dispatch('authChannel', data.payload)
      break
    case 'forgotPassword_failure':
      Hub.dispatch('authChannel', data.payload)
      break
    case 'forgotPasswordSubmit':
      Hub.dispatch('authChannel', data.payload)
      break
    case 'forgotPasswordSubmit_failure':
      Hub.dispatch('authChannel', data.payload)
      break
    case 'tokenRefresh':
      break
    case 'tokenRefresh_failure':
      console.error('token refresh failed')
      break
    case 'configured':
      break
  }
}
