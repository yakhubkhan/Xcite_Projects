import { setupServer } from 'msw/node'
import commerceFacadeClient from './commerceFacadeClient'
import commerceToolsReserveSlotHandler from '../../../../mocks/handler/CommerceToolsReserveSlotHandler'
import commerceToolsGetAvailableTimeSlotsHandler from '../../../../mocks/handler/CommerceToolsGetAvailableTimeSlotsHandler'
import commerceToolsGetPaymentEnumHandler from '../../../../mocks/handler/CommerceToolsGetPaymentEnumHandler'

const server = setupServer()

beforeAll(() => {
  server.listen({ onUnhandledRequest: 'error' })
})

afterEach(() => {
  server.resetHandlers()
})

afterAll(() => {
  server.close()
})

describe('Reserve Slot', () => {
  it('should return cart', async () => {
    server.use(commerceToolsReserveSlotHandler)
    server.use(commerceToolsGetPaymentEnumHandler)

    const result = await commerceFacadeClient.delivery.reserveSlot({
      user: { id: 'user-1234' },
      store: 'kw',
      language: 'en',
    })

    expect(result.cartId).toBe('a36080f4-6488-4d7e-8f6e-e72bd15dc30d')
  })
})

describe('Get Slots', () => {
  it('should return available slots', async () => {
    server.use(commerceToolsGetAvailableTimeSlotsHandler)

    const result = await commerceFacadeClient.delivery.getAvailableSlots({
      user: { id: 'user-1234' },
      store: 'kw',
      language: 'en',
      deliveryTeam: '02',
    })

    expect(result.availableSlots.length).toBe(16)
  })
})
