import { AvailableWarranties } from '../../../../types/content'
import { fetchBackendData } from './commerceFacadeClient'
import { CommercetoolsGetAvailableWarrantiesPayload } from '../../../../types/raw/ctWarranty'

export class WarrantyClient {
  public getWarranties = async (
    payload: CommercetoolsGetAvailableWarrantiesPayload
  ): Promise<AvailableWarranties[]> => {
    const { store, skus } = payload
    try {
      const data = await fetchBackendData(
        `/warranty/available-warranties?store=${store}&skus=${skus}`
      )
      return data
    } catch (error) {
      throw error
    }
  }
}
