/* eslint-disable @typescript-eslint/no-var-requires */
import commerceToolsGetPaymentMethodsHandler from '../../../../mocks/handler/CommerceToolsGetPaymentMethodsHandler'
import { PaymentMethodName } from '../../../../types/content'
import commerceToolsAddPaymentMethodsHandler from '../../../../mocks/handler/CommerceToolsAddPaymentMethod'
import { setupServer } from 'msw/node'
import commerceFacadeClient from './commerceFacadeClient'
import commerceToolsGetPaymentEnumHandler from '../../../../mocks/handler/CommerceToolsGetPaymentEnumHandler'

const server = setupServer()

beforeAll(() => {
  server.listen({ onUnhandledRequest: 'error' })
})

afterEach(() => {
  server.resetHandlers()
})

afterAll(() => {
  server.close()
})

describe('getPaymentMethods', () => {
  it('should return the available payment methods for that user and store', async () => {
    function compare(a, b) {
      const nameA = a.name.toUpperCase()
      const nameB = b.name.toUpperCase()
      return nameA < nameB ? -1 : nameA > nameB ? 1 : 0
    }

    server.use(commerceToolsGetPaymentMethodsHandler)

    const methods = await commerceFacadeClient.payment.getPaymentMethods({
      user: { id: '12345' },
      store: 'ksa',
      language: 'en',
      locale: 'en-SA',
    })

    expect(methods.sort(compare)).toStrictEqual([
      {
        name: PaymentMethodName.CashOnDelivery,
        label: 'Cash on Delivery',
        acceptedPaymentMethods: undefined,
      },
      {
        name: PaymentMethodName.CreditCard,
        label: 'Visa / Mastercard / Mada',
        acceptedPaymentMethods: ['Visa', 'Mastercard'],
      },
      {
        name: PaymentMethodName.Knet,
        label: 'KNET',
        acceptedPaymentMethods: undefined,
      },
      {
        name: PaymentMethodName.Paypal,
        label: 'Paypal',
        acceptedPaymentMethods: undefined,
      },
      {
        name: PaymentMethodName.Tamara,
        label: 'Tamara',
        acceptedPaymentMethods: undefined,
      },
    ])
  })
})

describe('addPaymentMethod', () => {
  it('should set the selected payment method to the cart in Commerce Facade and return the adjusted cart for that user and store', async () => {
    server.use(commerceToolsAddPaymentMethodsHandler)
    server.use(commerceToolsGetPaymentEnumHandler)

    const result = await commerceFacadeClient.payment.addPaymentMethodToCart({
      paymentMethod: 'Knet',
      user: { id: 'user-1234' },
      store: 'kw',
      language: 'en',
    })
    expect(result.userId).toBe('user-1234')
    expect(result.paymentMethod?.name).toBe('Knet')
  })
})
