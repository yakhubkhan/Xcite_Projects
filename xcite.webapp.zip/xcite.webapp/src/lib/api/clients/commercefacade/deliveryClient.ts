import {
  CommercetoolsGetSlotPayload,
  CommercetoolsUserStorePayload,
  CommercetoolsSoftReserveSlotPayload,
} from '../../../../types/api'
import { fetchBackendData, postBackendData } from './commerceFacadeClient'
import { CommercetoolsAvailableSlots } from '../../../../types/raw/ctDelivery'
import { CartType } from '../../../../types/content'
import transformCart from '../../processors/CartProcessor'
import { userUrlParams } from '../BFF/baseClient'

export class DeliveryClient {
  public reserveSlot = async (
    payload: CommercetoolsUserStorePayload
  ): Promise<CartType> => {
    const { store, user, language, locale = '' } = payload
    try {
      const data = await postBackendData(
        `/delivery/reserve-slot?${userUrlParams(user)}store=${store}`,
        {},
        payload
      )
      return transformCart(data, store, language, locale)
    } catch (error) {
      throw error
    }
  }

  public getAvailableSlots = async (
    payload: CommercetoolsGetSlotPayload
  ): Promise<CommercetoolsAvailableSlots> => {
    const { store, user, deliveryTeam } = payload
    try {
      const data = await fetchBackendData(
        `/delivery/get-slot?${userUrlParams(
          user
        )}store=${store}&deliveryTeam=${deliveryTeam}`,
        payload
      )
      console.log("Avaialable Slots Start");
      console.log(JSON.stringify(data));
      console.log("Avaialable Slots End");
      return data
    } catch (error) {
      throw error
    }
  }

  public softReserveSlot = async (
    payload: CommercetoolsSoftReserveSlotPayload
  ): Promise<CartType> => {
    const { store, user, language, locale = '' } = payload

    try {
      const data = await postBackendData(
        `/delivery/soft-reserve-slot?store=${store}&${userUrlParams(user)}`,
        payload.reqBody,
        payload
      )
      return transformCart(data, store, language, locale)
    } catch (error) {
      throw error
    }
  }
}
