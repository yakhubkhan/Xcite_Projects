import {
  CommerceToolsOrderPayload,
  CommerceToolsOrderReprintPayload,
} from '../../../../types/api'
import { Order, OrderReprint, SuccesfulOrder } from '../../../../types/content'
import { getSuccesfulOrder } from '../../processors/OrderProcessor'
import { fetchBackendData, postBackendData } from './commerceFacadeClient'
import { userUrlParams } from '../BFF/baseClient'

export class OrderClient {
  public getOrderDetails = async (
    payload: CommerceToolsOrderPayload
  ): Promise<Order> => {
    const {
      user,
      orderId,
      locale = payload?.language + '-' + payload?.store,
    } = payload
    try {
      const data = await fetchBackendData(
        `/orders/${orderId}?${userUrlParams(user)}`,
        payload
      )
      return getSuccesfulOrder(data, locale)
    } catch (error) {
      throw error
    }
  }

  public getOrdersReprint = async (
    payload: CommerceToolsOrderReprintPayload
  ): Promise<OrderReprint> => {
    const { store, user, orderNumber, lineItemIds } = payload
    try {
      const data = await postBackendData(
        `/orders/reprint?${userUrlParams(user)}store=${store}`,
        { orderNumber, lineItemIds },
        payload
      )
      return data
    } catch (error) {
      throw error
    }
  }
}
