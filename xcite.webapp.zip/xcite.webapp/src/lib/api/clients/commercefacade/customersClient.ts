import { CommercetoolsUserStorePayload } from '../../../../types/api'
import { UserProfileType } from '../../../../types/content'
import { fetchBackendData } from './commerceFacadeClient'

export class CustomersClient {
  public getCurrentUser = async (
    payload: CommercetoolsUserStorePayload
  ): Promise<UserProfileType> => {
    try {
      const data = await fetchBackendData('/customers/me', payload)
      return data
    } catch (error) {
      throw error
    }
  }
}
