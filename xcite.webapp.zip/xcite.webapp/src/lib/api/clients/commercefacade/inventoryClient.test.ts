import commercetoolsRemoveStoreHandler from '../../../../mocks/handler/CommercetoolsRemoveStoreHandler'
import commercetoolsUpdateStoreHandler from '../../../../mocks/handler/CommercetoolsUpdateStoreHandler'
import { setupServer } from 'msw/node'
import commerceFacadeClient from './commerceFacadeClient'
import commerceToolsGetPaymentEnumHandler from '../../../../mocks/handler/CommerceToolsGetPaymentEnumHandler'

const server = setupServer()

beforeAll(() => {
  server.listen({ onUnhandledRequest: 'error' })
})

afterEach(() => {
  server.resetHandlers()
})

afterAll(() => {
  server.close()
})

describe('Remove Store Pickup from Item', () => {
  it('returns the proper result when removing pickup store from the line item', async () => {
    server.use(commercetoolsRemoveStoreHandler)
    server.use(commerceToolsGetPaymentEnumHandler)

    const result = await commerceFacadeClient.inventoryClient.removeStorePickup(
      {
        lineItemId: '4fd572dd-021d-463a-b4a8-2c56500a2d81',
        user: { id: 'user-1234' },
        store: 'kw',
        language: 'en',
      }
    )
    expect(result.userId).toBe('user-1234')
    expect(result.items[0].id).toBe('4fd572dd-021d-463a-b4a8-2c56500a2d81')
  })
})

describe('Update Line Item with different Store Pickup', () => {
  it('returns the proper result when updating pickup store on the line item', async () => {
    server.use(commercetoolsUpdateStoreHandler)
    server.use(commerceToolsGetPaymentEnumHandler)
    const result = await commerceFacadeClient.inventoryClient.updateStorePickup(
      {
        lineItemId: '4fd572dd-021d-463a-b4a8-2c56500a2d81',
        cartSetClickAndCollectOptionsDTO: {
          firstName: 'Muster',
          lastName: 'Mustermann',
          civilID: '12323343434343',
          sapSite: '0106',
        },
        user: { id: 'user-1234' },
        store: 'kw',
        language: 'en',
      }
    )

    expect(result.userId).toBe('user-1234')
    expect(result.items[0].id).toBe('4fd572dd-021d-463a-b4a8-2c56500a2d81')
  })
})
