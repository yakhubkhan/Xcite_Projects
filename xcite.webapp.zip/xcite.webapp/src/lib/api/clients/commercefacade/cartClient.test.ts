import { setupServer } from 'msw/node'
import commerceFacadeClient from './commerceFacadeClient'
import commerceToolsSetShippingAndBillingAddressHandler from '../../../../mocks/handler/CommerceToolsSetShippingAddress'
import commerceToolsGetCartHandler from '../../../../mocks/handler/CommerceToolsGetCartHandler'
import commerceToolsAddToCartHandler from '../../../../mocks/handler/CommerceToolsAddToCartHandler'
import commerceToolsVerifyCartHandler from '../../../../mocks/handler/CommerceToolsVerifyCartHandler'
import commerceToolsGetPaymentEnumHandler from '../../../../mocks/handler/CommerceToolsGetPaymentEnumHandler'

const server = setupServer()

beforeAll(() => {
  server.listen({ onUnhandledRequest: 'error' })
})

afterEach(() => {
  server.resetHandlers()
})

afterAll(() => {
  server.close()
})

describe('addShippingAndBillingAddressToCart', () => {
  it('should set the addresses to the cart in Commerce Facade and return the adjusted cart for that user and store', async () => {
    server.use(commerceToolsSetShippingAndBillingAddressHandler)
    server.use(commerceToolsGetPaymentEnumHandler)

    const address = {
      id: 'abcedfg',
      key: 'CTsample-key',
      firstName: 'Fos',
      lastName: 'Shelling',
      paciNumber: '1233211232',
      primaryPhoneNumber: '5921831233',
      secondaryPhoneNumber: '87438233',
      avenue: 'Test Avenue',
      building: 'Mars',
      floor: '5',
      flat: '1290',
      addressExternalId: 'sap-id',
      email: 'Shelling@gmail.com',
      deliveryInstruction: 'Turn First right',
      formattedAddress:
        '2, Mars, 1290, 5, Cairo Street, Test Avenue, 2 Al Kuwayt, city, area, KW',
      localizedFormattedAddress: {
        'en-KW':
          '2, Mars, 1290, 5, Cairo Street, Test Avenue, 2 Al Kuwayt, city, area, KW',
      },
      address: {
        region: 'Al Kuwayt',
        city: 'city',
        block: '2',
        streetName: 'Cairo Street',
        longitude: 47.9989268,
        latitude: 29.3585972,
        country: 'KW',
        area: 'area',
      },
    }

    const result =
      await commerceFacadeClient.cart.addShippingAndBillingAddressToCart({
        user: { id: 'user-1234' },
        store: 'kw',
        language: 'en',
        addresses: {
          shippingAddress: address,
          billingAddress: address,
        },
      })

    expect(result.shippingAddress).toEqual(address)
  })
})

describe('getProductCartData', () => {
  it('should return empty data object for the product if not available cart', async () => {
    server.use(commerceToolsGetCartHandler)
    server.use(commerceToolsGetPaymentEnumHandler)

    const result = await commerceFacadeClient.cart.getProductCartData({
      sku: '67890',
      user: { id: 'user-1234' },
      store: 'kw',
      language: 'en',
    })

    expect(result.isMaxQuantityReached).toBe(false)
    expect(result.pickupStore).toBeUndefined()
  })

  it('should return data for the product if available in cart', async () => {
    server.use(commerceToolsGetCartHandler)
    server.use(commerceToolsGetPaymentEnumHandler)

    const result = await commerceFacadeClient.cart.getProductCartData({
      sku: '637510',
      user: { id: 'user-1234' },
      store: 'kw',
      language: 'en',
    })

    expect(result.isMaxQuantityReached).toBe(true)
    expect(result.lineItemId).toBe('5ae80280-0768-44aa-b449-bf59558f3506')
    expect(result.pickupStore?.id).toEqual('0311')
    expect(result.pickupStore?.name).toEqual(
      'Sultan Center Al-Manqaf - Express'
    )
    expect(result.pickupStore?.address).toEqual(
      'Manqaf, Block 4, Manqaf Roundabout, Sultan Center'
    )
    expect(result.pickupStore?.openingHours).toEqual('8:00 AM to 12:00 AM')
  })

  it('should return max quantity reached based on all line items wth this sku in cart', async () => {
    server.use(commerceToolsGetCartHandler)
    server.use(commerceToolsGetPaymentEnumHandler)

    const result = await commerceFacadeClient.cart.getProductCartData({
      sku: '637509',
      user: { id: 'user-1234' },
      store: 'kw',
      language: 'en',
    })

    expect(result.isMaxQuantityReached).toBe(true)
  })
})

describe('addItemToCart', () => {
  it('returns the proper result when adding an item to the cart', async () => {
    server.use(commerceToolsAddToCartHandler)
    const result = await commerceFacadeClient.cart.addItemToCart({
      sku: '12345',
      quantity: 1,
      user: { id: 'user-1234' },
      store: 'kw',
      language: 'en',
    })
    expect(result.userId).toBe('user-1234')
    expect(result.items[0].sku).toBe('12345')
    expect(result.items[0].quantity).toBe(1)
  })
})

describe('Verify Cart', () => {
  it('should return some error messages if an item within cart has an error', async () => {
    server.use(commerceToolsVerifyCartHandler)

    const result = await commerceFacadeClient.cart.verifyCart({
      user: { id: 'user-1234' },
      store: 'kw',
      language: 'en',
    })

    expect(result.messages).not.toHaveLength(0)
  })
})
