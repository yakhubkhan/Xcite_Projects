import {
  CommerceToolsCartAddItemPayload,
  CommercetoolsCartAddWarrantyActionPayload,
  CommercetoolsCartRemoveWarrantyActionPayload,
  CommerceToolsCartUpdateItemPayload,
  CommercetoolsCartUpdateWarrantyActionPayload,
  commercetoolsDiscountPayload,
  CommercetoolsProductFromCartPayload,
  CommercetoolsSetAddressesPayload,
  CommercetoolsSetAddressPayload,
  commercetoolsUpdateShippingMethodPayload,
  CommercetoolsUserStorePayload,
} from '../../../../types/api'
import transformCart from '../../processors/CartProcessor'
import {
  deleteBackendData,
  fetchBackendData,
  postBackendData,
} from './commerceFacadeClient'
import {
  CartType,
  DiscountErrorResponseType,
  ProductCartInformationType,
} from '../../../../types/content'
import { userUrlParams } from '../BFF/baseClient'

export class CartClient {
  public addShippingAndBillingAddressToCart = async (
    payload: CommercetoolsSetAddressesPayload
  ): Promise<CartType> => {
    const { store, language, addresses, user, locale = '' } = payload
    try {
      const data = await postBackendData(
        `/addresses/shippingAndBilling/?${userUrlParams(user)}store=${store}`,
        addresses,
        payload
      )
      return transformCart(data, store, language, locale)
    } catch (err) {
      throw err
    }
  }
  public addShippingAddressToCart = async (
    payload: CommercetoolsSetAddressPayload
  ): Promise<CartType> => {
    const { store, language, address, user, locale = '' } = payload
    try {
      const data = await postBackendData(
        `/addresses/shipping?${userUrlParams(user)}store=${store}`,
        address,
        payload
      )
      return transformCart(data, store, language, locale)
    } catch (err) {
      throw err
    }
  }

  public addBillingAddressToCart = async (
    payload: CommercetoolsSetAddressPayload
  ): Promise<CartType> => {
    const { store, language, address, user, locale = '' } = payload
    try {
      const data = await postBackendData(
        `/addresses/billing/?${userUrlParams(user)}store=${store}`,
        address,
        payload
      )
      return transformCart(data, store, language, locale)
    } catch (err) {
      throw err
    }
  }

  public getCartByUserId = async (
    payload: CommercetoolsUserStorePayload
  ): Promise<CartType> => {
    const { store, user, language, locale = '' } = payload
    try {
      const data = await fetchBackendData(
        `/carts?${userUrlParams(user)}store=${store}`,
        payload
      )
      return transformCart(data, store, language, locale)
    } catch (error) {
      throw error
    }
  }

  public updateCartGroupingByUserId = async (
    payload: CommercetoolsUserStorePayload
  ): Promise<CartType> => {
    const { store, user, language, locale = '' } = payload
    try {
      const cart = await postBackendData(
        `grouping?${userUrlParams(user)}store=${store}`,
        {},
        payload
      )
      return transformCart(cart, store, language, locale)
    } catch (error) {
      throw error
    }
  }

  public addItemToCart = async (
    payload: CommerceToolsCartAddItemPayload
  ): Promise<CartType> => {
    const {
      sku,
      quantity,
      store,
      language,
      user,
      cartClickAndCollectOption,
      warranty,
      locale = '',
    } = payload
    const reqBody = {
      sku,
      quantity,
      cartSetClickAndCollectAttributesDTO: cartClickAndCollectOption,
      warranty,
    }
    try {
      const data = await postBackendData(
        `/carts/add?${userUrlParams(user)}store=${store}`,
        reqBody,
        payload
      )
      return transformCart(data, store, language, locale)
    } catch (error) {
      throw error
    }
  }

  public updateCartItemQuantity = async (
    payload: CommerceToolsCartUpdateItemPayload
  ): Promise<CartType> => {
    const { lineItemId, quantity, store, user, language, locale = '' } = payload
    const reqBody = {
      lineItemId,
      quantity,
    }
    try {
      const data = await postBackendData(
        `/carts/quantity?${userUrlParams(user)}store=${store}`,
        reqBody,
        payload
      )

      return transformCart(data, store, language, locale)
    } catch (error) {
      throw error
    }
  }

  public getProductCartData = async (
    payload: CommercetoolsProductFromCartPayload
  ): Promise<ProductCartInformationType> => {
    const { store, user, language, sku, token } = payload

    const cart = await this.getCartByUserId({ store, language, user, token })

    const lineItem = cart?.items.find((item) => item.sku === sku)

    const totalItemQuantity = cart?.items
      .filter((item) => {
        return item.sku === sku
      })
      .reduce((totalItemQuantity, item) => totalItemQuantity + item.quantity, 0)

    return lineItem
      ? {
          isMaxQuantityReached: totalItemQuantity >= lineItem.maxQuantity,
          pickupStore: lineItem.pickupStore,
          lineItemId: lineItem.id,
        }
      : { isMaxQuantityReached: false }
  }

  public verifyCart = async (
    payload: CommercetoolsUserStorePayload
  ): Promise<CartType> => {
    const { store, user, language, locale = '' } = payload
    try {
      const data = await postBackendData(
        `/carts/verify?${userUrlParams(user)}store=${store}`,
        {},
        payload
      )
      return transformCart(
        data.cart,
        store,
        language,
        locale,
        data.messages,
        data.ccAvailability
      )
    } catch (error) {
      throw error
    }
  }

  public addWarrantyToCartV2 = async (
    payload: CommercetoolsCartAddWarrantyActionPayload
  ): Promise<CartType> => {
    const { store, user, language, addWarrantyAction, locale = '' } = payload
    try {
      const data = await postBackendData(
        `/v2/carts/warranty?${userUrlParams(user)}store=${store}`,
        addWarrantyAction,
        payload
      )

      return transformCart(data, store, language, locale)
    } catch (error) {
      throw error
    }
  }

  public updateWarrantyV2 = async (
    payload: CommercetoolsCartUpdateWarrantyActionPayload
  ): Promise<CartType> => {
    const {
      store,
      user,
      language,
      warrantySelection,
      locale = '',
      warrantyLineItemId,
    } = payload
    try {
      const data = await postBackendData(
        `/v2/carts/warranty/${warrantyLineItemId}?${userUrlParams(
          user
        )}store=${store}`,
        warrantySelection,
        payload
      )

      return transformCart(data, store, language, locale)
    } catch (error) {
      throw error
    }
  }

  public removeWarrantyV2 = async (
    payload: CommercetoolsCartRemoveWarrantyActionPayload
  ): Promise<CartType> => {
    const { store, user, language, locale = '', warrantyLineItemId } = payload
    try {
      const data = await deleteBackendData(
        `/v2/carts/warranty/${warrantyLineItemId}?${userUrlParams(
          user
        )}store=${store}`,
        payload
      )

      return transformCart(data, store, language, locale)
    } catch (error) {
      throw error
    }
  }

  public addDiscount = async (
    payload: commercetoolsDiscountPayload
  ): Promise<CartType | DiscountErrorResponseType> => {
    const { store, user, language, promocode, locale = '' } = payload
    try {
      const data = await postBackendData(
        `/discounts?${userUrlParams(
          user
        )}store=${store}&promocode=${promocode}`,
        {},
        payload
      )
      if (data.cart) {
        return transformCart(
          data.cart,
          store,
          language,
          locale,
          data.messages,
          data.ccAvailability
        )
      } else {
        return { discountError: data }
      }
    } catch (error) {
      throw error
    }
  }
  public removeDiscount = async (
    payload: commercetoolsDiscountPayload
  ): Promise<CartType> => {
    const { store, user, language, promocode, locale = '' } = payload
    try {
      const data = await deleteBackendData(
        `/discounts?${userUrlParams(
          user
        )}store=${store}&promocode=${promocode}`,
        payload
      )
      return transformCart(
        data.cart,
        store,
        language,
        locale,
        data.messages,
        data.ccAvailability
      )
    } catch (error) {
      throw error
    }
  }

  public updateShippingMethod = async (
    payload: commercetoolsUpdateShippingMethodPayload
  ): Promise<CartType> => {
    const {
      store,
      user,
      language,
      locale = '',
      deliveryKey,
      groupSlug,
    } = payload
    const reqBody = {
      deliveryKey,
      groupSlug,
    }
    try {
      const data = await postBackendData(
        `/delivery/select?${userUrlParams(user)}store=${store}`,
        reqBody,
        payload
      )
      return transformCart(data, store, language, locale)
    } catch (error) {
      throw error
    }
  }
}
