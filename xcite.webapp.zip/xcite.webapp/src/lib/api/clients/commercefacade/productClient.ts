import { fetchBackendData } from './commerceFacadeClient'
import { fetchBackendDataWithoutCache } from './commerceFacadeClient'
import {
  CommercetoolsProductDetails,
  CommercetoolsProductProjection,
  CommercetoolsWarranty,
} from '../../../../types/raw/ctProduct'

export class ProductClient {
  public getProductWithVariants = async (
    slug: string,
    store: string
  ): Promise<CommercetoolsProductDetails> => {
    try {
      const result = await fetchBackendDataWithoutCache(
        `/variant-projections/slug=${slug}?store=${store}`
      )
      if (result) {
        return result
      } else {
        throw new Error(
          `product with slug "${slug}" not found in store "${store}"`
        )
      }
    } catch (e) {
      throw new Error(
        `product with slug "${slug}" not found in store "${store}"`
      )
    }
  }

  public getWarranty = async (
    sku: string,
    store: string
  ): Promise<CommercetoolsWarranty> => {
    return await fetchBackendData(`/v2/warranty?sku=${sku}&store=${store}`)
  }

  public queryProductProjections = async (
    skus: string[],
    store: string
  ): Promise<CommercetoolsProductProjection[]> => {
    const skusQueryParam = (skuArr: string[]) => {
      let queryParam = ''
      skuArr.forEach((sku) => {
        queryParam = queryParam + `&var.skus=${sku}`
      })
      return queryParam
    }

    const url = `/product-projections?store=${store}&staged=true&where=masterVariant(sku in :skus) or variants(sku in :skus)${skusQueryParam(
      skus
    )}`

    try {
      const data = await fetchBackendData(url)
      if (data?.results?.length > 0) {
        return data.results
      } else {
        throw new Error(`products with skus "${skus.join(', ')}" not found"`)
      }
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      throw new Error(error)
    }
  }
}
