import commerceToolsGetProductDetailsHandler, {
  commerceToolsGetProductDetailsNoResultHandler,
} from '../../../../mocks/handler/CommerceToolsGetProductDetailsHandler'
import { setupServer } from 'msw/node'
import commerceFacadeClient from './commerceFacadeClient'

const server = setupServer()

beforeAll(() => {
  server.listen({ onUnhandledRequest: 'error' })
})

afterEach(() => {
  server.resetHandlers()
})

afterAll(() => {
  server.close()
})

describe('getProductWithVariants', () => {
  it('should return product for slug (KW)', async () => {
    server.use(
      commerceToolsGetProductDetailsHandler(
        'slug=bose-home-speaker-300-with-amazon-alexa-built-in-silver',
        'kw'
      )
    )
    await expect(
      commerceFacadeClient.product.getProductWithVariants(
        'bose-home-speaker-300-with-amazon-alexa-built-in-silver',
        'kw'
      )
    ).resolves.toBeTruthy()
  })
  it('should return product for slug (KSA)', async () => {
    server.use(
      commerceToolsGetProductDetailsHandler(
        'slug=bose-home-speaker-300-with-amazon-alexa-built-in-silver',
        'ksa'
      )
    )
    await expect(
      commerceFacadeClient.product.getProductWithVariants(
        'bose-home-speaker-300-with-amazon-alexa-built-in-silver',
        'ksa'
      )
    ).resolves.toBeTruthy()
  })
  it('should return throw error for unknown slug', async () => {
    server.use(commerceToolsGetProductDetailsNoResultHandler)

    await expect(() =>
      commerceFacadeClient.product.getProductWithVariants('foo', 'kw')
    ).rejects.toThrow()
  })
})
