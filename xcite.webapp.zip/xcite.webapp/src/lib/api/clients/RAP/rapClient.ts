import { OrdersController } from './ordersController'

class RAPClient {
  public static orders = new OrdersController()
}

export default RAPClient
