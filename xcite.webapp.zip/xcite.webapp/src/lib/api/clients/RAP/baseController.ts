import axios from 'axios'
import environment from '../../../environment'

export class BaseController {
  client = axios.create({
    baseURL: environment.apiRAPBaseUrlPublic,
    headers: {
      apiKey: environment.apiRAPApiKey,
    },
  })
}

const baseClient = new BaseController()

export default baseClient
