import commerceToolsGetDeliveryMethodsHandler from '../../../mocks/handler/CommerceToolsGetDeliveryMethodsHandler'
import { DeliveryMethodType } from '../../../types/content'
import { getDeliveryMethods, getProductCategory } from './commerceFacadeClient'
import { setupServer } from 'msw/node'
import commerceToolsGetCategoryDetailsHandler, {
  commerceToolsGetCategoryDetailsNoResultHandler,
} from '../../../mocks/handler/CommerceToolsGetCategoryDetailsHandler'
import localesFactory from '../l18n/LocalesFactory'

const server = setupServer()

beforeAll(() => {
  server.listen({ onUnhandledRequest: 'error' })
})

afterEach(() => {
  server.resetHandlers()
})

afterAll(() => {
  server.close()
})

describe('getDeliveryMethods', () => {
  it('should return delivery methods for kw', async () => {
    const locale = localesFactory.createFromHrefLang('en-KW').current
    server.use(commerceToolsGetDeliveryMethodsHandler('52879', 'kw'))
    const expectedOutputKw: DeliveryMethodType[] = [
      {
        name: 'FreeDelivery',
        countryCode: 'kw',
        surcharge: null,
      },
      {
        name: '1-Hour-Express',
        countryCode: 'kw',
        surcharge: {
          currency: 'KWD',
          value: 4.5,
          valueUnmodified: 0,
          formattedPrice: '4.500 KD',
          formattedCredit: '4.500 KD',
          formattedPriceUnmodified: '',
        },
      },
      {
        name: '2-Hours-Express',
        countryCode: 'kw',
        surcharge: null,
      },
      {
        name: '3-Hours-Express',
        countryCode: 'kw',
        surcharge: {
          currency: 'KWD',
          value: 3,
          valueUnmodified: 0,
          formattedPrice: '3.000 KD',
          formattedCredit: '3.000 KD',
          formattedPriceUnmodified: '',
        },
      },
      {
        name: 'ClickAndCollect',
        countryCode: 'kw',
        surcharge: null,
      },
    ]
    await expect(
      getDeliveryMethods('52879', 'kw', 'en', locale)
    ).resolves.toStrictEqual(expectedOutputKw)
  })

  it('should return delivery methods for ksa', async () => {
    const locale = localesFactory.createFromHrefLang('en-SA').current
    server.use(commerceToolsGetDeliveryMethodsHandler('52879', 'ksa'))
    const expectedOutputKsa: DeliveryMethodType[] = [
      {
        name: 'FreeDelivery',
        countryCode: 'ksa',
        surcharge: null,
      },
      {
        name: '1-Hour-Express',
        countryCode: 'ksa',
        surcharge: {
          currency: 'SAR',
          value: 45,
          valueUnmodified: 0,
          formattedPrice: '45.00 SR',
          formattedCredit: '45.00 SR',
          formattedPriceUnmodified: '',
        },
      },
      {
        name: '2-Hours-Express',
        countryCode: 'ksa',
        surcharge: null,
      },
      {
        name: '3-Hours-Express',
        countryCode: 'ksa',
        surcharge: {
          currency: 'SAR',
          value: 30,
          valueUnmodified: 0,
          formattedPrice: '30.00 SR',
          formattedCredit: '30.00 SR',
          formattedPriceUnmodified: '',
        },
      },
      {
        name: 'ClickAndCollect',
        countryCode: 'ksa',
        surcharge: null,
      },
    ]
    await expect(
      getDeliveryMethods('52879', 'ksa', 'en', locale)
    ).resolves.toStrictEqual(expectedOutputKsa)
  })
})

describe('getCategory', () => {
  it('should return category for slug (KW)', async () => {
    server.use(
      commerceToolsGetCategoryDetailsHandler(
        'slug(en-kw="kw-computers-tablet")',
        'kw'
      )
    )
    await expect(
      getProductCategory('kw-computers-tablet', 'kw')
    ).resolves.toBeTruthy()
  })
  it('should return category for slug (KSA)', async () => {
    server.use(
      commerceToolsGetCategoryDetailsHandler(
        'slug(en-sa="ksa-computers-tablet")',
        'sa'
      )
    )
    await expect(
      getProductCategory('ksa-computers-tablet', 'sa')
    ).resolves.toBeTruthy()
  })
  it('should return throw error for unknown slug', async () => {
    server.use(commerceToolsGetCategoryDetailsNoResultHandler)
    await expect(() => getProductCategory('007', 'kw')).rejects.toThrow()
  })
})
