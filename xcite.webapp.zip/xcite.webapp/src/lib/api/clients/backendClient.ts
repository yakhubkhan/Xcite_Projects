import axios, { AxiosRequestConfig } from 'axios'
import { Auth } from 'aws-amplify'
import { UserProfileType } from '../../../types/content'
import {
  CommerceToolsOrderPayload,
  CommercetoolsUserStorePayload,
} from '../../../types/api'
import transformStockCheckResponse from '../processors/StockCheckProcessor'
import environment from '../../environment'

const axiosPublicClient = axios.create({
  baseURL: '/api',
})

const axiosInternalClient = axios.create({
  baseURL: environment.apiBackendBaseUrlPublic,
})

const getClient = (isInternalCall = false) => {
  return isInternalCall ? axiosInternalClient : axiosPublicClient
}

const setupConfig = async (
  request?: CommercetoolsUserStorePayload,
  isCallFromApi = false
) => {
  const config: AxiosRequestConfig = {}
  if (request?.token) {
    config.headers = { Authorization: `Bearer ${request?.token}` }

    return config
  }

  if (!isCallFromApi && request?.user.authenticated) {
    const session = await Auth.currentSession()
    const token = session.getIdToken().getJwtToken()
    config.headers = { Authorization: `Bearer ${token}` }
  }

  return config
}

const fetchBackendData = async (
  url: string,
  request?: CommercetoolsUserStorePayload,
  isInternalCall = false
) => {
  const config = await setupConfig(request, isInternalCall)
  try {
    const { data } = await getClient(isInternalCall).get(url, config)
    return data
  } catch (error) {
    throw error
  }
}

const postBackendData = async (
  url: string,
  reqBody,
  request: CommercetoolsUserStorePayload,
  isCallFromApi = false
) => {
  const config = await setupConfig(request)
  try {
    const { data } = await getClient(isCallFromApi).post(url, reqBody, config)
    return data
  } catch (error) {
    throw error
  }
}

const userUrlParams = (user: UserProfileType) =>
  user.authenticated ? `customerId=${user.id}` : `anonymousId=${user.id}`

export const ensureCartIsValid = async (
  payload: CommercetoolsUserStorePayload
): Promise<void> => {
  const { store, user } = payload
  let transformedStockCheck
  try {
    const data = await postBackendData(
      `/carts/stockcheck?${userUrlParams(user)}&store=${store}`,
      {},
      payload
    )
    transformedStockCheck = transformStockCheckResponse(data)
  } catch (error) {
    throw 'UNKNOWN_ERROR'
  }
  if (transformedStockCheck?.length) {
    throw transformedStockCheck
  }
}
