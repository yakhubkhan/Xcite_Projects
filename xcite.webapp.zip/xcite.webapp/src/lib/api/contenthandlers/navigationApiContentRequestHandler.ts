import { ContentNavigationPayload } from '../../../types/api'
import { NavigationItemType } from '../../../types/content'
import amplienceClient from '../clients/amplienceClient'

class NavigationApiContentRequestHandler {
  async handleRequest(
    payload: ContentNavigationPayload
  ): Promise<NavigationItemType[]> {
    return amplienceClient.getChannelNavigation(payload)
  }

  isValidRequest(req: ContentNavigationPayload): boolean {
    if (req.locale && req.channel) {
      return true
    }

    return false
  }
}

export const navigationApiContentRequestHandler =
  new NavigationApiContentRequestHandler()
