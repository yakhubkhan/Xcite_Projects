import { DefaultApiCommerceRequestHandler } from './defaultApiCommerceRequestHandler'
import { CommercetoolsPaginationPayload } from '../../../types/api'
import { OrderPagedResult } from '../../../types/content'
import commerceFacadeClient from '../clients/commercefacade/commerceFacadeClient'
import rapClient from '../clients/RAP/rapClient'
import { transformRAPOrderHistory } from '../processors/OrderProcessor'
import environment from '../../environment'
import localesFactory from '../l18n/LocalesFactory'

class OrderApiCommerceRequestHandler extends DefaultApiCommerceRequestHandler {
  async handleRequest(
    payload: CommercetoolsPaginationPayload
  ): Promise<OrderPagedResult> {
    const { customerNumber = '' } =
      await commerceFacadeClient.customers.getCurrentUser(payload)
    const customerId = customerNumber

    const locale = localesFactory.createFromHrefLang(
      payload.locale || environment.defaultLocale
    ).current
    const { salesOrg } = locale.country

    const orderHistory = await rapClient.orders.getOrderHistory({
      customerId,
      offset: payload.offset,
      recordCount: payload.limit,
      salesOrg,
    })

    const orders = await transformRAPOrderHistory(orderHistory, locale)
    return orders
  }
}

export const orderApiCommerceRequestHandler =
  new OrderApiCommerceRequestHandler()
