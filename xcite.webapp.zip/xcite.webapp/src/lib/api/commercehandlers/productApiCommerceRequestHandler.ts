import { DefaultApiCommerceRequestHandler } from './defaultApiCommerceRequestHandler'
import { CommercetoolsProductFromCartPayload } from '../../../types/api'
import { ProductCartInformationType } from '../../../types/content'
import commerceFacadeClient from '../clients/commercefacade/commerceFacadeClient'

class ProductApiCommerceRequestHandler extends DefaultApiCommerceRequestHandler {
  async handleRequest(
    payload: CommercetoolsProductFromCartPayload
  ): Promise<ProductCartInformationType> {
    return commerceFacadeClient.cart.getProductCartData(payload)
  }
}

export const productApiCommerceRequestHandler =
  new ProductApiCommerceRequestHandler()
