import { CommercetoolsUserStorePayload } from '../../../types/api'

export interface ApiCommerceRequestHandler {
  isValidRequest(req: CommercetoolsUserStorePayload): boolean
}

export class DefaultApiCommerceRequestHandler
  implements ApiCommerceRequestHandler
{
  isValidRequest(req: CommercetoolsUserStorePayload): boolean {
    if ((req.user.id || req.token) && req.store) {
      return true
    }

    return false
  }
}

export const defaultApiCommerceRequestHandler =
  new DefaultApiCommerceRequestHandler()
