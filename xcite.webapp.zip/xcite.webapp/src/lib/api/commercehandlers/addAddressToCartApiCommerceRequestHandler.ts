import { DefaultApiCommerceRequestHandler } from './defaultApiCommerceRequestHandler'
import {
  CommercetoolsSetAddressesPayload,
  CommercetoolsSetAddressPayload,
} from '../../../types/api'
import commerceFacadeClient from '../clients/commercefacade/commerceFacadeClient'
import { CartType } from '../../../types/content'

export class AddAddressToCartApiCommerceRequestHandler extends DefaultApiCommerceRequestHandler {
  async handleShippingAndBillingRequest(
    payload: CommercetoolsSetAddressesPayload
  ): Promise<CartType> {
    return commerceFacadeClient.cart.addShippingAndBillingAddressToCart(payload)
  }
  async handleShippingRequest(
    payload: CommercetoolsSetAddressPayload
  ): Promise<CartType> {
    return commerceFacadeClient.cart.addShippingAddressToCart(payload)
  }

  async handleBillingRequest(
    payload: CommercetoolsSetAddressPayload
  ): Promise<CartType> {
    return commerceFacadeClient.cart.addBillingAddressToCart(payload)
  }
}

export const addAddressToCartApiCommerceRequestHandler =
  new AddAddressToCartApiCommerceRequestHandler()
