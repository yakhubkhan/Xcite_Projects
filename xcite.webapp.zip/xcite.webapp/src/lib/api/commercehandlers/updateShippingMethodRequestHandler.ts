import { commercetoolsUpdateShippingMethodPayload } from '../../../types/api'
import { CartType } from '../../../types/content'
import commerceFacadeClient from '../clients/commercefacade/commerceFacadeClient'
import { DefaultApiCommerceRequestHandler } from './defaultApiCommerceRequestHandler'

class UpdateShippingMethodRequestHandler extends DefaultApiCommerceRequestHandler {
  async handleUpdateRequest(
    payload: commercetoolsUpdateShippingMethodPayload
  ): Promise<CartType> {
    return commerceFacadeClient.cart.updateShippingMethod(payload)
  }
}

export const updateShippingMethodRequestHandler =
  new UpdateShippingMethodRequestHandler()
