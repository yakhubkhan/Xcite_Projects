import { DefaultApiCommerceRequestHandler } from './defaultApiCommerceRequestHandler'
import { CommercetoolsUserStorePayload } from '../../../types/api'
import { CartType } from '../../../types/content'
import commerceFacadeClient from '../clients/commercefacade/commerceFacadeClient'

export class VerifyCartApiCommerceRequestHandler extends DefaultApiCommerceRequestHandler {
  async handleRequest(
    payload: CommercetoolsUserStorePayload
  ): Promise<CartType> {
    return commerceFacadeClient.cart.verifyCart(payload)
  }
}

export const verifyCartApiCommerceRequestHandler =
  new VerifyCartApiCommerceRequestHandler()
