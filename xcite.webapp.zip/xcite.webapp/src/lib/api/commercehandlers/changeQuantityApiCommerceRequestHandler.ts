import { DefaultApiCommerceRequestHandler } from './defaultApiCommerceRequestHandler'
import { CommerceToolsCartUpdateItemPayload } from '../../../types/api'
import { CartType } from '../../../types/content'
import commerceFacadeClient from '../clients/commercefacade/commerceFacadeClient'

class ChangeQuantityApiCommerceRequestHandler extends DefaultApiCommerceRequestHandler {
  isValidRequest(req: CommerceToolsCartUpdateItemPayload): boolean {
    if (!req.lineItemId) {
      return false
    }

    return super.isValidRequest(req)
  }

  async handleRequest(
    payload: CommerceToolsCartUpdateItemPayload
  ): Promise<CartType> {
    return commerceFacadeClient.cart.updateCartItemQuantity(payload)
  }
}

export const changeQuantityApiCommerceRequestHandler =
  new ChangeQuantityApiCommerceRequestHandler()
