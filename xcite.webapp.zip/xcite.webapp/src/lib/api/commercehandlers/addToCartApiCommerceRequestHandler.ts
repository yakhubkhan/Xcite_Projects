import { DefaultApiCommerceRequestHandler } from './defaultApiCommerceRequestHandler'
import { CommerceToolsCartAddItemPayload } from '../../../types/api'
import { CartType } from '../../../types/content'
import commerceFacadeClient from '../clients/commercefacade/commerceFacadeClient'

export class AddToCartApiCommerceRequestHandler extends DefaultApiCommerceRequestHandler {
  async handleRequest(
    payload: CommerceToolsCartAddItemPayload
  ): Promise<CartType> {
    return commerceFacadeClient.cart.addItemToCart(payload)
  }
}

export const addToCartApiCommerceRequestHandler =
  new AddToCartApiCommerceRequestHandler()
