import { DefaultApiCommerceRequestHandler } from './defaultApiCommerceRequestHandler'
import { CartType, PickupStoresType } from '../../../types/content'
import commerceFacadeClient from '../clients/commercefacade/commerceFacadeClient'
import {
  CommercetoolsCartUpdateItemPickupPayload,
  CommercetoolsLoadStoresPayload,
} from '../../../types/raw/ctInventory'
import { CommerceToolsUpdateLineItemPayload } from '../../../types/raw/ctCart'

class InventoryApiCommerceRequestHandler extends DefaultApiCommerceRequestHandler {
  async handleStoresRequest(
    payload: CommercetoolsLoadStoresPayload
  ): Promise<PickupStoresType> {
    return commerceFacadeClient.inventoryClient.loadStoresToPickup(payload)
  }

  async handleUpdateStoreForProductRequest(
    payload: CommercetoolsCartUpdateItemPickupPayload
  ): Promise<CartType> {
    return commerceFacadeClient.inventoryClient.updateStorePickup(payload)
  }

  async handleRemoveStoreForProductRequest(
    payload: CommerceToolsUpdateLineItemPayload
  ): Promise<CartType> {
    return commerceFacadeClient.inventoryClient.removeStorePickup(payload)
  }
}

export const inventoryApiCommerceRequestHandler =
  new InventoryApiCommerceRequestHandler()
