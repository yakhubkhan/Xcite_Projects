import { DefaultApiCommerceRequestHandler } from './defaultApiCommerceRequestHandler'
import { CartType, TimeSlotSelectionDialog } from '../../../types/content'
import commerceFacadeClient from '../clients/commercefacade/commerceFacadeClient'
import {
  CommercetoolsGetSlotPayload,
  CommercetoolsSoftReserveSlotPayload,
  CommercetoolsUserStorePayload,
} from '../../../types/api'
import { handleChooseTimeSlotRequest } from '../handlers/TimeSlotSelectionHandler'

class DeliveryApiCommerceRequestHandler extends DefaultApiCommerceRequestHandler {
  isValidGetSlotsRequest(req: CommercetoolsGetSlotPayload): boolean {
    if (!req.deliveryTeam) {
      return false
    }

    return super.isValidRequest(req)
  }
  async handleReserveSlotRequest(
    payload: CommercetoolsUserStorePayload
  ): Promise<CartType> {
    return commerceFacadeClient.delivery.reserveSlot(payload)
  }

  async handleGetAvailableSlotsRequest(
    ctPayload: CommercetoolsGetSlotPayload
  ): Promise<TimeSlotSelectionDialog> {
    return handleChooseTimeSlotRequest(ctPayload)
  }

  async handleSoftReserveSlotRequest(
    payload: CommercetoolsSoftReserveSlotPayload
  ): Promise<CartType> {
    return commerceFacadeClient.delivery.softReserveSlot(payload)
  }
}

export const deliveryApiCommerceRequestHandler =
  new DeliveryApiCommerceRequestHandler()
