import { DefaultApiCommerceRequestHandler } from './defaultApiCommerceRequestHandler'
import {
  CommerceToolsPaymentAddMethodPayload,
  CommercetoolsUserStorePayload,
} from '../../../types/api'
import { CartType, PaymentMethodType } from '../../../types/content'
import commerceFacadeClient from '../clients/commercefacade/commerceFacadeClient'

class PaymentApiCommerceRequestHandler extends DefaultApiCommerceRequestHandler {
  async handleGetPaymentsRequest(
    payload: CommercetoolsUserStorePayload
  ): Promise<PaymentMethodType[]> {
    return commerceFacadeClient.payment.getPaymentMethods(payload)
  }

  async handleAddPaymentsRequest(
    payload: CommerceToolsPaymentAddMethodPayload
  ): Promise<CartType> {
    return commerceFacadeClient.payment.addPaymentMethodToCart(payload)
  }
}

export const paymentApiCommerceRequestHandler =
  new PaymentApiCommerceRequestHandler()
