import { DefaultApiCommerceRequestHandler } from './defaultApiCommerceRequestHandler'
import { CartType } from '../../../types/content'
import commerceFacadeClient from '../clients/commercefacade/commerceFacadeClient'
import {
  CommercetoolsCartAddWarrantyActionPayload,
  CommercetoolsCartRemoveWarrantyActionPayload,
  CommercetoolsCartUpdateWarrantyActionPayload,
} from '../../../types/api'

class RemoveAndUpdateWarrantyApiCommerceRequestHandler extends DefaultApiCommerceRequestHandler {
  isValidAddRequest(req: CommercetoolsCartAddWarrantyActionPayload): boolean {
    if (!req.addWarrantyAction.lineItemId) {
      return false
    }

    return super.isValidRequest(req)
  }
  isValidUpdateRequest(
    req: CommercetoolsCartUpdateWarrantyActionPayload
  ): boolean {
    if (!req.warrantyLineItemId) {
      return false
    }

    return super.isValidRequest(req)
  }

  isValidRemoveRequest(
    req: CommercetoolsCartRemoveWarrantyActionPayload
  ): boolean {
    if (!req.warrantyLineItemId) {
      return false
    }

    return super.isValidRequest(req)
  }

  async handleRemoveWarrantyRequest(
    payload: CommercetoolsCartRemoveWarrantyActionPayload
  ): Promise<CartType> {
    return commerceFacadeClient.cart.removeWarrantyV2(payload)
  }

  async handleWarrantyAddRequest(
    payload: CommercetoolsCartAddWarrantyActionPayload
  ): Promise<CartType> {
    return commerceFacadeClient.cart.addWarrantyToCartV2(payload)
  }

  async handleWarrantyUpdateRequest(
    payload: CommercetoolsCartUpdateWarrantyActionPayload
  ): Promise<CartType> {
    return commerceFacadeClient.cart.updateWarrantyV2(payload)
  }
}

export const removeAndUpdateWarrantyApiCommerceRequestHandler =
  new RemoveAndUpdateWarrantyApiCommerceRequestHandler()
