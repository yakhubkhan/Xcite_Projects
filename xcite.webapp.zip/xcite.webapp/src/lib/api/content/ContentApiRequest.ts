import { Locale } from '../l18n/Locale'
import { enKW } from '../l18n/LocalesFactory'

export class ContentApiRequest {
  private readonly _pathname: string
  private readonly _locale: Locale
  private readonly _vse: string
  private readonly _previewContentId: string

  constructor(
    pathname: string,
    locale: Locale = enKW,
    vse = '',
    previewContentId = ''
  ) {
    this._pathname = pathname
    this._locale = locale
    this._vse = vse
    this._previewContentId = previewContentId
  }

  get locale(): Locale {
    return this._locale
  }

  get pathname(): string {
    return this._pathname
  }

  get vse(): string {
    return this._vse
  }

  get previewContentId(): string {
    return this._previewContentId
  }
}
