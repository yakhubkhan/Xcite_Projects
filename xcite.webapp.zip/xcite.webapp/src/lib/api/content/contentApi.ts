/**
 * entry point for direct calls from /pages/[[...slug]]
 * @param path
 */
import { ContentApiRequest } from './ContentApiRequest'
import defaultApiRequestHandler from '../handlers/DefaultApiRequestHandler'
import { ShopPageType } from '../../../types/content'
import localesFactory from '../l18n/LocalesFactory'
import searchPageHandler from '../handlers/SearchPageHandler'
import environment from '../../environment'
import ProductDetailPageHandler from '../handlers/ProductDetailPageHandler'
import ProductCategoryPageHandler from '../handlers/ProductCategoryPageHandler'

export const getContent = (
  pathname: string,
  locale = environment.defaultLocale
): Promise<ShopPageType> => {
  const contentApiRequest = new ContentApiRequest(
    pathname,
    localesFactory.createFromHrefLang(locale).current
  )
  const specialRequestHandlers = [
    new ProductDetailPageHandler(),
    new ProductCategoryPageHandler(),
    searchPageHandler,
  ]
  const handler =
    specialRequestHandlers.find((requestHandler) =>
      requestHandler.canHandleRequest(contentApiRequest)
    ) || defaultApiRequestHandler
  return handler.resolveRequest(contentApiRequest)
}
