import { ApiRequestHandler } from './ApiRequestHandler'
import {
  ComponentType,
  ShopBasePageType,
  ShopPageType,
} from '../../../types/content'
import amplienceClient from '../clients/amplienceClient'
import { ContentApiRequest } from '../content/ContentApiRequest'
import { ContentKeyMapType } from '../../../types/api'
import transformBanner from '../processors/BannerProcessor'
import { removeTrailingSlash } from '../../../util/apiUtils'
import {
  AmplienceBannerComponentType,
  AmplienceComponentType,
  AmplienceContentKeyMapType,
  AmplienceContentsCarouselComponentType,
  AmplienceHeroBannerComponentType,
  AmplienceImageTextBlocks,
  AmplienceMosaicComponentType,
  AmpliencePageType,
  AmplienceProductCarouselComponentType,
  AmplienceTextRow,
  AmplienceImageRow,
  AmplienceVideoBlock,
  AmplienceHTMLBlocks,
} from '../../../types/amplience'
import transformStaticData from '../processors/StaticDataProcessor'
import transformProductCarousel from '../processors/ProductCarouselProcessor'
import { ComponentTypeEnum } from '../../../types/content/component'
import transformHeroBanner from '../processors/HeroBannerProcessor'
import transformImageTextBlocks from '../processors/ImageTextBlocksProcessor'
import transformVideoBlock from '../processors/VideoBlocksProcessor'
import transformContentsCarousel from '../processors/ContentsCarouselProcessor'
import transformTextRow from '../processors/TextRowProcessor'
import transformImageRow from '../processors/ImageRowProcessor'
import transformMosaicComponent from '../processors/MosaicComponentProcessor'
import transformHTML from '../processors/HTMLProcessor'

export class DefaultApiRequestHandler implements ApiRequestHandler {
  getContentKeyMap(req: ContentApiRequest): Promise<ContentKeyMapType> {
    const contentKey = 'xc' + removeTrailingSlash(req.pathname)
    const store = req.locale.country.ctStore
    return Promise.resolve({
      headerData: [`xc/static/header/${store}`],
      contentData: [contentKey],
      footerData: [`xc/static/footer/${store}`],
      pageNotFoundContentLink: [`xc/404/link/${req.locale.country.id}`],
    })
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  canHandleRequest(req: ContentApiRequest): boolean {
    return true
  }

  async postProcessComponent(
    component: AmplienceComponentType,
    req: ContentApiRequest,
    rawContentMap: AmplienceContentKeyMapType
  ): Promise<ComponentType> {
    switch (component.type) {
      case ComponentTypeEnum.banner:
        return transformBanner(component as AmplienceBannerComponentType, req)
      case ComponentTypeEnum.productCarousel:
        return transformProductCarousel(
          component as AmplienceProductCarouselComponentType,
          req
        )
      case ComponentTypeEnum.heroBanner:
        return transformHeroBanner(
          component as AmplienceHeroBannerComponentType,
          req.locale
        )
      case ComponentTypeEnum.contentsCarousel:
        return transformContentsCarousel(
          component as AmplienceContentsCarouselComponentType,
          req.locale
        )
      case ComponentTypeEnum.contentBlockImage:
        return transformImageTextBlocks(
          component as AmplienceImageTextBlocks,
          req.locale
        )
      case ComponentTypeEnum.contentRowtext:
        return transformTextRow(component as AmplienceTextRow, req.locale)
      case ComponentTypeEnum.contentRowImage:
        return transformImageRow(component as AmplienceImageRow, req.locale)
      case ComponentTypeEnum.youtubeVideoBlock:
        return transformVideoBlock(component as AmplienceVideoBlock, req.locale)
      case ComponentTypeEnum.mosaicComponent:
        return transformMosaicComponent(
          component as AmplienceMosaicComponentType,
          req.locale
        )
      case ComponentTypeEnum.htmlComponent:
        return transformHTML(component as AmplienceHTMLBlocks, req.locale)
    }
    return component as ComponentType
  }

  async composePage(
    req: ContentApiRequest,
    rawContentMap: AmplienceContentKeyMapType
  ): Promise<ShopPageType> {
    const { contentData, headerData, footerData, pageNotFoundContentLink } =
      rawContentMap
    const processedComponents: ComponentType[] = contentData?.content
      ?.pageContent?.components
      ? await Promise.all(
          contentData.content.pageContent.components.map((component) =>
            this.postProcessComponent(component, req, rawContentMap)
          )
        )
      : this.populateEmptyContainer(contentData)

    const page: ShopBasePageType = {
      _meta: contentData?.content?._meta,
      content: {
        meta: {
          title: contentData?.content?.meta?.title || '404 - Page Not Found',
          hrefLang: req.locale.hreflang,
        },
        components: processedComponents,
        siteLayout: transformStaticData(
          headerData?.content,
          footerData?.content,
          req,
          contentData?.content?._meta
            ? undefined
            : pageNotFoundContentLink?.content
        ),
      },
    }
    return page
  }

  private populateEmptyContainer(contentData: { content: AmpliencePageType }) {
    return contentData?.content?.pageContent?.type
      ? [contentData.content.pageContent as ComponentType]
      : []
  }

  async resolveRequest(req: ContentApiRequest): Promise<ShopPageType> {
    const contentKeyMap = await this.getContentKeyMap(req)
    const rawContentMap = await amplienceClient.getContents(
      contentKeyMap,
      req.locale.hreflang,
      req.vse
    )
    return this.composePage(req, rawContentMap)
  }
}

const defaultApiRequestHandler = new DefaultApiRequestHandler()
export default defaultApiRequestHandler
