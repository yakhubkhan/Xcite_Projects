/* eslint-disable @typescript-eslint/no-var-requires */
import { ContentApiRequest } from '../content/ContentApiRequest'
import defaultApiRequestHandler from './DefaultApiRequestHandler'
import { enKW } from '../l18n/LocalesFactory'
import { AmplienceNamedLinks } from '../../../types/amplience'
import { ComponentTypeEnum } from '../../../types/content/component'

const amplienceClient = require('../clients/amplienceClient').default
const bannerProcessor = require('../processors/BannerProcessor')

const createSpies = (expectedContentKey: string) => {
  const amplienceClientSpy = jest
    .spyOn(amplienceClient, 'getContents')
    .mockImplementation(() => {
      const namedLinks: AmplienceNamedLinks = {
        cart: {
          _meta: {
            name: 'Checkout / Cart Page',
            schema: 'https://xcite.com/content/page.json',
            deliveryKey: 'xc/checkout/cart',
            deliveryId: '27608098-e6d5-4b8f-a182-7769fd9aee21',
          },
        },
        confirmation: {
          _meta: {
            name: 'Checkout / Confirmation Page',
            schema: 'https://xcite.com/content/page.json',
            deliveryKey: 'xc/checkout/confirmation',
            deliveryId: '219c2731-8c8d-4aa6-a2ce-7a3a45f69e98',
          },
        },
        delivery: {
          _meta: {
            name: 'Checkout / Delivery',
            schema: 'https://xcite.com/content/page.json',
            deliveryKey: 'xc/checkout/delivery',
            deliveryId: 'f03ac4fe-6754-4796-bbac-b11b2e5ff611',
          },
        },
        home: {
          _meta: {
            name: 'Homepage',
            schema: 'https://xcite.com/content/page.json',
            deliveryKey: 'xc',
            deliveryId: '0298de03-e808-4858-b4a7-be04a398ceba',
          },
        },
        profile: {
          _meta: {
            name: 'Profile Page',
            schema: 'https://xcite.com/content/page.json',
            deliveryKey: 'xc/profile',
            deliveryId: '4335bc94-aa2f-4286-9eaf-c6c1f67e6ad9',
          },
        },
        orderHistory: {
          _meta: {
            name: 'Xcite Page',
            schema: 'https://xcite.com/content/page.json',
            deliveryKey: 'xc/profile/order-history',
            deliveryId: '17f82588-f9fb-4e15-9a71-486cd28974ac',
          },
        },
        review: {
          _meta: {
            name: 'Xcite Page',
            schema: 'https://xcite.com/content/page.json',
            deliveryKey: 'xc/checkout/review-order',
            deliveryId: '4807604e-cda2-4cdc-995d-00a6d95c53d8',
          },
        },
        payment: {
          _meta: {
            name: 'Checkout/Payment',
            schema: 'https://xcite.com/content/page.json',
            deliveryKey: 'xc/checkout/payment',
            deliveryId: 'e63c9ce6-be2b-4222-9c32-f8add403cafa',
          },
        },
        search: {
          _meta: {
            name: 'Search Results Page',
            schema: 'https://xcite.com/content/page.json',
            deliveryKey: 'xc/search',
            deliveryId: 'bac46198-fbff-4d90-ad5d-019e33b7c845',
          },
        },
        shipping: {
          _meta: {
            name: 'Checkout/Shipping',
            schema: 'https://xcite.com/content/page.json',
            deliveryKey: 'xc/checkout/shipping',
            deliveryId: '2ed8f9cf-ba9b-4e33-84da-01b2f18edc05',
          },
        },
        summary: {
          _meta: {
            name: 'Checkout / Summary',
            schema: 'https://xcite.com/content/page.json',
            deliveryKey: 'xc/checkout/summary',
            deliveryId: '83137659-dbc4-4fa8-ad39-b223c57836ff',
          },
        },
        wishlist: {
          _meta: {
            name: 'Wishlist Page',
            schema: 'https://xcite.com/content/page.json',
            deliveryKey: 'xc/wishlist',
            deliveryId: 'f03ac4fe-6754-4796-bbac-b11b2e5ff611',
          },
        },
        login: {
          _meta: {
            name: 'Login Page',
            schema: 'https://xcite.com/content/page.json',
            deliveryKey: 'xc/login',
            deliveryId: 'f03ac4fe-6754-4796-bbac-b11b2e5ff611',
          },
        },
      }
      return {
        headerData: {
          content: {
            _meta: { deliveryKey: 'xc/static/header/kw' },
            namedLinks,
          },
        },
        contentData: {
          content: {
            _meta: { deliveryKey: expectedContentKey },
            meta: {},
            pageContent: { components: [{ type: 'twoColumnBanner' }] },
          },
        },
      }
    })

  const bannerProcessorSpy = jest
    .spyOn(bannerProcessor, 'default')
    .mockImplementation((component: any) => ({ ...component, processed: true }))

  return {
    amplienceClientSpy,
    bannerProcessorSpy,
  }
}

describe('should resolve pages correctly', () => {
  const path = '/'
  const expectedContentKey = 'xc'
  const { amplienceClientSpy } = createSpies(expectedContentKey)
  it(`should resolve ${path} to ${expectedContentKey}`, () => {
    const req = new ContentApiRequest('/', enKW)
    return defaultApiRequestHandler.resolveRequest(req).then((data) => {
      expect(data._meta.deliveryKey).toEqual(expectedContentKey)
      expect(data.content.components).toEqual([
        { type: ComponentTypeEnum.banner, processed: true },
      ])
      expect(amplienceClientSpy).toHaveBeenCalledWith(
        {
          contentData: [expectedContentKey],
          headerData: ['xc/static/header/kw'],
          footerData: ['xc/static/footer/kw'],
          pageNotFoundContentLink: ['xc/404/link/kw'],
        },
        'en-KW',
        ''
      )
    })
  })
})
