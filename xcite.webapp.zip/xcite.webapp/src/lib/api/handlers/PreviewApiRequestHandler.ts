import { ContentApiRequest } from '../content/ContentApiRequest'
import { ContentKeyMapType } from '../../../types/api'
import { DefaultApiRequestHandler } from './DefaultApiRequestHandler'
import amplienceClient from '../clients/amplienceClient'
import { ShopPageType } from '../../../types/content'
import {
  AmplienceContentKeyMapType,
  AmplienceContentType,
  AmpliencePageType,
} from '../../../types/amplience'

export default class PreviewApiRequestHandler extends DefaultApiRequestHandler {
  private previewContentData: AmplienceContentType | null = null
  private isSingleComponentPreview = false

  canHandleRequest(req: ContentApiRequest): boolean {
    return !!(req.previewContentId && req.vse)
  }

  async getContentKeyMap(req: ContentApiRequest): Promise<ContentKeyMapType> {
    this.previewContentData = await amplienceClient.getContentById(
      req.previewContentId,
      req.locale.hreflang,
      req.vse
    )
    const { schema, deliveryKey } = this.previewContentData?.content._meta
    if (schema === 'https://xcite.com/content/v1/page.json') {
      this.isSingleComponentPreview = false
      return Promise.resolve({
        headerData: ['xc/static/staticData'],
        contentData: [deliveryKey],
        footerData: this.getFooterDeliveryKey(req),
      })
    }
    if (schema === 'https://xcite.com/static/footer.json') {
      this.isSingleComponentPreview = false
      return Promise.resolve({
        headerData: ['xc/static/staticData'],
        contentData: [],
        footerData: [deliveryKey],
      })
    } else {
      this.isSingleComponentPreview = true
      return Promise.resolve({
        headerData: ['xc/static/staticData'],
        contentData: [],
        footerData: this.getFooterDeliveryKey(req),
      })
    }
  }

  private getFooterDeliveryKey(req: ContentApiRequest) {
    return [`xc/static/footer/${req.locale.country.ctStore}`]
  }

  async composePage(
    req: ContentApiRequest,
    rawContentMap: AmplienceContentKeyMapType
  ): Promise<ShopPageType> {
    if (this.isSingleComponentPreview) {
      const placeHolderPage: AmpliencePageType = {
        pageContent: { components: [this.previewContentData?.content] },
        _meta: this.previewContentData?.content._meta,
        meta: { title: 'Preview' },
      }
      rawContentMap.contentData = { content: placeHolderPage }
    }
    const page = await super.composePage(req, rawContentMap)
    page.previewContext = {
      isSingleComponentPreview: this.isSingleComponentPreview,
    }
    return Promise.resolve(page)
  }
}
