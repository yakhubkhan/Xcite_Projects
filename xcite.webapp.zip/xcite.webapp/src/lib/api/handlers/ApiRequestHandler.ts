import { ShopPageType } from '../../../types/content'
import { ContentApiRequest } from '../content/ContentApiRequest'

export interface ApiRequestHandler {
  canHandleRequest(req: ContentApiRequest): boolean

  resolveRequest(req: ContentApiRequest): Promise<ShopPageType>
}
