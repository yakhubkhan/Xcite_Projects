import { ServerResponse } from 'http'
import environment from './environment'

/**
 * Add cache headers for CMS content. Only if process.env.NODE_ENV === 'production'
 *
 * @param res
 */
export const addResponseHeaders = (res: ServerResponse): ServerResponse => {
  const isCachingEnabled = environment.httpEnableCacheHeadersPublic
  const sMaxAge = environment.httpCacheSMaxAgePublic * 60
  const staleWhileRevalidate = environment.httpStaleWhileRevalidatePublic * 60
  const staleIfError = environment.httpStaleIfErrorPublic * 60

  if (isCachingEnabled && res.statusCode < 300)
    res.setHeader(
      'Cache-Control',
      `public, s-maxage=${sMaxAge}, stale-while-revalidate=${staleWhileRevalidate}, stale-if-error=${staleIfError}`
    )
  return res
}
