module.exports = {
  i18n: {
    localeDetection: false,
    defaultLocale: process.env.NEXT_PUBLIC_DEFAULT_LOCALE || 'en-KW',
    locales: ['en-KW', 'ar-KW', 'en-SA', 'ar'], // ar = ar-SA
    domains: [
      {
        domain: process.env.NEXT_PUBLIC_API_HOST_KW,
        locales: ['ar-KW', 'en-KW'],
        defaultLocale: 'en-KW',
        http: process.env.NEXT_PUBLIC_LOCAL_DEV === 'true', // defaults to false
      },
      {
        domain: process.env.NEXT_PUBLIC_API_HOST_SA,
        locales: ['ar', 'en-SA'],
        defaultLocale: 'en-SA',
        http: process.env.NEXT_PUBLIC_LOCAL_DEV === 'true', // defaults to false
      },
    ],
  },
  ns: ['common'], // the namespaces needs to be listed here, to make sure they got preloaded
  serializeConfig: false,
}
