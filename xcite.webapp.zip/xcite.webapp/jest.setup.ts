import '@testing-library/jest-dom'

import { setConfig } from 'next/config'
import config from './next.config'
setConfig({ publicRuntimeConfig: config.publicRuntimeConfig })
