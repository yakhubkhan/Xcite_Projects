class CategoryPicker {
  _sdk
  _locale
  _appNode
  _currentValue
  _localeLabel
  _queryInput
  _search
  _suggestions
  _removeValueButton
  _categories = []

  constructor(sdk, locale) {
    this._sdk = sdk
    this._locale = locale
  }

  async init(appNode, fieldTitle) {
    this._initDom(appNode)
    await this._populateDom(fieldTitle)
  }

  _initDom(appNode) {
    // DOM node references
    this._appNode = appNode
    this._currentValueButton = this._appNode.querySelector(
      '.currentValueButton'
    )
    this._removeValueButton = this._appNode.querySelector('.removeValueButton')
    this._currentValue = this._currentValueButton.querySelector('span')
    this._localeLabel = this._appNode.querySelector('.locale')
    this._queryInput = this._appNode.querySelector('.query')
    this._search = this._appNode.querySelector('.search')
    this._suggestions = this._appNode.querySelector('.suggestions')

    // event handler
    this._currentValueButton.onclick = this._toggleSearch.bind(this)
    this._removeValueButton.onclick = this._removeValue.bind(this)
    this._queryInput.onkeydown = (e) => {
      if (e.key === 'ArrowDown') {
        if (this._suggestions.children.length) {
          this._suggestions.selectedIndex = 0
          e.preventDefault()
        }
        this._suggestions.focus()
      } else if (e.key === 'Escape') {
        this._hideSearch()
      }
    }
    this._queryInput.oninput = this._updateSuggestions.bind(this)
    this._suggestions.onkeydown = async (e) => {
      if (this._suggestions.value && e.key === 'Enter') {
        await this._setValue(this._suggestions.value)
      } else if (e.key === 'Escape') {
        this._suggestions.selectedIndex = 0
        this._suggestions.selectedIndex = -1
        this._queryInput.focus()
      }
    }
    this._suggestions.onclick = async () => {
      await this._setValue(this._suggestions.value)
    }
  }

  async _populateDom(fieldTitle) {
    this._localeLabel.textContent = fieldTitle + ' (' + this._locale + ')'
    await fetch(
      '/api/amplience/categories?locale=' + encodeURIComponent(this._locale)
    )
      .then((response) => response.json())
      .then((data) => {
        this._categories = data.results
        this._appNode.classList.remove('loading')
      })
    try {
      const fieldValue = await this._sdk.field.getValue()
      const valueItem = fieldValue.values.find((v) => v.locale === this._locale)
      this._handleValueUpdate(valueItem ? valueItem.value : undefined)
      this._sdk.frame.setHeight()
    } catch (e) {
      console.error(e)
    }
  }

  _handleValueUpdate(categoryKey) {
    if (!categoryKey) {
      this._appNode.classList.add('empty')
      this._currentValue.textContent = ''
      return
    }
    this._appNode.classList.remove('empty')
    const record = this._categories.find(
      (category) => category.key === categoryKey
    )
    if (record) {
      const { key } = record
      this._currentValue.textContent = `${key}`
    } else {
      this._currentValue.textContent = `invalid categoryKey: "${categoryKey}"`
    }
  }

  _toggleSearch() {
    if (this._search.style.display === 'none') {
      this._showSearch()
    } else {
      this._hideSearch()
    }
  }

  _hideSearch() {
    this._appNode.classList.remove('active')
    this._search.style.display = 'none'
    this._sdk.frame.setHeight()
  }

  _showSearch() {
    this._appNode.classList.add('active')
    this._search.style.display = 'block'
    this._queryInput.value = ''
    this._updateSuggestions()
    this._suggestions.selectedIndex = 0
    this._suggestions.selectedIndex = -1
    this._queryInput.focus()
    this._sdk.frame.setHeight()
  }

  _updateSuggestions() {
    this._suggestions.innerHTML = ''
    const query = this._queryInput.value
    this._categories
      .filter((category) => {
        return (
          query === '' ||
          `${category.name} ${category.key}`
            .toLowerCase()
            .indexOf(query.toLowerCase()) !== -1
        )
      })
      .sort((a, b) => {
        const aMatch = `${a.name} ${a.key}`.indexOf(query)
        const bMatch = `${b.name} ${b.key}`.indexOf(query)
        return aMatch === bMatch ? a.key.localeCompare(b.key) : aMatch - bMatch
      })
      .forEach((record) => {
        const child = document.createElement('option')
        child.textContent = `${record.key}`
        child.value = record.key
        this._suggestions.appendChild(child)
      })
  }

  async _setValue(categoryKey) {
    this._hideSearch()
    const currentFieldValue = await this._sdk.field.getValue()
    const values =
      currentFieldValue && Array.isArray(currentFieldValue.values)
        ? currentFieldValue.values
        : []
    const updatedValues = values.filter(
      (valueItem) => valueItem.locale !== this._locale
    )
    if (categoryKey) {
      updatedValues.push({
        locale: this._locale,
        value: categoryKey,
      })
    }
    const newFieldValue = updatedValues.length
      ? { values: updatedValues }
      : undefined
    await this._sdk.field.setValue(newFieldValue)
    this._handleValueUpdate(categoryKey)
  }

  async _removeValue() {
    await this._setValue()
  }
}
