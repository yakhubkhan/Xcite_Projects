class DummySdk {
  _value = {
    values: [
      {
        locale: 'en-KW',
        value: '9089e0dc-9ecf-405f-894e-ce5e5f392ecb',
      },
    ],
  }

  constructor() {
    this._debug = document.createElement('pre')
    this._debug.style.border = '1px solid #aaa'
    this._debug.style.background = '#ddd'
    this._debug.style.position = 'absolute'
    this._debug.style.left = '500px'
    this._debug.style.top = '20px'
    this._debug.style.padding = '.5em'
    document.body.appendChild(this._debug)
    this._updateValueDisplay()
  }

  get locales() {
    return {
      default: ['en-KW', 'ar-KW', 'en-SA', 'ar-SA'],
      available: [
        {
          locale: 'en-KW',
          language: 'en',
          country: 'KW',
          index: 0,
          selected: true,
        },
        {
          locale: 'ar-KW',
          language: 'ar',
          country: 'KW',
          index: 1,
          selected: true,
        },
        {
          locale: 'en-SA',
          language: 'en',
          country: 'SA',
          index: 2,
          selected: true,
        },
        {
          locale: 'ar-SA',
          language: 'ar',
          country: 'SA',
          index: 3,
          selected: false,
        },
      ],
    }
  }

  get frame() {
    return {
      setHeight: () => void 0,
    }
  }

  get field() {
    return {
      schema: {
        title: 'Category',
      },
      getValue: () => {
        return Promise.resolve(this._value)
      },
      setValue: (value) => {
        this._value = value
        this._updateValueDisplay()
        return Promise.resolve()
      },
    }
  }

  _updateValueDisplay() {
    this._debug.textContent = JSON.stringify(this._value, null, 2)
  }
}
