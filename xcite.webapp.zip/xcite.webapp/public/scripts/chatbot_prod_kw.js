;(function (d, w, c) {
  if (!d.getElementById('spd-busns-spt')) {
    var n = d.getElementsByTagName('script')[0],
      s = d.createElement('script')
    var loaded = false
    s.id = 'spd-busns-spt'
    s.async = 'async'
    s.setAttribute('data-self-init', 'false')
    s.setAttribute('data-init-type', 'opt')
    s.src = 'https://cdn.euc-freshbots.ai/assets/share/js/freshbots.min.js'
    s.setAttribute('data-client', 'dd6be83353a723a64068f515789eea715a0ef7ec')
    s.setAttribute('data-bot-hash', '8f489a6840b1ac0375239d30546e0035932e7e17')
    s.setAttribute('data-env', 'prod')
    s.setAttribute('data-region', 'euc')
    if (c) {
      s.onreadystatechange = s.onload = function () {
        if (!loaded) {
          c()
        }
        loaded = true
      }
    }
    n.parentNode.insertBefore(s, n)
  }
})(document, window, function () {
  Freshbots?.initiateWidget({
    autoInitChat: false,
    getClientParams: function () {
      return globalThis?.freshchatUserClientParams
    },
  })
})
